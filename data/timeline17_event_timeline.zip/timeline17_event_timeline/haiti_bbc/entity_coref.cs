:Entity_EDL_0000000	type	GeopoliticalEntity
:Entity_EDL_0000000	canonical_mention	"country"	haiti_bbc__1000-01-01__timeline:2736-2742	1.0
:Entity_EDL_0000000	nominal_mention	"country"	haiti_bbc__1000-01-01__timeline:2736-2742	1.0
:Entity_EDL_0000000	link	NIL000000001
:Entity_EDL_0000001	type	Person
:Entity_EDL_0000001	nominal_mention	"police"	haiti_bbc__1000-01-01__timeline:4499-4504	1.0
:Entity_EDL_0000001	link	NIL000000002
:Entity_EDL_0000002	type	GeopoliticalEntity
:Entity_EDL_0000002	canonical_mention	"Leogane"	haiti_bbc__1000-01-01__timeline:5359-5365	1.0
:Entity_EDL_0000002	mention	"Leogane"	haiti_bbc__1000-01-01__timeline:5359-5365	1.0
:Entity_EDL_0000002	link	3722286
:Entity_EDL_0000003	type	Person
:Entity_EDL_0000003	nominal_mention	"teams"	haiti_bbc__1000-01-01__timeline:298-302	1.0
:Entity_EDL_0000003	link	NIL000000003
:Entity_EDL_0000004	type	GeopoliticalEntity
:Entity_EDL_0000004	mention	"Port-au-Prince"	haiti_bbc__1000-01-01__timeline:8395-8408	1.0
:Entity_EDL_0000004	link	3718426
:Entity_EDL_0000005	type	Person
:Entity_EDL_0000005	nominal_mention	"people"	haiti_bbc__1000-01-01__timeline:3319-3324	1.0
:Entity_EDL_0000005	link	NIL000000004
:Entity_EDL_0000006	type	Facility
:Entity_EDL_0000006	nominal_mention	"headquarters"	haiti_bbc__1000-01-01__timeline:10703-10714	1.0
:Entity_EDL_0000006	link	NIL000000005
:Entity_EDL_0000007	type	Person
:Entity_EDL_0000007	nominal_mention	"bodies"	haiti_bbc__1000-01-01__timeline:9740-9745	1.0
:Entity_EDL_0000007	link	NIL000000006
:Entity_EDL_0000008	type	Person
:Entity_EDL_0000008	canonical_mention	"boy"	haiti_bbc__1000-01-01__timeline:1866-1868	1.0
:Entity_EDL_0000008	nominal_mention	"boy"	haiti_bbc__1000-01-01__timeline:1866-1868	1.0
:Entity_EDL_0000008	link	NIL000000007
:Entity_EDL_0000009	type	Person
:Entity_EDL_0000009	nominal_mention	"survivors"	haiti_bbc__1000-01-01__timeline:653-661	1.0
:Entity_EDL_0000009	link	NIL000000008
:Entity_EDL_0000010	type	GeopoliticalEntity
:Entity_EDL_0000010	canonical_mention	"it"	haiti_bbc__1000-01-01__timeline:2096-2097	1.0
:Entity_EDL_0000010	pronominal_mention	"it"	haiti_bbc__1000-01-01__timeline:2096-2097	1.0
:Entity_EDL_0000010	link	NIL000000009
:Entity_EDL_0000011	type	Person
:Entity_EDL_0000011	nominal_mention	"people"	haiti_bbc__1000-01-01__timeline:4782-4787	1.0
:Entity_EDL_0000011	link	NIL000000010
:Entity_EDL_0000012	type	GeopoliticalEntity
:Entity_EDL_0000012	mention	"US"	haiti_bbc__1000-01-01__timeline:2717-2718	1.0
:Entity_EDL_0000012	link	6252001
:Entity_EDL_0000013	type	Facility
:Entity_EDL_0000013	canonical_mention	"homes"	haiti_bbc__1000-01-01__timeline:5046-5050	1.0
:Entity_EDL_0000013	nominal_mention	"homes"	haiti_bbc__1000-01-01__timeline:5046-5050	1.0
:Entity_EDL_0000013	link	NIL000000011
:Entity_EDL_0000014	type	Person
:Entity_EDL_0000014	nominal_mention	"survivors"	haiti_bbc__1000-01-01__timeline:7517-7525	1.0
:Entity_EDL_0000014	link	NIL000000012
:Entity_EDL_0000015	type	Facility
:Entity_EDL_0000015	nominal_mention	"airport"	haiti_bbc__1000-01-01__timeline:4569-4575	1.0
:Entity_EDL_0000015	link	NIL000000013
:Entity_EDL_0000016	type	Facility
:Entity_EDL_0000016	canonical_mention	"prison"	haiti_bbc__1000-01-01__timeline:6643-6648	1.0
:Entity_EDL_0000016	nominal_mention	"prison"	haiti_bbc__1000-01-01__timeline:6643-6648	1.0
:Entity_EDL_0000016	link	NIL000000014
:Entity_EDL_0000017	type	Person
:Entity_EDL_0000017	canonical_mention	"casualties"	haiti_bbc__1000-01-01__timeline:9913-9922	1.0
:Entity_EDL_0000017	nominal_mention	"casualties"	haiti_bbc__1000-01-01__timeline:9913-9922	1.0
:Entity_EDL_0000017	link	NIL000000015
:Entity_EDL_0000018	type	Vehicle
:Entity_EDL_0000018	canonical_mention	"planes"	haiti_bbc__1000-01-01__timeline:8795-8800	1.0
:Entity_EDL_0000018	nominal_mention	"planes"	haiti_bbc__1000-01-01__timeline:8795-8800	1.0
:Entity_EDL_0000018	link	NIL000000016
:Entity_EDL_0000019	type	Facility
:Entity_EDL_0000019	canonical_mention	"headquarters"	haiti_bbc__1000-01-01__timeline:8379-8390	1.0
:Entity_EDL_0000019	nominal_mention	"headquarters"	haiti_bbc__1000-01-01__timeline:8379-8390	1.0
:Entity_EDL_0000019	link	NIL000000017
:Entity_EDL_0000020	type	Facility
:Entity_EDL_0000020	nominal_mention	"buildings"	haiti_bbc__1000-01-01__timeline:5488-5496	1.0
:Entity_EDL_0000020	link	NIL000000018
:Entity_EDL_0000021	type	Person
:Entity_EDL_0000021	nominal_mention	"troops"	haiti_bbc__1000-01-01__timeline:2933-2938	1.0
:Entity_EDL_0000021	link	NIL000000019
:Entity_EDL_0000022	type	GeopoliticalEntity
:Entity_EDL_0000022	mention	"Haiti"	haiti_bbc__1000-01-01__timeline:2148-2152	1.0
:Entity_EDL_0000022	link	3723988
:Entity_EDL_0000023	type	Weapon
:Entity_EDL_0000023	nominal_mention	"rounds"	haiti_bbc__1000-01-01__timeline:4518-4523	0.000
:Entity_EDL_0000023	link	NIL000000020
:Entity_EDL_0000024	type	Person
:Entity_EDL_0000024	canonical_mention	"politician"	haiti_bbc__1000-01-01__timeline:6163-6172	1.0
:Entity_EDL_0000024	nominal_mention	"politician"	haiti_bbc__1000-01-01__timeline:6163-6172	1.0
:Entity_EDL_0000024	link	NIL000000021
:Entity_EDL_0000025	type	Person
:Entity_EDL_0000025	canonical_mention	"looters"	haiti_bbc__1000-01-01__timeline:4461-4467	1.0
:Entity_EDL_0000025	nominal_mention	"looters"	haiti_bbc__1000-01-01__timeline:4461-4467	1.0
:Entity_EDL_0000025	link	NIL000000022
:Entity_EDL_0000026	type	Location
:Entity_EDL_0000026	nominal_mention	"parts"	haiti_bbc__1000-01-01__timeline:4472-4476	1.0
:Entity_EDL_0000026	link	NIL000000023
:Entity_EDL_0000027	type	Facility
:Entity_EDL_0000027	canonical_mention	"home"	haiti_bbc__1000-01-01__timeline:1910-1913	1.0
:Entity_EDL_0000027	nominal_mention	"home"	haiti_bbc__1000-01-01__timeline:1910-1913	1.0
:Entity_EDL_0000027	link	NIL000000024
:Entity_EDL_0000028	type	Location
:Entity_EDL_0000028	canonical_mention	"countryside"	haiti_bbc__1000-01-01__timeline:4859-4869	1.0
:Entity_EDL_0000028	nominal_mention	"countryside"	haiti_bbc__1000-01-01__timeline:4859-4869	1.0
:Entity_EDL_0000028	link	NIL000000025
:Entity_EDL_0000029	type	Facility
:Entity_EDL_0000029	canonical_mention	"buildings"	haiti_bbc__1000-01-01__timeline:1577-1585	1.0
:Entity_EDL_0000029	nominal_mention	"buildings"	haiti_bbc__1000-01-01__timeline:1577-1585	1.0
:Entity_EDL_0000029	link	NIL000000026
:Entity_EDL_0000030	type	Person
:Entity_EDL_0000030	nominal_mention	"people"	haiti_bbc__1000-01-01__timeline:10089-10094	1.0
:Entity_EDL_0000030	link	NIL000000027
:Entity_EDL_0000031	type	GeopoliticalEntity
:Entity_EDL_0000031	mention	"Port-au-Prince"	haiti_bbc__1000-01-01__timeline:10745-10758	1.0
:Entity_EDL_0000031	link	3718426
:Entity_EDL_0000032	type	Person
:Entity_EDL_0000032	canonical_mention	"him"	haiti_bbc__1000-01-01__timeline:364-366	1.0
:Entity_EDL_0000032	pronominal_mention	"him"	haiti_bbc__1000-01-01__timeline:364-366	1.0
:Entity_EDL_0000032	link	NIL000000028
:Entity_EDL_0000033	type	Organization
:Entity_EDL_0000033	nominal_mention	"Parliament"	haiti_bbc__1000-01-01__timeline:10343-10352	1.0
:Entity_EDL_0000033	link	NIL000000029
:Entity_EDL_0000034	type	GeopoliticalEntity
:Entity_EDL_0000034	mention	"Haiti"	haiti_bbc__1000-01-01__timeline:6187-6191	1.0
:Entity_EDL_0000034	link	3723988
:Entity_EDL_0000035	type	Person
:Entity_EDL_0000035	nominal_mention	"victims"	haiti_bbc__1000-01-01__timeline:2252-2258	1.0
:Entity_EDL_0000035	link	NIL000000030
:Entity_EDL_0000036	type	GeopoliticalEntity
:Entity_EDL_0000036	mention	"Port-au-Prince"	haiti_bbc__1000-01-01__timeline:7497-7510	1.0
:Entity_EDL_0000036	link	3718426
:Entity_EDL_0000037	type	GeopoliticalEntity
:Entity_EDL_0000037	canonical_mention	"villages"	haiti_bbc__1000-01-01__timeline:687-694	1.0
:Entity_EDL_0000037	nominal_mention	"villages"	haiti_bbc__1000-01-01__timeline:687-694	1.0
:Entity_EDL_0000037	link	NIL000000031
:Entity_EDL_0000038	type	Vehicle
:Entity_EDL_0000038	canonical_mention	"Black Hawk"	haiti_bbc__1000-01-01__timeline:2757-2766	1.0
:Entity_EDL_0000038	mention	"Black Hawk"	haiti_bbc__1000-01-01__timeline:2757-2766	1.0
:Entity_EDL_0000038	link	NIL000000032
:Entity_EDL_0000039	type	GeopoliticalEntity
:Entity_EDL_0000039	mention	"US"	haiti_bbc__1000-01-01__timeline:8788-8789	1.0
:Entity_EDL_0000039	link	6252001
:Entity_EDL_0000040	type	GeopoliticalEntity
:Entity_EDL_0000040	mention	"Haiti"	haiti_bbc__1000-01-01__timeline:2954-2958	1.0
:Entity_EDL_0000040	link	3723988
:Entity_EDL_0000041	type	Person
:Entity_EDL_0000041	canonical_mention	"gangs"	haiti_bbc__1000-01-01__timeline:6524-6528	1.0
:Entity_EDL_0000041	nominal_mention	"gangs"	haiti_bbc__1000-01-01__timeline:6524-6528	1.0
:Entity_EDL_0000041	link	NIL000000033
:Entity_EDL_0000042	type	Person
:Entity_EDL_0000042	nominal_mention	"Police"	haiti_bbc__1000-01-01__timeline:4430-4435	1.0
:Entity_EDL_0000042	link	NIL000000034
:Entity_EDL_0000043	type	Location
:Entity_EDL_0000043	canonical_mention	"hills"	haiti_bbc__1000-01-01__timeline:4986-4990	1.0
:Entity_EDL_0000043	nominal_mention	"hills"	haiti_bbc__1000-01-01__timeline:4986-4990	1.0
:Entity_EDL_0000043	link	NIL000000035
:Entity_EDL_0000044	type	COM
:Entity_EDL_0000044	canonical_mention	"equipment"	haiti_bbc__1000-01-01__timeline:9332-9340	1.0
:Entity_EDL_0000044	nominal_mention	"equipment"	haiti_bbc__1000-01-01__timeline:9332-9340	1.0
:Entity_EDL_0000044	link	NIL000000036
:Entity_EDL_0000045	type	GeopoliticalEntity
:Entity_EDL_0000045	mention	"Dominican Republic"	haiti_bbc__1000-01-01__timeline:2329-2346	1.0
:Entity_EDL_0000045	link	3508796
:Entity_EDL_0000046	type	Person
:Entity_EDL_0000046	nominal_mention	"people"	haiti_bbc__1000-01-01__timeline:4085-4090	1.0
:Entity_EDL_0000046	link	NIL000000037
:Entity_EDL_0000047	type	Person
:Entity_EDL_0000047	canonical_mention	"residents"	haiti_bbc__1000-01-01__timeline:6541-6549	1.0
:Entity_EDL_0000047	nominal_mention	"residents"	haiti_bbc__1000-01-01__timeline:6541-6549	1.0
:Entity_EDL_0000047	link	NIL000000038
:Entity_EDL_0000048	type	GeopoliticalEntity
:Entity_EDL_0000048	mention	"Leogane"	haiti_bbc__1000-01-01__timeline:5501-5507	1.0
:Entity_EDL_0000048	link	3722286
:Entity_EDL_0000049	type	Vehicle
:Entity_EDL_0000049	nominal_mention	"helicopters"	haiti_bbc__1000-01-01__timeline:2768-2778	1.0
:Entity_EDL_0000049	link	NIL000000039
:Entity_EDL_0000050	type	GeopoliticalEntity
:Entity_EDL_0000050	mention	"US"	haiti_bbc__1000-01-01__timeline:436-437	1.0
:Entity_EDL_0000050	link	6252001
:Entity_EDL_0000051	type	Person
:Entity_EDL_0000051	canonical_mention	"people"	haiti_bbc__1000-01-01__timeline:748-753	1.0
:Entity_EDL_0000051	nominal_mention	"people"	haiti_bbc__1000-01-01__timeline:748-753	1.0
:Entity_EDL_0000051	link	NIL000000040
:Entity_EDL_0000052	type	Facility
:Entity_EDL_0000052	nominal_mention	"airport"	haiti_bbc__1000-01-01__timeline:8816-8822	1.0
:Entity_EDL_0000052	link	NIL000000041
:Entity_EDL_0000053	type	GeopoliticalEntity
:Entity_EDL_0000053	nominal_mention	"capital"	haiti_bbc__1000-01-01__timeline:4806-4812	1.0
:Entity_EDL_0000053	link	NIL000000042
:Entity_EDL_0000054	type	Person
:Entity_EDL_0000054	canonical_mention	"Thousands"	haiti_bbc__1000-01-01__timeline:4769-4777	1.0
:Entity_EDL_0000054	nominal_mention	"Thousands"	haiti_bbc__1000-01-01__timeline:4769-4777	1.0
:Entity_EDL_0000054	link	NIL000000043
:Entity_EDL_0000055	type	Person
:Entity_EDL_0000055	canonical_mention	"troops"	haiti_bbc__1000-01-01__timeline:2798-2803	1.0
:Entity_EDL_0000055	nominal_mention	"troops"	haiti_bbc__1000-01-01__timeline:2798-2803	1.0
:Entity_EDL_0000055	link	NIL000000044
:Entity_EDL_0000056	type	Person
:Entity_EDL_0000056	nominal_mention	"people"	haiti_bbc__1000-01-01__timeline:10660-10665	1.0
:Entity_EDL_0000056	link	NIL000000045
:Entity_EDL_0000057	type	Facility
:Entity_EDL_0000057	nominal_mention	"building"	haiti_bbc__1000-01-01__timeline:5437-5444	1.0
:Entity_EDL_0000057	link	NIL000000046
:Entity_EDL_0000058	type	Person
:Entity_EDL_0000058	canonical_mention	"dead"	haiti_bbc__1000-01-01__timeline:7186-7189	1.0
:Entity_EDL_0000058	nominal_mention	"dead"	haiti_bbc__1000-01-01__timeline:7186-7189	1.0
:Entity_EDL_0000058	link	NIL000000047
:Entity_EDL_0000059	type	Person
:Entity_EDL_0000059	canonical_mention	"sailors"	haiti_bbc__1000-01-01__timeline:2125-2131	1.0
:Entity_EDL_0000059	nominal_mention	"sailors"	haiti_bbc__1000-01-01__timeline:2125-2131	1.0
:Entity_EDL_0000059	link	NIL000000048
:Entity_EDL_0000060	type	Person
:Entity_EDL_0000060	canonical_mention	"many"	haiti_bbc__1000-01-01__timeline:4838-4841	1.0
:Entity_EDL_0000060	pronominal_mention	"many"	haiti_bbc__1000-01-01__timeline:4838-4841	1.0
:Entity_EDL_0000060	link	NIL000000049
:Entity_EDL_0000061	type	Location
:Entity_EDL_0000061	canonical_mention	"grounds"	haiti_bbc__1000-01-01__timeline:2814-2820	1.0
:Entity_EDL_0000061	nominal_mention	"grounds"	haiti_bbc__1000-01-01__timeline:2814-2820	1.0
:Entity_EDL_0000061	link	NIL000000050
:Entity_EDL_0000062	type	Person
:Entity_EDL_0000062	canonical_mention	"police"	haiti_bbc__1000-01-01__timeline:2944-2949	1.0
:Entity_EDL_0000062	nominal_mention	"police"	haiti_bbc__1000-01-01__timeline:2944-2949	1.0
:Entity_EDL_0000062	link	NIL000000051
:Entity_EDL_0000063	type	GeopoliticalEntity
:Entity_EDL_0000063	mention	"US"	haiti_bbc__1000-01-01__timeline:2083-2084	1.0
:Entity_EDL_0000063	link	6252001
:Entity_EDL_0000064	type	GeopoliticalEntity
:Entity_EDL_0000064	canonical_mention	"settlements"	haiti_bbc__1000-01-01__timeline:782-792	1.0
:Entity_EDL_0000064	nominal_mention	"settlements"	haiti_bbc__1000-01-01__timeline:782-792	1.0
:Entity_EDL_0000064	link	NIL000000052
:Entity_EDL_0000065	type	Person
:Entity_EDL_0000065	canonical_mention	"uncle"	haiti_bbc__1000-01-01__timeline:1922-1926	1.0
:Entity_EDL_0000065	nominal_mention	"uncle"	haiti_bbc__1000-01-01__timeline:1922-1926	1.0
:Entity_EDL_0000065	link	NIL000000053
:Entity_EDL_0000066	type	Facility
:Entity_EDL_0000066	nominal_mention	"buildings"	haiti_bbc__1000-01-01__timeline:10732-10740	1.0
:Entity_EDL_0000066	link	NIL000000054
:Entity_EDL_0000067	type	Person
:Entity_EDL_0000067	canonical_mention	"crowd"	haiti_bbc__1000-01-01__timeline:4536-4540	1.0
:Entity_EDL_0000067	nominal_mention	"crowd"	haiti_bbc__1000-01-01__timeline:4536-4540	1.0
:Entity_EDL_0000067	link	NIL000000055
:Entity_EDL_0000068	type	Person
:Entity_EDL_0000068	canonical_mention	"marines"	haiti_bbc__1000-01-01__timeline:2137-2143	1.0
:Entity_EDL_0000068	nominal_mention	"marines"	haiti_bbc__1000-01-01__timeline:2137-2143	1.0
:Entity_EDL_0000068	link	NIL000000056
:Entity_EDL_0000069	type	Person
:Entity_EDL_0000069	canonical_mention	"Bill Clinton"	haiti_bbc__1000-01-01__timeline:4610-4621	1.0
:Entity_EDL_0000069	mention	"Bill Clinton"	haiti_bbc__1000-01-01__timeline:4610-4621	1.0
:Entity_EDL_0000069	link	NIL000000057
