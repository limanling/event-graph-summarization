:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"uprising"	egypt_guardian__1000-01-01__timeline:1593-1600	1.000
:Event_0000000	canonical_mention.actual	"uprising"	egypt_guardian__1000-01-01__timeline:1593-1600	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:1584-1588	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_ap__1000-01-01__timeline:4356-4363	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_ap__1000-01-01__timeline:4356-4363	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000175	egypt_ap__1000-01-01__timeline:4397-4406	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protest"	egypt_guardian__1000-01-01__timeline:4384-4390	1.000
:Event_0000000	canonical_mention.actual	"protest"	egypt_guardian__1000-01-01__timeline:4384-4390	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:4322-4326	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000132	egypt_guardian__1000-01-01__timeline:4356-4361	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000005	egypt_guardian__1000-01-01__timeline:4378-4382	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protest"	egypt_ap__1000-01-01__timeline:5096-5102	1.000
:Event_0000000	canonical_mention.actual	"protest"	egypt_ap__1000-01-01__timeline:5096-5102	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000194	egypt_ap__1000-01-01__timeline:5086-5094	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000096	egypt_ap__1000-01-01__timeline:5116-5143	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_ap__1000-01-01__timeline:6531-6538	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_ap__1000-01-01__timeline:6531-6538	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000064	egypt_ap__1000-01-01__timeline:6516-6524	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	egypt_ap__1000-01-01__timeline:6543-6555	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	egypt_ap__1000-01-01__timeline:10664-10673	1.000
:Event_0000000	canonical_mention.actual	"protesters"	egypt_ap__1000-01-01__timeline:10664-10673	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000076	egypt_ap__1000-01-01__timeline:10664-10673	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000006	egypt_ap__1000-01-01__timeline:10678-10682	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	egypt_ap__1000-01-01__timeline:6941-6950	1.000
:Event_0000000	canonical_mention.actual	"protesters"	egypt_ap__1000-01-01__timeline:6941-6950	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000170	egypt_ap__1000-01-01__timeline:6908-6916	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000122	egypt_ap__1000-01-01__timeline:6941-6950	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_guardian__1000-01-01__timeline:1223-1230	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_guardian__1000-01-01__timeline:1223-1230	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000117	egypt_guardian__1000-01-01__timeline:1196-1203	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	egypt_latimes__1000-01-01__timeline:1135-1144	1.000
:Event_0000000	canonical_mention.actual	"protesters"	egypt_latimes__1000-01-01__timeline:1135-1144	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000013	egypt_latimes__1000-01-01__timeline:1135-1144	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:1182-1186	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"demonstrations"	egypt_reuters__1000-01-01__timeline:395-408	1.000
:Event_0000000	canonical_mention.actual	"demonstrations"	egypt_reuters__1000-01-01__timeline:395-408	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"rally"	egypt_ap__1000-01-01__timeline:8715-8719	1.000
:Event_0000000	canonical_mention.actual	"rally"	egypt_ap__1000-01-01__timeline:8715-8719	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000004	egypt_ap__1000-01-01__timeline:8666-8670	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000187	egypt_ap__1000-01-01__timeline:8702-8708	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protest"	egypt_reuters__1000-01-01__timeline:1955-1961	1.000
:Event_0000000	canonical_mention.actual	"protest"	egypt_reuters__1000-01-01__timeline:1955-1961	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000088	egypt_reuters__1000-01-01__timeline:1945-1953	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	egypt_reuters__1000-01-01__timeline:1966-1978	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_guardian__1000-01-01__timeline:1562-1569	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_guardian__1000-01-01__timeline:1562-1569	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:1584-1588	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"demonstrations"	egypt_ap__1000-01-01__timeline:9290-9303	1.000
:Event_0000000	canonical_mention.actual	"demonstrations"	egypt_ap__1000-01-01__timeline:9290-9303	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"demonstrations"	egypt_ap__1000-01-01__timeline:8981-8994	1.000
:Event_0000000	canonical_mention.actual	"demonstrations"	egypt_ap__1000-01-01__timeline:8981-8994	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"rallies"	egypt_guardian__1000-01-01__timeline:5771-5777	1.000
:Event_0000000	canonical_mention.actual	"rallies"	egypt_guardian__1000-01-01__timeline:5771-5777	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000016	egypt_guardian__1000-01-01__timeline:5717-5725	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"rally"	egypt_ap__1000-01-01__timeline:1613-1617	1.000
:Event_0000000	canonical_mention.actual	"rally"	egypt_ap__1000-01-01__timeline:1613-1617	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000089	egypt_ap__1000-01-01__timeline:1685-1694	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protest"	egypt_guardian__1000-01-01__timeline:758-764	1.000
:Event_0000000	canonical_mention.actual	"protest"	egypt_guardian__1000-01-01__timeline:758-764	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000001	egypt_guardian__1000-01-01__timeline:732-738	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	egypt_reuters__1000-01-01__timeline:3754-3763	1.000
:Event_0000000	canonical_mention.actual	"protesters"	egypt_reuters__1000-01-01__timeline:3754-3763	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000177	egypt_reuters__1000-01-01__timeline:3754-3763	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	egypt_ap__1000-01-01__timeline:1595-1604	1.000
:Event_0000000	canonical_mention.actual	"protesters"	egypt_ap__1000-01-01__timeline:1595-1604	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000179	egypt_ap__1000-01-01__timeline:1595-1604	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	egypt_guardian__1000-01-01__timeline:2639-2648	1.000
:Event_0000000	canonical_mention.actual	"protesters"	egypt_guardian__1000-01-01__timeline:2639-2648	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000008	egypt_guardian__1000-01-01__timeline:2625-2637	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000044	egypt_guardian__1000-01-01__timeline:2639-2648	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	egypt_guardian__1000-01-01__timeline:2538-2547	1.000
:Event_0000000	canonical_mention.actual	"protesters"	egypt_guardian__1000-01-01__timeline:2538-2547	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000008	egypt_guardian__1000-01-01__timeline:2507-2519	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000181	egypt_guardian__1000-01-01__timeline:2538-2547	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	egypt_ap__1000-01-01__timeline:1685-1694	1.000
:Event_0000000	canonical_mention.actual	"protesters"	egypt_ap__1000-01-01__timeline:1685-1694	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000089	egypt_ap__1000-01-01__timeline:1685-1694	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_reuters__1000-01-01__timeline:2677-2684	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_reuters__1000-01-01__timeline:2677-2684	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	egypt_reuters__1000-01-01__timeline:2627-2639	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_ap__1000-01-01__timeline:4827-4834	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_ap__1000-01-01__timeline:4827-4834	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_ap__1000-01-01__timeline:6754-6761	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_ap__1000-01-01__timeline:6754-6761	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000163	egypt_ap__1000-01-01__timeline:6713-6721	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_ap__1000-01-01__timeline:370-377	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_ap__1000-01-01__timeline:370-377	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000205	egypt_ap__1000-01-01__timeline:337-346	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000006	egypt_ap__1000-01-01__timeline:387-391	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"take"	egypt_ap__1000-01-01__timeline:8851-8854	1.000
:Event_0000000	canonical_mention.actual	"take"	egypt_ap__1000-01-01__timeline:8851-8854	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000022	egypt_ap__1000-01-01__timeline:8829-8836	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000036	egypt_ap__1000-01-01__timeline:8863-8869	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_reuters__1000-01-01__timeline:2311-2318	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_reuters__1000-01-01__timeline:2311-2318	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	egypt_reuters__1000-01-01__timeline:2323-2335	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"march"	egypt_ap__1000-01-01__timeline:5305-5309	1.000
:Event_0000000	canonical_mention.actual	"march"	egypt_ap__1000-01-01__timeline:5305-5309	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000147	egypt_ap__1000-01-01__timeline:5294-5303	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000134	egypt_ap__1000-01-01__timeline:5331-5336	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"rioting"	egypt_guardian__1000-01-01__timeline:1121-1127	1.000
:Event_0000000	canonical_mention.actual	"rioting"	egypt_guardian__1000-01-01__timeline:1121-1127	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	egypt_guardian__1000-01-01__timeline:5282-5291	1.000
:Event_0000000	canonical_mention.actual	"protesters"	egypt_guardian__1000-01-01__timeline:5282-5291	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000061	egypt_guardian__1000-01-01__timeline:5282-5291	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_guardian__1000-01-01__timeline:4125-4132	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_guardian__1000-01-01__timeline:4125-4132	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:4100-4104	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protest"	egypt_ap__1000-01-01__timeline:1520-1526	1.000
:Event_0000000	canonical_mention.actual	"protest"	egypt_ap__1000-01-01__timeline:1520-1526	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000032	egypt_ap__1000-01-01__timeline:1531-1540	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000006	egypt_ap__1000-01-01__timeline:1545-1549	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protest"	egypt_guardian__1000-01-01__timeline:490-496	1.000
:Event_0000000	canonical_mention.actual	"protest"	egypt_guardian__1000-01-01__timeline:490-496	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000049	egypt_guardian__1000-01-01__timeline:480-488	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protest"	egypt_ap__1000-01-01__timeline:7617-7623	1.000
:Event_0000000	canonical_mention.actual	"protest"	egypt_ap__1000-01-01__timeline:7617-7623	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000124	egypt_ap__1000-01-01__timeline:7521-7523	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"rally"	egypt_ap__1000-01-01__timeline:5842-5846	1.000
:Event_0000000	canonical_mention.actual	"rally"	egypt_ap__1000-01-01__timeline:5842-5846	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000114	egypt_ap__1000-01-01__timeline:5819-5827	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000093	egypt_ap__1000-01-01__timeline:5855-5858	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"Protests"	egypt_guardian__1000-01-01__timeline:3883-3890	1.000
:Event_0000000	canonical_mention.actual	"Protests"	egypt_guardian__1000-01-01__timeline:3883-3890	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:3902-3906	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"uprising"	egypt_guardian__1000-01-01__timeline:1033-1040	1.000
:Event_0000000	canonical_mention.actual	"uprising"	egypt_guardian__1000-01-01__timeline:1033-1040	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000005	egypt_guardian__1000-01-01__timeline:1027-1031	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_reuters__1000-01-01__timeline:29-36	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_reuters__1000-01-01__timeline:29-36	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	egypt_reuters__1000-01-01__timeline:51-55	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_guardian__1000-01-01__timeline:4268-4275	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_guardian__1000-01-01__timeline:4268-4275	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_ap__1000-01-01__timeline:9202-9209	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_ap__1000-01-01__timeline:9202-9209	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000152	egypt_ap__1000-01-01__timeline:9172-9181	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	egypt_latimes__1000-01-01__timeline:8127-8134	1.000
:Event_0000000	canonical_mention.actual	"protests"	egypt_latimes__1000-01-01__timeline:8127-8134	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"elections"	egypt_ap__1000-01-01__timeline:7154-7162	1.000
:Event_0000001	canonical_mention.actual	"elections"	egypt_ap__1000-01-01__timeline:7154-7162	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"elections"	egypt_ap__1000-01-01__timeline:1881-1889	1.000
:Event_0000001	canonical_mention.actual	"elections"	egypt_ap__1000-01-01__timeline:1881-1889	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"election"	egypt_ap__1000-01-01__timeline:1922-1929	1.000
:Event_0000001	canonical_mention.actual	"election"	egypt_ap__1000-01-01__timeline:1922-1929	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"election"	egypt_latimes__1000-01-01__timeline:1719-1726	1.000
:Event_0000001	canonical_mention.actual	"election"	egypt_latimes__1000-01-01__timeline:1719-1726	1.000
:Event_0000001	Personnel.Elect_Place.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:1682-1686	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"elections"	egypt_latimes__1000-01-01__timeline:123-131	1.000
:Event_0000001	canonical_mention.actual	"elections"	egypt_latimes__1000-01-01__timeline:123-131	1.000
:Event_0000001	Personnel.Elect_Place.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:34-38	1.000
:Event_0000001	Personnel.Elect_Place.actual	:Entity_EDL_0000158	egypt_latimes__1000-01-01__timeline:146-151	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"elections"	egypt_ap__1000-01-01__timeline:7442-7450	1.000
:Event_0000001	canonical_mention.actual	"elections"	egypt_ap__1000-01-01__timeline:7442-7450	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"election"	egypt_latimes__1000-01-01__timeline:597-604	1.000
:Event_0000001	canonical_mention.actual	"election"	egypt_latimes__1000-01-01__timeline:597-604	1.000
:Event_0000001	Personnel.Elect_Place.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:543-547	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"election"	egypt_ap__1000-01-01__timeline:7229-7236	1.000
:Event_0000001	canonical_mention.actual	"election"	egypt_ap__1000-01-01__timeline:7229-7236	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"election"	egypt_reuters__1000-01-01__timeline:4358-4365	1.000
:Event_0000001	canonical_mention.actual	"election"	egypt_reuters__1000-01-01__timeline:4358-4365	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"elections"	egypt_ap__1000-01-01__timeline:9786-9794	1.000
:Event_0000001	canonical_mention.actual	"elections"	egypt_ap__1000-01-01__timeline:9786-9794	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"Election"	egypt_ap__1000-01-01__timeline:2584-2591	1.000
:Event_0000001	canonical_mention.actual	"Election"	egypt_ap__1000-01-01__timeline:2584-2591	1.000
:Event_0000001	Personnel.Elect_Elect.actual	:Entity_EDL_0000004	egypt_ap__1000-01-01__timeline:2611-2615	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"election"	egypt_reuters__1000-01-01__timeline:3533-3540	1.000
:Event_0000001	canonical_mention.actual	"election"	egypt_reuters__1000-01-01__timeline:3533-3540	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"election"	egypt_latimes__1000-01-01__timeline:1578-1585	1.000
:Event_0000001	canonical_mention.actual	"election"	egypt_latimes__1000-01-01__timeline:1578-1585	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"elections"	egypt_ap__1000-01-01__timeline:1219-1227	1.000
:Event_0000001	canonical_mention.actual	"elections"	egypt_ap__1000-01-01__timeline:1219-1227	1.000
:Event_0000001	Personnel.Elect_Elector.actual	:Entity_EDL_0000037	egypt_ap__1000-01-01__timeline:1023-1031	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"election"	egypt_reuters__1000-01-01__timeline:4498-4505	1.000
:Event_0000001	canonical_mention.actual	"election"	egypt_reuters__1000-01-01__timeline:4498-4505	1.000
:Event_0000001	Personnel.Elect_Elect.actual	:Entity_EDL_0000123	egypt_reuters__1000-01-01__timeline:4475-4480	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"election"	egypt_guardian__1000-01-01__timeline:4156-4163	1.000
:Event_0000001	canonical_mention.actual	"election"	egypt_guardian__1000-01-01__timeline:4156-4163	1.000
:Event_0000001	Personnel.Elect_Place.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:4100-4104	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"elected"	egypt_reuters__1000-01-01__timeline:2477-2483	1.000
:Event_0000001	canonical_mention.actual	"elected"	egypt_reuters__1000-01-01__timeline:2477-2483	1.000
:Event_0000001	Personnel.Elect_Elect.actual	:Entity_EDL_0000165	egypt_reuters__1000-01-01__timeline:2459-2467	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"vote"	egypt_ap__1000-01-01__timeline:2649-2652	1.000
:Event_0000001	canonical_mention.actual	"vote"	egypt_ap__1000-01-01__timeline:2649-2652	1.000
:Event_0000001	Personnel.Elect_Elect.actual	:Entity_EDL_0000004	egypt_ap__1000-01-01__timeline:2611-2615	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"elections"	egypt_guardian__1000-01-01__timeline:5584-5592	1.000
:Event_0000001	canonical_mention.actual	"elections"	egypt_guardian__1000-01-01__timeline:5584-5592	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"elected"	egypt_latimes__1000-01-01__timeline:3007-3013	1.000
:Event_0000001	canonical_mention.actual	"elected"	egypt_latimes__1000-01-01__timeline:3007-3013	1.000
:Event_0000001	Personnel.Elect_Elect.actual	:Entity_EDL_0000007	egypt_latimes__1000-01-01__timeline:2960-2972	1.000
:Event_0000001	Personnel.Elect_Elector.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:2986-2990	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"election"	egypt_ap__1000-01-01__timeline:7406-7413	1.000
:Event_0000001	canonical_mention.actual	"election"	egypt_ap__1000-01-01__timeline:7406-7413	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"elections"	egypt_ap__1000-01-01__timeline:1278-1286	1.000
:Event_0000001	canonical_mention.actual	"elections"	egypt_ap__1000-01-01__timeline:1278-1286	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"replaced"	egypt_ap__1000-01-01__timeline:10253-10260	1.000
:Event_0000002	canonical_mention.actual	"replaced"	egypt_ap__1000-01-01__timeline:10253-10260	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000004	egypt_ap__1000-01-01__timeline:10238-10242	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000012	egypt_ap__1000-01-01__timeline:10265-10276	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"step down"	egypt_ap__1000-01-01__timeline:8918-8926	1.000
:Event_0000002	canonical_mention.actual	"step down"	egypt_ap__1000-01-01__timeline:8918-8926	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000004	egypt_ap__1000-01-01__timeline:8909-8913	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"retirement"	egypt_ap__1000-01-01__timeline:3326-3335	1.000
:Event_0000002	canonical_mention.actual	"retirement"	egypt_ap__1000-01-01__timeline:3326-3335	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000107	egypt_ap__1000-01-01__timeline:3360-3369	1.000
:Event_0000002	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000035	egypt_ap__1000-01-01__timeline:3378-3385	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"ouster"	egypt_ap__1000-01-01__timeline:1908-1913	1.000
:Event_0000002	canonical_mention.actual	"ouster"	egypt_ap__1000-01-01__timeline:1908-1913	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000001	egypt_ap__1000-01-01__timeline:1897-1903	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"ouster"	egypt_ap__1000-01-01__timeline:11115-11120	1.000
:Event_0000002	canonical_mention.actual	"ouster"	egypt_ap__1000-01-01__timeline:11115-11120	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000173	egypt_ap__1000-01-01__timeline:11107-11111	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"resigns"	egypt_guardian__1000-01-01__timeline:1795-1801	1.000
:Event_0000002	canonical_mention.actual	"resigns"	egypt_guardian__1000-01-01__timeline:1795-1801	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	egypt_guardian__1000-01-01__timeline:1781-1793	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"deposed"	egypt_latimes__1000-01-01__timeline:3085-3091	1.000
:Event_0000002	canonical_mention.actual	"deposed"	egypt_latimes__1000-01-01__timeline:3085-3091	1.000
:Event_0000002	Personnel.EndPosition_Place.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:2986-2990	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	egypt_latimes__1000-01-01__timeline:3100-3112	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"deposed"	egypt_latimes__1000-01-01__timeline:247-253	1.000
:Event_0000002	canonical_mention.actual	"deposed"	egypt_latimes__1000-01-01__timeline:247-253	1.000
:Event_0000002	Personnel.EndPosition_Place.actual	:Entity_EDL_0000158	egypt_latimes__1000-01-01__timeline:146-151	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	egypt_latimes__1000-01-01__timeline:265-277	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"steps down"	egypt_reuters__1000-01-01__timeline:1181-1190	1.000
:Event_0000002	canonical_mention.actual	"steps down"	egypt_reuters__1000-01-01__timeline:1181-1190	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000001	egypt_reuters__1000-01-01__timeline:1173-1179	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"ousted"	egypt_ap__1000-01-01__timeline:10467-10472	1.000
:Event_0000002	canonical_mention.actual	"ousted"	egypt_ap__1000-01-01__timeline:10467-10472	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000164	egypt_ap__1000-01-01__timeline:10497-10510	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"ousted"	egypt_guardian__1000-01-01__timeline:5618-5623	1.000
:Event_0000002	canonical_mention.actual	"ousted"	egypt_guardian__1000-01-01__timeline:5618-5623	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	egypt_guardian__1000-01-01__timeline:5600-5612	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"steps down"	egypt_ap__1000-01-01__timeline:715-724	1.000
:Event_0000002	canonical_mention.actual	"steps down"	egypt_ap__1000-01-01__timeline:715-724	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000001	egypt_ap__1000-01-01__timeline:707-713	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"removal"	egypt_ap__1000-01-01__timeline:1718-1724	1.000
:Event_0000002	canonical_mention.actual	"removal"	egypt_ap__1000-01-01__timeline:1718-1724	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000068	egypt_ap__1000-01-01__timeline:1733-1740	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"step down"	egypt_latimes__1000-01-01__timeline:8369-8377	1.000
:Event_0000002	canonical_mention.actual	"step down"	egypt_latimes__1000-01-01__timeline:8369-8377	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000156	egypt_latimes__1000-01-01__timeline:8359-8367	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"resigns"	egypt_reuters__1000-01-01__timeline:1482-1488	1.000
:Event_0000002	canonical_mention.actual	"resigns"	egypt_reuters__1000-01-01__timeline:1482-1488	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000118	egypt_reuters__1000-01-01__timeline:1475-1480	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"deposed"	egypt_latimes__1000-01-01__timeline:1960-1966	1.000
:Event_0000002	canonical_mention.actual	"deposed"	egypt_latimes__1000-01-01__timeline:1960-1966	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	egypt_latimes__1000-01-01__timeline:1978-1990	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"removed"	egypt_latimes__1000-01-01__timeline:8593-8599	1.000
:Event_0000002	canonical_mention.actual	"removed"	egypt_latimes__1000-01-01__timeline:8593-8599	1.000
:Event_0000002	Personnel.EndPosition_Place.actual	:Entity_EDL_0000202	egypt_latimes__1000-01-01__timeline:8545-8551	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000196	egypt_latimes__1000-01-01__timeline:8601-8603	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"deposed"	egypt_latimes__1000-01-01__timeline:1519-1525	1.000
:Event_0000002	canonical_mention.actual	"deposed"	egypt_latimes__1000-01-01__timeline:1519-1525	1.000
:Event_0000002	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000195	egypt_latimes__1000-01-01__timeline:1468-1477	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"ouster"	egypt_latimes__1000-01-01__timeline:8787-8792	1.000
:Event_0000002	canonical_mention.actual	"ouster"	egypt_latimes__1000-01-01__timeline:8787-8792	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000001	egypt_latimes__1000-01-01__timeline:8763-8769	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"resigns"	egypt_ap__1000-01-01__timeline:9223-9229	1.000
:Event_0000002	canonical_mention.actual	"resigns"	egypt_ap__1000-01-01__timeline:9223-9229	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000004	egypt_ap__1000-01-01__timeline:9217-9221	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"step down"	egypt_ap__1000-01-01__timeline:9905-9913	1.000
:Event_0000002	canonical_mention.actual	"step down"	egypt_ap__1000-01-01__timeline:9905-9913	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"attack"	egypt_guardian__1000-01-01__timeline:2618-2623	1.000
:Event_0000003	canonical_mention.actual	"attack"	egypt_guardian__1000-01-01__timeline:2618-2623	1.000
:Event_0000003	Conflict.Attack_Attacker.actual	:Entity_EDL_0000015	egypt_guardian__1000-01-01__timeline:2609-2616	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000008	egypt_guardian__1000-01-01__timeline:2625-2637	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000044	egypt_guardian__1000-01-01__timeline:2639-2648	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"riot"	egypt_ap__1000-01-01__timeline:6874-6877	1.000
:Event_0000003	canonical_mention.actual	"riot"	egypt_ap__1000-01-01__timeline:6874-6877	1.000
:Event_0000003	Conflict.Attack_Attacker.actual	:Entity_EDL_0000201	egypt_ap__1000-01-01__timeline:6828-6832	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000057	egypt_ap__1000-01-01__timeline:6866-6872	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"attack"	egypt_ap__1000-01-01__timeline:8525-8530	1.000
:Event_0000003	canonical_mention.actual	"attack"	egypt_ap__1000-01-01__timeline:8525-8530	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"attack"	egypt_guardian__1000-01-01__timeline:5389-5394	1.000
:Event_0000003	canonical_mention.actual	"attack"	egypt_guardian__1000-01-01__timeline:5389-5394	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000077	egypt_guardian__1000-01-01__timeline:5381-5387	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"attacks"	egypt_guardian__1000-01-01__timeline:4820-4826	1.000
:Event_0000003	canonical_mention.actual	"attacks"	egypt_guardian__1000-01-01__timeline:4820-4826	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000168	egypt_guardian__1000-01-01__timeline:4801-4808	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000109	egypt_guardian__1000-01-01__timeline:4839-4844	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"attack"	egypt_ap__1000-01-01__timeline:1565-1570	1.000
:Event_0000003	canonical_mention.actual	"attack"	egypt_ap__1000-01-01__timeline:1565-1570	1.000
:Event_0000003	Conflict.Attack_Attacker.actual	:Entity_EDL_0000017	egypt_ap__1000-01-01__timeline:1505-1510	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000006	egypt_ap__1000-01-01__timeline:1545-1549	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000020	egypt_ap__1000-01-01__timeline:1558-1563	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"beats"	egypt_ap__1000-01-01__timeline:8418-8422	1.000
:Event_0000003	canonical_mention.actual	"beats"	egypt_ap__1000-01-01__timeline:8418-8422	1.000
:Event_0000003	Conflict.Attack_Attacker.actual	:Entity_EDL_0000176	egypt_ap__1000-01-01__timeline:8414-8416	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000095	egypt_ap__1000-01-01__timeline:8447-8453	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000083	egypt_ap__1000-01-01__timeline:8464-8467	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000162	egypt_ap__1000-01-01__timeline:8474-8480	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"attacks"	egypt_ap__1000-01-01__timeline:7525-7531	1.000
:Event_0000003	canonical_mention.actual	"attacks"	egypt_ap__1000-01-01__timeline:7525-7531	1.000
:Event_0000003	Conflict.Attack_Attacker.actual	:Entity_EDL_0000124	egypt_ap__1000-01-01__timeline:7521-7523	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000042	egypt_ap__1000-01-01__timeline:7542-7550	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"attack"	egypt_ap__1000-01-01__timeline:5451-5456	1.000
:Event_0000003	canonical_mention.actual	"attack"	egypt_ap__1000-01-01__timeline:5451-5456	1.000
:Event_0000003	Conflict.Attack_Attacker.actual	:Entity_EDL_0000029	egypt_ap__1000-01-01__timeline:5441-5449	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"down"	egypt_ap__1000-01-01__timeline:6895-6898	1.000
:Event_0000003	canonical_mention.actual	"down"	egypt_ap__1000-01-01__timeline:6895-6898	1.000
:Event_0000003	Conflict.Attack_Attacker.actual	:Entity_EDL_0000174	egypt_ap__1000-01-01__timeline:6882-6887	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000170	egypt_ap__1000-01-01__timeline:6908-6916	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000122	egypt_ap__1000-01-01__timeline:6941-6950	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"attack"	egypt_ap__1000-01-01__timeline:7883-7888	1.000
:Event_0000003	canonical_mention.actual	"attack"	egypt_ap__1000-01-01__timeline:7883-7888	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000085	egypt_ap__1000-01-01__timeline:7837-7844	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"deaths"	egypt_guardian__1000-01-01__timeline:6273-6278	1.000
:Event_0000004	canonical_mention.actual	"deaths"	egypt_guardian__1000-01-01__timeline:6273-6278	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000039	egypt_guardian__1000-01-01__timeline:6265-6271	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"dead"	egypt_guardian__1000-01-01__timeline:5966-5969	1.000
:Event_0000004	canonical_mention.actual	"dead"	egypt_guardian__1000-01-01__timeline:5966-5969	1.000
:Event_0000004	Life.Die_Place.actual	:Entity_EDL_0000005	egypt_guardian__1000-01-01__timeline:5934-5938	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000066	egypt_guardian__1000-01-01__timeline:5963-5964	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"killing"	egypt_reuters__1000-01-01__timeline:3743-3749	1.000
:Event_0000004	canonical_mention.actual	"killing"	egypt_reuters__1000-01-01__timeline:3743-3749	1.000
:Event_0000004	Life.Die_Agent.actual	:Entity_EDL_0000001	egypt_reuters__1000-01-01__timeline:3684-3690	1.000
:Event_0000004	Life.Die_Agent.actual	:Entity_EDL_0000151	egypt_reuters__1000-01-01__timeline:3727-3729	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000177	egypt_reuters__1000-01-01__timeline:3754-3763	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"deaths"	egypt_latimes__1000-01-01__timeline:1113-1118	1.000
:Event_0000004	canonical_mention.actual	"deaths"	egypt_latimes__1000-01-01__timeline:1113-1118	1.000
:Event_0000004	Life.Die_Agent.actual	:Entity_EDL_0000002	egypt_latimes__1000-01-01__timeline:1077-1089	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000013	egypt_latimes__1000-01-01__timeline:1135-1144	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"dead"	egypt_guardian__1000-01-01__timeline:23-26	1.000
:Event_0000004	canonical_mention.actual	"dead"	egypt_guardian__1000-01-01__timeline:23-26	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000127	egypt_guardian__1000-01-01__timeline:20-21	1.000
:Event_0000004	Life.Die_Instrument.actual	:Entity_EDL_0000160	egypt_guardian__1000-01-01__timeline:59-62	1.000
:Event_0000004	Life.Die_Place.actual	:Entity_EDL_0000126	egypt_guardian__1000-01-01__timeline:88-93	1.000
:Event_0000005	type	Business.End
:Event_0000005	mention.actual	"dissolution"	egypt_ap__1000-01-01__timeline:2934-2944	1.000
:Event_0000005	canonical_mention.actual	"dissolution"	egypt_ap__1000-01-01__timeline:2934-2944	1.000
:Event_0000005	Business.End_Organization.actual	:Entity_EDL_0000078	egypt_ap__1000-01-01__timeline:2949-2958	1.000
:Event_0000005	type	Business.End
:Event_0000005	mention.actual	"dissolving"	egypt_ap__1000-01-01__timeline:4175-4184	1.000
:Event_0000005	canonical_mention.actual	"dissolving"	egypt_ap__1000-01-01__timeline:4175-4184	1.000
:Event_0000005	Business.End_Organization.actual	:Entity_EDL_0000197	egypt_ap__1000-01-01__timeline:4202-4209	1.000
:Event_0000005	type	Business.End
:Event_0000005	mention.actual	"dissolving"	egypt_ap__1000-01-01__timeline:2365-2374	1.000
:Event_0000005	canonical_mention.actual	"dissolving"	egypt_ap__1000-01-01__timeline:2365-2374	1.000
:Event_0000005	Business.End_Organization.actual	:Entity_EDL_0000030	egypt_ap__1000-01-01__timeline:2408-2412	1.000
:Event_0000005	type	Business.End
:Event_0000005	mention.actual	"disbanding"	egypt_ap__1000-01-01__timeline:3088-3097	1.000
:Event_0000005	canonical_mention.actual	"disbanding"	egypt_ap__1000-01-01__timeline:3088-3097	1.000
:Event_0000005	Business.End_Organization.actual	:Entity_EDL_0000185	egypt_ap__1000-01-01__timeline:3036-3045	1.000
:Event_0000005	Business.End_Organization.actual	:Entity_EDL_0000045	egypt_ap__1000-01-01__timeline:3099-3100	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"killing"	egypt_ap__1000-01-01__timeline:6920-6926	1.000
:Event_0000006	canonical_mention.actual	"killing"	egypt_ap__1000-01-01__timeline:6920-6926	1.000
:Event_0000006	Life.Die_Agent.actual	:Entity_EDL_0000174	egypt_ap__1000-01-01__timeline:6882-6887	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000170	egypt_ap__1000-01-01__timeline:6908-6916	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000122	egypt_ap__1000-01-01__timeline:6941-6950	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"killing"	egypt_ap__1000-01-01__timeline:10717-10723	1.000
:Event_0000006	canonical_mention.actual	"killing"	egypt_ap__1000-01-01__timeline:10717-10723	1.000
:Event_0000006	Life.Die_Agent.actual	:Entity_EDL_0000200	egypt_ap__1000-01-01__timeline:10626-10633	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000006	egypt_ap__1000-01-01__timeline:10678-10682	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000136	egypt_ap__1000-01-01__timeline:10738-10743	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"killing"	egypt_ap__1000-01-01__timeline:1574-1580	1.000
:Event_0000006	canonical_mention.actual	"killing"	egypt_ap__1000-01-01__timeline:1574-1580	1.000
:Event_0000006	Life.Die_Agent.actual	:Entity_EDL_0000017	egypt_ap__1000-01-01__timeline:1505-1510	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000179	egypt_ap__1000-01-01__timeline:1595-1604	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"dead"	egypt_ap__1000-01-01__timeline:5555-5558	1.000
:Event_0000006	canonical_mention.actual	"dead"	egypt_ap__1000-01-01__timeline:5555-5558	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000167	egypt_ap__1000-01-01__timeline:5552-5553	1.000
:Event_0000007	type	Business.End
:Event_0000007	mention.actual	"disbanded"	egypt_latimes__1000-01-01__timeline:3617-3625	1.000
:Event_0000007	canonical_mention.actual	"disbanded"	egypt_latimes__1000-01-01__timeline:3617-3625	1.000
:Event_0000007	Business.End_Organization.actual	:Entity_EDL_0000099	egypt_latimes__1000-01-01__timeline:3631-3637	1.000
:Event_0000007	type	Business.End
:Event_0000007	mention.actual	"dissolved"	egypt_latimes__1000-01-01__timeline:3483-3491	1.000
:Event_0000007	canonical_mention.actual	"dissolved"	egypt_latimes__1000-01-01__timeline:3483-3491	1.000
:Event_0000007	Business.End_Organization.actual	:Entity_EDL_0000112	egypt_latimes__1000-01-01__timeline:3493-3502	1.000
:Event_0000007	type	Business.End
:Event_0000007	mention.actual	"dissolve"	egypt_reuters__1000-01-01__timeline:4291-4298	1.000
:Event_0000007	canonical_mention.actual	"dissolve"	egypt_reuters__1000-01-01__timeline:4291-4298	1.000
:Event_0000007	Business.End_Organization.actual	:Entity_EDL_0000024	egypt_reuters__1000-01-01__timeline:4300-4309	1.000
:Event_0000007	type	Business.End
:Event_0000007	mention.actual	"disband"	egypt_latimes__1000-01-01__timeline:4699-4705	1.000
:Event_0000007	canonical_mention.actual	"disband"	egypt_latimes__1000-01-01__timeline:4699-4705	1.000
:Event_0000007	Business.End_Place.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:4495-4499	1.000
:Event_0000007	Business.End_Organization.actual	:Entity_EDL_0000188	egypt_latimes__1000-01-01__timeline:4711-4717	1.000
:Event_0000008	type	Conflict.Attack
:Event_0000008	mention.actual	"clashes"	egypt_ap__1000-01-01__timeline:9056-9062	1.000
:Event_0000008	canonical_mention.actual	"clashes"	egypt_ap__1000-01-01__timeline:9056-9062	1.000
:Event_0000008	Conflict.Attack_Target.actual	:Entity_EDL_0000059	egypt_ap__1000-01-01__timeline:9031-9036	1.000
:Event_0000008	Conflict.Attack_Attacker.actual	:Entity_EDL_0000033	egypt_ap__1000-01-01__timeline:9040-9043	1.000
:Event_0000008	Conflict.Attack_Place.actual	:Entity_EDL_0000146	egypt_ap__1000-01-01__timeline:9104-9115	1.000
:Event_0000008	type	Conflict.Attack
:Event_0000008	mention.actual	"violence"	egypt_ap__1000-01-01__timeline:7672-7679	1.000
:Event_0000008	canonical_mention.actual	"violence"	egypt_ap__1000-01-01__timeline:7672-7679	1.000
:Event_0000008	Conflict.Attack_Place.actual	:Entity_EDL_0000087	egypt_ap__1000-01-01__timeline:7681-7687	1.000
:Event_0000008	Conflict.Attack_Place.actual	:Entity_EDL_0000006	egypt_ap__1000-01-01__timeline:7692-7696	1.000
:Event_0000008	type	Conflict.Attack
:Event_0000008	mention.actual	"clashes"	egypt_ap__1000-01-01__timeline:7740-7746	1.000
:Event_0000008	canonical_mention.actual	"clashes"	egypt_ap__1000-01-01__timeline:7740-7746	1.000
:Event_0000008	Conflict.Attack_Target.actual	:Entity_EDL_0000145	egypt_ap__1000-01-01__timeline:7720-7725	1.000
:Event_0000008	Conflict.Attack_Place.actual	:Entity_EDL_0000034	egypt_ap__1000-01-01__timeline:7755-7763	1.000
:Event_0000009	type	Conflict.Attack
:Event_0000009	mention.actual	"clashes"	egypt_guardian__1000-01-01__timeline:3711-3717	1.000
:Event_0000009	canonical_mention.actual	"clashes"	egypt_guardian__1000-01-01__timeline:3711-3717	1.000
:Event_0000009	Conflict.Attack_Place.actual	:Entity_EDL_0000005	egypt_guardian__1000-01-01__timeline:3698-3702	1.000
:Event_0000009	Conflict.Attack_Place.actual	:Entity_EDL_0000148	egypt_guardian__1000-01-01__timeline:3704-3709	1.000
:Event_0000009	type	Conflict.Attack
:Event_0000009	mention.actual	"clashes"	egypt_guardian__1000-01-01__timeline:3800-3806	1.000
:Event_0000009	canonical_mention.actual	"clashes"	egypt_guardian__1000-01-01__timeline:3800-3806	1.000
:Event_0000009	Conflict.Attack_Attacker.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:3794-3798	1.000
:Event_0000009	type	Conflict.Attack
:Event_0000009	mention.actual	"clashes"	egypt_guardian__1000-01-01__timeline:5940-5946	1.000
:Event_0000009	canonical_mention.actual	"clashes"	egypt_guardian__1000-01-01__timeline:5940-5946	1.000
:Event_0000009	Conflict.Attack_Place.actual	:Entity_EDL_0000005	egypt_guardian__1000-01-01__timeline:5934-5938	1.000
:Event_0000010	type	Life.Die
:Event_0000010	mention.actual	"dead"	egypt_latimes__1000-01-01__timeline:2007-2010	1.000
:Event_0000010	canonical_mention.actual	"dead"	egypt_latimes__1000-01-01__timeline:2007-2010	1.000
:Event_0000010	Life.Die_Victim.actual	:Entity_EDL_0000002	egypt_latimes__1000-01-01__timeline:1978-1990	1.000
:Event_0000010	type	Life.Die
:Event_0000010	mention.actual	"death"	egypt_latimes__1000-01-01__timeline:2590-2594	1.000
:Event_0000010	canonical_mention.actual	"death"	egypt_latimes__1000-01-01__timeline:2590-2594	1.000
:Event_0000010	Life.Die_Victim.actual	:Entity_EDL_0000047	egypt_latimes__1000-01-01__timeline:2579-2581	1.000
:Event_0000010	type	Life.Die
:Event_0000010	mention.actual	"dead"	egypt_latimes__1000-01-01__timeline:2307-2310	1.000
:Event_0000010	canonical_mention.actual	"dead"	egypt_latimes__1000-01-01__timeline:2307-2310	1.000
:Event_0000010	Life.Die_Victim.actual	:Entity_EDL_0000190	egypt_latimes__1000-01-01__timeline:2273-2279	1.000
:Event_0000011	type	Transaction.TransferMoney
:Event_0000011	mention.actual	"releases"	egypt_latimes__1000-01-01__timeline:5916-5923	1.000
:Event_0000011	canonical_mention.actual	"releases"	egypt_latimes__1000-01-01__timeline:5916-5923	1.000
:Event_0000011	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000153	egypt_latimes__1000-01-01__timeline:5905-5914	1.000
:Event_0000011	Transaction.TransferMoney_Beneficiary.actual	:Entity_EDL_0000021	egypt_latimes__1000-01-01__timeline:5957-5966	1.000
:Event_0000011	type	Transaction.TransferMoney
:Event_0000011	mention.actual	"loan"	egypt_latimes__1000-01-01__timeline:6314-6317	1.000
:Event_0000011	canonical_mention.actual	"loan"	egypt_latimes__1000-01-01__timeline:6314-6317	1.000
:Event_0000011	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:6250-6254	1.000
:Event_0000011	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000113	egypt_latimes__1000-01-01__timeline:6336-6362	1.000
:Event_0000011	type	Transaction.TransferMoney
:Event_0000011	mention.actual	"aid"	egypt_latimes__1000-01-01__timeline:5942-5944	1.000
:Event_0000011	canonical_mention.actual	"aid"	egypt_latimes__1000-01-01__timeline:5942-5944	1.000
:Event_0000011	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000153	egypt_latimes__1000-01-01__timeline:5905-5914	1.000
:Event_0000011	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000021	egypt_latimes__1000-01-01__timeline:5957-5966	1.000
:Event_0000012	type	Personnel.StartPosition
:Event_0000012	mention.actual	"named"	egypt_ap__1000-01-01__timeline:10839-10843	1.000
:Event_0000012	canonical_mention.actual	"named"	egypt_ap__1000-01-01__timeline:10839-10843	1.000
:Event_0000012	Personnel.StartPosition_Person.actual	:Entity_EDL_0000090	egypt_ap__1000-01-01__timeline:10845-10853	1.000
:Event_0000012	type	Personnel.StartPosition
:Event_0000012	mention.actual	"installing"	egypt_ap__1000-01-01__timeline:11127-11136	1.000
:Event_0000012	canonical_mention.actual	"installing"	egypt_ap__1000-01-01__timeline:11127-11136	1.000
:Event_0000012	Personnel.StartPosition_Person.actual	:Entity_EDL_0000110	egypt_ap__1000-01-01__timeline:11150-11157	1.000
:Event_0000013	type	Life.Injure
:Event_0000013	mention.actual	"injured"	egypt_guardian__1000-01-01__timeline:4363-4369	1.000
:Event_0000013	canonical_mention.actual	"injured"	egypt_guardian__1000-01-01__timeline:4363-4369	1.000
:Event_0000013	Life.Injure_Place.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:4322-4326	1.000
:Event_0000013	Life.Injure_Victim.actual	:Entity_EDL_0000132	egypt_guardian__1000-01-01__timeline:4356-4361	1.000
:Event_0000013	Life.Injure_Place.actual	:Entity_EDL_0000005	egypt_guardian__1000-01-01__timeline:4378-4382	1.000
:Event_0000013	type	Life.Injure
:Event_0000013	mention.actual	"injured"	egypt_guardian__1000-01-01__timeline:3741-3747	1.000
:Event_0000013	canonical_mention.actual	"injured"	egypt_guardian__1000-01-01__timeline:3741-3747	1.000
:Event_0000013	Life.Injure_Place.actual	:Entity_EDL_0000005	egypt_guardian__1000-01-01__timeline:3698-3702	1.000
:Event_0000013	Life.Injure_Victim.actual	:Entity_EDL_0000018	egypt_guardian__1000-01-01__timeline:3735-3739	1.000
:Event_0000014	type	Justice.ChargeIndict
:Event_0000014	mention.actual	"charges"	egypt_latimes__1000-01-01__timeline:7554-7560	1.000
:Event_0000014	canonical_mention.actual	"charges"	egypt_latimes__1000-01-01__timeline:7554-7560	1.000
:Event_0000014	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000135	egypt_latimes__1000-01-01__timeline:7527-7535	1.000
:Event_0000014	type	Justice.ChargeIndict
:Event_0000014	mention.actual	"charges"	egypt_reuters__1000-01-01__timeline:2155-2161	1.000
:Event_0000014	canonical_mention.actual	"charges"	egypt_reuters__1000-01-01__timeline:2155-2161	1.000
:Event_0000014	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000001	egypt_reuters__1000-01-01__timeline:2140-2146	1.000
:Event_0000015	type	Conflict.Demonstrate
:Event_0000015	mention.actual	"protesters"	egypt_ap__1000-01-01__timeline:279-288	1.000
:Event_0000015	canonical_mention.actual	"protesters"	egypt_ap__1000-01-01__timeline:279-288	1.000
:Event_0000015	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	egypt_ap__1000-01-01__timeline:241-253	1.000
:Event_0000015	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000119	egypt_ap__1000-01-01__timeline:279-288	1.000
:Event_0000015	type	Conflict.Demonstrate
:Event_0000015	mention.actual	"protesters"	egypt_ap__1000-01-01__timeline:932-941	1.000
:Event_0000015	canonical_mention.actual	"protesters"	egypt_ap__1000-01-01__timeline:932-941	1.000
:Event_0000015	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000063	egypt_ap__1000-01-01__timeline:932-941	1.000
:Event_0000016	type	Life.Die
:Event_0000016	mention.actual	"killed"	egypt_ap__1000-01-01__timeline:7652-7657	1.000
:Event_0000016	canonical_mention.actual	"killed"	egypt_ap__1000-01-01__timeline:7652-7657	1.000
:Event_0000016	Life.Die_Victim.actual	:Entity_EDL_0000103	egypt_ap__1000-01-01__timeline:7641-7650	1.000
:Event_0000016	Life.Die_Place.actual	:Entity_EDL_0000087	egypt_ap__1000-01-01__timeline:7681-7687	1.000
:Event_0000016	Life.Die_Place.actual	:Entity_EDL_0000006	egypt_ap__1000-01-01__timeline:7692-7696	1.000
:Event_0000016	type	Life.Die
:Event_0000016	mention.actual	"killed"	egypt_ap__1000-01-01__timeline:7730-7735	1.000
:Event_0000016	canonical_mention.actual	"killed"	egypt_ap__1000-01-01__timeline:7730-7735	1.000
:Event_0000016	Life.Die_Victim.actual	:Entity_EDL_0000145	egypt_ap__1000-01-01__timeline:7720-7725	1.000
:Event_0000016	Life.Die_Place.actual	:Entity_EDL_0000034	egypt_ap__1000-01-01__timeline:7755-7763	1.000
:Event_0000017	type	Personnel.StartPosition
:Event_0000017	mention.actual	"appointed"	egypt_guardian__1000-01-01__timeline:1676-1684	1.000
:Event_0000017	canonical_mention.actual	"appointed"	egypt_guardian__1000-01-01__timeline:1676-1684	1.000
:Event_0000017	Personnel.StartPosition_Person.actual	:Entity_EDL_0000131	egypt_guardian__1000-01-01__timeline:1666-1668	1.000
:Event_0000017	type	Personnel.StartPosition
:Event_0000017	mention.actual	"sworn in"	egypt_ap__1000-01-01__timeline:10385-10392	1.000
:Event_0000017	canonical_mention.actual	"sworn in"	egypt_ap__1000-01-01__timeline:10385-10392	1.000
:Event_0000017	Personnel.StartPosition_Person.actual	:Entity_EDL_0000012	egypt_ap__1000-01-01__timeline:10369-10380	1.000
:Event_0000017	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000065	egypt_ap__1000-01-01__timeline:10401-10406	1.000
:Event_0000018	type	Contact.Meet
:Event_0000018	mention.actual	"meet"	egypt_latimes__1000-01-01__timeline:3577-3580	1.000
:Event_0000018	canonical_mention.actual	"meet"	egypt_latimes__1000-01-01__timeline:3577-3580	1.000
:Event_0000018	Contact.Meet_Participant.actual	:Entity_EDL_0000144	egypt_latimes__1000-01-01__timeline:3571-3572	1.000
:Event_0000018	type	Contact.Meet
:Event_0000018	mention.actual	"reconvene"	egypt_latimes__1000-01-01__timeline:3469-3477	1.000
:Event_0000018	canonical_mention.actual	"reconvene"	egypt_latimes__1000-01-01__timeline:3469-3477	1.000
:Event_0000018	Contact.Meet_Participant.actual	:Entity_EDL_0000130	egypt_latimes__1000-01-01__timeline:3436-3444	1.000
:Event_0000019	type	Justice.TrialHearing
:Event_0000019	mention.actual	"trial"	egypt_guardian__1000-01-01__timeline:4549-4553	1.000
:Event_0000019	canonical_mention.actual	"trial"	egypt_guardian__1000-01-01__timeline:4549-4553	1.000
:Event_0000019	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000097	egypt_guardian__1000-01-01__timeline:4574-4582	1.000
:Event_0000019	type	Justice.TrialHearing
:Event_0000019	mention.actual	"trial"	egypt_guardian__1000-01-01__timeline:4750-4754	1.000
:Event_0000019	canonical_mention.actual	"trial"	egypt_guardian__1000-01-01__timeline:4750-4754	1.000
:Event_0000019	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000001	egypt_guardian__1000-01-01__timeline:4739-4745	1.000
:Event_0000020	type	Conflict.Attack
:Event_0000020	mention.actual	"attack"	egypt_guardian__1000-01-01__timeline:4034-4039	1.000
:Event_0000020	canonical_mention.actual	"attack"	egypt_guardian__1000-01-01__timeline:4034-4039	1.000
:Event_0000020	Conflict.Attack_Place.actual	:Entity_EDL_0000172	egypt_guardian__1000-01-01__timeline:3992-3999	1.000
:Event_0000020	Conflict.Attack_Target.actual	:Entity_EDL_0000182	egypt_guardian__1000-01-01__timeline:4001-4008	1.000
:Event_0000020	Conflict.Attack_Instrument.actual	:Entity_EDL_0000129	egypt_guardian__1000-01-01__timeline:4024-4032	1.000
:Event_0000020	type	Conflict.Attack
:Event_0000020	mention.actual	"hit"	egypt_guardian__1000-01-01__timeline:4010-4012	1.000
:Event_0000020	canonical_mention.actual	"hit"	egypt_guardian__1000-01-01__timeline:4010-4012	1.000
:Event_0000020	Conflict.Attack_Place.actual	:Entity_EDL_0000172	egypt_guardian__1000-01-01__timeline:3992-3999	1.000
:Event_0000020	Conflict.Attack_Target.actual	:Entity_EDL_0000182	egypt_guardian__1000-01-01__timeline:4001-4008	1.000
:Event_0000020	Conflict.Attack_Instrument.actual	:Entity_EDL_0000129	egypt_guardian__1000-01-01__timeline:4024-4032	1.000
:Event_0000021	type	Justice.TrialHearing
:Event_0000021	mention.actual	"trial"	egypt_reuters__1000-01-01__timeline:2078-2082	1.000
:Event_0000021	canonical_mention.actual	"trial"	egypt_reuters__1000-01-01__timeline:2078-2082	1.000
:Event_0000021	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000001	egypt_reuters__1000-01-01__timeline:2070-2076	1.000
:Event_0000021	type	Justice.TrialHearing
:Event_0000021	mention.actual	"trial"	egypt_reuters__1000-01-01__timeline:2017-2021	1.000
:Event_0000021	canonical_mention.actual	"trial"	egypt_reuters__1000-01-01__timeline:2017-2021	1.000
:Event_0000021	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000001	egypt_reuters__1000-01-01__timeline:2006-2012	1.000
:Event_0000022	type	Life.Injure.IllnessDegredationSickness
:Event_0000022	mention.actual	"suffered"	egypt_latimes__1000-01-01__timeline:2021-2028	1.000
:Event_0000022	canonical_mention.actual	"suffered"	egypt_latimes__1000-01-01__timeline:2021-2028	1.000
:Event_0000022	Life.Injure.IllnessDegredationSickness_Victim.actual	:Entity_EDL_0000104	egypt_latimes__1000-01-01__timeline:2018-2019	1.000
:Event_0000023	type	Business.End
:Event_0000023	mention.actual	"resigns"	egypt_reuters__1000-01-01__timeline:2292-2298	1.000
:Event_0000023	canonical_mention.actual	"resigns"	egypt_reuters__1000-01-01__timeline:2292-2298	1.000
:Event_0000023	Business.End_Organization.actual	:Entity_EDL_0000169	egypt_reuters__1000-01-01__timeline:2281-2290	1.000
:Event_0000024	type	Personnel.StartPosition
:Event_0000024	mention.actual	"served"	egypt_reuters__1000-01-01__timeline:2818-2823	1.000
:Event_0000024	canonical_mention.actual	"served"	egypt_reuters__1000-01-01__timeline:2818-2823	1.000
:Event_0000024	Personnel.StartPosition_Person.actual	:Entity_EDL_0000150	egypt_reuters__1000-01-01__timeline:2811-2812	1.000
:Event_0000024	Personnel.StartPosition_Person.actual	:Entity_EDL_0000001	egypt_reuters__1000-01-01__timeline:2849-2855	1.000
:Event_0000025	type	Conflict.Attack
:Event_0000025	mention.actual	"strikes"	egypt_guardian__1000-01-01__timeline:5072-5078	1.000
:Event_0000025	canonical_mention.actual	"strikes"	egypt_guardian__1000-01-01__timeline:5072-5078	1.000
:Event_0000025	Conflict.Attack_Place.actual	:Entity_EDL_0000010	egypt_guardian__1000-01-01__timeline:5063-5066	1.000
:Event_0000026	type	Movement.TransportPerson
:Event_0000026	mention.actual	"into"	egypt_reuters__1000-01-01__timeline:374-377	1.000
:Event_0000026	canonical_mention.actual	"into"	egypt_reuters__1000-01-01__timeline:374-377	1.000
:Event_0000026	Movement.TransportPerson_Person.actual	:Entity_EDL_0000017	egypt_reuters__1000-01-01__timeline:357-362	1.000
:Event_0000026	Movement.TransportPerson_Instrument.actual	:Entity_EDL_0000052	egypt_reuters__1000-01-01__timeline:368-372	1.000
:Event_0000026	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000102	egypt_reuters__1000-01-01__timeline:379-384	1.000
:Event_0000027	type	Contact.Broadcast
:Event_0000027	mention.actual	"announces"	egypt_ap__1000-01-01__timeline:6107-6115	1.000
:Event_0000027	canonical_mention.actual	"announces"	egypt_ap__1000-01-01__timeline:6107-6115	1.000
:Event_0000027	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000193	egypt_ap__1000-01-01__timeline:6085-6105	1.000
:Event_0000028	type	Business.Start
:Event_0000028	mention.actual	"build"	egypt_latimes__1000-01-01__timeline:7639-7643	1.000
:Event_0000028	canonical_mention.actual	"build"	egypt_latimes__1000-01-01__timeline:7639-7643	1.000
:Event_0000028	Business.Start_Place.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:7629-7637	1.000
:Event_0000028	Business.Start_Organization.actual	:Entity_EDL_0000082	egypt_latimes__1000-01-01__timeline:7659-7670	1.000
:Event_0000029	type	Justice.Sentence
:Event_0000029	mention.actual	"sentenced"	egypt_latimes__1000-01-01__timeline:7742-7750	1.000
:Event_0000029	canonical_mention.actual	"sentenced"	egypt_latimes__1000-01-01__timeline:7742-7750	1.000
:Event_0000029	Justice.Sentence_Defendant.actual	:Entity_EDL_0000067	egypt_latimes__1000-01-01__timeline:7684-7693	1.000
:Event_0000030	type	Personnel.Elect
:Event_0000030	mention.actual	"won"	egypt_ap__1000-01-01__timeline:1979-1981	1.000
:Event_0000030	canonical_mention.actual	"won"	egypt_ap__1000-01-01__timeline:1979-1981	1.000
:Event_0000031	type	Life.Die
:Event_0000031	mention.actual	"die"	egypt_guardian__1000-01-01__timeline:6388-6390	1.000
:Event_0000031	canonical_mention.actual	"die"	egypt_guardian__1000-01-01__timeline:6388-6390	1.000
:Event_0000031	Life.Die_Victim.actual	:Entity_EDL_0000189	egypt_guardian__1000-01-01__timeline:6373-6374	1.000
:Event_0000032	type	Conflict.Attack
:Event_0000032	mention.actual	"coup"	egypt_reuters__1000-01-01__timeline:4405-4408	1.000
:Event_0000032	canonical_mention.actual	"coup"	egypt_reuters__1000-01-01__timeline:4405-4408	1.000
:Event_0000032	Conflict.Attack_Attacker.actual	:Entity_EDL_0000108	egypt_reuters__1000-01-01__timeline:4425-4437	1.000
:Event_0000033	type	Conflict.Attack
:Event_0000033	mention.actual	"explodes"	egypt_guardian__1000-01-01__timeline:64-71	1.000
:Event_0000033	canonical_mention.actual	"explodes"	egypt_guardian__1000-01-01__timeline:64-71	1.000
:Event_0000033	Conflict.Attack_Instrument.actual	:Entity_EDL_0000160	egypt_guardian__1000-01-01__timeline:59-62	1.000
:Event_0000033	Conflict.Attack_Target.actual	:Entity_EDL_0000126	egypt_guardian__1000-01-01__timeline:88-93	1.000
:Event_0000033	Conflict.Attack_Place.actual	:Entity_EDL_0000046	egypt_guardian__1000-01-01__timeline:98-107	1.000
:Event_0000034	type	Contact.Meet
:Event_0000034	mention.actual	"met"	egypt_ap__1000-01-01__timeline:10067-10069	1.000
:Event_0000034	canonical_mention.actual	"met"	egypt_ap__1000-01-01__timeline:10067-10069	1.000
:Event_0000034	Contact.Meet_Participant.actual	:Entity_EDL_0000128	egypt_ap__1000-01-01__timeline:10061-10065	1.000
:Event_0000034	Contact.Meet_Participant.actual	:Entity_EDL_0000178	egypt_ap__1000-01-01__timeline:10101-10107	1.000
:Event_0000035	type	Personnel.EndPosition
:Event_0000035	mention.actual	"last"	egypt_ap__1000-01-01__timeline:2205-2208	1.000
:Event_0000035	canonical_mention.actual	"last"	egypt_ap__1000-01-01__timeline:2205-2208	1.000
:Event_0000035	Personnel.EndPosition_Person.actual	:Entity_EDL_0000014	egypt_ap__1000-01-01__timeline:2186-2197	1.000
:Event_0000036	type	Movement.TransportPerson
:Event_0000036	mention.actual	"evacuates"	egypt_guardian__1000-01-01__timeline:5345-5353	1.000
:Event_0000036	canonical_mention.actual	"evacuates"	egypt_guardian__1000-01-01__timeline:5345-5353	1.000
:Event_0000036	Movement.TransportPerson_Agent.actual	:Entity_EDL_0000009	egypt_guardian__1000-01-01__timeline:5338-5343	1.000
:Event_0000036	Movement.TransportPerson_Person.actual	:Entity_EDL_0000023	egypt_guardian__1000-01-01__timeline:5355-5364	1.000
:Event_0000036	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:5369-5373	1.000
:Event_0000037	type	Conflict.Attack
:Event_0000037	mention.actual	"beating"	egypt_ap__1000-01-01__timeline:257-263	1.000
:Event_0000037	canonical_mention.actual	"beating"	egypt_ap__1000-01-01__timeline:257-263	1.000
:Event_0000037	Conflict.Attack_Attacker.actual	:Entity_EDL_0000154	egypt_ap__1000-01-01__timeline:215-219	1.000
:Event_0000037	Conflict.Attack_Target.actual	:Entity_EDL_0000119	egypt_ap__1000-01-01__timeline:279-288	1.000
:Event_0000037	Conflict.Attack_Instrument.actual	:Entity_EDL_0000184	egypt_ap__1000-01-01__timeline:307-313	1.000
:Event_0000037	Conflict.Attack_Instrument.actual	:Entity_EDL_0000199	egypt_ap__1000-01-01__timeline:319-326	1.000
:Event_0000038	type	Conflict.Attack
:Event_0000038	mention.actual	"fire"	egypt_guardian__1000-01-01__timeline:5274-5277	1.000
:Event_0000038	canonical_mention.actual	"fire"	egypt_guardian__1000-01-01__timeline:5274-5277	1.000
:Event_0000038	Conflict.Attack_Attacker.actual	:Entity_EDL_0000198	egypt_guardian__1000-01-01__timeline:5251-5256	1.000
:Event_0000038	Conflict.Attack_Target.actual	:Entity_EDL_0000061	egypt_guardian__1000-01-01__timeline:5282-5291	1.000
:Event_0000039	type	Life.Injure
:Event_0000039	mention.actual	"injured"	egypt_guardian__1000-01-01__timeline:45-51	1.000
:Event_0000039	canonical_mention.actual	"injured"	egypt_guardian__1000-01-01__timeline:45-51	1.000
:Event_0000039	Life.Injure_Victim.actual	:Entity_EDL_0000031	egypt_guardian__1000-01-01__timeline:32-35	1.000
:Event_0000039	Life.Injure_Victim.actual	:Entity_EDL_0000038	egypt_guardian__1000-01-01__timeline:42-43	1.000
:Event_0000039	Life.Injure_Instrument.actual	:Entity_EDL_0000160	egypt_guardian__1000-01-01__timeline:59-62	1.000
:Event_0000039	Life.Injure_Place.actual	:Entity_EDL_0000126	egypt_guardian__1000-01-01__timeline:88-93	1.000
:Event_0000040	type	Contact.Contact
:Event_0000040	mention.actual	"asked"	egypt_reuters__1000-01-01__timeline:3026-3030	1.000
:Event_0000040	canonical_mention.actual	"asked"	egypt_reuters__1000-01-01__timeline:3026-3030	1.000
:Event_0000040	Contact.Contact_Participant.actual	:Entity_EDL_0000000	egypt_reuters__1000-01-01__timeline:3008-3012	1.000
:Event_0000040	Contact.Contact_Participant.actual	:Entity_EDL_0000166	egypt_reuters__1000-01-01__timeline:3019-3020	1.000
:Event_0000040	Contact.Contact_Participant.actual	:Entity_EDL_0000048	egypt_reuters__1000-01-01__timeline:3036-3038	1.000
:Event_0000041	type	Conflict.Attack
:Event_0000041	mention.actual	"bloodshed"	egypt_guardian__1000-01-01__timeline:4945-4953	1.000
:Event_0000041	canonical_mention.actual	"bloodshed"	egypt_guardian__1000-01-01__timeline:4945-4953	1.000
:Event_0000042	type	Life.Die
:Event_0000042	mention.actual	"killed"	egypt_guardian__1000-01-01__timeline:4810-4815	1.000
:Event_0000042	canonical_mention.actual	"killed"	egypt_guardian__1000-01-01__timeline:4810-4815	1.000
:Event_0000042	Life.Die_Victim.actual	:Entity_EDL_0000168	egypt_guardian__1000-01-01__timeline:4801-4808	1.000
:Event_0000042	Life.Die_Place.actual	:Entity_EDL_0000109	egypt_guardian__1000-01-01__timeline:4839-4844	1.000
:Event_0000043	type	Life.Die
:Event_0000043	mention.actual	"deadly"	egypt_latimes__1000-01-01__timeline:8281-8286	1.000
:Event_0000043	canonical_mention.actual	"deadly"	egypt_latimes__1000-01-01__timeline:8281-8286	1.000
:Event_0000044	type	Conflict.Attack
:Event_0000044	mention.actual	"battles"	egypt_ap__1000-01-01__timeline:5524-5530	1.000
:Event_0000044	canonical_mention.actual	"battles"	egypt_ap__1000-01-01__timeline:5524-5530	1.000
:Event_0000044	Conflict.Attack_Place.actual	:Entity_EDL_0000054	egypt_ap__1000-01-01__timeline:5517-5522	1.000
:Event_0000045	type	Conflict.Attack
:Event_0000045	mention.actual	"clashes"	egypt_ap__1000-01-01__timeline:6661-6667	1.000
:Event_0000045	canonical_mention.actual	"clashes"	egypt_ap__1000-01-01__timeline:6661-6667	1.000
:Event_0000045	Conflict.Attack_Target.actual	:Entity_EDL_0000001	egypt_ap__1000-01-01__timeline:6647-6653	1.000
:Event_0000045	Conflict.Attack_Place.actual	:Entity_EDL_0000058	egypt_ap__1000-01-01__timeline:6683-6688	1.000
:Event_0000046	type	Conflict.Demonstrate
:Event_0000046	mention.actual	"rally"	egypt_guardian__1000-01-01__timeline:5451-5455	1.000
:Event_0000046	canonical_mention.actual	"rally"	egypt_guardian__1000-01-01__timeline:5451-5455	1.000
:Event_0000046	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000016	egypt_guardian__1000-01-01__timeline:5441-5449	1.000
:Event_0000046	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	egypt_guardian__1000-01-01__timeline:5460-5472	1.000
:Event_0000047	type	Contact.Meet
:Event_0000047	mention.actual	"meets"	egypt_latimes__1000-01-01__timeline:3765-3769	1.000
:Event_0000047	canonical_mention.actual	"meets"	egypt_latimes__1000-01-01__timeline:3765-3769	1.000
:Event_0000047	Contact.Meet_Participant.actual	:Entity_EDL_0000111	egypt_latimes__1000-01-01__timeline:3742-3763	1.000
:Event_0000047	Contact.Meet_Participant.actual	:Entity_EDL_0000007	egypt_latimes__1000-01-01__timeline:3809-3821	1.000
:Event_0000048	type	Justice.Sentence
:Event_0000048	mention.actual	"sentencing"	egypt_ap__1000-01-01__timeline:6806-6815	1.000
:Event_0000048	canonical_mention.actual	"sentencing"	egypt_ap__1000-01-01__timeline:6806-6815	1.000
:Event_0000048	Justice.Sentence_Adjudicator.actual	:Entity_EDL_0000141	egypt_ap__1000-01-01__timeline:6778-6782	1.000
:Event_0000048	Justice.Sentence_Defendant.actual	:Entity_EDL_0000201	egypt_ap__1000-01-01__timeline:6828-6832	1.000
:Event_0000049	type	Conflict.Demonstrate
:Event_0000049	mention.actual	"protesting"	egypt_ap__1000-01-01__timeline:3903-3912	1.000
:Event_0000049	canonical_mention.actual	"protesting"	egypt_ap__1000-01-01__timeline:3903-3912	1.000
:Event_0000049	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000070	egypt_ap__1000-01-01__timeline:3894-3897	1.000
:Event_0000050	type	Justice.ArrestJail
:Event_0000050	mention.actual	"detained"	egypt_guardian__1000-01-01__timeline:2802-2809	1.000
:Event_0000050	canonical_mention.actual	"detained"	egypt_guardian__1000-01-01__timeline:2802-2809	1.000
:Event_0000050	Justice.ArrestJail_Person.actual	:Entity_EDL_0000002	egypt_guardian__1000-01-01__timeline:2788-2800	1.000
:Event_0000051	type	Conflict.Demonstrate
:Event_0000051	mention.actual	"protests"	egypt_guardian__1000-01-01__timeline:426-433	1.000
:Event_0000051	canonical_mention.actual	"protests"	egypt_guardian__1000-01-01__timeline:426-433	1.000
:Event_0000051	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:307-311	1.000
:Event_0000051	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000094	egypt_guardian__1000-01-01__timeline:413-418	1.000
:Event_0000052	type	Justice.ArrestJail
:Event_0000052	mention.actual	"holds"	egypt_guardian__1000-01-01__timeline:3133-3137	1.000
:Event_0000052	canonical_mention.actual	"holds"	egypt_guardian__1000-01-01__timeline:3133-3137	1.000
:Event_0000052	Justice.ArrestJail_Place.actual	:Entity_EDL_0000008	egypt_guardian__1000-01-01__timeline:3098-3110	1.000
:Event_0000052	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:3127-3131	1.000
:Event_0000052	Justice.ArrestJail_Person.actual	:Entity_EDL_0000040	egypt_guardian__1000-01-01__timeline:3150-3153	1.000
:Event_0000053	type	Transaction.TransferOwnership
:Event_0000053	mention.actual	"trade"	egypt_guardian__1000-01-01__timeline:4907-4911	1.000
:Event_0000053	canonical_mention.actual	"trade"	egypt_guardian__1000-01-01__timeline:4907-4911	1.000
:Event_0000053	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000009	egypt_guardian__1000-01-01__timeline:4891-4896	1.000
:Event_0000053	Transaction.TransferOwnership_Giver.actual	:Entity_EDL_0000028	egypt_guardian__1000-01-01__timeline:4902-4905	1.000
:Event_0000053	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000140	egypt_guardian__1000-01-01__timeline:4913-4920	1.000
:Event_0000053	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000106	egypt_guardian__1000-01-01__timeline:4926-4932	1.000
:Event_0000054	type	Justice.ReleaseParole
:Event_0000054	mention.actual	"released"	egypt_guardian__1000-01-01__timeline:3821-3828	1.000
:Event_0000054	canonical_mention.actual	"released"	egypt_guardian__1000-01-01__timeline:3821-3828	1.000
:Event_0000054	Justice.ReleaseParole_Agent.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:3794-3798	1.000
:Event_0000054	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000073	egypt_guardian__1000-01-01__timeline:3814-3819	1.000
:Event_0000055	type	Conflict.Demonstrate
:Event_0000055	mention.actual	"strike"	egypt_guardian__1000-01-01__timeline:6359-6364	1.000
:Event_0000055	canonical_mention.actual	"strike"	egypt_guardian__1000-01-01__timeline:6359-6364	1.000
:Event_0000055	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000191	egypt_guardian__1000-01-01__timeline:6341-6347	1.000
:Event_0000056	type	Contact.Contact
:Event_0000056	mention.actual	"asks"	egypt_reuters__1000-01-01__timeline:1503-1506	1.000
:Event_0000056	canonical_mention.actual	"asks"	egypt_reuters__1000-01-01__timeline:1503-1506	1.000
:Event_0000056	Contact.Contact_Participant.actual	:Entity_EDL_0000069	egypt_reuters__1000-01-01__timeline:1494-1501	1.000
:Event_0000056	Contact.Contact_Participant.actual	:Entity_EDL_0000100	egypt_reuters__1000-01-01__timeline:1534-1545	1.000
:Event_0000057	type	Personnel.Elect
:Event_0000057	mention.actual	"elections"	egypt_reuters__1000-01-01__timeline:1768-1776	1.000
:Event_0000057	canonical_mention.actual	"elections"	egypt_reuters__1000-01-01__timeline:1768-1776	1.000
:Event_0000058	type	Transaction.TransferMoney
:Event_0000058	mention.actual	"loan"	egypt_ap__1000-01-01__timeline:8205-8208	1.000
:Event_0000058	canonical_mention.actual	"loan"	egypt_ap__1000-01-01__timeline:8205-8208	1.000
:Event_0000058	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000133	egypt_ap__1000-01-01__timeline:8151-8177	1.000
:Event_0000059	type	Personnel.Elect
:Event_0000059	mention.actual	"elected"	egypt_ap__1000-01-01__timeline:2472-2478	1.000
:Event_0000059	canonical_mention.actual	"elected"	egypt_ap__1000-01-01__timeline:2472-2478	1.000
:Event_0000059	Personnel.Elect_Elect.actual	:Entity_EDL_0000075	egypt_ap__1000-01-01__timeline:2446-2450	1.000
:Event_0000060	type	Conflict.Attack
:Event_0000060	mention.actual	"explosion"	egypt_guardian__1000-01-01__timeline:292-300	1.000
:Event_0000060	canonical_mention.actual	"explosion"	egypt_guardian__1000-01-01__timeline:292-300	1.000
:Event_0000060	Conflict.Attack_Place.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:307-311	1.000
:Event_0000061	type	Movement.TransportArtifact
:Event_0000061	mention.actual	"return"	egypt_latimes__1000-01-01__timeline:2701-2706	1.000
:Event_0000061	canonical_mention.actual	"return"	egypt_latimes__1000-01-01__timeline:2701-2706	1.000
:Event_0000061	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000071	egypt_latimes__1000-01-01__timeline:2690-2699	1.000
:Event_0000061	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000003	egypt_latimes__1000-01-01__timeline:2728-2740	1.000
:Event_0000062	type	Conflict.Attack
:Event_0000062	mention.actual	"Fighting"	egypt_guardian__1000-01-01__timeline:5125-5132	1.000
:Event_0000062	canonical_mention.actual	"Fighting"	egypt_guardian__1000-01-01__timeline:5125-5132	1.000
:Event_0000062	Conflict.Attack_Place.actual	:Entity_EDL_0000010	egypt_guardian__1000-01-01__timeline:5143-5146	1.000
:Event_0000063	type	Personnel.Elect
:Event_0000063	mention.actual	"vote"	egypt_ap__1000-01-01__timeline:1016-1019	1.000
:Event_0000063	canonical_mention.actual	"vote"	egypt_ap__1000-01-01__timeline:1016-1019	1.000
:Event_0000063	Personnel.Elect_Elector.actual	:Entity_EDL_0000037	egypt_ap__1000-01-01__timeline:1023-1031	1.000
:Event_0000064	type	Life.Die
:Event_0000064	mention.actual	"funeral"	egypt_ap__1000-01-01__timeline:7605-7611	1.000
:Event_0000064	canonical_mention.actual	"funeral"	egypt_ap__1000-01-01__timeline:7605-7611	1.000
:Event_0000064	Life.Die_Place.actual	:Entity_EDL_0000157	egypt_ap__1000-01-01__timeline:7625-7629	1.000
:Event_0000065	type	Life.Die
:Event_0000065	mention.actual	"killed"	egypt_reuters__1000-01-01__timeline:2710-2715	1.000
:Event_0000065	canonical_mention.actual	"killed"	egypt_reuters__1000-01-01__timeline:2710-2715	1.000
:Event_0000065	Life.Die_Victim.actual	:Entity_EDL_0000159	egypt_reuters__1000-01-01__timeline:2698-2703	1.000
:Event_0000066	type	Life.Injure
:Event_0000066	mention.actual	"bloodshed"	egypt_guardian__1000-01-01__timeline:6155-6163	1.000
:Event_0000066	canonical_mention.actual	"bloodshed"	egypt_guardian__1000-01-01__timeline:6155-6163	1.000
:Event_0000066	Life.Injure_Agent.actual	:Entity_EDL_0000203	egypt_guardian__1000-01-01__timeline:6144-6149	1.000
:Event_0000067	type	Movement.TransportPerson
:Event_0000067	mention.actual	"pack"	egypt_reuters__1000-01-01__timeline:2622-2625	1.000
:Event_0000067	canonical_mention.actual	"pack"	egypt_reuters__1000-01-01__timeline:2622-2625	1.000
:Event_0000067	Movement.TransportPerson_Person.actual	:Entity_EDL_0000074	egypt_reuters__1000-01-01__timeline:2578-2586	1.000
:Event_0000067	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000003	egypt_reuters__1000-01-01__timeline:2627-2639	1.000
:Event_0000068	type	Justice.Convict
:Event_0000068	mention.actual	"convicting"	egypt_ap__1000-01-01__timeline:6791-6800	1.000
:Event_0000068	canonical_mention.actual	"convicting"	egypt_ap__1000-01-01__timeline:6791-6800	1.000
:Event_0000068	Justice.Convict_Adjudicator.actual	:Entity_EDL_0000141	egypt_ap__1000-01-01__timeline:6778-6782	1.000
:Event_0000068	Justice.Convict_Defendant.actual	:Entity_EDL_0000201	egypt_ap__1000-01-01__timeline:6828-6832	1.000
:Event_0000069	type	Transaction.TransferMoney
:Event_0000069	mention.actual	"funded"	egypt_latimes__1000-01-01__timeline:7585-7590	1.000
:Event_0000069	canonical_mention.actual	"funded"	egypt_latimes__1000-01-01__timeline:7585-7590	1.000
:Event_0000069	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000135	egypt_latimes__1000-01-01__timeline:7527-7535	1.000
:Event_0000069	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000180	egypt_latimes__1000-01-01__timeline:7592-7604	1.000
:Event_0000070	type	Conflict.Demonstrate
:Event_0000070	mention.actual	"protest"	egypt_latimes__1000-01-01__timeline:2803-2809	1.000
:Event_0000070	canonical_mention.actual	"protest"	egypt_latimes__1000-01-01__timeline:2803-2809	1.000
:Event_0000070	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000050	egypt_latimes__1000-01-01__timeline:2778-2783	1.000
:Event_0000071	type	Life.Die
:Event_0000071	mention.actual	"death"	egypt_ap__1000-01-01__timeline:8427-8431	1.000
:Event_0000071	canonical_mention.actual	"death"	egypt_ap__1000-01-01__timeline:8427-8431	1.000
:Event_0000071	Life.Die_Agent.actual	:Entity_EDL_0000176	egypt_ap__1000-01-01__timeline:8414-8416	1.000
:Event_0000071	Life.Die_Victim.actual	:Entity_EDL_0000095	egypt_ap__1000-01-01__timeline:8447-8453	1.000
:Event_0000071	Life.Die_Place.actual	:Entity_EDL_0000162	egypt_ap__1000-01-01__timeline:8474-8480	1.000
:Event_0000072	type	Conflict.Attack
:Event_0000072	mention.actual	"killing"	egypt_reuters__1000-01-01__timeline:2179-2185	1.000
:Event_0000072	canonical_mention.actual	"killing"	egypt_reuters__1000-01-01__timeline:2179-2185	1.000
:Event_0000072	Conflict.Attack_Attacker.actual	:Entity_EDL_0000001	egypt_reuters__1000-01-01__timeline:2140-2146	1.000
:Event_0000072	Conflict.Attack_Target.actual	:Entity_EDL_0000013	egypt_reuters__1000-01-01__timeline:2187-2196	1.000
:Event_0000073	type	Personnel.Elect
:Event_0000073	mention.actual	"race"	egypt_latimes__1000-01-01__timeline:573-576	1.000
:Event_0000073	canonical_mention.actual	"race"	egypt_latimes__1000-01-01__timeline:573-576	1.000
:Event_0000073	Personnel.Elect_Place.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:543-547	1.000
:Event_0000074	type	Justice.ArrestJail
:Event_0000074	mention.actual	"arrest"	egypt_latimes__1000-01-01__timeline:6664-6669	1.000
:Event_0000074	canonical_mention.actual	"arrest"	egypt_latimes__1000-01-01__timeline:6664-6669	1.000
:Event_0000074	Justice.ArrestJail_Person.actual	:Entity_EDL_0000092	egypt_latimes__1000-01-01__timeline:6718-6726	1.000
:Event_0000075	type	Conflict.Demonstrate
:Event_0000075	mention.actual	"riots"	egypt_latimes__1000-01-01__timeline:5700-5704	1.000
:Event_0000075	canonical_mention.actual	"riots"	egypt_latimes__1000-01-01__timeline:5700-5704	1.000
:Event_0000075	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000149	egypt_latimes__1000-01-01__timeline:5661-5668	1.000
:Event_0000075	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000084	egypt_latimes__1000-01-01__timeline:5672-5680	1.000
:Event_0000076	type	Life.Injure
:Event_0000076	mention.actual	"bruised"	egypt_guardian__1000-01-01__timeline:586-592	1.000
:Event_0000076	canonical_mention.actual	"bruised"	egypt_guardian__1000-01-01__timeline:586-592	1.000
:Event_0000076	Life.Injure_Victim.actual	:Entity_EDL_0000139	egypt_guardian__1000-01-01__timeline:600-609	1.000
:Event_0000076	Life.Injure_Place.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:621-625	1.000
:Event_0000077	type	Movement.TransportPerson
:Event_0000077	mention.actual	"departure"	egypt_guardian__1000-01-01__timeline:1337-1345	1.000
:Event_0000077	canonical_mention.actual	"departure"	egypt_guardian__1000-01-01__timeline:1337-1345	1.000
:Event_0000077	Movement.TransportPerson_Person.actual	:Entity_EDL_0000001	egypt_guardian__1000-01-01__timeline:1316-1322	1.000
:Event_0000078	type	Personnel.EndPosition
:Event_0000078	mention.actual	"former"	egypt_reuters__1000-01-01__timeline:656-661	1.000
:Event_0000078	canonical_mention.actual	"former"	egypt_reuters__1000-01-01__timeline:656-661	1.000
:Event_0000078	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000062	egypt_reuters__1000-01-01__timeline:628-637	1.000
:Event_0000078	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000011	egypt_reuters__1000-01-01__timeline:663-671	1.000
:Event_0000079	type	Movement.TransportPerson
:Event_0000079	mention.actual	"deployed"	egypt_reuters__1000-01-01__timeline:550-557	1.000
:Event_0000079	canonical_mention.actual	"deployed"	egypt_reuters__1000-01-01__timeline:550-557	1.000
:Event_0000080	type	Conflict.Demonstrate
:Event_0000080	mention.actual	"uprising"	egypt_ap__1000-01-01__timeline:461-468	1.000
:Event_0000080	canonical_mention.actual	"uprising"	egypt_ap__1000-01-01__timeline:461-468	1.000
:Event_0000081	type	Life.Die
:Event_0000081	mention.actual	"killed"	egypt_ap__1000-01-01__timeline:9123-9128	1.000
:Event_0000081	canonical_mention.actual	"killed"	egypt_ap__1000-01-01__timeline:9123-9128	1.000
:Event_0000081	Life.Die_Victim.actual	:Entity_EDL_0000059	egypt_ap__1000-01-01__timeline:9031-9036	1.000
:Event_0000081	Life.Die_Victim.actual	:Entity_EDL_0000033	egypt_ap__1000-01-01__timeline:9040-9043	1.000
:Event_0000081	Life.Die_Place.actual	:Entity_EDL_0000146	egypt_ap__1000-01-01__timeline:9104-9115	1.000
:Event_0000082	type	Justice.ArrestJail
:Event_0000082	mention.actual	"arresting"	egypt_ap__1000-01-01__timeline:269-277	1.000
:Event_0000082	canonical_mention.actual	"arresting"	egypt_ap__1000-01-01__timeline:269-277	1.000
:Event_0000082	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000154	egypt_ap__1000-01-01__timeline:215-219	1.000
:Event_0000082	Justice.ArrestJail_Place.actual	:Entity_EDL_0000003	egypt_ap__1000-01-01__timeline:241-253	1.000
:Event_0000082	Justice.ArrestJail_Person.actual	:Entity_EDL_0000119	egypt_ap__1000-01-01__timeline:279-288	1.000
:Event_0000083	type	Conflict.Attack
:Event_0000083	mention.actual	"fire"	egypt_ap__1000-01-01__timeline:10640-10643	1.000
:Event_0000083	canonical_mention.actual	"fire"	egypt_ap__1000-01-01__timeline:10640-10643	1.000
:Event_0000083	Conflict.Attack_Attacker.actual	:Entity_EDL_0000200	egypt_ap__1000-01-01__timeline:10626-10633	1.000
:Event_0000083	Conflict.Attack_Target.actual	:Entity_EDL_0000076	egypt_ap__1000-01-01__timeline:10664-10673	1.000
:Event_0000083	Conflict.Attack_Place.actual	:Entity_EDL_0000006	egypt_ap__1000-01-01__timeline:10678-10682	1.000
:Event_0000084	type	Movement.TransportArtifact
:Event_0000084	mention.actual	"transferred"	egypt_latimes__1000-01-01__timeline:2328-2338	1.000
:Event_0000084	canonical_mention.actual	"transferred"	egypt_latimes__1000-01-01__timeline:2328-2338	1.000
:Event_0000084	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000081	egypt_latimes__1000-01-01__timeline:2321-2322	1.000
:Event_0000084	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000105	egypt_latimes__1000-01-01__timeline:2354-2361	1.000
:Event_0000084	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000051	egypt_latimes__1000-01-01__timeline:2384-2391	1.000
:Event_0000085	type	Personnel.StartPosition
:Event_0000085	mention.actual	"form"	egypt_reuters__1000-01-01__timeline:1550-1553	1.000
:Event_0000085	canonical_mention.actual	"form"	egypt_reuters__1000-01-01__timeline:1550-1553	1.000
:Event_0000085	Personnel.StartPosition_Person.actual	:Entity_EDL_0000100	egypt_reuters__1000-01-01__timeline:1534-1545	1.000
:Event_0000086	type	Contact.Contact
:Event_0000086	mention.actual	"dialogue"	egypt_reuters__1000-01-01__timeline:820-827	1.000
:Event_0000086	canonical_mention.actual	"dialogue"	egypt_reuters__1000-01-01__timeline:820-827	1.000
:Event_0000086	Contact.Contact_Participant.actual	:Entity_EDL_0000001	egypt_reuters__1000-01-01__timeline:789-795	1.000
:Event_0000086	Contact.Contact_Participant.actual	:Entity_EDL_0000142	egypt_reuters__1000-01-01__timeline:807-809	1.000
:Event_0000086	Contact.Contact_Participant.actual	:Entity_EDL_0000161	egypt_reuters__1000-01-01__timeline:844-849	1.000
:Event_0000087	type	Movement.TransportArtifact
:Event_0000087	mention.actual	"flee"	egypt_guardian__1000-01-01__timeline:1205-1208	1.000
:Event_0000087	canonical_mention.actual	"flee"	egypt_guardian__1000-01-01__timeline:1205-1208	1.000
:Event_0000087	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000117	egypt_guardian__1000-01-01__timeline:1196-1203	1.000
:Event_0000088	type	Conflict.Demonstrate
:Event_0000088	mention.actual	"demonstrations"	egypt_ap__1000-01-01__timeline:37-50	1.000
:Event_0000088	canonical_mention.actual	"demonstrations"	egypt_ap__1000-01-01__timeline:37-50	1.000
:Event_0000088	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000025	egypt_ap__1000-01-01__timeline:11-19	1.000
:Event_0000089	type	Conflict.Attack
:Event_0000089	mention.actual	"clashes"	egypt_ap__1000-01-01__timeline:1746-1752	1.000
:Event_0000089	canonical_mention.actual	"clashes"	egypt_ap__1000-01-01__timeline:1746-1752	1.000
:Event_0000090	type	Transaction.TransferMoney
:Event_0000090	mention.actual	"salaries"	egypt_guardian__1000-01-01__timeline:1436-1443	1.000
:Event_0000090	canonical_mention.actual	"salaries"	egypt_guardian__1000-01-01__timeline:1436-1443	1.000
:Event_0000090	Transaction.TransferMoney_Place.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:1392-1396	1.000
:Event_0000090	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000143	egypt_guardian__1000-01-01__timeline:1405-1411	1.000
:Event_0000091	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000091	mention.actual	"crimes"	egypt_guardian__1000-01-01__timeline:3159-3164	1.000
:Event_0000091	canonical_mention.actual	"crimes"	egypt_guardian__1000-01-01__timeline:3159-3164	1.000
:Event_0000092	type	Justice.Convict
:Event_0000092	mention.actual	"convicted"	egypt_latimes__1000-01-01__timeline:7541-7549	1.000
:Event_0000092	canonical_mention.actual	"convicted"	egypt_latimes__1000-01-01__timeline:7541-7549	1.000
:Event_0000092	Justice.Convict_Defendant.actual	:Entity_EDL_0000135	egypt_latimes__1000-01-01__timeline:7527-7535	1.000
:Event_0000093	type	Life.Die
:Event_0000093	mention.actual	"killed"	egypt_ap__1000-01-01__timeline:1779-1784	1.000
:Event_0000093	canonical_mention.actual	"killed"	egypt_ap__1000-01-01__timeline:1779-1784	1.000
:Event_0000093	Life.Die_Victim.actual	:Entity_EDL_0000206	egypt_ap__1000-01-01__timeline:1786-1791	1.000
:Event_0000094	type	Contact.Contact
:Event_0000094	mention.actual	"negotiations"	egypt_ap__1000-01-01__timeline:8129-8140	1.000
:Event_0000094	canonical_mention.actual	"negotiations"	egypt_ap__1000-01-01__timeline:8129-8140	1.000
:Event_0000094	Contact.Contact_Participant.actual	:Entity_EDL_0000133	egypt_ap__1000-01-01__timeline:8151-8177	1.000
:Event_0000095	type	Personnel.EndPosition
:Event_0000095	mention.actual	"former"	egypt_latimes__1000-01-01__timeline:680-685	1.000
:Event_0000095	canonical_mention.actual	"former"	egypt_latimes__1000-01-01__timeline:680-685	1.000
:Event_0000095	Personnel.EndPosition_Place.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:543-547	1.000
:Event_0000095	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000125	egypt_latimes__1000-01-01__timeline:671-676	1.000
:Event_0000095	Personnel.EndPosition_Person.actual	:Entity_EDL_0000027	egypt_latimes__1000-01-01__timeline:691-695	1.000
:Event_0000096	type	Life.Die
:Event_0000096	mention.actual	"killed"	egypt_latimes__1000-01-01__timeline:5716-5721	1.000
:Event_0000096	canonical_mention.actual	"killed"	egypt_latimes__1000-01-01__timeline:5716-5721	1.000
:Event_0000096	Life.Die_Victim.actual	:Entity_EDL_0000098	egypt_latimes__1000-01-01__timeline:5730-5731	1.000
:Event_0000097	type	Conflict.Attack
:Event_0000097	mention.actual	"clashes"	egypt_latimes__1000-01-01__timeline:8288-8294	1.000
:Event_0000097	canonical_mention.actual	"clashes"	egypt_latimes__1000-01-01__timeline:8288-8294	1.000
:Event_0000098	type	Contact.Broadcast
:Event_0000098	mention.actual	"statement"	egypt_ap__1000-01-01__timeline:9458-9466	1.000
:Event_0000098	canonical_mention.actual	"statement"	egypt_ap__1000-01-01__timeline:9458-9466	1.000
:Event_0000098	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000026	egypt_ap__1000-01-01__timeline:9446-9453	1.000
:Event_0000098	Contact.Broadcast_Audience.actual	:Entity_EDL_0000115	egypt_ap__1000-01-01__timeline:9488-9497	1.000
:Event_0000099	type	Personnel.EndPosition
:Event_0000099	mention.actual	"former"	egypt_latimes__1000-01-01__timeline:5532-5537	1.000
:Event_0000099	canonical_mention.actual	"former"	egypt_latimes__1000-01-01__timeline:5532-5537	1.000
:Event_0000099	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000121	egypt_latimes__1000-01-01__timeline:5539-5549	1.000
:Event_0000099	Personnel.EndPosition_Person.actual	:Entity_EDL_0000186	egypt_latimes__1000-01-01__timeline:5569-5578	1.000
:Event_0000100	type	Conflict.Demonstrate
:Event_0000100	mention.actual	"uprisings"	egypt_reuters__1000-01-01__timeline:149-157	1.000
:Event_0000100	canonical_mention.actual	"uprisings"	egypt_reuters__1000-01-01__timeline:149-157	1.000
:Event_0000101	type	Personnel.Elect
:Event_0000101	mention.actual	"win"	egypt_latimes__1000-01-01__timeline:67-69	1.000
:Event_0000101	canonical_mention.actual	"win"	egypt_latimes__1000-01-01__timeline:67-69	1.000
:Event_0000101	Personnel.Elect_Place.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:34-38	1.000
:Event_0000101	Personnel.Elect_Place.actual	:Entity_EDL_0000158	egypt_latimes__1000-01-01__timeline:146-151	1.000
:Event_0000102	type	Justice.ArrestJail
:Event_0000102	mention.actual	"arrested"	egypt_latimes__1000-01-01__timeline:3953-3960	1.000
:Event_0000102	canonical_mention.actual	"arrested"	egypt_latimes__1000-01-01__timeline:3953-3960	1.000
:Event_0000102	Justice.ArrestJail_Person.actual	:Entity_EDL_0000155	egypt_latimes__1000-01-01__timeline:3943-3951	1.000
:Event_0000103	type	Personnel.StartPosition
:Event_0000103	mention.actual	"sworn in"	egypt_reuters__1000-01-01__timeline:642-649	1.000
:Event_0000103	canonical_mention.actual	"sworn in"	egypt_reuters__1000-01-01__timeline:642-649	1.000
:Event_0000103	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000062	egypt_reuters__1000-01-01__timeline:628-637	1.000
:Event_0000103	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000011	egypt_reuters__1000-01-01__timeline:663-671	1.000
:Event_0000103	Personnel.StartPosition_Person.actual	:Entity_EDL_0000014	egypt_reuters__1000-01-01__timeline:683-694	1.000
:Event_0000104	type	Justice.Sentence
:Event_0000104	mention.actual	"sentence"	egypt_latimes__1000-01-01__timeline:1039-1046	1.000
:Event_0000104	canonical_mention.actual	"sentence"	egypt_latimes__1000-01-01__timeline:1039-1046	1.000
:Event_0000104	Justice.Sentence_Defendant.actual	:Entity_EDL_0000002	egypt_latimes__1000-01-01__timeline:1077-1089	1.000
:Event_0000105	type	Conflict.Attack
:Event_0000105	mention.actual	"clashes"	egypt_ap__1000-01-01__timeline:4372-4378	1.000
:Event_0000105	canonical_mention.actual	"clashes"	egypt_ap__1000-01-01__timeline:4372-4378	1.000
:Event_0000105	Conflict.Attack_Attacker.actual	:Entity_EDL_0000175	egypt_ap__1000-01-01__timeline:4397-4406	1.000
:Event_0000105	Conflict.Attack_Attacker.actual	:Entity_EDL_0000086	egypt_ap__1000-01-01__timeline:4412-4420	1.000
:Event_0000106	type	Contact.Meet
:Event_0000106	mention.actual	"convenes"	egypt_ap__1000-01-01__timeline:3047-3054	1.000
:Event_0000106	canonical_mention.actual	"convenes"	egypt_ap__1000-01-01__timeline:3047-3054	1.000
:Event_0000106	Contact.Meet_Participant.actual	:Entity_EDL_0000185	egypt_ap__1000-01-01__timeline:3036-3045	1.000
:Event_0000107	type	Justice.Pardon
:Event_0000107	mention.actual	"pardon"	egypt_latimes__1000-01-01__timeline:3920-3925	1.000
:Event_0000107	canonical_mention.actual	"pardon"	egypt_latimes__1000-01-01__timeline:3920-3925	1.000
:Event_0000107	Justice.Pardon_Place.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:3870-3877	1.000
:Event_0000107	Justice.Pardon_Adjudicator.actual	:Entity_EDL_0000007	egypt_latimes__1000-01-01__timeline:3889-3901	1.000
:Event_0000107	Justice.Pardon_Defendant.actual	:Entity_EDL_0000155	egypt_latimes__1000-01-01__timeline:3943-3951	1.000
:Event_0000108	type	Conflict.Demonstrate
:Event_0000108	mention.actual	"celebrate"	egypt_latimes__1000-01-01__timeline:8665-8673	1.000
:Event_0000108	canonical_mention.actual	"celebrate"	egypt_latimes__1000-01-01__timeline:8665-8673	1.000
:Event_0000108	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000055	egypt_latimes__1000-01-01__timeline:8651-8663	1.000
:Event_0000108	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	egypt_latimes__1000-01-01__timeline:8686-8698	1.000
:Event_0000109	type	Life.Die
:Event_0000109	mention.actual	"death"	egypt_ap__1000-01-01__timeline:426-430	1.000
:Event_0000109	canonical_mention.actual	"death"	egypt_ap__1000-01-01__timeline:426-430	1.000
:Event_0000109	Life.Die_Victim.actual	:Entity_EDL_0000041	egypt_ap__1000-01-01__timeline:446-448	1.000
:Event_0000110	type	Justice.Sentence
:Event_0000110	mention.actual	"sentenced"	egypt_reuters__1000-01-01__timeline:3695-3703	1.000
:Event_0000110	canonical_mention.actual	"sentenced"	egypt_reuters__1000-01-01__timeline:3695-3703	1.000
:Event_0000110	Justice.Sentence_Defendant.actual	:Entity_EDL_0000001	egypt_reuters__1000-01-01__timeline:3684-3690	1.000
:Event_0000111	type	Personnel.StartPosition
:Event_0000111	mention.actual	"names"	egypt_reuters__1000-01-01__timeline:2741-2745	1.000
:Event_0000111	canonical_mention.actual	"names"	egypt_reuters__1000-01-01__timeline:2741-2745	1.000
:Event_0000111	Personnel.StartPosition_Person.actual	:Entity_EDL_0000060	egypt_reuters__1000-01-01__timeline:2747-2763	1.000
:Event_0000112	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000112	mention.actual	"murder"	egypt_guardian__1000-01-01__timeline:3365-3370	1.000
:Event_0000112	canonical_mention.actual	"murder"	egypt_guardian__1000-01-01__timeline:3365-3370	1.000
:Event_0000112	GenericCrime.GenericCrime.GenericCrime_Perpetrator.actual	:Entity_EDL_0000002	egypt_guardian__1000-01-01__timeline:3338-3350	1.000
:Event_0000113	type	Movement.TransportPerson
:Event_0000113	mention.actual	"sent"	egypt_ap__1000-01-01__timeline:10113-10116	1.000
:Event_0000113	canonical_mention.actual	"sent"	egypt_ap__1000-01-01__timeline:10113-10116	1.000
:Event_0000113	Movement.TransportPerson_Agent.actual	:Entity_EDL_0000128	egypt_ap__1000-01-01__timeline:10061-10065	1.000
:Event_0000113	Movement.TransportPerson_Person.actual	:Entity_EDL_0000079	egypt_ap__1000-01-01__timeline:10118-10125	1.000
:Event_0000113	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000072	egypt_ap__1000-01-01__timeline:10145-10152	1.000
:Event_0000114	type	Conflict.Attack
:Event_0000114	mention.actual	"burn down"	egypt_ap__1000-01-01__timeline:528-536	1.000
:Event_0000114	canonical_mention.actual	"burn down"	egypt_ap__1000-01-01__timeline:528-536	1.000
:Event_0000114	Conflict.Attack_Attacker.actual	:Entity_EDL_0000204	egypt_ap__1000-01-01__timeline:517-526	1.000
:Event_0000114	Conflict.Attack_Target.actual	:Entity_EDL_0000138	egypt_ap__1000-01-01__timeline:558-569	1.000
:Event_0000115	type	Personnel.EndPosition
:Event_0000115	mention.actual	"former"	egypt_reuters__1000-01-01__timeline:223-228	1.000
:Event_0000115	canonical_mention.actual	"former"	egypt_reuters__1000-01-01__timeline:223-228	1.000
:Event_0000115	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000011	egypt_reuters__1000-01-01__timeline:230-238	1.000
:Event_0000115	Personnel.EndPosition_Person.actual	:Entity_EDL_0000056	egypt_reuters__1000-01-01__timeline:240-248	1.000
:Event_0000116	type	Life.Die
:Event_0000116	mention.actual	"killed"	egypt_ap__1000-01-01__timeline:352-357	1.000
:Event_0000116	canonical_mention.actual	"killed"	egypt_ap__1000-01-01__timeline:352-357	1.000
:Event_0000116	Life.Die_Victim.actual	:Entity_EDL_0000205	egypt_ap__1000-01-01__timeline:337-346	1.000
:Event_0000116	Life.Die_Place.actual	:Entity_EDL_0000006	egypt_ap__1000-01-01__timeline:387-391	1.000
:Event_0000117	type	Justice.ArrestJail
:Event_0000117	mention.actual	"arrest"	egypt_latimes__1000-01-01__timeline:3336-3341	1.000
:Event_0000117	canonical_mention.actual	"arrest"	egypt_latimes__1000-01-01__timeline:3336-3341	1.000
:Event_0000117	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000015	egypt_latimes__1000-01-01__timeline:3289-3296	1.000
:Event_0000117	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000183	egypt_latimes__1000-01-01__timeline:3324-3331	1.000
:Event_0000117	Justice.ArrestJail_Person.actual	:Entity_EDL_0000091	egypt_latimes__1000-01-01__timeline:3343-3351	1.000
:Event_0000117	Justice.ArrestJail_Place.actual	:Entity_EDL_0000019	egypt_latimes__1000-01-01__timeline:3364-3369	1.000
:Event_0000118	type	Personnel.EndPosition
:Event_0000118	mention.actual	"reshuffles"	egypt_guardian__1000-01-01__timeline:4234-4243	1.000
:Event_0000118	canonical_mention.actual	"reshuffles"	egypt_guardian__1000-01-01__timeline:4234-4243	1.000
:Event_0000118	Personnel.EndPosition_Place.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:4210-4214	1.000
:Event_0000118	Personnel.EndPosition_Person.actual	:Entity_EDL_0000192	egypt_guardian__1000-01-01__timeline:4225-4232	1.000
:Event_0000119	type	Justice.ChargeIndict
:Event_0000119	mention.actual	"charged"	egypt_guardian__1000-01-01__timeline:3352-3358	1.000
:Event_0000119	canonical_mention.actual	"charged"	egypt_guardian__1000-01-01__timeline:3352-3358	1.000
:Event_0000119	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000002	egypt_guardian__1000-01-01__timeline:3338-3350	1.000
:Event_0000120	type	Justice.ArrestJail
:Event_0000120	mention.actual	"arrest"	egypt_latimes__1000-01-01__timeline:6448-6453	1.000
:Event_0000120	canonical_mention.actual	"arrest"	egypt_latimes__1000-01-01__timeline:6448-6453	1.000
:Event_0000120	Justice.ArrestJail_Person.actual	:Entity_EDL_0000137	egypt_latimes__1000-01-01__timeline:6486-6499	1.000
:Event_0000121	type	Conflict.Attack
:Event_0000121	mention.actual	"clash"	egypt_guardian__1000-01-01__timeline:3038-3042	1.000
:Event_0000121	canonical_mention.actual	"clash"	egypt_guardian__1000-01-01__timeline:3038-3042	1.000
:Event_0000121	Conflict.Attack_Attacker.actual	:Entity_EDL_0000120	egypt_guardian__1000-01-01__timeline:3020-3024	1.000
:Event_0000121	Conflict.Attack_Attacker.actual	:Entity_EDL_0000116	egypt_guardian__1000-01-01__timeline:3030-3036	1.000
:Event_0000121	Conflict.Attack_Place.actual	:Entity_EDL_0000005	egypt_guardian__1000-01-01__timeline:3047-3051	1.000
:Event_0000122	type	Movement.TransportArtifact
:Event_0000122	mention.actual	"moves"	egypt_ap__1000-01-01__timeline:221-225	1.000
:Event_0000122	canonical_mention.actual	"moves"	egypt_ap__1000-01-01__timeline:221-225	1.000
:Event_0000122	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000154	egypt_ap__1000-01-01__timeline:215-219	1.000
:Event_0000122	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000003	egypt_ap__1000-01-01__timeline:241-253	1.000
:Event_0000123	type	Conflict.Attack
:Event_0000123	mention.actual	"overthrow"	egypt_reuters__1000-01-01__timeline:82-90	1.000
:Event_0000123	canonical_mention.actual	"overthrow"	egypt_reuters__1000-01-01__timeline:82-90	1.000
:Event_0000123	Conflict.Attack_Place.actual	:Entity_EDL_0000171	egypt_reuters__1000-01-01__timeline:95-101	1.000
:Event_0000123	Conflict.Attack_Target.actual	:Entity_EDL_0000080	egypt_reuters__1000-01-01__timeline:106-114	1.000
:Event_0000124	type	Personnel.EndPosition
:Event_0000124	mention.actual	"former"	egypt_reuters__1000-01-01__timeline:1508-1513	1.000
:Event_0000124	canonical_mention.actual	"former"	egypt_reuters__1000-01-01__timeline:1508-1513	1.000
:Event_0000124	Personnel.EndPosition_Person.actual	:Entity_EDL_0000100	egypt_reuters__1000-01-01__timeline:1534-1545	1.000
:Event_0000125	type	Conflict.Attack
:Event_0000125	mention.actual	"war"	egypt_ap__1000-01-01__timeline:8642-8644	1.000
:Event_0000125	canonical_mention.actual	"war"	egypt_ap__1000-01-01__timeline:8642-8644	1.000
:Event_0000125	Conflict.Attack_Place.actual	:Entity_EDL_0000101	egypt_ap__1000-01-01__timeline:8627-8631	1.000
:Event_0000126	type	Personnel.EndPosition
:Event_0000126	mention.actual	"former"	egypt_guardian__1000-01-01__timeline:4558-4563	1.000
:Event_0000126	canonical_mention.actual	"former"	egypt_guardian__1000-01-01__timeline:4558-4563	1.000
:Event_0000126	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000000	egypt_guardian__1000-01-01__timeline:4565-4572	1.000
:Event_0000126	Personnel.EndPosition_Person.actual	:Entity_EDL_0000097	egypt_guardian__1000-01-01__timeline:4574-4582	1.000
:Event_0000127	type	Personnel.EndPosition
:Event_0000127	mention.actual	"last"	egypt_latimes__1000-01-01__timeline:3056-3059	1.000
:Event_0000127	canonical_mention.actual	"last"	egypt_latimes__1000-01-01__timeline:3056-3059	1.000
:Event_0000127	Personnel.EndPosition_Place.actual	:Entity_EDL_0000000	egypt_latimes__1000-01-01__timeline:2986-2990	1.000
:Event_0000127	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	egypt_latimes__1000-01-01__timeline:3100-3112	1.000
