:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"death"	mj_bbc__1000-01-01__timeline:9361-9365	1.000
:Event_0000000	canonical_mention.actual	"death"	mj_bbc__1000-01-01__timeline:9361-9365	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000040	mj_bbc__1000-01-01__timeline:9339-9344	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000042	mj_bbc__1000-01-01__timeline:9353-9355	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"death"	mj_bbc__1000-01-01__timeline:1440-1444	1.000
:Event_0000000	canonical_mention.actual	"death"	mj_bbc__1000-01-01__timeline:1440-1444	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000006	mj_bbc__1000-01-01__timeline:1352-1358	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"dies"	mj_bbc__1000-01-01__timeline:303-306	1.000
:Event_0000000	canonical_mention.actual	"dies"	mj_bbc__1000-01-01__timeline:303-306	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000022	mj_bbc__1000-01-01__timeline:276-281	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000030	mj_bbc__1000-01-01__timeline:283-287	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000019	mj_bbc__1000-01-01__timeline:289-295	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"death"	mj_bbc__1000-01-01__timeline:8498-8502	1.000
:Event_0000000	canonical_mention.actual	"death"	mj_bbc__1000-01-01__timeline:8498-8502	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000013	mj_bbc__1000-01-01__timeline:8494-8496	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"died"	mj_bbc__1000-01-01__timeline:5203-5206	1.000
:Event_0000000	canonical_mention.actual	"died"	mj_bbc__1000-01-01__timeline:5203-5206	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000039	mj_bbc__1000-01-01__timeline:5195-5201	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"death"	mj_bbc__1000-01-01__timeline:6003-6007	1.000
:Event_0000000	canonical_mention.actual	"death"	mj_bbc__1000-01-01__timeline:6003-6007	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000034	mj_bbc__1000-01-01__timeline:5995-5998	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"death"	mj_bbc__1000-01-01__timeline:4429-4433	1.000
:Event_0000000	canonical_mention.actual	"death"	mj_bbc__1000-01-01__timeline:4429-4433	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000018	mj_bbc__1000-01-01__timeline:4425-4427	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"death"	mj_bbc__1000-01-01__timeline:1363-1367	1.000
:Event_0000000	canonical_mention.actual	"death"	mj_bbc__1000-01-01__timeline:1363-1367	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000006	mj_bbc__1000-01-01__timeline:1352-1358	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"died"	mj_bbc__1000-01-01__timeline:2912-2915	1.000
:Event_0000000	canonical_mention.actual	"died"	mj_bbc__1000-01-01__timeline:2912-2915	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000016	mj_bbc__1000-01-01__timeline:2904-2910	1.000
:Event_0000001	type	Justice.TrialHearing
:Event_0000001	mention.actual	"trial"	mj_bbc__1000-01-01__timeline:7269-7273	1.000
:Event_0000001	canonical_mention.actual	"trial"	mj_bbc__1000-01-01__timeline:7269-7273	1.000
:Event_0000001	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000025	mj_bbc__1000-01-01__timeline:7280-7285	1.000
:Event_0000001	type	Justice.TrialHearing
:Event_0000001	mention.actual	"trial"	mj_bbc__1000-01-01__timeline:4888-4892	1.000
:Event_0000001	canonical_mention.actual	"trial"	mj_bbc__1000-01-01__timeline:4888-4892	1.000
:Event_0000001	type	Justice.TrialHearing
:Event_0000001	mention.actual	"trial"	mj_bbc__1000-01-01__timeline:3834-3838	1.000
:Event_0000001	canonical_mention.actual	"trial"	mj_bbc__1000-01-01__timeline:3834-3838	1.000
:Event_0000001	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000021	mj_bbc__1000-01-01__timeline:3865-3870	1.000
:Event_0000001	type	Justice.TrialHearing
:Event_0000001	mention.actual	"trial"	mj_bbc__1000-01-01__timeline:4212-4216	1.000
:Event_0000001	canonical_mention.actual	"trial"	mj_bbc__1000-01-01__timeline:4212-4216	1.000
:Event_0000001	type	Justice.TrialHearing
:Event_0000001	mention.actual	"trial"	mj_bbc__1000-01-01__timeline:8374-8378	1.000
:Event_0000001	canonical_mention.actual	"trial"	mj_bbc__1000-01-01__timeline:8374-8378	1.000
:Event_0000001	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000000	mj_bbc__1000-01-01__timeline:8281-8287	1.000
:Event_0000001	type	Justice.TrialHearing
:Event_0000001	mention.actual	"trial"	mj_bbc__1000-01-01__timeline:3410-3414	1.000
:Event_0000001	canonical_mention.actual	"trial"	mj_bbc__1000-01-01__timeline:3410-3414	1.000
:Event_0000001	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000028	mj_bbc__1000-01-01__timeline:3441-3445	1.000
:Event_0000002	type	Justice.Convict
:Event_0000002	mention.actual	"guilty"	mj_bbc__1000-01-01__timeline:9578-9583	1.000
:Event_0000002	canonical_mention.actual	"guilty"	mj_bbc__1000-01-01__timeline:9578-9583	1.000
:Event_0000002	Justice.Convict_Defendant.actual	:Entity_EDL_0000049	mj_bbc__1000-01-01__timeline:9555-9567	1.000
:Event_0000002	Justice.Convict_Adjudicator.actual	:Entity_EDL_0000020	mj_bbc__1000-01-01__timeline:9633-9636	1.000
:Event_0000002	type	Justice.Convict
:Event_0000002	mention.actual	"found"	mj_bbc__1000-01-01__timeline:3193-3197	1.000
:Event_0000002	canonical_mention.actual	"found"	mj_bbc__1000-01-01__timeline:3193-3197	1.000
:Event_0000002	Justice.Convict_Defendant.actual	:Entity_EDL_0000002	mj_bbc__1000-01-01__timeline:3154-3155	1.000
:Event_0000002	type	Justice.Convict
:Event_0000002	mention.actual	"found"	mj_bbc__1000-01-01__timeline:9572-9576	1.000
:Event_0000002	canonical_mention.actual	"found"	mj_bbc__1000-01-01__timeline:9572-9576	1.000
:Event_0000002	Justice.Convict_Defendant.actual	:Entity_EDL_0000049	mj_bbc__1000-01-01__timeline:9555-9567	1.000
:Event_0000002	Justice.Convict_Adjudicator.actual	:Entity_EDL_0000020	mj_bbc__1000-01-01__timeline:9633-9636	1.000
:Event_0000003	type	Transaction.TransferOwnership
:Event_0000003	mention.actual	"bought"	mj_bbc__1000-01-01__timeline:1725-1730	1.000
:Event_0000003	canonical_mention.actual	"bought"	mj_bbc__1000-01-01__timeline:1725-1730	1.000
:Event_0000003	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000047	mj_bbc__1000-01-01__timeline:1718-1723	1.000
:Event_0000003	type	Transaction.TransferOwnership
:Event_0000003	mention.actual	"purchase"	mj_bbc__1000-01-01__timeline:1902-1909	1.000
:Event_0000003	canonical_mention.actual	"purchase"	mj_bbc__1000-01-01__timeline:1902-1909	1.000
:Event_0000003	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000058	mj_bbc__1000-01-01__timeline:1860-1865	1.000
:Event_0000003	Transaction.TransferOwnership_Place.actual	:Entity_EDL_0000027	mj_bbc__1000-01-01__timeline:1923-1931	1.000
:Event_0000004	type	Justice.TrialHearing
:Event_0000004	mention.actual	"pleads"	mj_bbc__1000-01-01__timeline:2133-2138	1.000
:Event_0000004	canonical_mention.actual	"pleads"	mj_bbc__1000-01-01__timeline:2133-2138	1.000
:Event_0000004	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000057	mj_bbc__1000-01-01__timeline:2130-2131	1.000
:Event_0000004	type	Justice.TrialHearing
:Event_0000004	mention.actual	"plea"	mj_bbc__1000-01-01__timeline:3284-3287	1.000
:Event_0000004	canonical_mention.actual	"plea"	mj_bbc__1000-01-01__timeline:3284-3287	1.000
:Event_0000004	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000033	mj_bbc__1000-01-01__timeline:3257-3262	1.000
:Event_0000005	type	Movement.TransportArtifact
:Event_0000005	mention.actual	"travels"	mj_bbc__1000-01-01__timeline:220-226	1.000
:Event_0000005	canonical_mention.actual	"travels"	mj_bbc__1000-01-01__timeline:220-226	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000029	mj_bbc__1000-01-01__timeline:217-218	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000031	mj_bbc__1000-01-01__timeline:237-242	1.000
:Event_0000005	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000015	mj_bbc__1000-01-01__timeline:250-258	1.000
:Event_0000005	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000022	mj_bbc__1000-01-01__timeline:276-281	1.000
:Event_0000006	type	Justice.ChargeIndict
:Event_0000006	mention.actual	"charged"	mj_bbc__1000-01-01__timeline:2089-2095	1.000
:Event_0000006	canonical_mention.actual	"charged"	mj_bbc__1000-01-01__timeline:2089-2095	1.000
:Event_0000006	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000048	mj_bbc__1000-01-01__timeline:2079-2084	1.000
:Event_0000007	type	Movement.TransportArtifact
:Event_0000007	mention.actual	"transported"	mj_bbc__1000-01-01__timeline:1944-1954	1.000
:Event_0000007	canonical_mention.actual	"transported"	mj_bbc__1000-01-01__timeline:1944-1954	1.000
:Event_0000007	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000058	mj_bbc__1000-01-01__timeline:1860-1865	1.000
:Event_0000007	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000027	mj_bbc__1000-01-01__timeline:1923-1931	1.000
:Event_0000007	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000004	mj_bbc__1000-01-01__timeline:1962-1972	1.000
:Event_0000008	type	Movement.TransportPerson
:Event_0000008	mention.actual	"called"	mj_bbc__1000-01-01__timeline:107-112	1.000
:Event_0000008	canonical_mention.actual	"called"	mj_bbc__1000-01-01__timeline:107-112	1.000
:Event_0000008	Movement.TransportPerson_Person.actual	:Entity_EDL_0000001	mj_bbc__1000-01-01__timeline:92-101	1.000
:Event_0000008	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000036	mj_bbc__1000-01-01__timeline:121-125	1.000
:Event_0000009	type	Conflict.Attack
:Event_0000009	mention.actual	"raided"	mj_bbc__1000-01-01__timeline:723-728	1.000
:Event_0000009	canonical_mention.actual	"raided"	mj_bbc__1000-01-01__timeline:723-728	1.000
:Event_0000009	Conflict.Attack_Place.actual	:Entity_EDL_0000007	mj_bbc__1000-01-01__timeline:710-713	1.000
:Event_0000010	type	Contact.Contact
:Event_0000010	mention.actual	"interview"	mj_bbc__1000-01-01__timeline:6188-6196	1.000
:Event_0000010	canonical_mention.actual	"interview"	mj_bbc__1000-01-01__timeline:6188-6196	1.000
:Event_0000010	Contact.Contact_Participant.actual	:Entity_EDL_0000010	mj_bbc__1000-01-01__timeline:6159-6164	1.000
:Event_0000010	Contact.Contact_Participant.actual	:Entity_EDL_0000011	mj_bbc__1000-01-01__timeline:6203-6208	1.000
:Event_0000011	type	Contact.Meet
:Event_0000011	mention.actual	"telling"	mj_bbc__1000-01-01__timeline:6338-6344	1.000
:Event_0000011	canonical_mention.actual	"telling"	mj_bbc__1000-01-01__timeline:6338-6344	1.000
:Event_0000011	Contact.Meet_Participant.actual	:Entity_EDL_0000003	mj_bbc__1000-01-01__timeline:6326-6327	1.000
:Event_0000011	Contact.Meet_Participant.actual	:Entity_EDL_0000056	mj_bbc__1000-01-01__timeline:6346-6355	1.000
:Event_0000012	type	Justice.Convict
:Event_0000012	mention.actual	"guilty"	mj_bbc__1000-01-01__timeline:3199-3204	1.000
:Event_0000012	canonical_mention.actual	"guilty"	mj_bbc__1000-01-01__timeline:3199-3204	1.000
:Event_0000012	Justice.Convict_Defendant.actual	:Entity_EDL_0000002	mj_bbc__1000-01-01__timeline:3154-3155	1.000
:Event_0000013	type	Justice.TrialHearing
:Event_0000013	mention.actual	"trial"	mj_bbc__1000-01-01__timeline:3116-3120	1.000
:Event_0000013	canonical_mention.actual	"trial"	mj_bbc__1000-01-01__timeline:3116-3120	1.000
:Event_0000013	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000012	mj_bbc__1000-01-01__timeline:3089-3094	1.000
:Event_0000014	type	Contact.Correspondence
:Event_0000014	mention.actual	"call"	mj_bbc__1000-01-01__timeline:209-212	1.000
:Event_0000014	canonical_mention.actual	"call"	mj_bbc__1000-01-01__timeline:209-212	1.000
:Event_0000015	type	Transaction.TransferOwnership
:Event_0000015	mention.actual	"seized"	mj_bbc__1000-01-01__timeline:925-930	1.000
:Event_0000015	canonical_mention.actual	"seized"	mj_bbc__1000-01-01__timeline:925-930	1.000
:Event_0000016	type	Contact.Broadcast
:Event_0000016	mention.actual	"statements"	mj_bbc__1000-01-01__timeline:9168-9177	1.000
:Event_0000016	canonical_mention.actual	"statements"	mj_bbc__1000-01-01__timeline:9168-9177	1.000
:Event_0000016	Contact.Broadcast_Audience.actual	:Entity_EDL_0000055	mj_bbc__1000-01-01__timeline:9145-9148	1.000
:Event_0000017	type	Contact.Correspondence
:Event_0000017	mention.actual	"call"	mj_bbc__1000-01-01__timeline:7298-7301	1.000
:Event_0000017	canonical_mention.actual	"call"	mj_bbc__1000-01-01__timeline:7298-7301	1.000
:Event_0000017	Contact.Correspondence_Participant.actual	:Entity_EDL_0000025	mj_bbc__1000-01-01__timeline:7280-7285	1.000
:Event_0000017	Contact.Correspondence_Participant.actual	:Entity_EDL_0000051	mj_bbc__1000-01-01__timeline:7290-7296	1.000
:Event_0000017	Contact.Correspondence_Participant.actual	:Entity_EDL_0000046	mj_bbc__1000-01-01__timeline:7315-7323	1.000
:Event_0000018	type	Transaction.TransferMoney
:Event_0000018	mention.actual	"owing"	mj_bbc__1000-01-01__timeline:1126-1130	1.000
:Event_0000018	canonical_mention.actual	"owing"	mj_bbc__1000-01-01__timeline:1126-1130	1.000
:Event_0000018	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000017	mj_bbc__1000-01-01__timeline:1098-1103	1.000
:Event_0000018	Transaction.TransferMoney_Beneficiary.actual	:Entity_EDL_0000037	mj_bbc__1000-01-01__timeline:1198-1200	1.000
:Event_0000019	type	Contact.Meet
:Event_0000019	mention.actual	"interview"	mj_bbc__1000-01-01__timeline:374-382	1.000
:Event_0000019	canonical_mention.actual	"interview"	mj_bbc__1000-01-01__timeline:374-382	1.000
:Event_0000019	Contact.Meet_Place.actual	:Entity_EDL_0000032	mj_bbc__1000-01-01__timeline:355-365	1.000
:Event_0000019	Contact.Meet_Participant.actual	:Entity_EDL_0000026	mj_bbc__1000-01-01__timeline:367-372	1.000
:Event_0000019	Contact.Meet_Participant.actual	:Entity_EDL_0000043	mj_bbc__1000-01-01__timeline:387-392	1.000
:Event_0000020	type	Justice.Sue
:Event_0000020	mention.actual	"lawsuit"	mj_bbc__1000-01-01__timeline:2593-2599	1.000
:Event_0000020	canonical_mention.actual	"lawsuit"	mj_bbc__1000-01-01__timeline:2593-2599	1.000
:Event_0000020	Justice.Sue_Plaintiff.actual	:Entity_EDL_0000050	mj_bbc__1000-01-01__timeline:2552-2557	1.000
:Event_0000020	Justice.Sue_Defendant.actual	:Entity_EDL_0000044	mj_bbc__1000-01-01__timeline:2613-2621	1.000
:Event_0000021	type	Life.Die
:Event_0000021	mention.actual	"death"	mj_bbc__1000-01-01__timeline:2587-2591	1.000
:Event_0000021	canonical_mention.actual	"death"	mj_bbc__1000-01-01__timeline:2587-2591	1.000
:Event_0000022	type	Transaction.TransferMoney
:Event_0000022	mention.actual	"spent"	mj_bbc__1000-01-01__timeline:1867-1871	1.000
:Event_0000022	canonical_mention.actual	"spent"	mj_bbc__1000-01-01__timeline:1867-1871	1.000
:Event_0000022	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000058	mj_bbc__1000-01-01__timeline:1860-1865	1.000
:Event_0000022	Transaction.TransferMoney_Place.actual	:Entity_EDL_0000027	mj_bbc__1000-01-01__timeline:1923-1931	1.000
:Event_0000023	type	Conflict.Attack
:Event_0000023	mention.actual	"raided"	mj_bbc__1000-01-01__timeline:971-976	1.000
:Event_0000023	canonical_mention.actual	"raided"	mj_bbc__1000-01-01__timeline:971-976	1.000
:Event_0000023	Conflict.Attack_Target.actual	:Entity_EDL_0000024	mj_bbc__1000-01-01__timeline:940-947	1.000
:Event_0000023	Conflict.Attack_Place.actual	:Entity_EDL_0000054	mj_bbc__1000-01-01__timeline:952-960	1.000
:Event_0000024	type	Justice.ReleaseParole
:Event_0000024	mention.actual	"released"	mj_bbc__1000-01-01__timeline:2158-2165	1.000
:Event_0000024	canonical_mention.actual	"released"	mj_bbc__1000-01-01__timeline:2158-2165	1.000
:Event_0000024	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000057	mj_bbc__1000-01-01__timeline:2130-2131	1.000
:Event_0000025	type	Personnel.StartPosition
:Event_0000025	mention.actual	"hired"	mj_bbc__1000-01-01__timeline:1802-1806	1.000
:Event_0000025	canonical_mention.actual	"hired"	mj_bbc__1000-01-01__timeline:1802-1806	1.000
:Event_0000025	Personnel.StartPosition_Person.actual	:Entity_EDL_0000038	mj_bbc__1000-01-01__timeline:1795-1796	1.000
:Event_0000026	type	Conflict.Attack
:Event_0000026	mention.actual	"raided"	mj_bbc__1000-01-01__timeline:545-550	1.000
:Event_0000026	canonical_mention.actual	"raided"	mj_bbc__1000-01-01__timeline:545-550	1.000
:Event_0000026	Conflict.Attack_Target.actual	:Entity_EDL_0000035	mj_bbc__1000-01-01__timeline:524-529	1.000
:Event_0000026	Conflict.Attack_Place.actual	:Entity_EDL_0000041	mj_bbc__1000-01-01__timeline:534-540	1.000
:Event_0000026	Conflict.Attack_Attacker.actual	:Entity_EDL_0000023	mj_bbc__1000-01-01__timeline:555-562	1.000
:Event_0000027	type	Justice.TrialHearing
:Event_0000027	mention.actual	"testify"	mj_bbc__1000-01-01__timeline:8972-8978	1.000
:Event_0000027	canonical_mention.actual	"testify"	mj_bbc__1000-01-01__timeline:8972-8978	1.000
:Event_0000028	type	Justice.Sentence
:Event_0000028	mention.actual	"faces"	mj_bbc__1000-01-01__timeline:3157-3161	1.000
:Event_0000028	canonical_mention.actual	"faces"	mj_bbc__1000-01-01__timeline:3157-3161	1.000
:Event_0000028	Justice.Sentence_Defendant.actual	:Entity_EDL_0000002	mj_bbc__1000-01-01__timeline:3154-3155	1.000
:Event_0000029	type	Movement.TransportPerson
:Event_0000029	mention.actual	"came"	mj_bbc__1000-01-01__timeline:7999-8002	1.000
:Event_0000029	canonical_mention.actual	"came"	mj_bbc__1000-01-01__timeline:7999-8002	1.000
:Event_0000029	Movement.TransportPerson_Agent.actual	:Entity_EDL_0000009	mj_bbc__1000-01-01__timeline:7997-7997	1.000
:Event_0000029	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000052	mj_bbc__1000-01-01__timeline:8004-8007	1.000
:Event_0000030	type	Contact.Correspondence
:Event_0000030	mention.actual	"calling"	mj_bbc__1000-01-01__timeline:2874-2880	1.000
:Event_0000030	canonical_mention.actual	"calling"	mj_bbc__1000-01-01__timeline:2874-2880	1.000
:Event_0000030	Contact.Correspondence_Participant.actual	:Entity_EDL_0000045	mj_bbc__1000-01-01__timeline:2844-2849	1.000
:Event_0000030	Contact.Correspondence_Participant.actual	:Entity_EDL_0000008	mj_bbc__1000-01-01__timeline:2882-2891	1.000
