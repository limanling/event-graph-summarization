:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"paid"	egyptianprotest_cnn__1000-01-01__timeline:3422-3425	1.000
:Event_0000000	canonical_mention.actual	"paid"	egyptianprotest_cnn__1000-01-01__timeline:3422-3425	1.000
:Event_0000000	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000013	egyptianprotest_cnn__1000-01-01__timeline:3406-3412	1.000
:Event_0000001	type	Personnel.Elect
:Event_0000001	mention.actual	"elections"	egyptianprotest_cnn__1000-01-01__timeline:5915-5923	1.000
:Event_0000001	canonical_mention.actual	"elections"	egyptianprotest_cnn__1000-01-01__timeline:5915-5923	1.000
:Event_0000001	Personnel.Elect_Place.actual	:Entity_EDL_0000008	egyptianprotest_cnn__1000-01-01__timeline:5852-5856	1.000
:Event_0000002	type	Life.Die
:Event_0000002	mention.actual	"dying"	egyptianprotest_cnn__1000-01-01__timeline:6795-6799	1.000
:Event_0000002	canonical_mention.actual	"dying"	egyptianprotest_cnn__1000-01-01__timeline:6795-6799	1.000
:Event_0000002	Life.Die_Victim.actual	:Entity_EDL_0000010	egyptianprotest_cnn__1000-01-01__timeline:6703-6709	1.000
:Event_0000003	type	ArtifactExistence.DamageDestroy.Destroy
:Event_0000003	mention.actual	"burned"	egyptianprotest_cnn__1000-01-01__timeline:7650-7655	1.000
:Event_0000003	canonical_mention.actual	"burned"	egyptianprotest_cnn__1000-01-01__timeline:7650-7655	1.000
:Event_0000003	ArtifactExistence.DamageDestroy.Destroy_Artifact.actual	:Entity_EDL_0000058	egyptianprotest_cnn__1000-01-01__timeline:7657-7660	1.000
:Event_0000004	type	Justice.ArrestJail
:Event_0000004	mention.actual	"arrested"	egyptianprotest_cnn__1000-01-01__timeline:4258-4265	1.000
:Event_0000004	canonical_mention.actual	"arrested"	egyptianprotest_cnn__1000-01-01__timeline:4258-4265	1.000
:Event_0000004	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000005	egyptianprotest_cnn__1000-01-01__timeline:4196-4200	1.000
:Event_0000004	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000031	egyptianprotest_cnn__1000-01-01__timeline:4219-4222	1.000
:Event_0000004	Justice.ArrestJail_Place.actual	:Entity_EDL_0000006	egyptianprotest_cnn__1000-01-01__timeline:4245-4252	1.000
:Event_0000004	Justice.ArrestJail_Person.actual	:Entity_EDL_0000055	egyptianprotest_cnn__1000-01-01__timeline:4271-4281	1.000
:Event_0000004	Justice.ArrestJail_Person.actual	:Entity_EDL_0000093	egyptianprotest_cnn__1000-01-01__timeline:4285-4295	1.000
:Event_0000004	Justice.ArrestJail_Person.actual	:Entity_EDL_0000003	egyptianprotest_cnn__1000-01-01__timeline:4301-4314	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"use"	egyptianprotest_cnn__1000-01-01__timeline:363-365	1.000
:Event_0000005	canonical_mention.actual	"use"	egyptianprotest_cnn__1000-01-01__timeline:363-365	1.000
:Event_0000005	Conflict.Attack_Attacker.actual	:Entity_EDL_0000021	egyptianprotest_cnn__1000-01-01__timeline:356-361	1.000
:Event_0000005	Conflict.Attack_Instrument.actual	:Entity_EDL_0000097	egyptianprotest_cnn__1000-01-01__timeline:373-379	1.000
:Event_0000005	Conflict.Attack_Instrument.actual	:Entity_EDL_0000039	egyptianprotest_cnn__1000-01-01__timeline:385-392	1.000
:Event_0000005	Conflict.Attack_Target.actual	:Entity_EDL_0000091	egyptianprotest_cnn__1000-01-01__timeline:415-424	1.000
:Event_0000006	type	Movement.TransportPerson
:Event_0000006	mention.actual	"returns"	egyptianprotest_cnn__1000-01-01__timeline:783-789	1.000
:Event_0000006	canonical_mention.actual	"returns"	egyptianprotest_cnn__1000-01-01__timeline:783-789	1.000
:Event_0000006	Movement.TransportPerson_Person.actual	:Entity_EDL_0000074	egyptianprotest_cnn__1000-01-01__timeline:702-705	1.000
:Event_0000006	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000016	egyptianprotest_cnn__1000-01-01__timeline:794-798	1.000
:Event_0000007	type	Conflict.Demonstrate
:Event_0000007	mention.actual	"march"	egyptianprotest_cnn__1000-01-01__timeline:2329-2333	1.000
:Event_0000007	canonical_mention.actual	"march"	egyptianprotest_cnn__1000-01-01__timeline:2329-2333	1.000
:Event_0000007	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000085	egyptianprotest_cnn__1000-01-01__timeline:2338-2345	1.000
:Event_0000008	type	Life.Injure
:Event_0000008	mention.actual	"wounded"	egyptianprotest_cnn__1000-01-01__timeline:6468-6474	1.000
:Event_0000008	canonical_mention.actual	"wounded"	egyptianprotest_cnn__1000-01-01__timeline:6468-6474	1.000
:Event_0000008	Life.Injure_Victim.actual	:Entity_EDL_0000070	egyptianprotest_cnn__1000-01-01__timeline:6457-6462	1.000
:Event_0000008	Life.Injure_Agent.actual	:Entity_EDL_0000098	egyptianprotest_cnn__1000-01-01__timeline:6492-6497	1.000
:Event_0000008	Life.Injure_Place.actual	:Entity_EDL_0000046	egyptianprotest_cnn__1000-01-01__timeline:6511-6515	1.000
:Event_0000009	type	Personnel.EndPosition
:Event_0000009	mention.actual	"sacked"	egyptianprotest_cnn__1000-01-01__timeline:1569-1574	1.000
:Event_0000009	canonical_mention.actual	"sacked"	egyptianprotest_cnn__1000-01-01__timeline:1569-1574	1.000
:Event_0000009	Personnel.EndPosition_Person.actual	:Entity_EDL_0000024	egyptianprotest_cnn__1000-01-01__timeline:1580-1586	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"battles"	egyptianprotest_cnn__1000-01-01__timeline:3541-3547	1.000
:Event_0000010	canonical_mention.actual	"battles"	egyptianprotest_cnn__1000-01-01__timeline:3541-3547	1.000
:Event_0000010	Conflict.Attack_Place.actual	:Entity_EDL_0000004	egyptianprotest_cnn__1000-01-01__timeline:3534-3539	1.000
:Event_0000010	Conflict.Attack_Place.actual	:Entity_EDL_0000000	egyptianprotest_cnn__1000-01-01__timeline:3565-3577	1.000
:Event_0000011	type	Conflict.Attack
:Event_0000011	mention.actual	"clashes"	egyptianprotest_cnn__1000-01-01__timeline:4089-4095	1.000
:Event_0000011	canonical_mention.actual	"clashes"	egyptianprotest_cnn__1000-01-01__timeline:4089-4095	1.000
:Event_0000011	Conflict.Attack_Place.actual	:Entity_EDL_0000053	egyptianprotest_cnn__1000-01-01__timeline:4067-4071	1.000
:Event_0000011	Conflict.Attack_Attacker.actual	:Entity_EDL_0000087	egyptianprotest_cnn__1000-01-01__timeline:4110-4114	1.000
:Event_0000012	type	Business.Start
:Event_0000012	mention.actual	"form"	egyptianprotest_cnn__1000-01-01__timeline:5189-5192	1.000
:Event_0000012	canonical_mention.actual	"form"	egyptianprotest_cnn__1000-01-01__timeline:5189-5192	1.000
:Event_0000012	Business.Start_Agent.actual	:Entity_EDL_0000060	egyptianprotest_cnn__1000-01-01__timeline:5110-5114	1.000
:Event_0000012	Business.Start_Organization.actual	:Entity_EDL_0000090	egyptianprotest_cnn__1000-01-01__timeline:5194-5203	1.000
:Event_0000013	type	Life.Injure
:Event_0000013	mention.actual	"wounded"	egyptianprotest_cnn__1000-01-01__timeline:588-594	1.000
:Event_0000013	canonical_mention.actual	"wounded"	egyptianprotest_cnn__1000-01-01__timeline:588-594	1.000
:Event_0000013	Life.Injure_Victim.actual	:Entity_EDL_0000064	egyptianprotest_cnn__1000-01-01__timeline:585-586	1.000
:Event_0000013	Life.Injure_Place.actual	:Entity_EDL_0000047	egyptianprotest_cnn__1000-01-01__timeline:599-602	1.000
:Event_0000014	type	Personnel.EndPosition
:Event_0000014	mention.actual	"resignation"	egyptianprotest_cnn__1000-01-01__timeline:3835-3845	1.000
:Event_0000014	canonical_mention.actual	"resignation"	egyptianprotest_cnn__1000-01-01__timeline:3835-3845	1.000
:Event_0000014	Personnel.EndPosition_Person.actual	:Entity_EDL_0000079	egyptianprotest_cnn__1000-01-01__timeline:3821-3823	1.000
:Event_0000014	Personnel.EndPosition_Place.actual	:Entity_EDL_0000069	egyptianprotest_cnn__1000-01-01__timeline:3860-3864	1.000
:Event_0000015	type	Conflict.Demonstrate
:Event_0000015	mention.actual	"rally"	egyptianprotest_cnn__1000-01-01__timeline:4047-4051	1.000
:Event_0000015	canonical_mention.actual	"rally"	egyptianprotest_cnn__1000-01-01__timeline:4047-4051	1.000
:Event_0000015	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000041	egyptianprotest_cnn__1000-01-01__timeline:3995-4000	1.000
:Event_0000015	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000059	egyptianprotest_cnn__1000-01-01__timeline:4005-4017	1.000
:Event_0000016	type	Contact.Meet
:Event_0000016	mention.actual	"talks"	egyptianprotest_cnn__1000-01-01__timeline:5453-5457	1.000
:Event_0000016	canonical_mention.actual	"talks"	egyptianprotest_cnn__1000-01-01__timeline:5453-5457	1.000
:Event_0000016	Contact.Meet_Participant.actual	:Entity_EDL_0000049	egyptianprotest_cnn__1000-01-01__timeline:5475-5481	1.000
:Event_0000017	type	Justice.ReleaseParole
:Event_0000017	mention.actual	"released"	egyptianprotest_cnn__1000-01-01__timeline:5664-5671	1.000
:Event_0000017	canonical_mention.actual	"released"	egyptianprotest_cnn__1000-01-01__timeline:5664-5671	1.000
:Event_0000017	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000080	egyptianprotest_cnn__1000-01-01__timeline:5606-5616	1.000
:Event_0000018	type	Conflict.Demonstrate
:Event_0000018	mention.actual	"rally"	egyptianprotest_cnn__1000-01-01__timeline:6624-6628	1.000
:Event_0000018	canonical_mention.actual	"rally"	egyptianprotest_cnn__1000-01-01__timeline:6624-6628	1.000
:Event_0000019	type	Business.End
:Event_0000019	mention.actual	"dissolved"	egyptianprotest_cnn__1000-01-01__timeline:8149-8157	1.000
:Event_0000019	canonical_mention.actual	"dissolved"	egyptianprotest_cnn__1000-01-01__timeline:8149-8157	1.000
:Event_0000019	Business.End_Organization.actual	:Entity_EDL_0000050	egyptianprotest_cnn__1000-01-01__timeline:8159-8168	1.000
:Event_0000019	Business.End_Place.actual	:Entity_EDL_0000028	egyptianprotest_cnn__1000-01-01__timeline:8188-8194	1.000
:Event_0000020	type	Movement.TransportPerson
:Event_0000020	mention.actual	"draws"	egyptianprotest_cnn__1000-01-01__timeline:3968-3972	1.000
:Event_0000020	canonical_mention.actual	"draws"	egyptianprotest_cnn__1000-01-01__timeline:3968-3972	1.000
:Event_0000020	Movement.TransportPerson_Person.actual	:Entity_EDL_0000041	egyptianprotest_cnn__1000-01-01__timeline:3995-4000	1.000
:Event_0000020	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000059	egyptianprotest_cnn__1000-01-01__timeline:4005-4017	1.000
:Event_0000021	type	Personnel.EndPosition
:Event_0000021	mention.actual	"resigned"	egyptianprotest_cnn__1000-01-01__timeline:8311-8318	1.000
:Event_0000021	canonical_mention.actual	"resigned"	egyptianprotest_cnn__1000-01-01__timeline:8311-8318	1.000
:Event_0000021	Personnel.EndPosition_Person.actual	:Entity_EDL_0000012	egyptianprotest_cnn__1000-01-01__timeline:8297-8309	1.000
:Event_0000022	type	Conflict.Attack
:Event_0000022	mention.actual	"battle"	egyptianprotest_cnn__1000-01-01__timeline:1081-1086	1.000
:Event_0000022	canonical_mention.actual	"battle"	egyptianprotest_cnn__1000-01-01__timeline:1081-1086	1.000
:Event_0000022	Conflict.Attack_Attacker.actual	:Entity_EDL_0000088	egyptianprotest_cnn__1000-01-01__timeline:1070-1079	1.000
:Event_0000022	Conflict.Attack_Target.actual	:Entity_EDL_0000026	egyptianprotest_cnn__1000-01-01__timeline:1088-1093	1.000
:Event_0000022	Conflict.Attack_Place.actual	:Entity_EDL_0000078	egyptianprotest_cnn__1000-01-01__timeline:1098-1102	1.000
:Event_0000022	Conflict.Attack_Place.actual	:Entity_EDL_0000034	egyptianprotest_cnn__1000-01-01__timeline:1106-1109	1.000
:Event_0000022	Conflict.Attack_Place.actual	:Entity_EDL_0000072	egyptianprotest_cnn__1000-01-01__timeline:1115-1124	1.000
:Event_0000023	type	Life.Injure
:Event_0000023	mention.actual	"wounded"	egyptianprotest_cnn__1000-01-01__timeline:225-231	1.000
:Event_0000023	canonical_mention.actual	"wounded"	egyptianprotest_cnn__1000-01-01__timeline:225-231	1.000
:Event_0000023	Life.Injure_Victim.actual	:Entity_EDL_0000002	egyptianprotest_cnn__1000-01-01__timeline:222-223	1.000
:Event_0000023	Life.Injure_Agent.actual	:Entity_EDL_0000035	egyptianprotest_cnn__1000-01-01__timeline:252-261	1.000
:Event_0000023	Life.Injure_Agent.actual	:Entity_EDL_0000057	egyptianprotest_cnn__1000-01-01__timeline:267-272	1.000
:Event_0000023	Life.Injure_Place.actual	:Entity_EDL_0000033	egyptianprotest_cnn__1000-01-01__timeline:277-281	1.000
:Event_0000023	Life.Injure_Place.actual	:Entity_EDL_0000068	egyptianprotest_cnn__1000-01-01__timeline:296-299	1.000
:Event_0000024	type	Conflict.Demonstrate
:Event_0000024	mention.actual	"protesters"	egyptianprotest_cnn__1000-01-01__timeline:6261-6270	1.000
:Event_0000024	canonical_mention.actual	"protesters"	egyptianprotest_cnn__1000-01-01__timeline:6261-6270	1.000
:Event_0000024	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000081	egyptianprotest_cnn__1000-01-01__timeline:6261-6270	1.000
:Event_0000024	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000027	egyptianprotest_cnn__1000-01-01__timeline:6276-6280	1.000
:Event_0000024	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000030	egyptianprotest_cnn__1000-01-01__timeline:6285-6297	1.000
:Event_0000025	type	Personnel.EndPosition
:Event_0000025	mention.actual	"step down"	egyptianprotest_cnn__1000-01-01__timeline:4511-4519	1.000
:Event_0000025	canonical_mention.actual	"step down"	egyptianprotest_cnn__1000-01-01__timeline:4511-4519	1.000
:Event_0000025	Personnel.EndPosition_Person.actual	:Entity_EDL_0000089	egyptianprotest_cnn__1000-01-01__timeline:4420-4426	1.000
:Event_0000025	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000082	egyptianprotest_cnn__1000-01-01__timeline:4447-4451	1.000
:Event_0000025	Personnel.EndPosition_Person.actual	:Entity_EDL_0000073	egyptianprotest_cnn__1000-01-01__timeline:4505-4507	1.000
:Event_0000026	type	Life.Die
:Event_0000026	mention.actual	"dead"	egyptianprotest_cnn__1000-01-01__timeline:213-216	1.000
:Event_0000026	canonical_mention.actual	"dead"	egyptianprotest_cnn__1000-01-01__timeline:213-216	1.000
:Event_0000026	Life.Die_Victim.actual	:Entity_EDL_0000025	egyptianprotest_cnn__1000-01-01__timeline:207-211	1.000
:Event_0000026	Life.Die_Place.actual	:Entity_EDL_0000033	egyptianprotest_cnn__1000-01-01__timeline:277-281	1.000
:Event_0000027	type	Conflict.Demonstrate
:Event_0000027	mention.actual	"protesters"	egyptianprotest_cnn__1000-01-01__timeline:2417-2426	1.000
:Event_0000027	canonical_mention.actual	"protesters"	egyptianprotest_cnn__1000-01-01__timeline:2417-2426	1.000
:Event_0000027	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000017	egyptianprotest_cnn__1000-01-01__timeline:2417-2426	1.000
:Event_0000028	type	Life.Die
:Event_0000028	mention.actual	"killed"	egyptianprotest_cnn__1000-01-01__timeline:1848-1853	1.000
:Event_0000028	canonical_mention.actual	"killed"	egyptianprotest_cnn__1000-01-01__timeline:1848-1853	1.000
:Event_0000028	Life.Die_Victim.actual	:Entity_EDL_0000011	egyptianprotest_cnn__1000-01-01__timeline:1831-1836	1.000
:Event_0000028	Life.Die_Place.actual	:Entity_EDL_0000023	egyptianprotest_cnn__1000-01-01__timeline:1855-1859	1.000
:Event_0000029	type	Conflict.Attack
:Event_0000029	mention.actual	"Clashes"	egyptianprotest_cnn__1000-01-01__timeline:1696-1702	1.000
:Event_0000029	canonical_mention.actual	"Clashes"	egyptianprotest_cnn__1000-01-01__timeline:1696-1702	1.000
:Event_0000030	type	Conflict.Attack
:Event_0000030	mention.actual	"violence"	egyptianprotest_cnn__1000-01-01__timeline:3761-3768	1.000
:Event_0000030	canonical_mention.actual	"violence"	egyptianprotest_cnn__1000-01-01__timeline:3761-3768	1.000
:Event_0000031	type	Justice.ArrestJail
:Event_0000031	mention.actual	"arrests"	egyptianprotest_cnn__1000-01-01__timeline:524-530	1.000
:Event_0000031	canonical_mention.actual	"arrests"	egyptianprotest_cnn__1000-01-01__timeline:524-530	1.000
:Event_0000031	Justice.ArrestJail_Place.actual	:Entity_EDL_0000071	egyptianprotest_cnn__1000-01-01__timeline:535-539	1.000
:Event_0000032	type	Conflict.Demonstrate
:Event_0000032	mention.actual	"demonstrations"	egyptianprotest_cnn__1000-01-01__timeline:808-821	1.000
:Event_0000032	canonical_mention.actual	"demonstrations"	egyptianprotest_cnn__1000-01-01__timeline:808-821	1.000
:Event_0000032	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000016	egyptianprotest_cnn__1000-01-01__timeline:794-798	1.000
:Event_0000033	type	Personnel.StartPosition
:Event_0000033	mention.actual	"appoint"	egyptianprotest_cnn__1000-01-01__timeline:8366-8372	1.000
:Event_0000033	canonical_mention.actual	"appoint"	egyptianprotest_cnn__1000-01-01__timeline:8366-8372	1.000
:Event_0000033	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000045	egyptianprotest_cnn__1000-01-01__timeline:8323-8324	1.000
:Event_0000034	type	Personnel.EndPosition
:Event_0000034	mention.actual	"former"	egyptianprotest_cnn__1000-01-01__timeline:695-700	1.000
:Event_0000034	canonical_mention.actual	"former"	egyptianprotest_cnn__1000-01-01__timeline:695-700	1.000
:Event_0000034	Personnel.EndPosition_Person.actual	:Entity_EDL_0000074	egyptianprotest_cnn__1000-01-01__timeline:702-705	1.000
:Event_0000034	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000048	egyptianprotest_cnn__1000-01-01__timeline:736-741	1.000
:Event_0000035	type	Contact.Contact
:Event_0000035	mention.actual	"discussing"	egyptianprotest_cnn__1000-01-01__timeline:2495-2504	1.000
:Event_0000035	canonical_mention.actual	"discussing"	egyptianprotest_cnn__1000-01-01__timeline:2495-2504	1.000
:Event_0000035	Contact.Contact_Participant.actual	:Entity_EDL_0000015	egyptianprotest_cnn__1000-01-01__timeline:2474-2483	1.000
:Event_0000035	Contact.Contact_Participant.actual	:Entity_EDL_0000044	egyptianprotest_cnn__1000-01-01__timeline:2529-2535	1.000
:Event_0000036	type	Personnel.EndPosition
:Event_0000036	mention.actual	"step down"	egyptianprotest_cnn__1000-01-01__timeline:3790-3798	1.000
:Event_0000036	canonical_mention.actual	"step down"	egyptianprotest_cnn__1000-01-01__timeline:3790-3798	1.000
:Event_0000036	Personnel.EndPosition_Person.actual	:Entity_EDL_0000036	egyptianprotest_cnn__1000-01-01__timeline:3781-3782	1.000
:Event_0000037	type	Movement.TransportArtifact
:Event_0000037	mention.actual	"move"	egyptianprotest_cnn__1000-01-01__timeline:6396-6399	1.000
:Event_0000037	canonical_mention.actual	"move"	egyptianprotest_cnn__1000-01-01__timeline:6396-6399	1.000
:Event_0000037	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000038	egyptianprotest_cnn__1000-01-01__timeline:6337-6344	1.000
:Event_0000037	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000022	egyptianprotest_cnn__1000-01-01__timeline:6386-6394	1.000
:Event_0000037	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000092	egyptianprotest_cnn__1000-01-01__timeline:6401-6410	1.000
:Event_0000037	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000065	egyptianprotest_cnn__1000-01-01__timeline:6423-6426	1.000
:Event_0000038	type	Movement.TransportPerson
:Event_0000038	mention.actual	"returned"	egyptianprotest_cnn__1000-01-01__timeline:430-437	1.000
:Event_0000038	canonical_mention.actual	"returned"	egyptianprotest_cnn__1000-01-01__timeline:430-437	1.000
:Event_0000038	Movement.TransportPerson_Person.actual	:Entity_EDL_0000091	egyptianprotest_cnn__1000-01-01__timeline:415-424	1.000
:Event_0000038	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000032	egyptianprotest_cnn__1000-01-01__timeline:446-452	1.000
:Event_0000039	type	Life.Die
:Event_0000039	mention.actual	"killed"	egyptianprotest_cnn__1000-01-01__timeline:6446-6451	1.000
:Event_0000039	canonical_mention.actual	"killed"	egyptianprotest_cnn__1000-01-01__timeline:6446-6451	1.000
:Event_0000039	Life.Die_Victim.actual	:Entity_EDL_0000051	egyptianprotest_cnn__1000-01-01__timeline:6435-6440	1.000
:Event_0000039	Life.Die_Place.actual	:Entity_EDL_0000046	egyptianprotest_cnn__1000-01-01__timeline:6511-6515	1.000
:Event_0000040	type	Conflict.Attack
:Event_0000040	mention.actual	"battle"	egyptianprotest_cnn__1000-01-01__timeline:3154-3159	1.000
:Event_0000040	canonical_mention.actual	"battle"	egyptianprotest_cnn__1000-01-01__timeline:3154-3159	1.000
:Event_0000040	Conflict.Attack_Attacker.actual	:Entity_EDL_0000086	egyptianprotest_cnn__1000-01-01__timeline:3140-3152	1.000
:Event_0000040	Conflict.Attack_Target.actual	:Entity_EDL_0000075	egyptianprotest_cnn__1000-01-01__timeline:3166-3170	1.000
:Event_0000040	Conflict.Attack_Instrument.actual	:Entity_EDL_0000009	egyptianprotest_cnn__1000-01-01__timeline:3177-3181	1.000
:Event_0000040	Conflict.Attack_Instrument.actual	:Entity_EDL_0000007	egyptianprotest_cnn__1000-01-01__timeline:3208-3224	1.000
:Event_0000040	Conflict.Attack_Place.actual	:Entity_EDL_0000056	egyptianprotest_cnn__1000-01-01__timeline:3233-3245	1.000
:Event_0000041	type	Contact.Meet
:Event_0000041	mention.actual	"meets"	egyptianprotest_cnn__1000-01-01__timeline:4871-4875	1.000
:Event_0000041	canonical_mention.actual	"meets"	egyptianprotest_cnn__1000-01-01__timeline:4871-4875	1.000
:Event_0000041	Contact.Meet_Participant.actual	:Entity_EDL_0000043	egyptianprotest_cnn__1000-01-01__timeline:4857-4869	1.000
:Event_0000041	Contact.Meet_Participant.actual	:Entity_EDL_0000083	egyptianprotest_cnn__1000-01-01__timeline:4882-4896	1.000
:Event_0000042	type	Movement.TransportArtifact
:Event_0000042	mention.actual	"arrives"	egyptianprotest_cnn__1000-01-01__timeline:2093-2099	1.000
:Event_0000042	canonical_mention.actual	"arrives"	egyptianprotest_cnn__1000-01-01__timeline:2093-2099	1.000
:Event_0000042	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000061	egyptianprotest_cnn__1000-01-01__timeline:2090-2091	1.000
:Event_0000042	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000040	egyptianprotest_cnn__1000-01-01__timeline:2108-2113	1.000
:Event_0000043	type	Personnel.EndPosition
:Event_0000043	mention.actual	"step down"	egyptianprotest_cnn__1000-01-01__timeline:6781-6789	1.000
:Event_0000043	canonical_mention.actual	"step down"	egyptianprotest_cnn__1000-01-01__timeline:6781-6789	1.000
:Event_0000043	Personnel.EndPosition_Person.actual	:Entity_EDL_0000010	egyptianprotest_cnn__1000-01-01__timeline:6703-6709	1.000
:Event_0000044	type	Personnel.Elect
:Event_0000044	mention.actual	"election"	egyptianprotest_cnn__1000-01-01__timeline:8220-8227	1.000
:Event_0000044	canonical_mention.actual	"election"	egyptianprotest_cnn__1000-01-01__timeline:8220-8227	1.000
:Event_0000044	Personnel.Elect_Place.actual	:Entity_EDL_0000028	egyptianprotest_cnn__1000-01-01__timeline:8188-8194	1.000
:Event_0000045	type	Life.Die
:Event_0000045	mention.actual	"death"	egyptianprotest_cnn__1000-01-01__timeline:6575-6579	1.000
:Event_0000045	canonical_mention.actual	"death"	egyptianprotest_cnn__1000-01-01__timeline:6575-6579	1.000
:Event_0000045	Life.Die_Victim.actual	:Entity_EDL_0000094	egyptianprotest_cnn__1000-01-01__timeline:6599-6601	1.000
:Event_0000046	type	Personnel.EndPosition
:Event_0000046	mention.actual	"resigned"	egyptianprotest_cnn__1000-01-01__timeline:7250-7257	1.000
:Event_0000046	canonical_mention.actual	"resigned"	egyptianprotest_cnn__1000-01-01__timeline:7250-7257	1.000
:Event_0000046	Personnel.EndPosition_Place.actual	:Entity_EDL_0000052	egyptianprotest_cnn__1000-01-01__timeline:7153-7157	1.000
:Event_0000046	Personnel.EndPosition_Person.actual	:Entity_EDL_0000077	egyptianprotest_cnn__1000-01-01__timeline:7237-7244	1.000
:Event_0000047	type	Conflict.Demonstrate
:Event_0000047	mention.actual	"protesters"	egyptianprotest_cnn__1000-01-01__timeline:415-424	1.000
:Event_0000047	canonical_mention.actual	"protesters"	egyptianprotest_cnn__1000-01-01__timeline:415-424	1.000
:Event_0000047	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000091	egyptianprotest_cnn__1000-01-01__timeline:415-424	1.000
:Event_0000047	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000032	egyptianprotest_cnn__1000-01-01__timeline:446-452	1.000
:Event_0000048	type	Conflict.Attack
:Event_0000048	mention.actual	"attack"	egyptianprotest_cnn__1000-01-01__timeline:4348-4353	1.000
:Event_0000048	canonical_mention.actual	"attack"	egyptianprotest_cnn__1000-01-01__timeline:4348-4353	1.000
:Event_0000048	Conflict.Attack_Target.actual	:Entity_EDL_0000063	egyptianprotest_cnn__1000-01-01__timeline:4362-4367	1.000
:Event_0000049	type	Personnel.Elect
:Event_0000049	mention.actual	"elections"	egyptianprotest_cnn__1000-01-01__timeline:2832-2840	1.000
:Event_0000049	canonical_mention.actual	"elections"	egyptianprotest_cnn__1000-01-01__timeline:2832-2840	1.000
:Event_0000050	type	Conflict.Demonstrate
:Event_0000050	mention.actual	"demonstrations"	egyptianprotest_cnn__1000-01-01__timeline:2708-2721	1.000
:Event_0000050	canonical_mention.actual	"demonstrations"	egyptianprotest_cnn__1000-01-01__timeline:2708-2721	1.000
:Event_0000050	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000096	egyptianprotest_cnn__1000-01-01__timeline:2671-2679	1.000
:Event_0000051	type	Conflict.Attack
:Event_0000051	mention.actual	"ransacked"	egyptianprotest_cnn__1000-01-01__timeline:1232-1240	1.000
:Event_0000051	canonical_mention.actual	"ransacked"	egyptianprotest_cnn__1000-01-01__timeline:1232-1240	1.000
:Event_0000051	Conflict.Attack_Target.actual	:Entity_EDL_0000014	egyptianprotest_cnn__1000-01-01__timeline:1169-1180	1.000
:Event_0000052	type	Conflict.Attack
:Event_0000052	mention.actual	"stormed"	egyptianprotest_cnn__1000-01-01__timeline:4233-4239	1.000
:Event_0000052	canonical_mention.actual	"stormed"	egyptianprotest_cnn__1000-01-01__timeline:4233-4239	1.000
:Event_0000052	Conflict.Attack_Attacker.actual	:Entity_EDL_0000005	egyptianprotest_cnn__1000-01-01__timeline:4196-4200	1.000
:Event_0000052	Conflict.Attack_Attacker.actual	:Entity_EDL_0000031	egyptianprotest_cnn__1000-01-01__timeline:4219-4222	1.000
:Event_0000052	Conflict.Attack_Target.actual	:Entity_EDL_0000006	egyptianprotest_cnn__1000-01-01__timeline:4245-4252	1.000
:Event_0000053	type	Conflict.Attack
:Event_0000053	mention.actual	"clashes"	egyptianprotest_cnn__1000-01-01__timeline:6479-6485	1.000
:Event_0000053	canonical_mention.actual	"clashes"	egyptianprotest_cnn__1000-01-01__timeline:6479-6485	1.000
:Event_0000053	Conflict.Attack_Target.actual	:Entity_EDL_0000051	egyptianprotest_cnn__1000-01-01__timeline:6435-6440	1.000
:Event_0000053	Conflict.Attack_Target.actual	:Entity_EDL_0000070	egyptianprotest_cnn__1000-01-01__timeline:6457-6462	1.000
:Event_0000053	Conflict.Attack_Attacker.actual	:Entity_EDL_0000098	egyptianprotest_cnn__1000-01-01__timeline:6492-6497	1.000
:Event_0000053	Conflict.Attack_Place.actual	:Entity_EDL_0000046	egyptianprotest_cnn__1000-01-01__timeline:6511-6515	1.000
:Event_0000054	type	Movement.TransportPerson
:Event_0000054	mention.actual	"leave"	egyptianprotest_cnn__1000-01-01__timeline:2226-2230	1.000
:Event_0000054	canonical_mention.actual	"leave"	egyptianprotest_cnn__1000-01-01__timeline:2226-2230	1.000
:Event_0000054	Movement.TransportPerson_Person.actual	:Entity_EDL_0000066	egyptianprotest_cnn__1000-01-01__timeline:2215-2221	1.000
:Event_0000054	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000019	egyptianprotest_cnn__1000-01-01__timeline:2251-2257	1.000
:Event_0000055	type	Conflict.Demonstrate
:Event_0000055	mention.actual	"demonstrations"	egyptianprotest_cnn__1000-01-01__timeline:3027-3040	1.000
:Event_0000055	canonical_mention.actual	"demonstrations"	egyptianprotest_cnn__1000-01-01__timeline:3027-3040	1.000
:Event_0000055	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000037	egyptianprotest_cnn__1000-01-01__timeline:3021-3025	1.000
:Event_0000056	type	Conflict.Attack
:Event_0000056	mention.actual	"fire"	egyptianprotest_cnn__1000-01-01__timeline:2400-2403	1.000
:Event_0000056	canonical_mention.actual	"fire"	egyptianprotest_cnn__1000-01-01__timeline:2400-2403	1.000
:Event_0000056	Conflict.Attack_Attacker.actual	:Entity_EDL_0000018	egyptianprotest_cnn__1000-01-01__timeline:2367-2373	1.000
:Event_0000056	Conflict.Attack_Target.actual	:Entity_EDL_0000017	egyptianprotest_cnn__1000-01-01__timeline:2417-2426	1.000
:Event_0000057	type	Movement.TransportArtifact
:Event_0000057	mention.actual	"move"	egyptianprotest_cnn__1000-01-01__timeline:1276-1279	1.000
:Event_0000057	canonical_mention.actual	"move"	egyptianprotest_cnn__1000-01-01__timeline:1276-1279	1.000
:Event_0000057	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000062	egyptianprotest_cnn__1000-01-01__timeline:1269-1274	1.000
:Event_0000057	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000020	egyptianprotest_cnn__1000-01-01__timeline:1290-1296	1.000
:Event_0000058	type	Personnel.StartPosition
:Event_0000058	mention.actual	"came"	egyptianprotest_cnn__1000-01-01__timeline:7513-7516	1.000
:Event_0000058	canonical_mention.actual	"came"	egyptianprotest_cnn__1000-01-01__timeline:7513-7516	1.000
:Event_0000058	Personnel.StartPosition_Person.actual	:Entity_EDL_0000054	egyptianprotest_cnn__1000-01-01__timeline:7505-7511	1.000
:Event_0000059	type	Personnel.EndPosition
:Event_0000059	mention.actual	"stepped down"	egyptianprotest_cnn__1000-01-01__timeline:7910-7921	1.000
:Event_0000059	canonical_mention.actual	"stepped down"	egyptianprotest_cnn__1000-01-01__timeline:7910-7921	1.000
:Event_0000059	Personnel.EndPosition_Person.actual	:Entity_EDL_0000076	egyptianprotest_cnn__1000-01-01__timeline:7896-7908	1.000
:Event_0000059	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000001	egyptianprotest_cnn__1000-01-01__timeline:7939-7948	1.000
:Event_0000060	type	Conflict.Demonstrate
:Event_0000060	mention.actual	"protests"	egyptianprotest_cnn__1000-01-01__timeline:918-925	1.000
:Event_0000060	canonical_mention.actual	"protests"	egyptianprotest_cnn__1000-01-01__timeline:918-925	1.000
:Event_0000060	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000029	egyptianprotest_cnn__1000-01-01__timeline:899-908	1.000
:Event_0000061	type	Conflict.Attack
:Event_0000061	mention.actual	"clashes"	egyptianprotest_cnn__1000-01-01__timeline:236-242	1.000
:Event_0000061	canonical_mention.actual	"clashes"	egyptianprotest_cnn__1000-01-01__timeline:236-242	1.000
:Event_0000061	Conflict.Attack_Target.actual	:Entity_EDL_0000002	egyptianprotest_cnn__1000-01-01__timeline:222-223	1.000
:Event_0000061	Conflict.Attack_Attacker.actual	:Entity_EDL_0000035	egyptianprotest_cnn__1000-01-01__timeline:252-261	1.000
:Event_0000061	Conflict.Attack_Attacker.actual	:Entity_EDL_0000057	egyptianprotest_cnn__1000-01-01__timeline:267-272	1.000
:Event_0000061	Conflict.Attack_Place.actual	:Entity_EDL_0000033	egyptianprotest_cnn__1000-01-01__timeline:277-281	1.000
:Event_0000061	Conflict.Attack_Place.actual	:Entity_EDL_0000068	egyptianprotest_cnn__1000-01-01__timeline:296-299	1.000
:Event_0000062	type	Movement.TransportPerson
:Event_0000062	mention.actual	"spill into"	egyptianprotest_cnn__1000-01-01__timeline:39-48	1.000
:Event_0000062	canonical_mention.actual	"spill into"	egyptianprotest_cnn__1000-01-01__timeline:39-48	1.000
:Event_0000062	Movement.TransportPerson_Person.actual	:Entity_EDL_0000067	egyptianprotest_cnn__1000-01-01__timeline:28-37	1.000
:Event_0000062	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000084	egyptianprotest_cnn__1000-01-01__timeline:54-60	1.000
:Event_0000063	type	Contact.Contact
:Event_0000063	mention.actual	"interview"	egyptianprotest_cnn__1000-01-01__timeline:2191-2199	1.000
:Event_0000063	canonical_mention.actual	"interview"	egyptianprotest_cnn__1000-01-01__timeline:2191-2199	1.000
:Event_0000063	Contact.Contact_Participant.actual	:Entity_EDL_0000095	egyptianprotest_cnn__1000-01-01__timeline:2187-2189	1.000
:Event_0000063	Contact.Contact_Participant.actual	:Entity_EDL_0000042	egyptianprotest_cnn__1000-01-01__timeline:2203-2204	1.000
