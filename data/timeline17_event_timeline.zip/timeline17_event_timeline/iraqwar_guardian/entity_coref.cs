:Entity_EDL_0000000	type	Organization
:Entity_EDL_0000000	mention	"Al-Qaida"	iraqwar_guardian__1000-01-01__timeline:26264-26271	1.0
:Entity_EDL_0000000	link	NIL000000001
:Entity_EDL_0000001	type	Person
:Entity_EDL_0000001	canonical_mention	"Nine"	iraqwar_guardian__1000-01-01__timeline:253-256	1.0
:Entity_EDL_0000001	pronominal_mention	"Nine"	iraqwar_guardian__1000-01-01__timeline:253-256	1.0
:Entity_EDL_0000001	link	NIL000000002
:Entity_EDL_0000002	type	GeopoliticalEntity
:Entity_EDL_0000002	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:42994-42997	1.0
:Entity_EDL_0000002	link	99237
:Entity_EDL_0000003	type	GeopoliticalEntity
:Entity_EDL_0000003	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:53669-53672	1.0
:Entity_EDL_0000003	link	99237
:Entity_EDL_0000004	type	Person
:Entity_EDL_0000004	canonical_mention	"teachers"	iraqwar_guardian__1000-01-01__timeline:10176-10183	1.0
:Entity_EDL_0000004	nominal_mention	"teachers"	iraqwar_guardian__1000-01-01__timeline:10176-10183	1.0
:Entity_EDL_0000004	link	NIL000000003
:Entity_EDL_0000005	type	GeopoliticalEntity
:Entity_EDL_0000005	canonical_mention	"Basra"	iraqwar_guardian__1000-01-01__timeline:363-367	1.0
:Entity_EDL_0000005	mention	"Basra"	iraqwar_guardian__1000-01-01__timeline:363-367	1.0
:Entity_EDL_0000005	link	99532
:Entity_EDL_0000006	type	Person
:Entity_EDL_0000006	nominal_mention	"terrorist"	iraqwar_guardian__1000-01-01__timeline:24380-24388	1.0
:Entity_EDL_0000006	link	NIL000000004
:Entity_EDL_0000007	type	Person
:Entity_EDL_0000007	canonical_mention	"Ibrahim al-Jaafari"	iraqwar_guardian__1000-01-01__timeline:4318-4335	1.0
:Entity_EDL_0000007	mention	"Ibrahim al-Jaafari"	iraqwar_guardian__1000-01-01__timeline:4318-4335	1.0
:Entity_EDL_0000007	link	30002245
:Entity_EDL_0000008	type	GeopoliticalEntity
:Entity_EDL_0000008	canonical_mention	"town"	iraqwar_guardian__1000-01-01__timeline:33824-33827	1.0
:Entity_EDL_0000008	nominal_mention	"town"	iraqwar_guardian__1000-01-01__timeline:33824-33827	1.0
:Entity_EDL_0000008	link	NIL000000005
:Entity_EDL_0000009	type	GeopoliticalEntity
:Entity_EDL_0000009	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:8860-8863	1.0
:Entity_EDL_0000009	link	99237
:Entity_EDL_0000010	type	Person
:Entity_EDL_0000010	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:34242-34247	1.0
:Entity_EDL_0000010	link	NIL000000006
:Entity_EDL_0000011	type	Location
:Entity_EDL_0000011	nominal_mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:15692-15695	1.0
:Entity_EDL_0000011	link	NIL000000007
:Entity_EDL_0000012	type	GeopoliticalEntity
:Entity_EDL_0000012	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:45242-45245	1.0
:Entity_EDL_0000012	link	99237
:Entity_EDL_0000013	type	Person
:Entity_EDL_0000013	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:3696-3703	1.0
:Entity_EDL_0000013	link	NIL000000008
:Entity_EDL_0000014	type	Person
:Entity_EDL_0000014	nominal_mention	"minister"	iraqwar_guardian__1000-01-01__timeline:37455-37462	1.0
:Entity_EDL_0000014	link	NIL000000009
:Entity_EDL_0000015	type	GeopoliticalEntity
:Entity_EDL_0000015	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:39864-39867	1.0
:Entity_EDL_0000015	link	99237
:Entity_EDL_0000016	type	GeopoliticalEntity
:Entity_EDL_0000016	mention	"Basra"	iraqwar_guardian__1000-01-01__timeline:13316-13320	1.0
:Entity_EDL_0000016	link	99532
:Entity_EDL_0000017	type	Person
:Entity_EDL_0000017	nominal_mention	"forces"	iraqwar_guardian__1000-01-01__timeline:15197-15202	1.0
:Entity_EDL_0000017	link	NIL000000010
:Entity_EDL_0000018	type	Person
:Entity_EDL_0000018	nominal_mention	"Boy"	iraqwar_guardian__1000-01-01__timeline:47651-47653	1.0
:Entity_EDL_0000018	link	NIL000000011
:Entity_EDL_0000019	type	Person
:Entity_EDL_0000019	nominal_mention	"Iraqis"	iraqwar_guardian__1000-01-01__timeline:48016-48021	1.0
:Entity_EDL_0000019	link	NIL000000012
:Entity_EDL_0000020	type	Facility
:Entity_EDL_0000020	nominal_mention	"mosque"	iraqwar_guardian__1000-01-01__timeline:43799-43804	1.0
:Entity_EDL_0000020	link	NIL000000013
:Entity_EDL_0000021	type	Person
:Entity_EDL_0000021	canonical_mention	"Abdullah Abu Azzam"	iraqwar_guardian__1000-01-01__timeline:9436-9453	1.0
:Entity_EDL_0000021	mention	"Abdullah Abu Azzam"	iraqwar_guardian__1000-01-01__timeline:9436-9453	1.0
:Entity_EDL_0000021	link	NIL000000014
:Entity_EDL_0000022	type	Person
:Entity_EDL_0000022	mention	"Saddam"	iraqwar_guardian__1000-01-01__timeline:37991-37996	1.0
:Entity_EDL_0000022	link	NIL000000015
:Entity_EDL_0000023	type	Facility
:Entity_EDL_0000023	nominal_mention	"house"	iraqwar_guardian__1000-01-01__timeline:53845-53849	1.0
:Entity_EDL_0000023	link	NIL000000016
:Entity_EDL_0000024	type	Person
:Entity_EDL_0000024	canonical_mention	"33"	iraqwar_guardian__1000-01-01__timeline:4096-4097	1.0
:Entity_EDL_0000024	pronominal_mention	"33"	iraqwar_guardian__1000-01-01__timeline:4096-4097	1.0
:Entity_EDL_0000024	link	NIL000000017
:Entity_EDL_0000025	type	Person
:Entity_EDL_0000025	canonical_mention	"prisoners"	iraqwar_guardian__1000-01-01__timeline:168-176	1.0
:Entity_EDL_0000025	nominal_mention	"prisoners"	iraqwar_guardian__1000-01-01__timeline:168-176	1.0
:Entity_EDL_0000025	link	NIL000000018
:Entity_EDL_0000026	type	Person
:Entity_EDL_0000026	pronominal_mention	"many"	iraqwar_guardian__1000-01-01__timeline:7231-7234	1.0
:Entity_EDL_0000026	link	NIL000000019
:Entity_EDL_0000027	type	Vehicle
:Entity_EDL_0000027	nominal_mention	"aircraft"	iraqwar_guardian__1000-01-01__timeline:14946-14953	1.0
:Entity_EDL_0000027	link	NIL000000020
:Entity_EDL_0000028	type	Person
:Entity_EDL_0000028	nominal_mention	"prisoners"	iraqwar_guardian__1000-01-01__timeline:10084-10092	1.0
:Entity_EDL_0000028	link	NIL000000021
:Entity_EDL_0000029	type	GeopoliticalEntity
:Entity_EDL_0000029	pronominal_mention	"it"	iraqwar_guardian__1000-01-01__timeline:28307-28308	1.0
:Entity_EDL_0000029	link	NIL000000022
:Entity_EDL_0000030	type	Vehicle
:Entity_EDL_0000030	nominal_mention	"vehicle"	iraqwar_guardian__1000-01-01__timeline:49475-49481	1.0
:Entity_EDL_0000030	link	NIL000000023
:Entity_EDL_0000031	type	GeopoliticalEntity
:Entity_EDL_0000031	mention	"Falluja"	iraqwar_guardian__1000-01-01__timeline:2549-2555	1.0
:Entity_EDL_0000031	link	99454
:Entity_EDL_0000032	type	Person
:Entity_EDL_0000032	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:33418-33423	1.0
:Entity_EDL_0000032	link	NIL000000024
:Entity_EDL_0000033	type	GeopoliticalEntity
:Entity_EDL_0000033	nominal_mention	"Iraqis"	iraqwar_guardian__1000-01-01__timeline:44377-44382	1.0
:Entity_EDL_0000033	link	NIL000000025
:Entity_EDL_0000034	type	Facility
:Entity_EDL_0000034	canonical_mention	"roadblocks"	iraqwar_guardian__1000-01-01__timeline:17405-17414	1.0
:Entity_EDL_0000034	nominal_mention	"roadblocks"	iraqwar_guardian__1000-01-01__timeline:17405-17414	1.0
:Entity_EDL_0000034	link	NIL000000026
:Entity_EDL_0000035	type	Person
:Entity_EDL_0000035	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:51531-51538	1.0
:Entity_EDL_0000035	link	NIL000000027
:Entity_EDL_0000036	type	Person
:Entity_EDL_0000036	nominal_mention	"soldier"	iraqwar_guardian__1000-01-01__timeline:3743-3749	1.0
:Entity_EDL_0000036	link	NIL000000028
:Entity_EDL_0000037	type	GeopoliticalEntity
:Entity_EDL_0000037	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:29663-29666	1.0
:Entity_EDL_0000037	link	99237
:Entity_EDL_0000038	type	Person
:Entity_EDL_0000038	nominal_mention	"forces"	iraqwar_guardian__1000-01-01__timeline:49329-49334	0.000
:Entity_EDL_0000038	link	NIL000000029
:Entity_EDL_0000039	type	Person
:Entity_EDL_0000039	canonical_mention	"Roy Hallums"	iraqwar_guardian__1000-01-01__timeline:49587-49597	1.0
:Entity_EDL_0000039	mention	"Roy Hallums"	iraqwar_guardian__1000-01-01__timeline:49587-49597	1.0
:Entity_EDL_0000039	link	NIL000000030
:Entity_EDL_0000040	type	Person
:Entity_EDL_0000040	mention	"Abu Ghraib"	iraqwar_guardian__1000-01-01__timeline:51638-51647	1.0
:Entity_EDL_0000040	link	NIL000000031
:Entity_EDL_0000041	type	Person
:Entity_EDL_0000041	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:39555-39564	1.0
:Entity_EDL_0000041	link	NIL000000032
:Entity_EDL_0000042	type	Person
:Entity_EDL_0000042	nominal_mention	"detainees"	iraqwar_guardian__1000-01-01__timeline:52120-52128	1.0
:Entity_EDL_0000042	link	NIL000000033
:Entity_EDL_0000043	type	Person
:Entity_EDL_0000043	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:49844-49853	1.0
:Entity_EDL_0000043	link	NIL000000034
:Entity_EDL_0000044	type	GeopoliticalEntity
:Entity_EDL_0000044	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:23881-23884	1.0
:Entity_EDL_0000044	link	99237
:Entity_EDL_0000045	type	Person
:Entity_EDL_0000045	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:37269-37274	1.0
:Entity_EDL_0000045	link	NIL000000035
:Entity_EDL_0000046	type	Person
:Entity_EDL_0000046	canonical_mention	"11"	iraqwar_guardian__1000-01-01__timeline:37334-37335	1.0
:Entity_EDL_0000046	pronominal_mention	"11"	iraqwar_guardian__1000-01-01__timeline:37334-37335	1.0
:Entity_EDL_0000046	link	NIL000000036
:Entity_EDL_0000047	type	Weapon
:Entity_EDL_0000047	nominal_mention	"explosives"	iraqwar_guardian__1000-01-01__timeline:45762-45771	1.0
:Entity_EDL_0000047	link	NIL000000037
:Entity_EDL_0000048	type	Person
:Entity_EDL_0000048	nominal_mention	"agent"	iraqwar_guardian__1000-01-01__timeline:44602-44606	1.0
:Entity_EDL_0000048	link	NIL000000038
:Entity_EDL_0000049	type	Person
:Entity_EDL_0000049	pronominal_mention	"60"	iraqwar_guardian__1000-01-01__timeline:9152-9153	1.0
:Entity_EDL_0000049	link	NIL000000039
:Entity_EDL_0000050	type	Person
:Entity_EDL_0000050	nominal_mention	"police"	iraqwar_guardian__1000-01-01__timeline:27363-27368	1.0
:Entity_EDL_0000050	link	NIL000000040
:Entity_EDL_0000051	type	Person
:Entity_EDL_0000051	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:44438-44445	1.0
:Entity_EDL_0000051	link	NIL000000041
:Entity_EDL_0000052	type	GeopoliticalEntity
:Entity_EDL_0000052	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:11464-11467	1.0
:Entity_EDL_0000052	link	99237
:Entity_EDL_0000053	type	Person
:Entity_EDL_0000053	nominal_mention	"journalist"	iraqwar_guardian__1000-01-01__timeline:21133-21142	1.0
:Entity_EDL_0000053	link	NIL000000042
:Entity_EDL_0000054	type	GeopoliticalEntity
:Entity_EDL_0000054	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:6593-6599	1.0
:Entity_EDL_0000054	link	98182
:Entity_EDL_0000055	type	Person
:Entity_EDL_0000055	canonical_mention	"groups"	iraqwar_guardian__1000-01-01__timeline:18968-18973	1.0
:Entity_EDL_0000055	nominal_mention	"groups"	iraqwar_guardian__1000-01-01__timeline:18968-18973	1.0
:Entity_EDL_0000055	link	NIL000000043
:Entity_EDL_0000056	type	Weapon
:Entity_EDL_0000056	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:3732-3735	1.0
:Entity_EDL_0000056	link	NIL000000044
:Entity_EDL_0000057	type	Weapon
:Entity_EDL_0000057	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:15613-15616	1.0
:Entity_EDL_0000057	link	NIL000000045
:Entity_EDL_0000058	type	Facility
:Entity_EDL_0000058	nominal_mention	"stronghold"	iraqwar_guardian__1000-01-01__timeline:21057-21066	1.0
:Entity_EDL_0000058	link	NIL000000046
:Entity_EDL_0000059	type	Person
:Entity_EDL_0000059	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:13839-13844	1.0
:Entity_EDL_0000059	link	NIL000000047
:Entity_EDL_0000060	type	Person
:Entity_EDL_0000060	canonical_mention	"Tony Blair"	iraqwar_guardian__1000-01-01__timeline:345-354	1.0
:Entity_EDL_0000060	mention	"Tony Blair"	iraqwar_guardian__1000-01-01__timeline:345-354	1.0
:Entity_EDL_0000060	link	NIL000000048
:Entity_EDL_0000061	type	Person
:Entity_EDL_0000061	canonical_mention	"journalist"	iraqwar_guardian__1000-01-01__timeline:6666-6675	1.0
:Entity_EDL_0000061	nominal_mention	"journalist"	iraqwar_guardian__1000-01-01__timeline:6666-6675	1.0
:Entity_EDL_0000061	link	NIL000000049
:Entity_EDL_0000062	type	GeopoliticalEntity
:Entity_EDL_0000062	canonical_mention	"Israel"	iraqwar_guardian__1000-01-01__timeline:26554-26559	1.0
:Entity_EDL_0000062	mention	"Israel"	iraqwar_guardian__1000-01-01__timeline:26554-26559	1.0
:Entity_EDL_0000062	link	294640
:Entity_EDL_0000063	type	Person
:Entity_EDL_0000063	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:53904-53909	1.0
:Entity_EDL_0000063	link	NIL000000050
:Entity_EDL_0000064	type	Person
:Entity_EDL_0000064	canonical_mention	"hundreds"	iraqwar_guardian__1000-01-01__timeline:14907-14914	1.0
:Entity_EDL_0000064	pronominal_mention	"hundreds"	iraqwar_guardian__1000-01-01__timeline:14907-14914	1.0
:Entity_EDL_0000064	link	NIL000000051
:Entity_EDL_0000065	type	Vehicle
:Entity_EDL_0000065	nominal_mention	"car"	iraqwar_guardian__1000-01-01__timeline:49955-49957	1.0
:Entity_EDL_0000065	link	NIL000000052
:Entity_EDL_0000066	type	Person
:Entity_EDL_0000066	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:53254-53263	1.0
:Entity_EDL_0000066	link	NIL000000053
:Entity_EDL_0000067	type	Facility
:Entity_EDL_0000067	canonical_mention	"mosques"	iraqwar_guardian__1000-01-01__timeline:45851-45857	1.0
:Entity_EDL_0000067	nominal_mention	"mosques"	iraqwar_guardian__1000-01-01__timeline:45851-45857	1.0
:Entity_EDL_0000067	link	NIL000000054
:Entity_EDL_0000068	type	Person
:Entity_EDL_0000068	mention	"Abu Musab al-Zarqawi"	iraqwar_guardian__1000-01-01__timeline:50118-50137	1.0
:Entity_EDL_0000068	link	NIL000000055
:Entity_EDL_0000069	type	Person
:Entity_EDL_0000069	canonical_mention	"boys"	iraqwar_guardian__1000-01-01__timeline:6826-6829	1.0
:Entity_EDL_0000069	nominal_mention	"boys"	iraqwar_guardian__1000-01-01__timeline:6826-6829	1.0
:Entity_EDL_0000069	link	NIL000000056
:Entity_EDL_0000070	type	Person
:Entity_EDL_0000070	nominal_mention	"prisoner"	iraqwar_guardian__1000-01-01__timeline:37038-37045	1.0
:Entity_EDL_0000070	link	NIL000000057
:Entity_EDL_0000071	type	GeopoliticalEntity
:Entity_EDL_0000071	nominal_mention	"city"	iraqwar_guardian__1000-01-01__timeline:53873-53876	1.0
:Entity_EDL_0000071	link	NIL000000058
:Entity_EDL_0000072	type	Facility
:Entity_EDL_0000072	canonical_mention	"Abu Ghraib prison"	iraqwar_guardian__1000-01-01__timeline:39691-39707	1.0
:Entity_EDL_0000072	mention	"Abu Ghraib prison"	iraqwar_guardian__1000-01-01__timeline:39691-39707	1.0
:Entity_EDL_0000072	link	NIL000000059
:Entity_EDL_0000073	type	GeopoliticalEntity
:Entity_EDL_0000073	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:28217-28220	1.0
:Entity_EDL_0000073	link	99237
:Entity_EDL_0000074	type	Person
:Entity_EDL_0000074	canonical_mention	"Lynndie England"	iraqwar_guardian__1000-01-01__timeline:9742-9756	1.0
:Entity_EDL_0000074	mention	"Lynndie England"	iraqwar_guardian__1000-01-01__timeline:9742-9756	1.0
:Entity_EDL_0000074	link	NIL000000060
:Entity_EDL_0000075	type	Person
:Entity_EDL_0000075	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:50515-50522	1.0
:Entity_EDL_0000075	link	NIL000000061
:Entity_EDL_0000076	type	GeopoliticalEntity
:Entity_EDL_0000076	mention	"Iraqi"	iraqwar_guardian__1000-01-01__timeline:48550-48554	1.0
:Entity_EDL_0000076	link	99237
:Entity_EDL_0000077	type	Facility
:Entity_EDL_0000077	mention	"Abu Ghraib prison"	iraqwar_guardian__1000-01-01__timeline:51604-51620	1.0
:Entity_EDL_0000077	link	NIL000000062
:Entity_EDL_0000078	type	Person
:Entity_EDL_0000078	canonical_mention	"hundreds of thousands"	iraqwar_guardian__1000-01-01__timeline:16014-16034	1.0
:Entity_EDL_0000078	nominal_mention	"hundreds of thousands"	iraqwar_guardian__1000-01-01__timeline:16014-16034	1.0
:Entity_EDL_0000078	link	NIL000000063
:Entity_EDL_0000079	type	Person
:Entity_EDL_0000079	pronominal_mention	"dozens"	iraqwar_guardian__1000-01-01__timeline:37552-37557	1.0
:Entity_EDL_0000079	link	NIL000000064
:Entity_EDL_0000080	type	GeopoliticalEntity
:Entity_EDL_0000080	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:26276-26279	1.0
:Entity_EDL_0000080	link	99237
:Entity_EDL_0000081	type	Person
:Entity_EDL_0000081	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:51708-51717	1.0
:Entity_EDL_0000081	link	NIL000000065
:Entity_EDL_0000082	type	Person
:Entity_EDL_0000082	pronominal_mention	"22"	iraqwar_guardian__1000-01-01__timeline:36812-36813	1.0
:Entity_EDL_0000082	link	NIL000000066
:Entity_EDL_0000083	type	Person
:Entity_EDL_0000083	pronominal_mention	"20"	iraqwar_guardian__1000-01-01__timeline:21595-21596	1.0
:Entity_EDL_0000083	link	NIL000000067
:Entity_EDL_0000084	type	Person
:Entity_EDL_0000084	canonical_mention	"people"	iraqwar_guardian__1000-01-01__timeline:16-21	1.0
:Entity_EDL_0000084	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:16-21	1.0
:Entity_EDL_0000084	link	NIL000000068
:Entity_EDL_0000085	type	Person
:Entity_EDL_0000085	canonical_mention	"58"	iraqwar_guardian__1000-01-01__timeline:34046-34047	1.0
:Entity_EDL_0000085	pronominal_mention	"58"	iraqwar_guardian__1000-01-01__timeline:34046-34047	1.0
:Entity_EDL_0000085	link	NIL000000069
:Entity_EDL_0000086	type	Person
:Entity_EDL_0000086	canonical_mention	"rescuer"	iraqwar_guardian__1000-01-01__timeline:44651-44657	1.0
:Entity_EDL_0000086	nominal_mention	"rescuer"	iraqwar_guardian__1000-01-01__timeline:44651-44657	1.0
:Entity_EDL_0000086	link	NIL000000070
:Entity_EDL_0000087	type	Person
:Entity_EDL_0000087	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:29037-29046	1.0
:Entity_EDL_0000087	link	NIL000000071
:Entity_EDL_0000088	type	Person
:Entity_EDL_0000088	canonical_mention	"MP"	iraqwar_guardian__1000-01-01__timeline:33244-33245	1.0
:Entity_EDL_0000088	nominal_mention	"MP"	iraqwar_guardian__1000-01-01__timeline:33244-33245	1.0
:Entity_EDL_0000088	link	NIL000000072
:Entity_EDL_0000089	type	Person
:Entity_EDL_0000089	canonical_mention	"24,865"	iraqwar_guardian__1000-01-01__timeline:23858-23863	1.0
:Entity_EDL_0000089	nominal_mention	"24,865"	iraqwar_guardian__1000-01-01__timeline:23858-23863	1.0
:Entity_EDL_0000089	link	NIL000000073
:Entity_EDL_0000090	type	Weapon
:Entity_EDL_0000090	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:2522-2525	1.0
:Entity_EDL_0000090	link	NIL000000074
:Entity_EDL_0000091	type	GeopoliticalEntity
:Entity_EDL_0000091	mention	"Basra"	iraqwar_guardian__1000-01-01__timeline:21162-21166	1.0
:Entity_EDL_0000091	link	99532
:Entity_EDL_0000092	type	GeopoliticalEntity
:Entity_EDL_0000092	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:43565-43568	1.0
:Entity_EDL_0000092	link	99237
:Entity_EDL_0000093	type	Person
:Entity_EDL_0000093	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:9577-9582	1.0
:Entity_EDL_0000093	link	NIL000000075
:Entity_EDL_0000095	type	Person
:Entity_EDL_0000095	canonical_mention	"60"	iraqwar_guardian__1000-01-01__timeline:34303-34304	1.0
:Entity_EDL_0000095	nominal_mention	"60"	iraqwar_guardian__1000-01-01__timeline:34303-34304	1.0
:Entity_EDL_0000095	link	NIL000000077
:Entity_EDL_0000096	type	GeopoliticalEntity
:Entity_EDL_0000096	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:14072-14078	1.0
:Entity_EDL_0000096	link	98182
:Entity_EDL_0000097	type	Facility
:Entity_EDL_0000097	nominal_mention	"streets"	iraqwar_guardian__1000-01-01__timeline:16328-16334	1.0
:Entity_EDL_0000097	link	NIL000000078
:Entity_EDL_0000098	type	Vehicle
:Entity_EDL_0000098	canonical_mention	"warplanes"	iraqwar_guardian__1000-01-01__timeline:27667-27675	1.0
:Entity_EDL_0000098	nominal_mention	"warplanes"	iraqwar_guardian__1000-01-01__timeline:27667-27675	1.0
:Entity_EDL_0000098	link	NIL000000079
:Entity_EDL_0000099	type	Person
:Entity_EDL_0000099	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:29522-29527	1.0
:Entity_EDL_0000099	link	NIL000000080
:Entity_EDL_0000100	type	Person
:Entity_EDL_0000100	canonical_mention	"more"	iraqwar_guardian__1000-01-01__timeline:1959-1962	1.0
:Entity_EDL_0000100	pronominal_mention	"more"	iraqwar_guardian__1000-01-01__timeline:1959-1962	1.0
:Entity_EDL_0000100	link	NIL000000081
:Entity_EDL_0000101	type	Person
:Entity_EDL_0000101	canonical_mention	"opponents"	iraqwar_guardian__1000-01-01__timeline:29907-29915	1.0
:Entity_EDL_0000101	nominal_mention	"opponents"	iraqwar_guardian__1000-01-01__timeline:29907-29915	1.0
:Entity_EDL_0000101	link	NIL000000082
:Entity_EDL_0000102	type	GeopoliticalEntity
:Entity_EDL_0000102	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:37383-37386	1.0
:Entity_EDL_0000102	link	99237
:Entity_EDL_0000103	type	Facility
:Entity_EDL_0000103	nominal_mention	"academy"	iraqwar_guardian__1000-01-01__timeline:2005-2011	1.0
:Entity_EDL_0000103	link	NIL000000083
:Entity_EDL_0000104	type	Person
:Entity_EDL_0000104	nominal_mention	"soldier"	iraqwar_guardian__1000-01-01__timeline:10052-10058	1.0
:Entity_EDL_0000104	link	NIL000000084
:Entity_EDL_0000105	type	Person
:Entity_EDL_0000105	pronominal_mention	"them"	iraqwar_guardian__1000-01-01__timeline:31503-31506	1.0
:Entity_EDL_0000105	link	NIL000000085
:Entity_EDL_0000106	type	Person
:Entity_EDL_0000106	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:47454-47461	1.0
:Entity_EDL_0000106	link	NIL000000086
:Entity_EDL_0000107	type	Organization
:Entity_EDL_0000107	mention	"Guardian"	iraqwar_guardian__1000-01-01__timeline:36366-36373	1.0
:Entity_EDL_0000107	link	NIL000000087
:Entity_EDL_0000108	type	Person
:Entity_EDL_0000108	canonical_mention	"Abu Musab al-Zarqawi"	iraqwar_guardian__1000-01-01__timeline:7817-7836	1.0
:Entity_EDL_0000108	mention	"Abu Musab al-Zarqawi"	iraqwar_guardian__1000-01-01__timeline:7817-7836	1.0
:Entity_EDL_0000108	link	NIL000000088
:Entity_EDL_0000109	type	Person
:Entity_EDL_0000109	nominal_mention	"militants"	iraqwar_guardian__1000-01-01__timeline:49344-49352	1.0
:Entity_EDL_0000109	link	NIL000000089
:Entity_EDL_0000110	type	Person
:Entity_EDL_0000110	nominal_mention	"bombers"	iraqwar_guardian__1000-01-01__timeline:45823-45829	1.0
:Entity_EDL_0000110	link	NIL000000090
:Entity_EDL_0000111	type	Facility
:Entity_EDL_0000111	canonical_mention	"academy"	iraqwar_guardian__1000-01-01__timeline:1937-1943	1.0
:Entity_EDL_0000111	nominal_mention	"academy"	iraqwar_guardian__1000-01-01__timeline:1937-1943	1.0
:Entity_EDL_0000111	link	NIL000000091
:Entity_EDL_0000112	type	Person
:Entity_EDL_0000112	pronominal_mention	"he"	iraqwar_guardian__1000-01-01__timeline:31338-31339	1.0
:Entity_EDL_0000112	link	NIL000000092
:Entity_EDL_0000113	type	Location
:Entity_EDL_0000113	nominal_mention	"district"	iraqwar_guardian__1000-01-01__timeline:49290-49297	1.0
:Entity_EDL_0000113	link	NIL000000093
:Entity_EDL_0000114	type	GeopoliticalEntity
:Entity_EDL_0000114	mention	"Britain"	iraqwar_guardian__1000-01-01__timeline:51625-51631	1.0
:Entity_EDL_0000114	link	2635167
:Entity_EDL_0000115	type	Person
:Entity_EDL_0000115	canonical_mention	"him"	iraqwar_guardian__1000-01-01__timeline:719-721	1.0
:Entity_EDL_0000115	pronominal_mention	"him"	iraqwar_guardian__1000-01-01__timeline:719-721	1.0
:Entity_EDL_0000115	link	NIL000000094
:Entity_EDL_0000116	type	Vehicle
:Entity_EDL_0000116	nominal_mention	"car"	iraqwar_guardian__1000-01-01__timeline:33767-33769	1.0
:Entity_EDL_0000116	link	NIL000000095
:Entity_EDL_0000117	type	Person
:Entity_EDL_0000117	mention	"Ayad Allawi"	iraqwar_guardian__1000-01-01__timeline:49928-49938	1.0
:Entity_EDL_0000117	link	30002229
:Entity_EDL_0000118	type	Person
:Entity_EDL_0000118	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:50807-50812	1.0
:Entity_EDL_0000118	link	NIL000000096
:Entity_EDL_0000119	type	Person
:Entity_EDL_0000119	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:23551-23558	1.0
:Entity_EDL_0000119	link	NIL000000097
:Entity_EDL_0000120	type	Person
:Entity_EDL_0000120	canonical_mention	"15"	iraqwar_guardian__1000-01-01__timeline:38458-38459	1.0
:Entity_EDL_0000120	pronominal_mention	"15"	iraqwar_guardian__1000-01-01__timeline:38458-38459	1.0
:Entity_EDL_0000120	link	NIL000000098
:Entity_EDL_0000121	type	GeopoliticalEntity
:Entity_EDL_0000121	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:41036-41039	1.0
:Entity_EDL_0000121	link	99237
:Entity_EDL_0000122	type	GeopoliticalEntity
:Entity_EDL_0000122	canonical_mention	"sides"	iraqwar_guardian__1000-01-01__timeline:28792-28796	1.0
:Entity_EDL_0000122	nominal_mention	"sides"	iraqwar_guardian__1000-01-01__timeline:28792-28796	1.0
:Entity_EDL_0000122	link	NIL000000099
:Entity_EDL_0000123	type	Person
:Entity_EDL_0000123	pronominal_mention	"others"	iraqwar_guardian__1000-01-01__timeline:34272-34277	1.0
:Entity_EDL_0000123	link	NIL000000100
:Entity_EDL_0000124	type	Facility
:Entity_EDL_0000124	nominal_mention	"prison"	iraqwar_guardian__1000-01-01__timeline:44367-44372	1.0
:Entity_EDL_0000124	link	NIL000000101
:Entity_EDL_0000125	type	GeopoliticalEntity
:Entity_EDL_0000125	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:23933-23936	1.0
:Entity_EDL_0000125	link	99237
:Entity_EDL_0000126	type	Facility
:Entity_EDL_0000126	canonical_mention	"Abu Ghraib jail"	iraqwar_guardian__1000-01-01__timeline:9796-9810	1.0
:Entity_EDL_0000126	mention	"Abu Ghraib jail"	iraqwar_guardian__1000-01-01__timeline:9796-9810	1.0
:Entity_EDL_0000126	link	NIL000000102
:Entity_EDL_0000127	type	Person
:Entity_EDL_0000127	pronominal_mention	"hundreds"	iraqwar_guardian__1000-01-01__timeline:16109-16116	1.0
:Entity_EDL_0000127	link	NIL000000103
:Entity_EDL_0000128	type	Facility
:Entity_EDL_0000128	nominal_mention	"school"	iraqwar_guardian__1000-01-01__timeline:10203-10208	1.0
:Entity_EDL_0000128	link	NIL000000104
:Entity_EDL_0000129	type	GeopoliticalEntity
:Entity_EDL_0000129	mention	"London"	iraqwar_guardian__1000-01-01__timeline:42884-42889	1.0
:Entity_EDL_0000129	link	2643743
:Entity_EDL_0000130	type	Facility
:Entity_EDL_0000130	nominal_mention	"stronghold"	iraqwar_guardian__1000-01-01__timeline:15222-15231	1.0
:Entity_EDL_0000130	link	NIL000000105
:Entity_EDL_0000131	type	Person
:Entity_EDL_0000131	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:12246-12251	1.0
:Entity_EDL_0000131	link	NIL000000106
:Entity_EDL_0000132	type	Facility
:Entity_EDL_0000132	canonical_mention	"bridge"	iraqwar_guardian__1000-01-01__timeline:15924-15929	1.0
:Entity_EDL_0000132	nominal_mention	"bridge"	iraqwar_guardian__1000-01-01__timeline:15924-15929	1.0
:Entity_EDL_0000132	link	NIL000000107
:Entity_EDL_0000133	type	GeopoliticalEntity
:Entity_EDL_0000133	nominal_mention	"country"	iraqwar_guardian__1000-01-01__timeline:4266-4272	1.0
:Entity_EDL_0000133	link	NIL000000108
:Entity_EDL_0000134	type	Person
:Entity_EDL_0000134	canonical_mention	"politicians"	iraqwar_guardian__1000-01-01__timeline:18491-18501	1.0
:Entity_EDL_0000134	nominal_mention	"politicians"	iraqwar_guardian__1000-01-01__timeline:18491-18501	1.0
:Entity_EDL_0000134	link	NIL000000109
:Entity_EDL_0000135	type	Person
:Entity_EDL_0000135	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:7089-7098	1.0
:Entity_EDL_0000135	link	NIL000000110
:Entity_EDL_0000136	type	GeopoliticalEntity
:Entity_EDL_0000136	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:2903-2906	1.0
:Entity_EDL_0000136	link	99237
:Entity_EDL_0000137	type	Person
:Entity_EDL_0000137	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:51771-51776	1.0
:Entity_EDL_0000137	link	NIL000000111
:Entity_EDL_0000138	type	Weapon
:Entity_EDL_0000138	nominal_mention	"bombs"	iraqwar_guardian__1000-01-01__timeline:13156-13160	0.000
:Entity_EDL_0000138	link	NIL000000112
:Entity_EDL_0000139	type	Person
:Entity_EDL_0000139	nominal_mention	"minister"	iraqwar_guardian__1000-01-01__timeline:38564-38571	1.0
:Entity_EDL_0000139	link	NIL000000113
:Entity_EDL_0000140	type	GeopoliticalEntity
:Entity_EDL_0000140	canonical_mention	"G8 Gleneagles"	iraqwar_guardian__1000-01-01__timeline:26054-26066	1.0
:Entity_EDL_0000140	mention	"G8 Gleneagles"	iraqwar_guardian__1000-01-01__timeline:26054-26066	1.0
:Entity_EDL_0000140	link	NIL000000114
:Entity_EDL_0000141	type	Person
:Entity_EDL_0000141	nominal_mention	"they"	iraqwar_guardian__1000-01-01__timeline:45710-45713	1.0
:Entity_EDL_0000141	link	NIL000000115
:Entity_EDL_0000142	type	GeopoliticalEntity
:Entity_EDL_0000142	canonical_mention	"Iran"	iraqwar_guardian__1000-01-01__timeline:8330-8333	1.0
:Entity_EDL_0000142	mention	"Iran"	iraqwar_guardian__1000-01-01__timeline:8330-8333	1.0
:Entity_EDL_0000142	link	130758
:Entity_EDL_0000143	type	Person
:Entity_EDL_0000143	mention	"Saddam Hussein"	iraqwar_guardian__1000-01-01__timeline:35542-35555	1.0
:Entity_EDL_0000143	link	NIL000000116
:Entity_EDL_0000144	type	Person
:Entity_EDL_0000144	nominal_mention	"journalist"	iraqwar_guardian__1000-01-01__timeline:6445-6454	1.0
:Entity_EDL_0000144	link	NIL000000117
:Entity_EDL_0000145	type	Person
:Entity_EDL_0000145	canonical_mention	"reporter"	iraqwar_guardian__1000-01-01__timeline:13460-13467	1.0
:Entity_EDL_0000145	nominal_mention	"reporter"	iraqwar_guardian__1000-01-01__timeline:13460-13467	1.0
:Entity_EDL_0000145	link	NIL000000118
:Entity_EDL_0000146	type	Person
:Entity_EDL_0000146	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:50712-50717	1.0
:Entity_EDL_0000146	link	NIL000000119
:Entity_EDL_0000147	type	GeopoliticalEntity
:Entity_EDL_0000147	mention	"US"	iraqwar_guardian__1000-01-01__timeline:29014-29015	1.0
:Entity_EDL_0000147	link	6252001
:Entity_EDL_0000148	type	Person
:Entity_EDL_0000148	pronominal_mention	"others"	iraqwar_guardian__1000-01-01__timeline:36656-36661	1.0
:Entity_EDL_0000148	link	NIL000000120
:Entity_EDL_0000149	type	Person
:Entity_EDL_0000149	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:18318-18323	1.0
:Entity_EDL_0000149	link	NIL000000121
:Entity_EDL_0000150	type	GeopoliticalEntity
:Entity_EDL_0000150	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:4351-4354	1.0
:Entity_EDL_0000150	link	99237
:Entity_EDL_0000151	type	Person
:Entity_EDL_0000151	nominal_mention	"paratroopers"	iraqwar_guardian__1000-01-01__timeline:47052-47063	1.0
:Entity_EDL_0000151	link	NIL000000122
:Entity_EDL_0000152	type	Person
:Entity_EDL_0000152	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:48727-48736	1.0
:Entity_EDL_0000152	link	NIL000000123
:Entity_EDL_0000153	type	Person
:Entity_EDL_0000153	canonical_mention	"Guardsman"	iraqwar_guardian__1000-01-01__timeline:34381-34389	1.0
:Entity_EDL_0000153	nominal_mention	"Guardsman"	iraqwar_guardian__1000-01-01__timeline:34381-34389	1.0
:Entity_EDL_0000153	link	NIL000000124
:Entity_EDL_0000154	type	Person
:Entity_EDL_0000154	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:27301-27310	1.0
:Entity_EDL_0000154	link	NIL000000125
:Entity_EDL_0000155	type	GeopoliticalEntity
:Entity_EDL_0000155	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:26012-26015	1.0
:Entity_EDL_0000155	link	99237
:Entity_EDL_0000156	type	Vehicle
:Entity_EDL_0000156	canonical_mention	"tank"	iraqwar_guardian__1000-01-01__timeline:13064-13067	1.0
:Entity_EDL_0000156	nominal_mention	"tank"	iraqwar_guardian__1000-01-01__timeline:13064-13067	1.0
:Entity_EDL_0000156	link	NIL000000126
:Entity_EDL_0000157	type	Organization
:Entity_EDL_0000157	nominal_mention	"court"	iraqwar_guardian__1000-01-01__timeline:47467-47471	1.0
:Entity_EDL_0000157	link	NIL000000127
:Entity_EDL_0000158	type	GeopoliticalEntity
:Entity_EDL_0000158	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:48643-48646	1.0
:Entity_EDL_0000158	link	99237
:Entity_EDL_0000159	type	Location
:Entity_EDL_0000159	canonical_mention	"outskirts"	iraqwar_guardian__1000-01-01__timeline:13639-13647	1.0
:Entity_EDL_0000159	nominal_mention	"outskirts"	iraqwar_guardian__1000-01-01__timeline:13639-13647	1.0
:Entity_EDL_0000159	link	NIL000000128
:Entity_EDL_0000160	type	GeopoliticalEntity
:Entity_EDL_0000160	canonical_mention	"village"	iraqwar_guardian__1000-01-01__timeline:50866-50872	1.0
:Entity_EDL_0000160	nominal_mention	"village"	iraqwar_guardian__1000-01-01__timeline:50866-50872	1.0
:Entity_EDL_0000160	link	NIL000000129
:Entity_EDL_0000161	type	GeopoliticalEntity
:Entity_EDL_0000161	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:42114-42117	1.0
:Entity_EDL_0000161	link	99237
:Entity_EDL_0000162	type	Person
:Entity_EDL_0000162	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:26200-26205	1.0
:Entity_EDL_0000162	link	NIL000000130
:Entity_EDL_0000163	type	Person
:Entity_EDL_0000163	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:11288-11293	1.0
:Entity_EDL_0000163	link	NIL000000131
:Entity_EDL_0000164	type	GeopoliticalEntity
:Entity_EDL_0000164	mention	"London"	iraqwar_guardian__1000-01-01__timeline:24401-24406	1.0
:Entity_EDL_0000164	link	2643743
:Entity_EDL_0000165	type	Weapon
:Entity_EDL_0000165	nominal_mention	"Bombs"	iraqwar_guardian__1000-01-01__timeline:36801-36805	1.0
:Entity_EDL_0000165	link	NIL000000132
:Entity_EDL_0000166	type	Vehicle
:Entity_EDL_0000166	nominal_mention	"truck"	iraqwar_guardian__1000-01-01__timeline:22764-22768	1.0
:Entity_EDL_0000166	link	NIL000000133
:Entity_EDL_0000167	type	Person
:Entity_EDL_0000167	canonical_mention	"70"	iraqwar_guardian__1000-01-01__timeline:7291-7292	1.0
:Entity_EDL_0000167	nominal_mention	"70"	iraqwar_guardian__1000-01-01__timeline:7291-7292	1.0
:Entity_EDL_0000167	link	NIL000000134
:Entity_EDL_0000168	type	Person
:Entity_EDL_0000168	nominal_mention	"governor"	iraqwar_guardian__1000-01-01__timeline:54352-54359	1.0
:Entity_EDL_0000168	link	NIL000000135
:Entity_EDL_0000169	type	Person
:Entity_EDL_0000169	canonical_mention	"rebels"	iraqwar_guardian__1000-01-01__timeline:14612-14617	1.0
:Entity_EDL_0000169	nominal_mention	"rebels"	iraqwar_guardian__1000-01-01__timeline:14612-14617	1.0
:Entity_EDL_0000169	link	NIL000000136
:Entity_EDL_0000170	type	GeopoliticalEntity
:Entity_EDL_0000170	mention	"US"	iraqwar_guardian__1000-01-01__timeline:5310-5311	1.0
:Entity_EDL_0000170	link	6252001
:Entity_EDL_0000171	type	Facility
:Entity_EDL_0000171	canonical_mention	"checkpoint"	iraqwar_guardian__1000-01-01__timeline:21547-21556	1.0
:Entity_EDL_0000171	nominal_mention	"checkpoint"	iraqwar_guardian__1000-01-01__timeline:21547-21556	1.0
:Entity_EDL_0000171	link	NIL000000137
:Entity_EDL_0000172	type	Organization
:Entity_EDL_0000172	canonical_mention	"RAF"	iraqwar_guardian__1000-01-01__timeline:27798-27800	1.0
:Entity_EDL_0000172	mention	"RAF"	iraqwar_guardian__1000-01-01__timeline:27798-27800	1.0
:Entity_EDL_0000172	link	NIL000000138
:Entity_EDL_0000173	type	GeopoliticalEntity
:Entity_EDL_0000173	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:47258-47261	1.0
:Entity_EDL_0000173	link	99237
:Entity_EDL_0000174	type	GeopoliticalEntity
:Entity_EDL_0000174	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:40123-40126	1.0
:Entity_EDL_0000174	link	99237
:Entity_EDL_0000175	type	Person
:Entity_EDL_0000175	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:45805-45810	1.0
:Entity_EDL_0000175	link	NIL000000139
:Entity_EDL_0000176	type	Person
:Entity_EDL_0000176	nominal_mention	"forces"	iraqwar_guardian__1000-01-01__timeline:27870-27875	1.0
:Entity_EDL_0000176	link	NIL000000140
:Entity_EDL_0000177	type	GeopoliticalEntity
:Entity_EDL_0000177	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:26941-26944	1.0
:Entity_EDL_0000177	link	99237
:Entity_EDL_0000178	type	Vehicle
:Entity_EDL_0000178	canonical_mention	"minibus"	iraqwar_guardian__1000-01-01__timeline:3003-3009	1.0
:Entity_EDL_0000178	nominal_mention	"minibus"	iraqwar_guardian__1000-01-01__timeline:3003-3009	1.0
:Entity_EDL_0000178	link	NIL000000141
:Entity_EDL_0000179	type	Person
:Entity_EDL_0000179	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:10519-10524	1.0
:Entity_EDL_0000179	link	NIL000000142
:Entity_EDL_0000180	type	Person
:Entity_EDL_0000180	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:31453-31458	1.0
:Entity_EDL_0000180	link	NIL000000143
:Entity_EDL_0000181	type	GeopoliticalEntity
:Entity_EDL_0000181	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:38541-38544	1.0
:Entity_EDL_0000181	link	99237
:Entity_EDL_0000182	type	Person
:Entity_EDL_0000182	canonical_mention	"Ayad Allawi"	iraqwar_guardian__1000-01-01__timeline:1126-1136	1.0
:Entity_EDL_0000182	mention	"Ayad Allawi"	iraqwar_guardian__1000-01-01__timeline:1126-1136	1.0
:Entity_EDL_0000182	link	30002229
:Entity_EDL_0000183	type	Vehicle
:Entity_EDL_0000183	nominal_mention	"helicopters"	iraqwar_guardian__1000-01-01__timeline:41782-41792	1.0
:Entity_EDL_0000183	link	NIL000000144
:Entity_EDL_0000184	type	Location
:Entity_EDL_0000184	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:17132-17135	1.0
:Entity_EDL_0000184	link	99237
:Entity_EDL_0000185	type	Person
:Entity_EDL_0000185	nominal_mention	"worshippers"	iraqwar_guardian__1000-01-01__timeline:50749-50759	1.0
:Entity_EDL_0000185	link	NIL000000145
:Entity_EDL_0000186	type	Vehicle
:Entity_EDL_0000186	nominal_mention	"car"	iraqwar_guardian__1000-01-01__timeline:44470-44472	1.0
:Entity_EDL_0000186	link	NIL000000146
:Entity_EDL_0000187	type	Facility
:Entity_EDL_0000187	nominal_mention	"station"	iraqwar_guardian__1000-01-01__timeline:18243-18249	1.0
:Entity_EDL_0000187	link	NIL000000147
:Entity_EDL_0000188	type	Person
:Entity_EDL_0000188	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:182-191	1.0
:Entity_EDL_0000188	link	NIL000000148
:Entity_EDL_0000189	type	Person
:Entity_EDL_0000189	canonical_mention	"jailors"	iraqwar_guardian__1000-01-01__timeline:700-706	1.0
:Entity_EDL_0000189	nominal_mention	"jailors"	iraqwar_guardian__1000-01-01__timeline:700-706	1.0
:Entity_EDL_0000189	link	NIL000000149
:Entity_EDL_0000190	type	Person
:Entity_EDL_0000190	canonical_mention	"pilgrims"	iraqwar_guardian__1000-01-01__timeline:15880-15887	1.0
:Entity_EDL_0000190	nominal_mention	"pilgrims"	iraqwar_guardian__1000-01-01__timeline:15880-15887	1.0
:Entity_EDL_0000190	link	NIL000000150
:Entity_EDL_0000191	type	Person
:Entity_EDL_0000191	pronominal_mention	"700"	iraqwar_guardian__1000-01-01__timeline:16218-16220	1.0
:Entity_EDL_0000191	link	NIL000000151
:Entity_EDL_0000192	type	Organization
:Entity_EDL_0000192	canonical_mention	"administration"	iraqwar_guardian__1000-01-01__timeline:10723-10736	1.0
:Entity_EDL_0000192	nominal_mention	"administration"	iraqwar_guardian__1000-01-01__timeline:10723-10736	1.0
:Entity_EDL_0000192	link	NIL000000152
:Entity_EDL_0000193	type	Person
:Entity_EDL_0000193	nominal_mention	"Insurgents"	iraqwar_guardian__1000-01-01__timeline:49126-49135	1.0
:Entity_EDL_0000193	link	NIL000000153
:Entity_EDL_0000194	type	Person
:Entity_EDL_0000194	canonical_mention	"seven"	iraqwar_guardian__1000-01-01__timeline:50910-50914	1.0
:Entity_EDL_0000194	pronominal_mention	"seven"	iraqwar_guardian__1000-01-01__timeline:50910-50914	1.0
:Entity_EDL_0000194	link	NIL000000154
:Entity_EDL_0000195	type	GeopoliticalEntity
:Entity_EDL_0000195	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:22382-22385	1.0
:Entity_EDL_0000195	link	99237
:Entity_EDL_0000196	type	Person
:Entity_EDL_0000196	mention	"Iraqi"	iraqwar_guardian__1000-01-01__timeline:4988-4992	1.0
:Entity_EDL_0000196	link	99237
:Entity_EDL_0000197	type	Person
:Entity_EDL_0000197	canonical_mention	"detainees"	iraqwar_guardian__1000-01-01__timeline:23631-23639	1.0
:Entity_EDL_0000197	nominal_mention	"detainees"	iraqwar_guardian__1000-01-01__timeline:23631-23639	1.0
:Entity_EDL_0000197	link	NIL000000155
:Entity_EDL_0000198	type	Person
:Entity_EDL_0000198	canonical_mention	"man"	iraqwar_guardian__1000-01-01__timeline:27430-27432	1.0
:Entity_EDL_0000198	nominal_mention	"man"	iraqwar_guardian__1000-01-01__timeline:27430-27432	1.0
:Entity_EDL_0000198	link	NIL000000156
:Entity_EDL_0000199	type	Organization
:Entity_EDL_0000199	nominal_mention	"government"	iraqwar_guardian__1000-01-01__timeline:25075-25084	1.0
:Entity_EDL_0000199	link	NIL000000157
:Entity_EDL_0000200	type	Person
:Entity_EDL_0000200	pronominal_mention	"20"	iraqwar_guardian__1000-01-01__timeline:29652-29653	1.0
:Entity_EDL_0000200	link	NIL000000158
:Entity_EDL_0000201	type	Person
:Entity_EDL_0000201	mention	"Ibrahim al-Jaafari"	iraqwar_guardian__1000-01-01__timeline:33981-33998	1.0
:Entity_EDL_0000201	link	30002245
:Entity_EDL_0000202	type	Location
:Entity_EDL_0000202	nominal_mention	"district"	iraqwar_guardian__1000-01-01__timeline:13775-13782	1.0
:Entity_EDL_0000202	link	NIL000000159
:Entity_EDL_0000203	type	Person
:Entity_EDL_0000203	canonical_mention	"Paratroopers"	iraqwar_guardian__1000-01-01__timeline:4954-4965	1.0
:Entity_EDL_0000203	nominal_mention	"Paratroopers"	iraqwar_guardian__1000-01-01__timeline:4954-4965	1.0
:Entity_EDL_0000203	link	NIL000000160
:Entity_EDL_0000204	type	GeopoliticalEntity
:Entity_EDL_0000204	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:37173-37176	1.0
:Entity_EDL_0000204	link	99237
:Entity_EDL_0000205	type	GeopoliticalEntity
:Entity_EDL_0000205	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:38447-38453	1.0
:Entity_EDL_0000205	link	98182
:Entity_EDL_0000206	type	GeopoliticalEntity
:Entity_EDL_0000206	nominal_mention	"village"	iraqwar_guardian__1000-01-01__timeline:53938-53944	1.0
:Entity_EDL_0000206	link	NIL000000161
:Entity_EDL_0000207	type	Organization
:Entity_EDL_0000207	nominal_mention	"military"	iraqwar_guardian__1000-01-01__timeline:14585-14592	1.0
:Entity_EDL_0000207	link	NIL000000162
:Entity_EDL_0000208	type	Facility
:Entity_EDL_0000208	canonical_mention	"restaurant"	iraqwar_guardian__1000-01-01__timeline:4143-4152	1.0
:Entity_EDL_0000208	nominal_mention	"restaurant"	iraqwar_guardian__1000-01-01__timeline:4143-4152	1.0
:Entity_EDL_0000208	link	NIL000000163
:Entity_EDL_0000209	type	GeopoliticalEntity
:Entity_EDL_0000209	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:3175-3178	1.0
:Entity_EDL_0000209	link	99237
:Entity_EDL_0000210	type	GeopoliticalEntity
:Entity_EDL_0000210	mention	"France"	iraqwar_guardian__1000-01-01__timeline:28560-28565	1.0
:Entity_EDL_0000210	link	3017382
:Entity_EDL_0000211	type	GeopoliticalEntity
:Entity_EDL_0000211	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:42506-42509	1.0
:Entity_EDL_0000211	link	99237
:Entity_EDL_0000212	type	Person
:Entity_EDL_0000212	nominal_mention	"minister"	iraqwar_guardian__1000-01-01__timeline:28436-28443	1.0
:Entity_EDL_0000212	link	NIL000000164
:Entity_EDL_0000213	type	Person
:Entity_EDL_0000213	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:39646-39651	1.0
:Entity_EDL_0000213	link	NIL000000165
:Entity_EDL_0000214	type	Person
:Entity_EDL_0000214	nominal_mention	"they"	iraqwar_guardian__1000-01-01__timeline:14998-15001	1.0
:Entity_EDL_0000214	link	NIL000000166
:Entity_EDL_0000215	type	GeopoliticalEntity
:Entity_EDL_0000215	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:9599-9605	1.0
:Entity_EDL_0000215	link	98182
:Entity_EDL_0000216	type	Person
:Entity_EDL_0000216	canonical_mention	"1,500"	iraqwar_guardian__1000-01-01__timeline:25040-25044	1.0
:Entity_EDL_0000216	pronominal_mention	"1,500"	iraqwar_guardian__1000-01-01__timeline:25040-25044	1.0
:Entity_EDL_0000216	link	NIL000000167
:Entity_EDL_0000217	type	Person
:Entity_EDL_0000217	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:11835-11840	1.0
:Entity_EDL_0000217	link	NIL000000168
:Entity_EDL_0000218	type	Person
:Entity_EDL_0000218	canonical_mention	"workers"	iraqwar_guardian__1000-01-01__timeline:17347-17353	1.0
:Entity_EDL_0000218	nominal_mention	"workers"	iraqwar_guardian__1000-01-01__timeline:17347-17353	1.0
:Entity_EDL_0000218	link	NIL000000169
:Entity_EDL_0000219	type	GeopoliticalEntity
:Entity_EDL_0000219	canonical_mention	"city"	iraqwar_guardian__1000-01-01__timeline:12189-12192	1.0
:Entity_EDL_0000219	nominal_mention	"city"	iraqwar_guardian__1000-01-01__timeline:12189-12192	1.0
:Entity_EDL_0000219	link	NIL000000170
:Entity_EDL_0000220	type	Weapon
:Entity_EDL_0000220	canonical_mention	"stones"	iraqwar_guardian__1000-01-01__timeline:13166-13171	1.0
:Entity_EDL_0000220	nominal_mention	"stones"	iraqwar_guardian__1000-01-01__timeline:13166-13171	1.0
:Entity_EDL_0000220	link	NIL000000171
:Entity_EDL_0000221	type	Person
:Entity_EDL_0000221	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:43837-43842	1.0
:Entity_EDL_0000221	link	NIL000000172
:Entity_EDL_0000222	type	Person
:Entity_EDL_0000222	pronominal_mention	"60"	iraqwar_guardian__1000-01-01__timeline:9347-9348	1.0
:Entity_EDL_0000222	link	NIL000000173
:Entity_EDL_0000223	type	Person
:Entity_EDL_0000223	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:30421-30426	1.0
:Entity_EDL_0000223	link	NIL000000174
:Entity_EDL_0000224	type	Person
:Entity_EDL_0000224	canonical_mention	"115"	iraqwar_guardian__1000-01-01__timeline:45104-45106	1.0
:Entity_EDL_0000224	pronominal_mention	"115"	iraqwar_guardian__1000-01-01__timeline:45104-45106	1.0
:Entity_EDL_0000224	link	NIL000000175
:Entity_EDL_0000225	type	GeopoliticalEntity
:Entity_EDL_0000225	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:41166-41169	1.0
:Entity_EDL_0000225	link	99237
:Entity_EDL_0000226	type	Person
:Entity_EDL_0000226	nominal_mention	"forces"	iraqwar_guardian__1000-01-01__timeline:25588-25593	1.0
:Entity_EDL_0000226	link	NIL000000176
:Entity_EDL_0000227	type	Person
:Entity_EDL_0000227	canonical_mention	"officials"	iraqwar_guardian__1000-01-01__timeline:4560-4568	1.0
:Entity_EDL_0000227	nominal_mention	"officials"	iraqwar_guardian__1000-01-01__timeline:4560-4568	1.0
:Entity_EDL_0000227	link	NIL000000177
:Entity_EDL_0000228	type	GeopoliticalEntity
:Entity_EDL_0000228	mention	"British"	iraqwar_guardian__1000-01-01__timeline:3121-3127	1.0
:Entity_EDL_0000228	link	2635167
:Entity_EDL_0000230	type	Person
:Entity_EDL_0000230	canonical_mention	"commanders"	iraqwar_guardian__1000-01-01__timeline:28674-28683	1.0
:Entity_EDL_0000230	nominal_mention	"commanders"	iraqwar_guardian__1000-01-01__timeline:28674-28683	1.0
:Entity_EDL_0000230	link	NIL000000179
:Entity_EDL_0000231	type	GeopoliticalEntity
:Entity_EDL_0000231	canonical_mention	"Fallujah"	iraqwar_guardian__1000-01-01__timeline:2448-2455	1.0
:Entity_EDL_0000231	mention	"Fallujah"	iraqwar_guardian__1000-01-01__timeline:2448-2455	1.0
:Entity_EDL_0000231	link	99454
:Entity_EDL_0000232	type	Person
:Entity_EDL_0000232	nominal_mention	"civilians"	iraqwar_guardian__1000-01-01__timeline:23782-23790	1.0
:Entity_EDL_0000232	link	NIL000000180
:Entity_EDL_0000233	type	Vehicle
:Entity_EDL_0000233	nominal_mention	"aircraft"	iraqwar_guardian__1000-01-01__timeline:48074-48081	0.000
:Entity_EDL_0000233	link	NIL000000181
:Entity_EDL_0000234	type	Vehicle
:Entity_EDL_0000234	canonical_mention	"aeroplanes"	iraqwar_guardian__1000-01-01__timeline:7131-7140	1.0
:Entity_EDL_0000234	nominal_mention	"aeroplanes"	iraqwar_guardian__1000-01-01__timeline:7131-7140	1.0
:Entity_EDL_0000234	link	NIL000000182
:Entity_EDL_0000235	type	Person
:Entity_EDL_0000235	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:25233-25238	1.0
:Entity_EDL_0000235	link	NIL000000183
:Entity_EDL_0000236	type	Person
:Entity_EDL_0000236	canonical_mention	"himself"	iraqwar_guardian__1000-01-01__timeline:11530-11536	1.0
:Entity_EDL_0000236	pronominal_mention	"himself"	iraqwar_guardian__1000-01-01__timeline:11530-11536	1.0
:Entity_EDL_0000236	link	NIL000000184
:Entity_EDL_0000237	type	GeopoliticalEntity
:Entity_EDL_0000237	mention	"US"	iraqwar_guardian__1000-01-01__timeline:7270-7271	1.0
:Entity_EDL_0000237	link	6252001
:Entity_EDL_0000238	type	Organization
:Entity_EDL_0000238	mention	"army"	iraqwar_guardian__1000-01-01__timeline:13059-13062	1.0
:Entity_EDL_0000238	link	NIL000000185
:Entity_EDL_0000239	type	Person
:Entity_EDL_0000239	nominal_mention	"diplomats"	iraqwar_guardian__1000-01-01__timeline:28655-28663	1.0
:Entity_EDL_0000239	link	NIL000000186
:Entity_EDL_0000240	type	Person
:Entity_EDL_0000240	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:54613-54618	1.0
:Entity_EDL_0000240	link	NIL000000187
:Entity_EDL_0000241	type	GeopoliticalEntity
:Entity_EDL_0000241	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:36596-36602	1.0
:Entity_EDL_0000241	link	98182
:Entity_EDL_0000242	type	Weapon
:Entity_EDL_0000242	nominal_mention	"explosives"	iraqwar_guardian__1000-01-01__timeline:25325-25334	1.0
:Entity_EDL_0000242	link	NIL000000188
:Entity_EDL_0000243	type	Person
:Entity_EDL_0000243	nominal_mention	"chief"	iraqwar_guardian__1000-01-01__timeline:53693-53697	1.0
:Entity_EDL_0000243	link	NIL000000189
:Entity_EDL_0000244	type	GeopoliticalEntity
:Entity_EDL_0000244	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:3019-3025	1.0
:Entity_EDL_0000244	link	98182
:Entity_EDL_0000245	type	Person
:Entity_EDL_0000245	canonical_mention	"17"	iraqwar_guardian__1000-01-01__timeline:53363-53364	1.0
:Entity_EDL_0000245	pronominal_mention	"17"	iraqwar_guardian__1000-01-01__timeline:53363-53364	1.0
:Entity_EDL_0000245	link	NIL000000190
:Entity_EDL_0000246	type	GeopoliticalEntity
:Entity_EDL_0000246	mention	"US"	iraqwar_guardian__1000-01-01__timeline:4646-4647	1.0
:Entity_EDL_0000246	link	6252001
:Entity_EDL_0000247	type	Weapon
:Entity_EDL_0000247	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:21467-21470	1.0
:Entity_EDL_0000247	link	NIL000000191
:Entity_EDL_0000248	type	Person
:Entity_EDL_0000248	nominal_mention	"Iraqis"	iraqwar_guardian__1000-01-01__timeline:30876-30881	1.0
:Entity_EDL_0000248	link	NIL000000192
:Entity_EDL_0000249	type	Location
:Entity_EDL_0000249	canonical_mention	"Falklands"	iraqwar_guardian__1000-01-01__timeline:43276-43284	1.0
:Entity_EDL_0000249	mention	"Falklands"	iraqwar_guardian__1000-01-01__timeline:43276-43284	1.0
:Entity_EDL_0000249	link	3427040
:Entity_EDL_0000250	type	GeopoliticalEntity
:Entity_EDL_0000250	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:52971-52974	1.0
:Entity_EDL_0000250	link	99237
:Entity_EDL_0000251	type	GeopoliticalEntity
:Entity_EDL_0000251	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:26214-26217	1.0
:Entity_EDL_0000251	link	99237
:Entity_EDL_0000252	type	Person
:Entity_EDL_0000252	canonical_mention	"George Galloway"	iraqwar_guardian__1000-01-01__timeline:5789-5803	1.0
:Entity_EDL_0000252	mention	"George Galloway"	iraqwar_guardian__1000-01-01__timeline:5789-5803	1.0
:Entity_EDL_0000252	link	NIL000000193
:Entity_EDL_0000253	type	Person
:Entity_EDL_0000253	nominal_mention	"Bomber"	iraqwar_guardian__1000-01-01__timeline:45300-45305	1.0
:Entity_EDL_0000253	link	NIL000000194
:Entity_EDL_0000254	type	GeopoliticalEntity
:Entity_EDL_0000254	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:51324-51330	1.0
:Entity_EDL_0000254	link	98182
:Entity_EDL_0000255	type	Person
:Entity_EDL_0000255	nominal_mention	"minister"	iraqwar_guardian__1000-01-01__timeline:11998-12005	1.0
:Entity_EDL_0000255	link	NIL000000195
:Entity_EDL_0000256	type	GeopoliticalEntity
:Entity_EDL_0000256	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:21290-21293	1.0
:Entity_EDL_0000256	link	99237
:Entity_EDL_0000257	type	Person
:Entity_EDL_0000257	canonical_mention	"commandos"	iraqwar_guardian__1000-01-01__timeline:41083-41091	1.0
:Entity_EDL_0000257	nominal_mention	"commandos"	iraqwar_guardian__1000-01-01__timeline:41083-41091	1.0
:Entity_EDL_0000257	link	NIL000000196
:Entity_EDL_0000258	type	GeopoliticalEntity
:Entity_EDL_0000258	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:4666-4669	1.0
:Entity_EDL_0000258	link	99237
:Entity_EDL_0000259	type	Facility
:Entity_EDL_0000259	canonical_mention	"block"	iraqwar_guardian__1000-01-01__timeline:9617-9621	1.0
:Entity_EDL_0000259	nominal_mention	"block"	iraqwar_guardian__1000-01-01__timeline:9617-9621	1.0
:Entity_EDL_0000259	link	NIL000000197
:Entity_EDL_0000260	type	Location
:Entity_EDL_0000260	canonical_mention	"areas"	iraqwar_guardian__1000-01-01__timeline:9090-9094	1.0
:Entity_EDL_0000260	nominal_mention	"areas"	iraqwar_guardian__1000-01-01__timeline:9090-9094	1.0
:Entity_EDL_0000260	link	NIL000000198
:Entity_EDL_0000261	type	Person
:Entity_EDL_0000261	nominal_mention	"they"	iraqwar_guardian__1000-01-01__timeline:16174-16177	1.0
:Entity_EDL_0000261	link	NIL000000199
:Entity_EDL_0000262	type	GeopoliticalEntity
:Entity_EDL_0000262	nominal_mention	"town"	iraqwar_guardian__1000-01-01__timeline:29265-29268	1.0
:Entity_EDL_0000262	link	NIL000000200
:Entity_EDL_0000263	type	Person
:Entity_EDL_0000263	canonical_mention	"dictator"	iraqwar_guardian__1000-01-01__timeline:31837-31844	1.0
:Entity_EDL_0000263	nominal_mention	"dictator"	iraqwar_guardian__1000-01-01__timeline:31837-31844	1.0
:Entity_EDL_0000263	link	NIL000000201
:Entity_EDL_0000264	type	GeopoliticalEntity
:Entity_EDL_0000264	mention	"Germany"	iraqwar_guardian__1000-01-01__timeline:51543-51549	1.0
:Entity_EDL_0000264	link	2921044
:Entity_EDL_0000265	type	Person
:Entity_EDL_0000265	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:52077-52082	1.0
:Entity_EDL_0000265	link	NIL000000202
:Entity_EDL_0000266	type	Person
:Entity_EDL_0000266	canonical_mention	"She"	iraqwar_guardian__1000-01-01__timeline:9941-9943	1.0
:Entity_EDL_0000266	pronominal_mention	"She"	iraqwar_guardian__1000-01-01__timeline:9941-9943	1.0
:Entity_EDL_0000266	link	NIL000000203
:Entity_EDL_0000267	type	Facility
:Entity_EDL_0000267	nominal_mention	"mosque"	iraqwar_guardian__1000-01-01__timeline:51030-51035	1.0
:Entity_EDL_0000267	link	NIL000000204
:Entity_EDL_0000268	type	Person
:Entity_EDL_0000268	nominal_mention	"Muslims"	iraqwar_guardian__1000-01-01__timeline:6858-6864	1.0
:Entity_EDL_0000268	link	NIL000000205
:Entity_EDL_0000269	type	Person
:Entity_EDL_0000269	nominal_mention	"Gunmen"	iraqwar_guardian__1000-01-01__timeline:53674-53679	1.0
:Entity_EDL_0000269	link	NIL000000206
:Entity_EDL_0000270	type	Facility
:Entity_EDL_0000270	nominal_mention	"stations"	iraqwar_guardian__1000-01-01__timeline:48971-48978	0.000
:Entity_EDL_0000270	link	NIL000000207
:Entity_EDL_0000271	type	Person
:Entity_EDL_0000271	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:33515-33520	1.0
:Entity_EDL_0000271	link	NIL000000208
:Entity_EDL_0000272	type	Person
:Entity_EDL_0000272	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:14139-14144	1.0
:Entity_EDL_0000272	link	NIL000000209
:Entity_EDL_0000273	type	Organization
:Entity_EDL_0000273	nominal_mention	"military"	iraqwar_guardian__1000-01-01__timeline:31634-31641	1.0
:Entity_EDL_0000273	link	NIL000000210
:Entity_EDL_0000274	type	GeopoliticalEntity
:Entity_EDL_0000274	mention	"Iraqi"	iraqwar_guardian__1000-01-01__timeline:33619-33623	1.0
:Entity_EDL_0000274	link	99237
:Entity_EDL_0000275	type	Weapon
:Entity_EDL_0000275	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:37498-37501	1.0
:Entity_EDL_0000275	link	NIL000000211
:Entity_EDL_0000276	type	Person
:Entity_EDL_0000276	canonical_mention	"Infantry"	iraqwar_guardian__1000-01-01__timeline:14927-14934	1.0
:Entity_EDL_0000276	nominal_mention	"Infantry"	iraqwar_guardian__1000-01-01__timeline:14927-14934	1.0
:Entity_EDL_0000276	link	NIL000000212
:Entity_EDL_0000277	type	Person
:Entity_EDL_0000277	nominal_mention	"marines"	iraqwar_guardian__1000-01-01__timeline:21033-21039	1.0
:Entity_EDL_0000277	link	NIL000000213
:Entity_EDL_0000278	type	Person
:Entity_EDL_0000278	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:22118-22123	1.0
:Entity_EDL_0000278	link	NIL000000214
:Entity_EDL_0000280	type	Person
:Entity_EDL_0000280	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:394-399	1.0
:Entity_EDL_0000280	link	NIL000000216
:Entity_EDL_0000281	type	Facility
:Entity_EDL_0000281	nominal_mention	"mosque"	iraqwar_guardian__1000-01-01__timeline:36586-36591	1.0
:Entity_EDL_0000281	link	NIL000000217
:Entity_EDL_0000282	type	Person
:Entity_EDL_0000282	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:34796-34803	1.0
:Entity_EDL_0000282	link	NIL000000218
:Entity_EDL_0000283	type	GeopoliticalEntity
:Entity_EDL_0000283	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:53480-53483	1.0
:Entity_EDL_0000283	link	99237
:Entity_EDL_0000284	type	GeopoliticalEntity
:Entity_EDL_0000284	nominal_mention	"government"	iraqwar_guardian__1000-01-01__timeline:28486-28495	0.000
:Entity_EDL_0000284	link	NIL000000219
:Entity_EDL_0000285	type	GeopoliticalEntity
:Entity_EDL_0000285	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:48100-48106	1.0
:Entity_EDL_0000285	link	98182
:Entity_EDL_0000286	type	Person
:Entity_EDL_0000286	nominal_mention	"Insurgents"	iraqwar_guardian__1000-01-01__timeline:48893-48902	1.0
:Entity_EDL_0000286	link	NIL000000220
:Entity_EDL_0000287	type	Facility
:Entity_EDL_0000287	nominal_mention	"streets"	iraqwar_guardian__1000-01-01__timeline:42649-42655	1.0
:Entity_EDL_0000287	link	NIL000000221
:Entity_EDL_0000289	type	Person
:Entity_EDL_0000289	canonical_mention	"260"	iraqwar_guardian__1000-01-01__timeline:24182-24184	1.0
:Entity_EDL_0000289	pronominal_mention	"260"	iraqwar_guardian__1000-01-01__timeline:24182-24184	1.0
:Entity_EDL_0000289	link	NIL000000222
:Entity_EDL_0000290	type	Facility
:Entity_EDL_0000290	canonical_mention	"stronghold"	iraqwar_guardian__1000-01-01__timeline:14832-14841	1.0
:Entity_EDL_0000290	nominal_mention	"stronghold"	iraqwar_guardian__1000-01-01__timeline:14832-14841	1.0
:Entity_EDL_0000290	link	NIL000000223
:Entity_EDL_0000291	type	Person
:Entity_EDL_0000291	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:14309-14314	1.0
:Entity_EDL_0000291	link	NIL000000224
:Entity_EDL_0000292	type	GeopoliticalEntity
:Entity_EDL_0000292	nominal_mention	"capital"	iraqwar_guardian__1000-01-01__timeline:54401-54407	1.0
:Entity_EDL_0000292	link	NIL000000225
:Entity_EDL_0000293	type	GeopoliticalEntity
:Entity_EDL_0000293	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:16232-16235	1.0
:Entity_EDL_0000293	link	99237
:Entity_EDL_0000294	type	Facility
:Entity_EDL_0000294	canonical_mention	"camp"	iraqwar_guardian__1000-01-01__timeline:41845-41848	1.0
:Entity_EDL_0000294	nominal_mention	"camp"	iraqwar_guardian__1000-01-01__timeline:41845-41848	1.0
:Entity_EDL_0000294	link	NIL000000226
:Entity_EDL_0000295	type	Person
:Entity_EDL_0000295	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:53199-53204	1.0
:Entity_EDL_0000295	link	NIL000000227
:Entity_EDL_0000296	type	Person
:Entity_EDL_0000296	nominal_mention	"civilians"	iraqwar_guardian__1000-01-01__timeline:24859-24867	1.0
:Entity_EDL_0000296	link	NIL000000228
:Entity_EDL_0000297	type	GeopoliticalEntity
:Entity_EDL_0000297	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:31108-31111	1.0
:Entity_EDL_0000297	link	99237
:Entity_EDL_0000298	type	Person
:Entity_EDL_0000298	canonical_mention	"Britons"	iraqwar_guardian__1000-01-01__timeline:21398-21404	1.0
:Entity_EDL_0000298	nominal_mention	"Britons"	iraqwar_guardian__1000-01-01__timeline:21398-21404	1.0
:Entity_EDL_0000298	link	NIL000000229
:Entity_EDL_0000299	type	GeopoliticalEntity
:Entity_EDL_0000299	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:42733-42736	1.0
:Entity_EDL_0000299	link	99237
:Entity_EDL_0000300	type	Person
:Entity_EDL_0000300	canonical_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:14356-14361	1.0
:Entity_EDL_0000300	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:14356-14361	1.0
:Entity_EDL_0000300	link	NIL000000230
:Entity_EDL_0000301	type	Weapon
:Entity_EDL_0000301	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:21327-21330	1.0
:Entity_EDL_0000301	link	NIL000000231
:Entity_EDL_0000302	type	GeopoliticalEntity
:Entity_EDL_0000302	pronominal_mention	"us"	iraqwar_guardian__1000-01-01__timeline:1782-1783	1.0
:Entity_EDL_0000302	link	NIL000000232
:Entity_EDL_0000303	type	GeopoliticalEntity
:Entity_EDL_0000303	mention	"Basra"	iraqwar_guardian__1000-01-01__timeline:12943-12947	1.0
:Entity_EDL_0000303	link	99532
:Entity_EDL_0000304	type	GeopoliticalEntity
:Entity_EDL_0000304	mention	"US"	iraqwar_guardian__1000-01-01__timeline:42775-42776	1.0
:Entity_EDL_0000304	link	6252001
:Entity_EDL_0000305	type	Person
:Entity_EDL_0000305	canonical_mention	"dozens"	iraqwar_guardian__1000-01-01__timeline:14891-14896	1.0
:Entity_EDL_0000305	nominal_mention	"dozens"	iraqwar_guardian__1000-01-01__timeline:14891-14896	1.0
:Entity_EDL_0000305	link	NIL000000233
:Entity_EDL_0000306	type	Person
:Entity_EDL_0000306	canonical_mention	"scientists"	iraqwar_guardian__1000-01-01__timeline:53036-53045	1.0
:Entity_EDL_0000306	nominal_mention	"scientists"	iraqwar_guardian__1000-01-01__timeline:53036-53045	1.0
:Entity_EDL_0000306	link	NIL000000234
:Entity_EDL_0000307	type	Vehicle
:Entity_EDL_0000307	nominal_mention	"car"	iraqwar_guardian__1000-01-01__timeline:38370-38372	1.0
:Entity_EDL_0000307	link	NIL000000235
:Entity_EDL_0000308	type	Person
:Entity_EDL_0000308	nominal_mention	"soldier"	iraqwar_guardian__1000-01-01__timeline:43065-43071	1.0
:Entity_EDL_0000308	link	NIL000000236
:Entity_EDL_0000309	type	Person
:Entity_EDL_0000309	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:2890-2895	1.0
:Entity_EDL_0000309	link	NIL000000237
:Entity_EDL_0000310	type	GeopoliticalEntity
:Entity_EDL_0000310	mention	"US"	iraqwar_guardian__1000-01-01__timeline:52212-52213	1.0
:Entity_EDL_0000310	link	6252001
:Entity_EDL_0000311	type	Facility
:Entity_EDL_0000311	nominal_mention	"jail"	iraqwar_guardian__1000-01-01__timeline:12812-12815	1.0
:Entity_EDL_0000311	link	NIL000000238
:Entity_EDL_0000312	type	Person
:Entity_EDL_0000312	nominal_mention	"head"	iraqwar_guardian__1000-01-01__timeline:46624-46627	1.0
:Entity_EDL_0000312	link	NIL000000239
:Entity_EDL_0000313	type	Person
:Entity_EDL_0000313	mention	"Abu Ghraib"	iraqwar_guardian__1000-01-01__timeline:52371-52380	1.0
:Entity_EDL_0000313	link	NIL000000240
:Entity_EDL_0000314	type	Vehicle
:Entity_EDL_0000314	nominal_mention	"car"	iraqwar_guardian__1000-01-01__timeline:45088-45090	1.0
:Entity_EDL_0000314	link	NIL000000241
:Entity_EDL_0000315	type	Person
:Entity_EDL_0000315	canonical_mention	"22"	iraqwar_guardian__1000-01-01__timeline:51024-51025	1.0
:Entity_EDL_0000315	nominal_mention	"22"	iraqwar_guardian__1000-01-01__timeline:51024-51025	1.0
:Entity_EDL_0000315	link	NIL000000242
:Entity_EDL_0000316	type	GeopoliticalEntity
:Entity_EDL_0000316	canonical_mention	"Tal Afar"	iraqwar_guardian__1000-01-01__timeline:15009-15016	1.0
:Entity_EDL_0000316	mention	"Tal Afar"	iraqwar_guardian__1000-01-01__timeline:15009-15016	1.0
:Entity_EDL_0000316	link	90393
:Entity_EDL_0000317	type	Person
:Entity_EDL_0000317	canonical_mention	"reservists"	iraqwar_guardian__1000-01-01__timeline:21232-21241	1.0
:Entity_EDL_0000317	nominal_mention	"reservists"	iraqwar_guardian__1000-01-01__timeline:21232-21241	1.0
:Entity_EDL_0000317	link	NIL000000243
:Entity_EDL_0000318	type	Person
:Entity_EDL_0000318	canonical_mention	"figures"	iraqwar_guardian__1000-01-01__timeline:5869-5875	1.0
:Entity_EDL_0000318	nominal_mention	"figures"	iraqwar_guardian__1000-01-01__timeline:5869-5875	1.0
:Entity_EDL_0000318	link	NIL000000244
:Entity_EDL_0000319	type	Person
:Entity_EDL_0000319	canonical_mention	"marines"	iraqwar_guardian__1000-01-01__timeline:2359-2365	1.0
:Entity_EDL_0000319	nominal_mention	"marines"	iraqwar_guardian__1000-01-01__timeline:2359-2365	1.0
:Entity_EDL_0000319	link	NIL000000245
:Entity_EDL_0000320	type	Person
:Entity_EDL_0000320	nominal_mention	"gunmen"	iraqwar_guardian__1000-01-01__timeline:53583-53588	1.0
:Entity_EDL_0000320	link	NIL000000246
:Entity_EDL_0000321	type	Person
:Entity_EDL_0000321	nominal_mention	"Iraqis"	iraqwar_guardian__1000-01-01__timeline:32302-32307	1.0
:Entity_EDL_0000321	link	NIL000000247
:Entity_EDL_0000322	type	Person
:Entity_EDL_0000322	pronominal_mention	"his"	iraqwar_guardian__1000-01-01__timeline:6784-6786	1.0
:Entity_EDL_0000322	link	NIL000000248
:Entity_EDL_0000323	type	GeopoliticalEntity
:Entity_EDL_0000323	mention	"Britain"	iraqwar_guardian__1000-01-01__timeline:36284-36290	1.0
:Entity_EDL_0000323	link	2635167
:Entity_EDL_0000324	type	Facility
:Entity_EDL_0000324	canonical_mention	"jail"	iraqwar_guardian__1000-01-01__timeline:114-117	1.0
:Entity_EDL_0000324	nominal_mention	"jail"	iraqwar_guardian__1000-01-01__timeline:114-117	1.0
:Entity_EDL_0000324	link	NIL000000249
:Entity_EDL_0000325	type	Person
:Entity_EDL_0000325	nominal_mention	"forces"	iraqwar_guardian__1000-01-01__timeline:45955-45960	1.0
:Entity_EDL_0000325	link	NIL000000250
:Entity_EDL_0000326	type	Person
:Entity_EDL_0000326	nominal_mention	"personnel"	iraqwar_guardian__1000-01-01__timeline:48299-48307	1.0
:Entity_EDL_0000326	link	NIL000000251
:Entity_EDL_0000327	type	Person
:Entity_EDL_0000327	mention	"Ayad Allawi"	iraqwar_guardian__1000-01-01__timeline:37466-37476	1.0
:Entity_EDL_0000327	link	30002229
:Entity_EDL_0000328	type	Person
:Entity_EDL_0000328	nominal_mention	"prisoners"	iraqwar_guardian__1000-01-01__timeline:47661-47669	1.0
:Entity_EDL_0000328	link	NIL000000252
:Entity_EDL_0000329	type	Person
:Entity_EDL_0000329	nominal_mention	"marine"	iraqwar_guardian__1000-01-01__timeline:48940-48945	1.0
:Entity_EDL_0000329	link	NIL000000253
:Entity_EDL_0000330	type	Location
:Entity_EDL_0000330	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:34318-34321	1.0
:Entity_EDL_0000330	link	99237
:Entity_EDL_0000331	type	Person
:Entity_EDL_0000331	canonical_mention	"brass"	iraqwar_guardian__1000-01-01__timeline:37089-37093	1.0
:Entity_EDL_0000331	nominal_mention	"brass"	iraqwar_guardian__1000-01-01__timeline:37089-37093	1.0
:Entity_EDL_0000331	link	NIL000000254
:Entity_EDL_0000332	type	GeopoliticalEntity
:Entity_EDL_0000332	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:46189-46192	1.0
:Entity_EDL_0000332	link	99237
:Entity_EDL_0000333	type	Person
:Entity_EDL_0000333	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:45564-45571	1.0
:Entity_EDL_0000333	link	NIL000000255
:Entity_EDL_0000334	type	Person
:Entity_EDL_0000334	canonical_mention	"Nicola Calipari"	iraqwar_guardian__1000-01-01__timeline:34703-34717	1.0
:Entity_EDL_0000334	mention	"Nicola Calipari"	iraqwar_guardian__1000-01-01__timeline:34703-34717	1.0
:Entity_EDL_0000334	link	NIL000000256
:Entity_EDL_0000335	type	Person
:Entity_EDL_0000335	nominal_mention	"detainees"	iraqwar_guardian__1000-01-01__timeline:51474-51482	1.0
:Entity_EDL_0000335	link	NIL000000257
:Entity_EDL_0000336	type	GeopoliticalEntity
:Entity_EDL_0000336	canonical_mention	"Tikrit"	iraqwar_guardian__1000-01-01__timeline:33481-33486	1.0
:Entity_EDL_0000336	mention	"Tikrit"	iraqwar_guardian__1000-01-01__timeline:33481-33486	1.0
:Entity_EDL_0000336	link	90150
:Entity_EDL_0000337	type	Location
:Entity_EDL_0000337	nominal_mention	"area"	iraqwar_guardian__1000-01-01__timeline:14019-14022	1.0
:Entity_EDL_0000337	link	NIL000000258
:Entity_EDL_0000338	type	Person
:Entity_EDL_0000338	nominal_mention	"civilians"	iraqwar_guardian__1000-01-01__timeline:13956-13964	1.0
:Entity_EDL_0000338	link	NIL000000259
:Entity_EDL_0000339	type	Person
:Entity_EDL_0000339	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:36739-36744	1.0
:Entity_EDL_0000339	link	NIL000000260
:Entity_EDL_0000340	type	Weapon
:Entity_EDL_0000340	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:24782-24785	1.0
:Entity_EDL_0000340	link	NIL000000261
:Entity_EDL_0000341	type	Location
:Entity_EDL_0000341	nominal_mention	"border"	iraqwar_guardian__1000-01-01__timeline:28074-28079	1.0
:Entity_EDL_0000341	link	NIL000000262
:Entity_EDL_0000342	type	Person
:Entity_EDL_0000342	canonical_mention	"paras"	iraqwar_guardian__1000-01-01__timeline:47272-47276	1.0
:Entity_EDL_0000342	nominal_mention	"paras"	iraqwar_guardian__1000-01-01__timeline:47272-47276	1.0
:Entity_EDL_0000342	link	NIL000000263
:Entity_EDL_0000343	type	Weapon
:Entity_EDL_0000343	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:33771-33774	1.0
:Entity_EDL_0000343	link	NIL000000264
:Entity_EDL_0000344	type	Person
:Entity_EDL_0000344	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:17383-17392	1.0
:Entity_EDL_0000344	link	NIL000000265
:Entity_EDL_0000346	type	Person
:Entity_EDL_0000346	canonical_mention	"colleagues"	iraqwar_guardian__1000-01-01__timeline:11424-11433	1.0
:Entity_EDL_0000346	nominal_mention	"colleagues"	iraqwar_guardian__1000-01-01__timeline:11424-11433	1.0
:Entity_EDL_0000346	link	NIL000000267
:Entity_EDL_0000347	type	Person
:Entity_EDL_0000347	nominal_mention	"marines"	iraqwar_guardian__1000-01-01__timeline:2536-2542	1.0
:Entity_EDL_0000347	link	NIL000000268
:Entity_EDL_0000348	type	Person
:Entity_EDL_0000348	nominal_mention	"officers"	iraqwar_guardian__1000-01-01__timeline:1880-1887	1.0
:Entity_EDL_0000348	link	NIL000000269
:Entity_EDL_0000349	type	Vehicle
:Entity_EDL_0000349	canonical_mention	"tanks"	iraqwar_guardian__1000-01-01__timeline:12794-12798	1.0
:Entity_EDL_0000349	nominal_mention	"tanks"	iraqwar_guardian__1000-01-01__timeline:12794-12798	1.0
:Entity_EDL_0000349	link	NIL000000270
:Entity_EDL_0000350	type	Person
:Entity_EDL_0000350	pronominal_mention	"Scores"	iraqwar_guardian__1000-01-01__timeline:14705-14710	1.0
:Entity_EDL_0000350	link	NIL000000271
:Entity_EDL_0000351	type	Person
:Entity_EDL_0000351	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:27705-27714	1.0
:Entity_EDL_0000351	link	NIL000000272
:Entity_EDL_0000352	type	Person
:Entity_EDL_0000352	canonical_mention	"wife"	iraqwar_guardian__1000-01-01__timeline:5827-5830	1.0
:Entity_EDL_0000352	nominal_mention	"wife"	iraqwar_guardian__1000-01-01__timeline:5827-5830	1.0
:Entity_EDL_0000352	link	NIL000000273
:Entity_EDL_0000353	type	Facility
:Entity_EDL_0000353	canonical_mention	"Abu Ghraib"	iraqwar_guardian__1000-01-01__timeline:37056-37065	1.0
:Entity_EDL_0000353	mention	"Abu Ghraib"	iraqwar_guardian__1000-01-01__timeline:37056-37065	1.0
:Entity_EDL_0000353	link	NIL000000274
:Entity_EDL_0000354	type	Vehicle
:Entity_EDL_0000354	nominal_mention	"car"	iraqwar_guardian__1000-01-01__timeline:51802-51804	1.0
:Entity_EDL_0000354	link	NIL000000275
:Entity_EDL_0000355	type	GeopoliticalEntity
:Entity_EDL_0000355	mention	"US"	iraqwar_guardian__1000-01-01__timeline:35072-35073	1.0
:Entity_EDL_0000355	link	6252001
:Entity_EDL_0000356	type	Person
:Entity_EDL_0000356	canonical_mention	"bombers"	iraqwar_guardian__1000-01-01__timeline:1864-1870	1.0
:Entity_EDL_0000356	nominal_mention	"bombers"	iraqwar_guardian__1000-01-01__timeline:1864-1870	1.0
:Entity_EDL_0000356	link	NIL000000276
:Entity_EDL_0000357	type	GeopoliticalEntity
:Entity_EDL_0000357	nominal_mention	"country"	iraqwar_guardian__1000-01-01__timeline:23847-23853	1.0
:Entity_EDL_0000357	link	NIL000000277
:Entity_EDL_0000358	type	Facility
:Entity_EDL_0000358	nominal_mention	"embassy"	iraqwar_guardian__1000-01-01__timeline:51184-51190	1.0
:Entity_EDL_0000358	link	NIL000000278
:Entity_EDL_0000359	type	GeopoliticalEntity
:Entity_EDL_0000359	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:5329-5332	1.0
:Entity_EDL_0000359	link	99237
:Entity_EDL_0000360	type	GeopoliticalEntity
:Entity_EDL_0000360	mention	"London"	iraqwar_guardian__1000-01-01__timeline:21839-21844	1.0
:Entity_EDL_0000360	link	2643743
:Entity_EDL_0000362	type	Person
:Entity_EDL_0000362	nominal_mention	"militias"	iraqwar_guardian__1000-01-01__timeline:29836-29843	1.0
:Entity_EDL_0000362	link	NIL000000280
:Entity_EDL_0000363	type	Person
:Entity_EDL_0000363	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:14795-14800	1.0
:Entity_EDL_0000363	link	NIL000000281
:Entity_EDL_0000364	type	Person
:Entity_EDL_0000364	canonical_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:74-81	1.0
:Entity_EDL_0000364	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:74-81	1.0
:Entity_EDL_0000364	link	NIL000000282
:Entity_EDL_0000365	type	Weapon
:Entity_EDL_0000365	nominal_mention	"bombs"	iraqwar_guardian__1000-01-01__timeline:8502-8506	1.0
:Entity_EDL_0000365	link	NIL000000283
:Entity_EDL_0000366	type	Person
:Entity_EDL_0000366	canonical_mention	"Jack Straw"	iraqwar_guardian__1000-01-01__timeline:4231-4240	1.0
:Entity_EDL_0000366	mention	"Jack Straw"	iraqwar_guardian__1000-01-01__timeline:4231-4240	1.0
:Entity_EDL_0000366	link	NIL000000284
:Entity_EDL_0000367	type	Person
:Entity_EDL_0000367	mention	"John Reid"	iraqwar_guardian__1000-01-01__timeline:11966-11974	1.0
:Entity_EDL_0000367	link	NIL000000285
:Entity_EDL_0000368	type	Person
:Entity_EDL_0000368	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:44875-44880	1.0
:Entity_EDL_0000368	link	NIL000000286
:Entity_EDL_0000369	type	Person
:Entity_EDL_0000369	canonical_mention	"rulers"	iraqwar_guardian__1000-01-01__timeline:37758-37763	1.0
:Entity_EDL_0000369	nominal_mention	"rulers"	iraqwar_guardian__1000-01-01__timeline:37758-37763	1.0
:Entity_EDL_0000369	link	NIL000000287
:Entity_EDL_0000370	type	GeopoliticalEntity
:Entity_EDL_0000370	nominal_mention	"country"	iraqwar_guardian__1000-01-01__timeline:30965-30971	1.0
:Entity_EDL_0000370	link	NIL000000288
:Entity_EDL_0000371	type	GeopoliticalEntity
:Entity_EDL_0000371	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:36173-36176	1.0
:Entity_EDL_0000371	link	99237
:Entity_EDL_0000372	type	Person
:Entity_EDL_0000372	nominal_mention	"Insurgents"	iraqwar_guardian__1000-01-01__timeline:40994-41003	1.0
:Entity_EDL_0000372	link	NIL000000289
:Entity_EDL_0000373	type	Organization
:Entity_EDL_0000373	nominal_mention	"government"	iraqwar_guardian__1000-01-01__timeline:35295-35304	1.0
:Entity_EDL_0000373	link	NIL000000290
:Entity_EDL_0000374	type	GeopoliticalEntity
:Entity_EDL_0000374	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:39059-39062	1.0
:Entity_EDL_0000374	link	99237
:Entity_EDL_0000375	type	GeopoliticalEntity
:Entity_EDL_0000375	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:8965-8968	1.0
:Entity_EDL_0000375	link	99237
:Entity_EDL_0000376	type	Location
:Entity_EDL_0000376	nominal_mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:34452-34455	1.0
:Entity_EDL_0000376	link	NIL000000291
:Entity_EDL_0000377	type	Person
:Entity_EDL_0000377	canonical_mention	"woman"	iraqwar_guardian__1000-01-01__timeline:44558-44562	1.0
:Entity_EDL_0000377	nominal_mention	"woman"	iraqwar_guardian__1000-01-01__timeline:44558-44562	1.0
:Entity_EDL_0000377	link	NIL000000292
:Entity_EDL_0000378	type	Person
:Entity_EDL_0000378	pronominal_mention	"more"	iraqwar_guardian__1000-01-01__timeline:29212-29215	1.0
:Entity_EDL_0000378	link	NIL000000293
:Entity_EDL_0000379	type	Person
:Entity_EDL_0000379	nominal_mention	"forces"	iraqwar_guardian__1000-01-01__timeline:11035-11040	1.0
:Entity_EDL_0000379	link	NIL000000294
:Entity_EDL_0000380	type	Person
:Entity_EDL_0000380	nominal_mention	"forces"	iraqwar_guardian__1000-01-01__timeline:29361-29366	0.000
:Entity_EDL_0000380	link	NIL000000295
:Entity_EDL_0000381	type	Person
:Entity_EDL_0000381	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:43742-43747	1.0
:Entity_EDL_0000381	link	NIL000000296
:Entity_EDL_0000382	type	Person
:Entity_EDL_0000382	nominal_mention	"chief"	iraqwar_guardian__1000-01-01__timeline:53627-53631	1.0
:Entity_EDL_0000382	link	NIL000000297
:Entity_EDL_0000383	type	Person
:Entity_EDL_0000383	canonical_mention	"schoolteachers"	iraqwar_guardian__1000-01-01__timeline:10404-10417	1.0
:Entity_EDL_0000383	nominal_mention	"schoolteachers"	iraqwar_guardian__1000-01-01__timeline:10404-10417	1.0
:Entity_EDL_0000383	link	NIL000000298
:Entity_EDL_0000384	type	GeopoliticalEntity
:Entity_EDL_0000384	mention	"Britain"	iraqwar_guardian__1000-01-01__timeline:27515-27521	1.0
:Entity_EDL_0000384	link	2635167
:Entity_EDL_0000385	type	Weapon
:Entity_EDL_0000385	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:15811-15814	1.0
:Entity_EDL_0000385	link	NIL000000299
:Entity_EDL_0000386	type	GeopoliticalEntity
:Entity_EDL_0000386	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:44321-44324	1.0
:Entity_EDL_0000386	link	99237
:Entity_EDL_0000387	type	GeopoliticalEntity
:Entity_EDL_0000387	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:31676-31679	1.0
:Entity_EDL_0000387	link	99237
:Entity_EDL_0000388	type	Person
:Entity_EDL_0000388	canonical_mention	"family"	iraqwar_guardian__1000-01-01__timeline:6583-6588	1.0
:Entity_EDL_0000388	nominal_mention	"family"	iraqwar_guardian__1000-01-01__timeline:6583-6588	1.0
:Entity_EDL_0000388	link	NIL000000300
:Entity_EDL_0000389	type	Person
:Entity_EDL_0000389	nominal_mention	"authorities"	iraqwar_guardian__1000-01-01__timeline:44233-44243	1.0
:Entity_EDL_0000389	link	NIL000000301
:Entity_EDL_0000390	type	Person
:Entity_EDL_0000390	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:44639-44644	1.0
:Entity_EDL_0000390	link	NIL000000302
:Entity_EDL_0000391	type	Person
:Entity_EDL_0000391	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:28199-28204	1.0
:Entity_EDL_0000391	link	NIL000000303
:Entity_EDL_0000392	type	GeopoliticalEntity
:Entity_EDL_0000392	nominal_mention	"villages"	iraqwar_guardian__1000-01-01__timeline:7161-7168	1.0
:Entity_EDL_0000392	link	NIL000000304
:Entity_EDL_0000393	type	Facility
:Entity_EDL_0000393	nominal_mention	"market"	iraqwar_guardian__1000-01-01__timeline:34077-34082	1.0
:Entity_EDL_0000393	link	NIL000000305
:Entity_EDL_0000394	type	GeopoliticalEntity
:Entity_EDL_0000394	mention	"London"	iraqwar_guardian__1000-01-01__timeline:12030-12035	1.0
:Entity_EDL_0000394	link	2643743
:Entity_EDL_0000395	type	GeopoliticalEntity
:Entity_EDL_0000395	mention	"British"	iraqwar_guardian__1000-01-01__timeline:12786-12792	1.0
:Entity_EDL_0000395	link	2635167
:Entity_EDL_0000396	type	Person
:Entity_EDL_0000396	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:16205-16210	1.0
:Entity_EDL_0000396	link	NIL000000306
:Entity_EDL_0000397	type	Person
:Entity_EDL_0000397	nominal_mention	"Insurgents"	iraqwar_guardian__1000-01-01__timeline:35137-35146	1.0
:Entity_EDL_0000397	link	NIL000000307
:Entity_EDL_0000398	type	Person
:Entity_EDL_0000398	mention	"Jalal Talabani"	iraqwar_guardian__1000-01-01__timeline:37864-37877	1.0
:Entity_EDL_0000398	link	NIL000000308
:Entity_EDL_0000399	type	Person
:Entity_EDL_0000399	pronominal_mention	"he"	iraqwar_guardian__1000-01-01__timeline:26510-26511	1.0
:Entity_EDL_0000399	link	NIL000000309
:Entity_EDL_0000400	type	Person
:Entity_EDL_0000400	canonical_mention	"leader"	iraqwar_guardian__1000-01-01__timeline:29575-29580	1.0
:Entity_EDL_0000400	nominal_mention	"leader"	iraqwar_guardian__1000-01-01__timeline:29575-29580	1.0
:Entity_EDL_0000400	link	NIL000000310
:Entity_EDL_0000401	type	Person
:Entity_EDL_0000401	nominal_mention	"prisoners"	iraqwar_guardian__1000-01-01__timeline:39660-39668	1.0
:Entity_EDL_0000401	link	NIL000000311
:Entity_EDL_0000402	type	Person
:Entity_EDL_0000402	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:50984-50989	1.0
:Entity_EDL_0000402	link	NIL000000312
:Entity_EDL_0000403	type	Person
:Entity_EDL_0000403	canonical_mention	"troop"	iraqwar_guardian__1000-01-01__timeline:2778-2782	1.0
:Entity_EDL_0000403	nominal_mention	"troop"	iraqwar_guardian__1000-01-01__timeline:2778-2782	1.0
:Entity_EDL_0000403	link	NIL000000313
:Entity_EDL_0000404	type	Person
:Entity_EDL_0000404	nominal_mention	"officers"	iraqwar_guardian__1000-01-01__timeline:24880-24887	1.0
:Entity_EDL_0000404	link	NIL000000314
:Entity_EDL_0000405	type	GeopoliticalEntity
:Entity_EDL_0000405	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:27880-27883	1.0
:Entity_EDL_0000405	link	99237
:Entity_EDL_0000406	type	Organization
:Entity_EDL_0000406	nominal_mention	"group"	iraqwar_guardian__1000-01-01__timeline:14438-14442	1.0
:Entity_EDL_0000406	link	NIL000000315
:Entity_EDL_0000407	type	Person
:Entity_EDL_0000407	canonical_mention	"five"	iraqwar_guardian__1000-01-01__timeline:21577-21580	1.0
:Entity_EDL_0000407	pronominal_mention	"five"	iraqwar_guardian__1000-01-01__timeline:21577-21580	1.0
:Entity_EDL_0000407	link	NIL000000316
:Entity_EDL_0000408	type	Person
:Entity_EDL_0000408	canonical_mention	"Shias"	iraqwar_guardian__1000-01-01__timeline:24568-24572	1.0
:Entity_EDL_0000408	nominal_mention	"Shias"	iraqwar_guardian__1000-01-01__timeline:24568-24572	1.0
:Entity_EDL_0000408	link	NIL000000317
:Entity_EDL_0000409	type	Person
:Entity_EDL_0000409	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:28715-28724	1.0
:Entity_EDL_0000409	link	NIL000000318
:Entity_EDL_0000410	type	Person
:Entity_EDL_0000410	canonical_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:33-42	1.0
:Entity_EDL_0000410	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:33-42	1.0
:Entity_EDL_0000410	link	NIL000000319
:Entity_EDL_0000411	type	Organization
:Entity_EDL_0000411	canonical_mention	"services"	iraqwar_guardian__1000-01-01__timeline:18287-18294	1.0
:Entity_EDL_0000411	nominal_mention	"services"	iraqwar_guardian__1000-01-01__timeline:18287-18294	1.0
:Entity_EDL_0000411	link	NIL000000320
:Entity_EDL_0000412	type	Facility
:Entity_EDL_0000412	nominal_mention	"station"	iraqwar_guardian__1000-01-01__timeline:22707-22713	1.0
:Entity_EDL_0000412	link	NIL000000321
:Entity_EDL_0000413	type	Person
:Entity_EDL_0000413	nominal_mention	"journalist"	iraqwar_guardian__1000-01-01__timeline:28596-28605	1.0
:Entity_EDL_0000413	link	NIL000000322
:Entity_EDL_0000414	type	Person
:Entity_EDL_0000414	nominal_mention	"Insurgents"	iraqwar_guardian__1000-01-01__timeline:44752-44761	1.0
:Entity_EDL_0000414	link	NIL000000323
:Entity_EDL_0000415	type	Person
:Entity_EDL_0000415	pronominal_mention	"dozens"	iraqwar_guardian__1000-01-01__timeline:18338-18343	1.0
:Entity_EDL_0000415	link	NIL000000324
:Entity_EDL_0000416	type	Facility
:Entity_EDL_0000416	nominal_mention	"home"	iraqwar_guardian__1000-01-01__timeline:27386-27389	1.0
:Entity_EDL_0000416	link	NIL000000325
:Entity_EDL_0000417	type	Person
:Entity_EDL_0000417	canonical_mention	"victims"	iraqwar_guardian__1000-01-01__timeline:3948-3954	1.0
:Entity_EDL_0000417	nominal_mention	"victims"	iraqwar_guardian__1000-01-01__timeline:3948-3954	1.0
:Entity_EDL_0000417	link	NIL000000326
:Entity_EDL_0000418	type	GeopoliticalEntity
:Entity_EDL_0000418	mention	"America"	iraqwar_guardian__1000-01-01__timeline:10017-10023	1.0
:Entity_EDL_0000418	link	6252001
:Entity_EDL_0000419	type	Weapon
:Entity_EDL_0000419	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:21019-21022	1.0
:Entity_EDL_0000419	link	NIL000000327
:Entity_EDL_0000420	type	Vehicle
:Entity_EDL_0000420	nominal_mention	"car"	iraqwar_guardian__1000-01-01__timeline:25309-25311	1.0
:Entity_EDL_0000420	link	NIL000000328
:Entity_EDL_0000421	type	Person
:Entity_EDL_0000421	pronominal_mention	"one"	iraqwar_guardian__1000-01-01__timeline:29586-29588	1.0
:Entity_EDL_0000421	link	NIL000000329
:Entity_EDL_0000422	type	GeopoliticalEntity
:Entity_EDL_0000422	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:50686-50692	1.0
:Entity_EDL_0000422	link	98182
:Entity_EDL_0000423	type	Vehicle
:Entity_EDL_0000423	canonical_mention	"ambulance"	iraqwar_guardian__1000-01-01__timeline:50827-50835	1.0
:Entity_EDL_0000423	nominal_mention	"ambulance"	iraqwar_guardian__1000-01-01__timeline:50827-50835	1.0
:Entity_EDL_0000423	link	NIL000000330
:Entity_EDL_0000424	type	Vehicle
:Entity_EDL_0000424	nominal_mention	"Land Rover"	iraqwar_guardian__1000-01-01__timeline:15669-15678	0.000
:Entity_EDL_0000424	link	NIL000000331
:Entity_EDL_0000425	type	Facility
:Entity_EDL_0000425	nominal_mention	"mosque"	iraqwar_guardian__1000-01-01__timeline:50676-50681	1.0
:Entity_EDL_0000425	link	NIL000000332
:Entity_EDL_0000426	type	Person
:Entity_EDL_0000426	nominal_mention	"envoy"	iraqwar_guardian__1000-01-01__timeline:26308-26312	1.0
:Entity_EDL_0000426	link	NIL000000333
:Entity_EDL_0000427	type	Person
:Entity_EDL_0000427	mention	"Saddam"	iraqwar_guardian__1000-01-01__timeline:6985-6990	1.0
:Entity_EDL_0000427	link	NIL000000334
:Entity_EDL_0000428	type	Person
:Entity_EDL_0000428	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:22248-22253	1.0
:Entity_EDL_0000428	link	NIL000000335
:Entity_EDL_0000429	type	GeopoliticalEntity
:Entity_EDL_0000429	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:47119-47122	1.0
:Entity_EDL_0000429	link	99237
:Entity_EDL_0000430	type	Vehicle
:Entity_EDL_0000430	nominal_mention	"helicopter"	iraqwar_guardian__1000-01-01__timeline:37202-37211	1.0
:Entity_EDL_0000430	link	NIL000000336
:Entity_EDL_0000431	type	Person
:Entity_EDL_0000431	nominal_mention	"militants"	iraqwar_guardian__1000-01-01__timeline:43931-43939	1.0
:Entity_EDL_0000431	link	NIL000000337
:Entity_EDL_0000432	type	Person
:Entity_EDL_0000432	canonical_mention	"national"	iraqwar_guardian__1000-01-01__timeline:27479-27486	1.0
:Entity_EDL_0000432	nominal_mention	"national"	iraqwar_guardian__1000-01-01__timeline:27479-27486	1.0
:Entity_EDL_0000432	link	NIL000000338
:Entity_EDL_0000433	type	Location
:Entity_EDL_0000433	canonical_mention	"heart"	iraqwar_guardian__1000-01-01__timeline:41860-41864	1.0
:Entity_EDL_0000433	nominal_mention	"heart"	iraqwar_guardian__1000-01-01__timeline:41860-41864	1.0
:Entity_EDL_0000433	link	NIL000000339
:Entity_EDL_0000434	type	Person
:Entity_EDL_0000434	nominal_mention	"Muslims"	iraqwar_guardian__1000-01-01__timeline:46202-46208	1.0
:Entity_EDL_0000434	link	NIL000000340
:Entity_EDL_0000435	type	GeopoliticalEntity
:Entity_EDL_0000435	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:24340-24343	1.0
:Entity_EDL_0000435	link	99237
:Entity_EDL_0000436	type	Person
:Entity_EDL_0000436	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:53648-53653	1.0
:Entity_EDL_0000436	link	NIL000000341
:Entity_EDL_0000437	type	Person
:Entity_EDL_0000437	canonical_mention	"seekers"	iraqwar_guardian__1000-01-01__timeline:17112-17118	1.0
:Entity_EDL_0000437	nominal_mention	"seekers"	iraqwar_guardian__1000-01-01__timeline:17112-17118	1.0
:Entity_EDL_0000437	link	NIL000000342
:Entity_EDL_0000438	type	GeopoliticalEntity
:Entity_EDL_0000438	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:27561-27564	1.0
:Entity_EDL_0000438	link	99237
:Entity_EDL_0000439	type	Person
:Entity_EDL_0000439	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:29183-29188	1.0
:Entity_EDL_0000439	link	NIL000000343
:Entity_EDL_0000440	type	Facility
:Entity_EDL_0000440	nominal_mention	"home"	iraqwar_guardian__1000-01-01__timeline:13437-13440	1.0
:Entity_EDL_0000440	link	NIL000000344
:Entity_EDL_0000441	type	Person
:Entity_EDL_0000441	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:32320-32325	1.0
:Entity_EDL_0000441	link	NIL000000345
:Entity_EDL_0000442	type	Person
:Entity_EDL_0000442	nominal_mention	"leader"	iraqwar_guardian__1000-01-01__timeline:53130-53135	1.0
:Entity_EDL_0000442	link	NIL000000346
:Entity_EDL_0000443	type	Person
:Entity_EDL_0000443	nominal_mention	"soldier"	iraqwar_guardian__1000-01-01__timeline:35017-35023	1.0
:Entity_EDL_0000443	link	NIL000000347
:Entity_EDL_0000444	type	Person
:Entity_EDL_0000444	canonical_mention	"battalion"	iraqwar_guardian__1000-01-01__timeline:21180-21188	1.0
:Entity_EDL_0000444	nominal_mention	"battalion"	iraqwar_guardian__1000-01-01__timeline:21180-21188	1.0
:Entity_EDL_0000444	link	NIL000000348
:Entity_EDL_0000445	type	GeopoliticalEntity
:Entity_EDL_0000445	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:28729-28732	1.0
:Entity_EDL_0000445	link	99237
:Entity_EDL_0000446	type	Location
:Entity_EDL_0000446	nominal_mention	"district"	iraqwar_guardian__1000-01-01__timeline:14394-14401	1.0
:Entity_EDL_0000446	link	NIL000000349
:Entity_EDL_0000447	type	Organization
:Entity_EDL_0000447	nominal_mention	"police"	iraqwar_guardian__1000-01-01__timeline:12959-12964	1.0
:Entity_EDL_0000447	link	NIL000000350
:Entity_EDL_0000448	type	Vehicle
:Entity_EDL_0000448	nominal_mention	"helicopter"	iraqwar_guardian__1000-01-01__timeline:37356-37365	1.0
:Entity_EDL_0000448	link	NIL000000351
:Entity_EDL_0000449	type	Facility
:Entity_EDL_0000449	canonical_mention	"what"	iraqwar_guardian__1000-01-01__timeline:41801-41804	1.0
:Entity_EDL_0000449	pronominal_mention	"what"	iraqwar_guardian__1000-01-01__timeline:41801-41804	1.0
:Entity_EDL_0000449	link	NIL000000352
:Entity_EDL_0000450	type	Person
:Entity_EDL_0000450	canonical_mention	"his"	iraqwar_guardian__1000-01-01__timeline:774-776	1.0
:Entity_EDL_0000450	pronominal_mention	"his"	iraqwar_guardian__1000-01-01__timeline:774-776	1.0
:Entity_EDL_0000450	link	NIL000000353
:Entity_EDL_0000451	type	Person
:Entity_EDL_0000451	canonical_mention	"44"	iraqwar_guardian__1000-01-01__timeline:33721-33722	1.0
:Entity_EDL_0000451	pronominal_mention	"44"	iraqwar_guardian__1000-01-01__timeline:33721-33722	1.0
:Entity_EDL_0000451	link	NIL000000354
:Entity_EDL_0000452	type	Facility
:Entity_EDL_0000452	canonical_mention	"market"	iraqwar_guardian__1000-01-01__timeline:24608-24613	1.0
:Entity_EDL_0000452	nominal_mention	"market"	iraqwar_guardian__1000-01-01__timeline:24608-24613	1.0
:Entity_EDL_0000452	link	NIL000000355
:Entity_EDL_0000453	type	Person
:Entity_EDL_0000453	canonical_mention	"agent"	iraqwar_guardian__1000-01-01__timeline:35086-35090	1.0
:Entity_EDL_0000453	nominal_mention	"agent"	iraqwar_guardian__1000-01-01__timeline:35086-35090	1.0
:Entity_EDL_0000453	link	NIL000000356
:Entity_EDL_0000454	type	Person
:Entity_EDL_0000454	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:25359-25366	1.0
:Entity_EDL_0000454	link	NIL000000357
:Entity_EDL_0000455	type	Person
:Entity_EDL_0000455	pronominal_mention	"four"	iraqwar_guardian__1000-01-01__timeline:3591-3594	1.0
:Entity_EDL_0000455	link	NIL000000358
:Entity_EDL_0000456	type	Person
:Entity_EDL_0000456	nominal_mention	"Iraqis"	iraqwar_guardian__1000-01-01__timeline:32085-32090	1.0
:Entity_EDL_0000456	link	NIL000000359
:Entity_EDL_0000457	type	Weapon
:Entity_EDL_0000457	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:24762-24765	1.0
:Entity_EDL_0000457	link	NIL000000360
:Entity_EDL_0000458	type	GeopoliticalEntity
:Entity_EDL_0000458	mention	"Italy"	iraqwar_guardian__1000-01-01__timeline:26176-26180	1.0
:Entity_EDL_0000458	link	3175395
:Entity_EDL_0000459	type	GeopoliticalEntity
:Entity_EDL_0000459	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:8599-8602	1.0
:Entity_EDL_0000459	link	99237
:Entity_EDL_0000460	type	GeopoliticalEntity
:Entity_EDL_0000460	nominal_mention	"Iraqis"	iraqwar_guardian__1000-01-01__timeline:41891-41896	1.0
:Entity_EDL_0000460	link	NIL000000361
:Entity_EDL_0000461	type	Location
:Entity_EDL_0000461	nominal_mention	"area"	iraqwar_guardian__1000-01-01__timeline:28188-28191	1.0
:Entity_EDL_0000461	link	NIL000000362
:Entity_EDL_0000462	type	Person
:Entity_EDL_0000462	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:51427-51432	1.0
:Entity_EDL_0000462	link	NIL000000363
:Entity_EDL_0000463	type	Facility
:Entity_EDL_0000463	nominal_mention	"house"	iraqwar_guardian__1000-01-01__timeline:53985-53989	1.0
:Entity_EDL_0000463	link	NIL000000364
:Entity_EDL_0000464	type	Location
:Entity_EDL_0000464	nominal_mention	"desert"	iraqwar_guardian__1000-01-01__timeline:48716-48721	1.0
:Entity_EDL_0000464	link	NIL000000365
:Entity_EDL_0000465	type	Location
:Entity_EDL_0000465	canonical_mention	"Tigris river"	iraqwar_guardian__1000-01-01__timeline:16153-16164	1.0
:Entity_EDL_0000465	mention	"Tigris river"	iraqwar_guardian__1000-01-01__timeline:16153-16164	1.0
:Entity_EDL_0000465	link	96998
:Entity_EDL_0000466	type	Person
:Entity_EDL_0000466	mention	"Saddam Hussein"	iraqwar_guardian__1000-01-01__timeline:6731-6744	1.0
:Entity_EDL_0000466	link	NIL000000366
:Entity_EDL_0000467	type	Person
:Entity_EDL_0000467	nominal_mention	"militants"	iraqwar_guardian__1000-01-01__timeline:14866-14874	1.0
:Entity_EDL_0000467	link	NIL000000367
:Entity_EDL_0000468	type	Weapon
:Entity_EDL_0000468	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:9063-9066	1.0
:Entity_EDL_0000468	link	NIL000000368
:Entity_EDL_0000469	type	Weapon
:Entity_EDL_0000469	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:30150-30153	1.0
:Entity_EDL_0000469	link	NIL000000369
:Entity_EDL_0000470	type	Person
:Entity_EDL_0000470	nominal_mention	"minister"	iraqwar_guardian__1000-01-01__timeline:37666-37673	1.0
:Entity_EDL_0000470	link	NIL000000370
:Entity_EDL_0000472	type	Person
:Entity_EDL_0000472	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:15787-15794	1.0
:Entity_EDL_0000472	link	NIL000000372
:Entity_EDL_0000473	type	Person
:Entity_EDL_0000473	nominal_mention	"Britons"	iraqwar_guardian__1000-01-01__timeline:23868-23874	1.0
:Entity_EDL_0000473	link	NIL000000373
:Entity_EDL_0000474	type	Weapon
:Entity_EDL_0000474	canonical_mention	"gun"	iraqwar_guardian__1000-01-01__timeline:52-54	1.0
:Entity_EDL_0000474	nominal_mention	"gun"	iraqwar_guardian__1000-01-01__timeline:52-54	1.0
:Entity_EDL_0000474	link	NIL000000374
:Entity_EDL_0000475	type	Person
:Entity_EDL_0000475	canonical_mention	"dead"	iraqwar_guardian__1000-01-01__timeline:9264-9267	1.0
:Entity_EDL_0000475	nominal_mention	"dead"	iraqwar_guardian__1000-01-01__timeline:9264-9267	1.0
:Entity_EDL_0000475	link	NIL000000375
:Entity_EDL_0000476	type	Person
:Entity_EDL_0000476	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:33947-33952	1.0
:Entity_EDL_0000476	link	NIL000000376
:Entity_EDL_0000477	type	Weapon
:Entity_EDL_0000477	nominal_mention	"bombs"	iraqwar_guardian__1000-01-01__timeline:36553-36557	1.0
:Entity_EDL_0000477	link	NIL000000377
:Entity_EDL_0000478	type	Person
:Entity_EDL_0000478	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:25998-26003	1.0
:Entity_EDL_0000478	link	NIL000000378
:Entity_EDL_0000479	type	GeopoliticalEntity
:Entity_EDL_0000479	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:53246-53249	1.0
:Entity_EDL_0000479	link	99237
:Entity_EDL_0000480	type	Weapon
:Entity_EDL_0000480	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:50654-50657	1.0
:Entity_EDL_0000480	link	NIL000000379
:Entity_EDL_0000481	type	Person
:Entity_EDL_0000481	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:11014-11021	1.0
:Entity_EDL_0000481	link	NIL000000380
:Entity_EDL_0000482	type	Person
:Entity_EDL_0000482	canonical_mention	"800"	iraqwar_guardian__1000-01-01__timeline:24943-24945	1.0
:Entity_EDL_0000482	pronominal_mention	"800"	iraqwar_guardian__1000-01-01__timeline:24943-24945	1.0
:Entity_EDL_0000482	link	NIL000000381
:Entity_EDL_0000483	type	Person
:Entity_EDL_0000483	canonical_mention	"Ayman al-Zawahiri"	iraqwar_guardian__1000-01-01__timeline:7777-7793	1.0
:Entity_EDL_0000483	mention	"Ayman al-Zawahiri"	iraqwar_guardian__1000-01-01__timeline:7777-7793	1.0
:Entity_EDL_0000483	link	NIL000000382
:Entity_EDL_0000484	type	GeopoliticalEntity
:Entity_EDL_0000484	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:3715-3718	1.0
:Entity_EDL_0000484	link	99237
:Entity_EDL_0000485	type	Person
:Entity_EDL_0000485	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:44853-44858	1.0
:Entity_EDL_0000485	link	NIL000000383
:Entity_EDL_0000486	type	Person
:Entity_EDL_0000486	pronominal_mention	"40"	iraqwar_guardian__1000-01-01__timeline:50741-50742	1.0
:Entity_EDL_0000486	link	NIL000000384
:Entity_EDL_0000487	type	Person
:Entity_EDL_0000487	canonical_mention	"others"	iraqwar_guardian__1000-01-01__timeline:4168-4173	1.0
:Entity_EDL_0000487	pronominal_mention	"others"	iraqwar_guardian__1000-01-01__timeline:4168-4173	1.0
:Entity_EDL_0000487	link	NIL000000385
:Entity_EDL_0000488	type	GeopoliticalEntity
:Entity_EDL_0000488	canonical_mention	"countries"	iraqwar_guardian__1000-01-01__timeline:8902-8910	1.0
:Entity_EDL_0000488	nominal_mention	"countries"	iraqwar_guardian__1000-01-01__timeline:8902-8910	1.0
:Entity_EDL_0000488	link	NIL000000386
:Entity_EDL_0000489	type	Person
:Entity_EDL_0000489	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:8846-8855	1.0
:Entity_EDL_0000489	link	NIL000000387
:Entity_EDL_0000490	type	GeopoliticalEntity
:Entity_EDL_0000490	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:38471-38477	1.0
:Entity_EDL_0000490	link	98182
:Entity_EDL_0000491	type	Person
:Entity_EDL_0000491	nominal_mention	"commandos"	iraqwar_guardian__1000-01-01__timeline:41746-41754	1.0
:Entity_EDL_0000491	link	NIL000000388
:Entity_EDL_0000492	type	GeopoliticalEntity
:Entity_EDL_0000492	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:10561-10564	1.0
:Entity_EDL_0000492	link	99237
:Entity_EDL_0000493	type	Person
:Entity_EDL_0000493	nominal_mention	"envoy"	iraqwar_guardian__1000-01-01__timeline:26573-26577	1.0
:Entity_EDL_0000493	link	NIL000000389
:Entity_EDL_0000494	type	Person
:Entity_EDL_0000494	nominal_mention	"soldier"	iraqwar_guardian__1000-01-01__timeline:30169-30175	1.0
:Entity_EDL_0000494	link	NIL000000390
:Entity_EDL_0000495	type	GeopoliticalEntity
:Entity_EDL_0000495	mention	"US"	iraqwar_guardian__1000-01-01__timeline:51584-51585	1.0
:Entity_EDL_0000495	link	6252001
:Entity_EDL_0000496	type	Organization
:Entity_EDL_0000496	nominal_mention	"military"	iraqwar_guardian__1000-01-01__timeline:12931-12938	1.0
:Entity_EDL_0000496	link	NIL000000391
:Entity_EDL_0000497	type	Person
:Entity_EDL_0000497	nominal_mention	"policemen"	iraqwar_guardian__1000-01-01__timeline:49236-49244	1.0
:Entity_EDL_0000497	link	NIL000000392
:Entity_EDL_0000499	type	Person
:Entity_EDL_0000499	nominal_mention	"soldier"	iraqwar_guardian__1000-01-01__timeline:29974-29980	1.0
:Entity_EDL_0000499	link	NIL000000393
:Entity_EDL_0000500	type	Person
:Entity_EDL_0000500	canonical_mention	"46"	iraqwar_guardian__1000-01-01__timeline:44065-44066	1.0
:Entity_EDL_0000500	nominal_mention	"46"	iraqwar_guardian__1000-01-01__timeline:44065-44066	1.0
:Entity_EDL_0000500	link	NIL000000394
:Entity_EDL_0000501	type	GeopoliticalEntity
:Entity_EDL_0000501	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:18590-18593	1.0
:Entity_EDL_0000501	link	99237
:Entity_EDL_0000502	type	GeopoliticalEntity
:Entity_EDL_0000502	mention	"Hawija"	iraqwar_guardian__1000-01-01__timeline:33492-33497	1.0
:Entity_EDL_0000502	link	95889
:Entity_EDL_0000503	type	Person
:Entity_EDL_0000503	nominal_mention	"another"	iraqwar_guardian__1000-01-01__timeline:34405-34411	1.0
:Entity_EDL_0000503	link	NIL000000395
:Entity_EDL_0000504	type	Person
:Entity_EDL_0000504	nominal_mention	"officers"	iraqwar_guardian__1000-01-01__timeline:12164-12171	1.0
:Entity_EDL_0000504	link	NIL000000396
:Entity_EDL_0000505	type	Facility
:Entity_EDL_0000505	nominal_mention	"checkpoint"	iraqwar_guardian__1000-01-01__timeline:34734-34743	1.0
:Entity_EDL_0000505	link	NIL000000397
:Entity_EDL_0000506	type	GeopoliticalEntity
:Entity_EDL_0000506	mention	"Iraqi"	iraqwar_guardian__1000-01-01__timeline:23625-23629	1.0
:Entity_EDL_0000506	link	99237
:Entity_EDL_0000507	type	Person
:Entity_EDL_0000507	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:54546-54551	1.0
:Entity_EDL_0000507	link	NIL000000398
:Entity_EDL_0000508	type	Person
:Entity_EDL_0000508	nominal_mention	"civilians"	iraqwar_guardian__1000-01-01__timeline:23910-23918	1.0
:Entity_EDL_0000508	link	NIL000000399
:Entity_EDL_0000509	type	GeopoliticalEntity
:Entity_EDL_0000509	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:14240-14246	1.0
:Entity_EDL_0000509	link	98182
:Entity_EDL_0000510	type	Weapon
:Entity_EDL_0000510	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:27546-27549	1.0
:Entity_EDL_0000510	link	NIL000000400
:Entity_EDL_0000511	type	GeopoliticalEntity
:Entity_EDL_0000511	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:11641-11644	1.0
:Entity_EDL_0000511	link	99237
:Entity_EDL_0000512	type	GeopoliticalEntity
:Entity_EDL_0000512	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:51127-51133	1.0
:Entity_EDL_0000512	link	98182
:Entity_EDL_0000513	type	GeopoliticalEntity
:Entity_EDL_0000513	nominal_mention	"country"	iraqwar_guardian__1000-01-01__timeline:25971-25977	1.0
:Entity_EDL_0000513	link	NIL000000401
:Entity_EDL_0000514	type	Organization
:Entity_EDL_0000514	nominal_mention	"group"	iraqwar_guardian__1000-01-01__timeline:34148-34152	1.0
:Entity_EDL_0000514	link	NIL000000402
:Entity_EDL_0000515	type	Person
:Entity_EDL_0000515	canonical_mention	"judge"	iraqwar_guardian__1000-01-01__timeline:4839-4843	1.0
:Entity_EDL_0000515	nominal_mention	"judge"	iraqwar_guardian__1000-01-01__timeline:4839-4843	1.0
:Entity_EDL_0000515	link	NIL000000403
:Entity_EDL_0000516	type	Person
:Entity_EDL_0000516	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:24739-24746	1.0
:Entity_EDL_0000516	link	NIL000000404
:Entity_EDL_0000517	type	Person
:Entity_EDL_0000517	nominal_mention	"bombers"	iraqwar_guardian__1000-01-01__timeline:9334-9340	1.0
:Entity_EDL_0000517	link	NIL000000405
:Entity_EDL_0000518	type	GeopoliticalEntity
:Entity_EDL_0000518	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:10422-10425	1.0
:Entity_EDL_0000518	link	99237
:Entity_EDL_0000519	type	Person
:Entity_EDL_0000519	nominal_mention	"marine"	iraqwar_guardian__1000-01-01__timeline:11516-11521	1.0
:Entity_EDL_0000519	link	NIL000000406
:Entity_EDL_0000520	type	Person
:Entity_EDL_0000520	nominal_mention	"Insurgents"	iraqwar_guardian__1000-01-01__timeline:37159-37168	1.0
:Entity_EDL_0000520	link	NIL000000407
:Entity_EDL_0000521	type	Location
:Entity_EDL_0000521	nominal_mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:49213-49219	1.0
:Entity_EDL_0000521	link	NIL000000408
:Entity_EDL_0000522	type	Person
:Entity_EDL_0000522	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:52230-52235	1.0
:Entity_EDL_0000522	link	NIL000000409
:Entity_EDL_0000523	type	GeopoliticalEntity
:Entity_EDL_0000523	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:5176-5179	1.0
:Entity_EDL_0000523	link	99237
:Entity_EDL_0000525	type	Person
:Entity_EDL_0000525	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:36626-36631	1.0
:Entity_EDL_0000525	link	NIL000000411
:Entity_EDL_0000526	type	Person
:Entity_EDL_0000526	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:33699-33704	1.0
:Entity_EDL_0000526	link	NIL000000412
:Entity_EDL_0000527	type	Person
:Entity_EDL_0000527	nominal_mention	"Police"	iraqwar_guardian__1000-01-01__timeline:27569-27574	1.0
:Entity_EDL_0000527	link	NIL000000413
:Entity_EDL_0000528	type	Facility
:Entity_EDL_0000528	nominal_mention	"home"	iraqwar_guardian__1000-01-01__timeline:27609-27612	1.0
:Entity_EDL_0000528	link	NIL000000414
:Entity_EDL_0000529	type	Person
:Entity_EDL_0000529	canonical_mention	"cadets"	iraqwar_guardian__1000-01-01__timeline:1893-1898	1.0
:Entity_EDL_0000529	nominal_mention	"cadets"	iraqwar_guardian__1000-01-01__timeline:1893-1898	1.0
:Entity_EDL_0000529	link	NIL000000415
:Entity_EDL_0000530	type	Weapon
:Entity_EDL_0000530	canonical_mention	"gunpoint"	iraqwar_guardian__1000-01-01__timeline:49615-49622	1.0
:Entity_EDL_0000530	nominal_mention	"gunpoint"	iraqwar_guardian__1000-01-01__timeline:49615-49622	1.0
:Entity_EDL_0000530	link	NIL000000416
:Entity_EDL_0000531	type	Person
:Entity_EDL_0000531	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:24509-24514	1.0
:Entity_EDL_0000531	link	NIL000000417
:Entity_EDL_0000532	type	Weapon
:Entity_EDL_0000532	nominal_mention	"bombs"	iraqwar_guardian__1000-01-01__timeline:35172-35176	1.0
:Entity_EDL_0000532	link	NIL000000418
:Entity_EDL_0000533	type	GeopoliticalEntity
:Entity_EDL_0000533	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:52679-52682	1.0
:Entity_EDL_0000533	link	99237
:Entity_EDL_0000534	type	GeopoliticalEntity
:Entity_EDL_0000534	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:52133-52136	1.0
:Entity_EDL_0000534	link	99237
:Entity_EDL_0000535	type	Person
:Entity_EDL_0000535	pronominal_mention	"some"	iraqwar_guardian__1000-01-01__timeline:3929-3932	1.0
:Entity_EDL_0000535	link	NIL000000419
:Entity_EDL_0000536	type	Person
:Entity_EDL_0000536	canonical_mention	"fighters"	iraqwar_guardian__1000-01-01__timeline:8948-8955	1.0
:Entity_EDL_0000536	nominal_mention	"fighters"	iraqwar_guardian__1000-01-01__timeline:8948-8955	1.0
:Entity_EDL_0000536	link	NIL000000420
:Entity_EDL_0000537	type	Person
:Entity_EDL_0000537	nominal_mention	"Head"	iraqwar_guardian__1000-01-01__timeline:46844-46847	1.0
:Entity_EDL_0000537	link	NIL000000421
:Entity_EDL_0000539	type	Weapon
:Entity_EDL_0000539	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:3618-3621	1.0
:Entity_EDL_0000539	link	NIL000000422
:Entity_EDL_0000540	type	Person
:Entity_EDL_0000540	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:45175-45180	1.0
:Entity_EDL_0000540	link	NIL000000423
:Entity_EDL_0000541	type	GeopoliticalEntity
:Entity_EDL_0000541	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:35181-35184	1.0
:Entity_EDL_0000541	link	99237
:Entity_EDL_0000542	type	Weapon
:Entity_EDL_0000542	canonical_mention	"bombs"	iraqwar_guardian__1000-01-01__timeline:8384-8388	1.0
:Entity_EDL_0000542	nominal_mention	"bombs"	iraqwar_guardian__1000-01-01__timeline:8384-8388	1.0
:Entity_EDL_0000542	link	NIL000000424
:Entity_EDL_0000543	type	Person
:Entity_EDL_0000543	canonical_mention	"150"	iraqwar_guardian__1000-01-01__timeline:24445-24447	1.0
:Entity_EDL_0000543	pronominal_mention	"150"	iraqwar_guardian__1000-01-01__timeline:24445-24447	1.0
:Entity_EDL_0000543	link	NIL000000425
:Entity_EDL_0000544	type	GeopoliticalEntity
:Entity_EDL_0000544	mention	"British"	iraqwar_guardian__1000-01-01__timeline:42799-42805	1.0
:Entity_EDL_0000544	link	2635167
:Entity_EDL_0000545	type	Person
:Entity_EDL_0000545	pronominal_mention	"others"	iraqwar_guardian__1000-01-01__timeline:43868-43873	1.0
:Entity_EDL_0000545	link	NIL000000426
:Entity_EDL_0000546	type	Organization
:Entity_EDL_0000546	canonical_mention	"regime"	iraqwar_guardian__1000-01-01__timeline:33304-33309	1.0
:Entity_EDL_0000546	nominal_mention	"regime"	iraqwar_guardian__1000-01-01__timeline:33304-33309	1.0
:Entity_EDL_0000546	link	NIL000000427
:Entity_EDL_0000547	type	Person
:Entity_EDL_0000547	canonical_mention	"Muslims"	iraqwar_guardian__1000-01-01__timeline:3129-3135	1.0
:Entity_EDL_0000547	nominal_mention	"Muslims"	iraqwar_guardian__1000-01-01__timeline:3129-3135	1.0
:Entity_EDL_0000547	link	NIL000000428
:Entity_EDL_0000548	type	Person
:Entity_EDL_0000548	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:34923-34930	1.0
:Entity_EDL_0000548	link	NIL000000429
:Entity_EDL_0000549	type	Person
:Entity_EDL_0000549	nominal_mention	"official"	iraqwar_guardian__1000-01-01__timeline:46684-46691	1.0
:Entity_EDL_0000549	link	NIL000000430
:Entity_EDL_0000550	type	Person
:Entity_EDL_0000550	canonical_mention	"Wael al-Rubaei"	iraqwar_guardian__1000-01-01__timeline:31002-31015	1.0
:Entity_EDL_0000550	mention	"Wael al-Rubaei"	iraqwar_guardian__1000-01-01__timeline:31002-31015	1.0
:Entity_EDL_0000550	link	NIL000000431
:Entity_EDL_0000551	type	Person
:Entity_EDL_0000551	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:43553-43558	1.0
:Entity_EDL_0000551	link	NIL000000432
:Entity_EDL_0000552	type	Organization
:Entity_EDL_0000552	nominal_mention	"army"	iraqwar_guardian__1000-01-01__timeline:46981-46984	1.0
:Entity_EDL_0000552	link	NIL000000433
:Entity_EDL_0000553	type	Person
:Entity_EDL_0000553	canonical_mention	"investigators"	iraqwar_guardian__1000-01-01__timeline:52883-52895	1.0
:Entity_EDL_0000553	nominal_mention	"investigators"	iraqwar_guardian__1000-01-01__timeline:52883-52895	1.0
:Entity_EDL_0000553	link	NIL000000434
:Entity_EDL_0000554	type	Person
:Entity_EDL_0000554	mention	"Saddam Hussein"	iraqwar_guardian__1000-01-01__timeline:37799-37812	1.0
:Entity_EDL_0000554	link	NIL000000435
:Entity_EDL_0000555	type	Person
:Entity_EDL_0000555	canonical_mention	"they"	iraqwar_guardian__1000-01-01__timeline:3044-3047	1.0
:Entity_EDL_0000555	nominal_mention	"they"	iraqwar_guardian__1000-01-01__timeline:3044-3047	1.0
:Entity_EDL_0000555	link	NIL000000436
:Entity_EDL_0000556	type	Organization
:Entity_EDL_0000556	mention	"foreign"	iraqwar_guardian__1000-01-01__timeline:28428-28434	1.0
:Entity_EDL_0000556	link	NIL000000437
:Entity_EDL_0000557	type	Weapon
:Entity_EDL_0000557	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:34435-34438	1.0
:Entity_EDL_0000557	link	NIL000000438
:Entity_EDL_0000558	type	Person
:Entity_EDL_0000558	nominal_mention	"judge"	iraqwar_guardian__1000-01-01__timeline:5000-5004	1.0
:Entity_EDL_0000558	link	NIL000000439
:Entity_EDL_0000559	type	Person
:Entity_EDL_0000559	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:44052-44057	1.0
:Entity_EDL_0000559	link	NIL000000440
:Entity_EDL_0000560	type	Person
:Entity_EDL_0000560	canonical_mention	"inmates"	iraqwar_guardian__1000-01-01__timeline:9785-9791	1.0
:Entity_EDL_0000560	nominal_mention	"inmates"	iraqwar_guardian__1000-01-01__timeline:9785-9791	1.0
:Entity_EDL_0000560	link	NIL000000441
:Entity_EDL_0000561	type	Vehicle
:Entity_EDL_0000561	nominal_mention	"minibus"	iraqwar_guardian__1000-01-01__timeline:14323-14329	1.0
:Entity_EDL_0000561	link	NIL000000442
:Entity_EDL_0000562	type	Vehicle
:Entity_EDL_0000562	nominal_mention	"convoy"	iraqwar_guardian__1000-01-01__timeline:30075-30080	1.0
:Entity_EDL_0000562	link	NIL000000443
:Entity_EDL_0000563	type	GeopoliticalEntity
:Entity_EDL_0000563	mention	"UK"	iraqwar_guardian__1000-01-01__timeline:27285-27286	1.0
:Entity_EDL_0000563	link	2635167
:Entity_EDL_0000564	type	Facility
:Entity_EDL_0000564	mention	"Abu Ghraib jail"	iraqwar_guardian__1000-01-01__timeline:39604-39618	1.0
:Entity_EDL_0000564	link	NIL000000444
:Entity_EDL_0000565	type	Location
:Entity_EDL_0000565	nominal_mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:30094-30097	1.0
:Entity_EDL_0000565	link	NIL000000445
:Entity_EDL_0000566	type	Vehicle
:Entity_EDL_0000566	canonical_mention	"helicopters"	iraqwar_guardian__1000-01-01__timeline:7146-7156	1.0
:Entity_EDL_0000566	nominal_mention	"helicopters"	iraqwar_guardian__1000-01-01__timeline:7146-7156	1.0
:Entity_EDL_0000566	link	NIL000000446
:Entity_EDL_0000567	type	Person
:Entity_EDL_0000567	pronominal_mention	"40"	iraqwar_guardian__1000-01-01__timeline:4340-4341	1.0
:Entity_EDL_0000567	link	NIL000000447
:Entity_EDL_0000568	type	Person
:Entity_EDL_0000568	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:53455-53460	1.0
:Entity_EDL_0000568	link	NIL000000448
:Entity_EDL_0000569	type	GeopoliticalEntity
:Entity_EDL_0000569	nominal_mention	"country"	iraqwar_guardian__1000-01-01__timeline:48413-48419	1.0
:Entity_EDL_0000569	link	NIL000000449
:Entity_EDL_0000570	type	Person
:Entity_EDL_0000570	pronominal_mention	"more"	iraqwar_guardian__1000-01-01__timeline:49072-49075	1.0
:Entity_EDL_0000570	link	NIL000000450
:Entity_EDL_0000571	type	Person
:Entity_EDL_0000571	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:18751-18756	1.0
:Entity_EDL_0000571	link	NIL000000451
:Entity_EDL_0000572	type	Person
:Entity_EDL_0000572	nominal_mention	"police"	iraqwar_guardian__1000-01-01__timeline:45333-45338	1.0
:Entity_EDL_0000572	link	NIL000000452
:Entity_EDL_0000573	type	Vehicle
:Entity_EDL_0000573	canonical_mention	"truck"	iraqwar_guardian__1000-01-01__timeline:22611-22615	1.0
:Entity_EDL_0000573	nominal_mention	"truck"	iraqwar_guardian__1000-01-01__timeline:22611-22615	1.0
:Entity_EDL_0000573	link	NIL000000453
:Entity_EDL_0000574	type	Person
:Entity_EDL_0000574	canonical_mention	"men"	iraqwar_guardian__1000-01-01__timeline:6818-6820	1.0
:Entity_EDL_0000574	nominal_mention	"men"	iraqwar_guardian__1000-01-01__timeline:6818-6820	1.0
:Entity_EDL_0000574	link	NIL000000454
:Entity_EDL_0000575	type	Person
:Entity_EDL_0000575	canonical_mention	"20"	iraqwar_guardian__1000-01-01__timeline:38424-38425	1.0
:Entity_EDL_0000575	pronominal_mention	"20"	iraqwar_guardian__1000-01-01__timeline:38424-38425	1.0
:Entity_EDL_0000575	link	NIL000000455
:Entity_EDL_0000576	type	Person
:Entity_EDL_0000576	nominal_mention	"commanders"	iraqwar_guardian__1000-01-01__timeline:53765-53774	1.0
:Entity_EDL_0000576	link	NIL000000456
:Entity_EDL_0000577	type	Person
:Entity_EDL_0000577	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:41171-41180	1.0
:Entity_EDL_0000577	link	NIL000000457
:Entity_EDL_0000578	type	Person
:Entity_EDL_0000578	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:49983-49988	1.0
:Entity_EDL_0000578	link	NIL000000458
:Entity_EDL_0000579	type	GeopoliticalEntity
:Entity_EDL_0000579	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:21503-21509	1.0
:Entity_EDL_0000579	link	98182
:Entity_EDL_0000580	type	Person
:Entity_EDL_0000580	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:35208-35213	1.0
:Entity_EDL_0000580	link	NIL000000459
:Entity_EDL_0000582	type	GeopoliticalEntity
:Entity_EDL_0000582	nominal_mention	"town"	iraqwar_guardian__1000-01-01__timeline:45024-45027	1.0
:Entity_EDL_0000582	link	NIL000000461
:Entity_EDL_0000583	type	Person
:Entity_EDL_0000583	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:24909-24918	1.0
:Entity_EDL_0000583	link	NIL000000462
:Entity_EDL_0000584	type	Person
:Entity_EDL_0000584	canonical_mention	"warders"	iraqwar_guardian__1000-01-01__timeline:87-93	1.0
:Entity_EDL_0000584	nominal_mention	"warders"	iraqwar_guardian__1000-01-01__timeline:87-93	1.0
:Entity_EDL_0000584	link	NIL000000463
:Entity_EDL_0000585	type	Person
:Entity_EDL_0000585	nominal_mention	"prisoners"	iraqwar_guardian__1000-01-01__timeline:45434-45442	1.0
:Entity_EDL_0000585	link	NIL000000464
:Entity_EDL_0000586	type	GeopoliticalEntity
:Entity_EDL_0000586	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:46663-46666	1.0
:Entity_EDL_0000586	link	99237
:Entity_EDL_0000587	type	GeopoliticalEntity
:Entity_EDL_0000587	canonical_mention	"cities"	iraqwar_guardian__1000-01-01__timeline:31483-31488	1.0
:Entity_EDL_0000587	nominal_mention	"cities"	iraqwar_guardian__1000-01-01__timeline:31483-31488	1.0
:Entity_EDL_0000587	link	NIL000000465
:Entity_EDL_0000588	type	Weapon
:Entity_EDL_0000588	nominal_mention	"Bomb"	iraqwar_guardian__1000-01-01__timeline:34998-35001	1.0
:Entity_EDL_0000588	link	NIL000000466
:Entity_EDL_0000589	type	GeopoliticalEntity
:Entity_EDL_0000589	canonical_mention	"Manchester"	iraqwar_guardian__1000-01-01__timeline:27394-27403	1.0
:Entity_EDL_0000589	mention	"Manchester"	iraqwar_guardian__1000-01-01__timeline:27394-27403	1.0
:Entity_EDL_0000589	link	3333169
:Entity_EDL_0000590	type	GeopoliticalEntity
:Entity_EDL_0000590	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:33912-33915	1.0
:Entity_EDL_0000590	link	99237
:Entity_EDL_0000591	type	Person
:Entity_EDL_0000591	canonical_mention	"Rory Carroll"	iraqwar_guardian__1000-01-01__timeline:6456-6467	1.0
:Entity_EDL_0000591	mention	"Rory Carroll"	iraqwar_guardian__1000-01-01__timeline:6456-6467	1.0
:Entity_EDL_0000591	link	NIL000000467
:Entity_EDL_0000592	type	Person
:Entity_EDL_0000592	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:28052-28061	1.0
:Entity_EDL_0000592	link	NIL000000468
:Entity_EDL_0000593	type	Person
:Entity_EDL_0000593	canonical_mention	"most"	iraqwar_guardian__1000-01-01__timeline:25574-25577	1.0
:Entity_EDL_0000593	pronominal_mention	"most"	iraqwar_guardian__1000-01-01__timeline:25574-25577	1.0
:Entity_EDL_0000593	link	NIL000000469
:Entity_EDL_0000594	type	Person
:Entity_EDL_0000594	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:31372-31377	1.0
:Entity_EDL_0000594	link	NIL000000470
:Entity_EDL_0000595	type	Person
:Entity_EDL_0000595	nominal_mention	"prisoners"	iraqwar_guardian__1000-01-01__timeline:52442-52450	1.0
:Entity_EDL_0000595	link	NIL000000471
:Entity_EDL_0000596	type	Person
:Entity_EDL_0000596	nominal_mention	"officers"	iraqwar_guardian__1000-01-01__timeline:12980-12987	1.0
:Entity_EDL_0000596	link	NIL000000472
:Entity_EDL_0000597	type	Person
:Entity_EDL_0000597	canonical_mention	"25"	iraqwar_guardian__1000-01-01__timeline:25289-25290	1.0
:Entity_EDL_0000597	pronominal_mention	"25"	iraqwar_guardian__1000-01-01__timeline:25289-25290	1.0
:Entity_EDL_0000597	link	NIL000000473
:Entity_EDL_0000598	type	Person
:Entity_EDL_0000598	pronominal_mention	"he"	iraqwar_guardian__1000-01-01__timeline:37817-37818	1.0
:Entity_EDL_0000598	link	NIL000000474
:Entity_EDL_0000599	type	GeopoliticalEntity
:Entity_EDL_0000599	nominal_mention	"town"	iraqwar_guardian__1000-01-01__timeline:27728-27731	1.0
:Entity_EDL_0000599	link	NIL000000475
:Entity_EDL_0000600	type	Person
:Entity_EDL_0000600	canonical_mention	"crowd"	iraqwar_guardian__1000-01-01__timeline:14368-14372	1.0
:Entity_EDL_0000600	nominal_mention	"crowd"	iraqwar_guardian__1000-01-01__timeline:14368-14372	1.0
:Entity_EDL_0000600	link	NIL000000476
:Entity_EDL_0000601	type	GeopoliticalEntity
:Entity_EDL_0000601	mention	"Iraqi"	iraqwar_guardian__1000-01-01__timeline:25159-25163	1.0
:Entity_EDL_0000601	link	99237
:Entity_EDL_0000602	type	Person
:Entity_EDL_0000602	canonical_mention	"attacker"	iraqwar_guardian__1000-01-01__timeline:33747-33754	1.0
:Entity_EDL_0000602	nominal_mention	"attacker"	iraqwar_guardian__1000-01-01__timeline:33747-33754	1.0
:Entity_EDL_0000602	link	NIL000000477
:Entity_EDL_0000603	type	Person
:Entity_EDL_0000603	nominal_mention	"journalist"	iraqwar_guardian__1000-01-01__timeline:44494-44503	1.0
:Entity_EDL_0000603	link	NIL000000478
:Entity_EDL_0000604	type	Organization
:Entity_EDL_0000604	nominal_mention	"government"	iraqwar_guardian__1000-01-01__timeline:35513-35522	1.0
:Entity_EDL_0000604	link	NIL000000479
:Entity_EDL_0000605	type	GeopoliticalEntity
:Entity_EDL_0000605	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:37746-37749	1.0
:Entity_EDL_0000605	link	99237
:Entity_EDL_0000606	type	Person
:Entity_EDL_0000606	nominal_mention	"Iraqis"	iraqwar_guardian__1000-01-01__timeline:48924-48929	1.0
:Entity_EDL_0000606	link	NIL000000480
:Entity_EDL_0000607	type	Person
:Entity_EDL_0000607	canonical_mention	"Alan Brackenbury"	iraqwar_guardian__1000-01-01__timeline:29999-30014	1.0
:Entity_EDL_0000607	mention	"Alan Brackenbury"	iraqwar_guardian__1000-01-01__timeline:29999-30014	1.0
:Entity_EDL_0000607	link	NIL000000481
:Entity_EDL_0000608	type	Person
:Entity_EDL_0000608	nominal_mention	"Gunmen"	iraqwar_guardian__1000-01-01__timeline:10392-10397	1.0
:Entity_EDL_0000608	link	NIL000000482
:Entity_EDL_0000609	type	Person
:Entity_EDL_0000609	nominal_mention	"they"	iraqwar_guardian__1000-01-01__timeline:11053-11056	1.0
:Entity_EDL_0000609	link	NIL000000483
:Entity_EDL_0000610	type	Person
:Entity_EDL_0000610	pronominal_mention	"his"	iraqwar_guardian__1000-01-01__timeline:34828-34830	1.0
:Entity_EDL_0000610	link	NIL000000484
:Entity_EDL_0000611	type	Facility
:Entity_EDL_0000611	canonical_mention	"sites"	iraqwar_guardian__1000-01-01__timeline:3108-3112	1.0
:Entity_EDL_0000611	nominal_mention	"sites"	iraqwar_guardian__1000-01-01__timeline:3108-3112	1.0
:Entity_EDL_0000611	link	NIL000000485
:Entity_EDL_0000612	type	GeopoliticalEntity
:Entity_EDL_0000612	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:53376-53379	1.0
:Entity_EDL_0000612	link	99237
:Entity_EDL_0000613	type	Person
:Entity_EDL_0000613	pronominal_mention	"Thousands"	iraqwar_guardian__1000-01-01__timeline:16291-16299	1.0
:Entity_EDL_0000613	link	NIL000000486
:Entity_EDL_0000614	type	GeopoliticalEntity
:Entity_EDL_0000614	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:26705-26708	1.0
:Entity_EDL_0000614	link	99237
:Entity_EDL_0000615	type	Person
:Entity_EDL_0000615	nominal_mention	"Men"	iraqwar_guardian__1000-01-01__timeline:13389-13391	1.0
:Entity_EDL_0000615	link	NIL000000487
:Entity_EDL_0000616	type	Person
:Entity_EDL_0000616	nominal_mention	"reservist"	iraqwar_guardian__1000-01-01__timeline:52323-52331	1.0
:Entity_EDL_0000616	link	NIL000000488
:Entity_EDL_0000617	type	Person
:Entity_EDL_0000617	nominal_mention	"Muslims"	iraqwar_guardian__1000-01-01__timeline:14218-14224	1.0
:Entity_EDL_0000617	link	NIL000000489
:Entity_EDL_0000618	type	Person
:Entity_EDL_0000618	nominal_mention	"marines"	iraqwar_guardian__1000-01-01__timeline:21341-21347	1.0
:Entity_EDL_0000618	link	NIL000000490
:Entity_EDL_0000619	type	Facility
:Entity_EDL_0000619	nominal_mention	"bases"	iraqwar_guardian__1000-01-01__timeline:31667-31671	1.0
:Entity_EDL_0000619	link	NIL000000491
:Entity_EDL_0000620	type	Person
:Entity_EDL_0000620	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:32103-32110	1.0
:Entity_EDL_0000620	link	NIL000000492
:Entity_EDL_0000621	type	Person
:Entity_EDL_0000621	canonical_mention	"translators"	iraqwar_guardian__1000-01-01__timeline:41109-41119	1.0
:Entity_EDL_0000621	nominal_mention	"translators"	iraqwar_guardian__1000-01-01__timeline:41109-41119	1.0
:Entity_EDL_0000621	link	NIL000000493
:Entity_EDL_0000622	type	Facility
:Entity_EDL_0000622	mention	"Abu Ghraib"	iraqwar_guardian__1000-01-01__timeline:44356-44365	1.0
:Entity_EDL_0000622	link	NIL000000494
:Entity_EDL_0000624	type	Person
:Entity_EDL_0000624	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:4765-4772	1.0
:Entity_EDL_0000624	link	NIL000000496
:Entity_EDL_0000625	type	GeopoliticalEntity
:Entity_EDL_0000625	canonical_mention	"Germany"	iraqwar_guardian__1000-01-01__timeline:47484-47490	1.0
:Entity_EDL_0000625	mention	"Germany"	iraqwar_guardian__1000-01-01__timeline:47484-47490	1.0
:Entity_EDL_0000625	link	2921044
:Entity_EDL_0000626	type	Person
:Entity_EDL_0000626	nominal_mention	"civilian"	iraqwar_guardian__1000-01-01__timeline:31281-31288	1.0
:Entity_EDL_0000626	link	NIL000000497
:Entity_EDL_0000627	type	Person
:Entity_EDL_0000627	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:21523-21528	1.0
:Entity_EDL_0000627	link	NIL000000498
:Entity_EDL_0000628	type	Person
:Entity_EDL_0000628	mention	"Saddam Hussein"	iraqwar_guardian__1000-01-01__timeline:6630-6643	1.0
:Entity_EDL_0000628	link	NIL000000499
:Entity_EDL_0000629	type	GeopoliticalEntity
:Entity_EDL_0000629	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:25600-25603	1.0
:Entity_EDL_0000629	link	99237
:Entity_EDL_0000631	type	Person
:Entity_EDL_0000631	pronominal_mention	"He"	iraqwar_guardian__1000-01-01__timeline:13550-13551	1.0
:Entity_EDL_0000631	link	NIL000000501
:Entity_EDL_0000632	type	GeopoliticalEntity
:Entity_EDL_0000632	mention	"Basra"	iraqwar_guardian__1000-01-01__timeline:12806-12810	1.0
:Entity_EDL_0000632	link	99532
:Entity_EDL_0000633	type	GeopoliticalEntity
:Entity_EDL_0000633	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:22635-22641	1.0
:Entity_EDL_0000633	link	98182
:Entity_EDL_0000634	type	Weapon
:Entity_EDL_0000634	canonical_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:2408-2411	1.0
:Entity_EDL_0000634	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:2408-2411	1.0
:Entity_EDL_0000634	link	NIL000000502
:Entity_EDL_0000635	type	Person
:Entity_EDL_0000635	nominal_mention	"Britons"	iraqwar_guardian__1000-01-01__timeline:21605-21611	1.0
:Entity_EDL_0000635	link	NIL000000503
:Entity_EDL_0000636	type	Vehicle
:Entity_EDL_0000636	nominal_mention	"car"	iraqwar_guardian__1000-01-01__timeline:29501-29503	1.0
:Entity_EDL_0000636	link	NIL000000504
:Entity_EDL_0000637	type	GeopoliticalEntity
:Entity_EDL_0000637	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:18690-18696	1.0
:Entity_EDL_0000637	link	98182
:Entity_EDL_0000638	type	Person
:Entity_EDL_0000638	mention	"Berlusconi"	iraqwar_guardian__1000-01-01__timeline:26080-26089	1.0
:Entity_EDL_0000638	link	NIL000000505
:Entity_EDL_0000639	type	Facility
:Entity_EDL_0000639	canonical_mention	"Trafalgar Square"	iraqwar_guardian__1000-01-01__timeline:42615-42630	1.0
:Entity_EDL_0000639	mention	"Trafalgar Square"	iraqwar_guardian__1000-01-01__timeline:42615-42630	1.0
:Entity_EDL_0000639	link	NIL000000506
:Entity_EDL_0000640	type	Person
:Entity_EDL_0000640	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:48794-48799	1.0
:Entity_EDL_0000640	link	NIL000000507
:Entity_EDL_0000641	type	Person
:Entity_EDL_0000641	canonical_mention	"Gunmen"	iraqwar_guardian__1000-01-01__timeline:10139-10144	1.0
:Entity_EDL_0000641	nominal_mention	"Gunmen"	iraqwar_guardian__1000-01-01__timeline:10139-10144	1.0
:Entity_EDL_0000641	link	NIL000000508
:Entity_EDL_0000642	type	GeopoliticalEntity
:Entity_EDL_0000642	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:40000-40003	1.0
:Entity_EDL_0000642	link	99237
:Entity_EDL_0000643	type	Person
:Entity_EDL_0000643	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:22662-22667	1.0
:Entity_EDL_0000643	link	NIL000000509
:Entity_EDL_0000644	type	GeopoliticalEntity
:Entity_EDL_0000644	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:45111-45114	1.0
:Entity_EDL_0000644	link	99237
:Entity_EDL_0000645	type	Facility
:Entity_EDL_0000645	canonical_mention	"prison"	iraqwar_guardian__1000-01-01__timeline:276-281	1.0
:Entity_EDL_0000645	nominal_mention	"prison"	iraqwar_guardian__1000-01-01__timeline:276-281	1.0
:Entity_EDL_0000645	link	NIL000000510
:Entity_EDL_0000646	type	Vehicle
:Entity_EDL_0000646	nominal_mention	"car"	iraqwar_guardian__1000-01-01__timeline:36751-36753	1.0
:Entity_EDL_0000646	link	NIL000000511
:Entity_EDL_0000647	type	GeopoliticalEntity
:Entity_EDL_0000647	mention	"American"	iraqwar_guardian__1000-01-01__timeline:36148-36155	1.0
:Entity_EDL_0000647	link	6252001
:Entity_EDL_0000648	type	Facility
:Entity_EDL_0000648	canonical_mention	"walls"	iraqwar_guardian__1000-01-01__timeline:13088-13092	1.0
:Entity_EDL_0000648	nominal_mention	"walls"	iraqwar_guardian__1000-01-01__timeline:13088-13092	1.0
:Entity_EDL_0000648	link	NIL000000512
:Entity_EDL_0000649	type	Organization
:Entity_EDL_0000649	nominal_mention	"army"	iraqwar_guardian__1000-01-01__timeline:37073-37076	1.0
:Entity_EDL_0000649	link	NIL000000513
:Entity_EDL_0000650	type	GeopoliticalEntity
:Entity_EDL_0000650	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:17471-17477	1.0
:Entity_EDL_0000650	link	98182
:Entity_EDL_0000651	type	Person
:Entity_EDL_0000651	nominal_mention	"bombers"	iraqwar_guardian__1000-01-01__timeline:45648-45654	1.0
:Entity_EDL_0000651	link	NIL000000514
:Entity_EDL_0000652	type	Person
:Entity_EDL_0000652	canonical_mention	"aides"	iraqwar_guardian__1000-01-01__timeline:52784-52788	1.0
:Entity_EDL_0000652	nominal_mention	"aides"	iraqwar_guardian__1000-01-01__timeline:52784-52788	1.0
:Entity_EDL_0000652	link	NIL000000515
:Entity_EDL_0000653	type	Person
:Entity_EDL_0000653	nominal_mention	"Insurgents"	iraqwar_guardian__1000-01-01__timeline:39673-39682	1.0
:Entity_EDL_0000653	link	NIL000000516
:Entity_EDL_0000654	type	Person
:Entity_EDL_0000654	nominal_mention	"journalist"	iraqwar_guardian__1000-01-01__timeline:13681-13690	1.0
:Entity_EDL_0000654	link	NIL000000517
:Entity_EDL_0000655	type	Person
:Entity_EDL_0000655	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:34290-34295	1.0
:Entity_EDL_0000655	link	NIL000000518
:Entity_EDL_0000656	type	Person
:Entity_EDL_0000656	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:8577-8582	1.0
:Entity_EDL_0000656	link	NIL000000519
:Entity_EDL_0000657	type	Person
:Entity_EDL_0000657	nominal_mention	"seekers"	iraqwar_guardian__1000-01-01__timeline:17251-17257	1.0
:Entity_EDL_0000657	link	NIL000000520
:Entity_EDL_0000658	type	Person
:Entity_EDL_0000658	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:45389-45396	1.0
:Entity_EDL_0000658	link	NIL000000521
:Entity_EDL_0000659	type	Person
:Entity_EDL_0000659	pronominal_mention	"100"	iraqwar_guardian__1000-01-01__timeline:35238-35240	1.0
:Entity_EDL_0000659	link	NIL000000522
:Entity_EDL_0000660	type	Person
:Entity_EDL_0000660	canonical_mention	"36"	iraqwar_guardian__1000-01-01__timeline:1992-1993	1.0
:Entity_EDL_0000660	nominal_mention	"36"	iraqwar_guardian__1000-01-01__timeline:1992-1993	1.0
:Entity_EDL_0000660	link	NIL000000523
:Entity_EDL_0000661	type	Person
:Entity_EDL_0000661	nominal_mention	"bombers"	iraqwar_guardian__1000-01-01__timeline:48258-48264	1.0
:Entity_EDL_0000661	link	NIL000000524
:Entity_EDL_0000662	type	GeopoliticalEntity
:Entity_EDL_0000662	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:4135-4141	1.0
:Entity_EDL_0000662	link	98182
:Entity_EDL_0000663	type	GeopoliticalEntity
:Entity_EDL_0000663	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:14722-14728	1.0
:Entity_EDL_0000663	link	98182
:Entity_EDL_0000664	type	Person
:Entity_EDL_0000664	nominal_mention	"authorities"	iraqwar_guardian__1000-01-01__timeline:12615-12625	1.0
:Entity_EDL_0000664	link	NIL000000525
:Entity_EDL_0000665	type	GeopoliticalEntity
:Entity_EDL_0000665	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:35028-35031	1.0
:Entity_EDL_0000665	link	99237
:Entity_EDL_0000666	type	GeopoliticalEntity
:Entity_EDL_0000666	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:3067-3070	1.0
:Entity_EDL_0000666	link	99237
:Entity_EDL_0000667	type	Person
:Entity_EDL_0000667	pronominal_mention	"Dozens"	iraqwar_guardian__1000-01-01__timeline:15167-15172	1.0
:Entity_EDL_0000667	link	NIL000000526
:Entity_EDL_0000668	type	Person
:Entity_EDL_0000668	nominal_mention	"Officer"	iraqwar_guardian__1000-01-01__timeline:31590-31596	1.0
:Entity_EDL_0000668	link	NIL000000527
:Entity_EDL_0000669	type	Vehicle
:Entity_EDL_0000669	nominal_mention	"car"	iraqwar_guardian__1000-01-01__timeline:34056-34058	1.0
:Entity_EDL_0000669	link	NIL000000528
:Entity_EDL_0000670	type	Person
:Entity_EDL_0000670	nominal_mention	"bombers"	iraqwar_guardian__1000-01-01__timeline:1979-1985	1.0
:Entity_EDL_0000670	link	NIL000000529
:Entity_EDL_0000671	type	Person
:Entity_EDL_0000671	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:15636-15643	1.0
:Entity_EDL_0000671	link	NIL000000530
:Entity_EDL_0000672	type	Person
:Entity_EDL_0000672	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:22617-22622	1.0
:Entity_EDL_0000672	link	NIL000000531
:Entity_EDL_0000673	type	GeopoliticalEntity
:Entity_EDL_0000673	mention	"Basra"	iraqwar_guardian__1000-01-01__timeline:13702-13706	1.0
:Entity_EDL_0000673	link	99532
:Entity_EDL_0000674	type	GeopoliticalEntity
:Entity_EDL_0000674	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:33471-33477	1.0
:Entity_EDL_0000674	link	98182
:Entity_EDL_0000675	type	Person
:Entity_EDL_0000675	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:29375-29380	1.0
:Entity_EDL_0000675	link	NIL000000532
:Entity_EDL_0000676	type	Person
:Entity_EDL_0000676	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:39981-39988	1.0
:Entity_EDL_0000676	link	NIL000000533
:Entity_EDL_0000677	type	GeopoliticalEntity
:Entity_EDL_0000677	canonical_mention	"Afghanistan"	iraqwar_guardian__1000-01-01__timeline:24349-24359	1.0
:Entity_EDL_0000677	mention	"Afghanistan"	iraqwar_guardian__1000-01-01__timeline:24349-24359	1.0
:Entity_EDL_0000677	link	1149361
:Entity_EDL_0000678	type	GeopoliticalEntity
:Entity_EDL_0000678	mention	"US"	iraqwar_guardian__1000-01-01__timeline:39831-39832	1.0
:Entity_EDL_0000678	link	6252001
:Entity_EDL_0000679	type	Facility
:Entity_EDL_0000679	canonical_mention	"headquarters"	iraqwar_guardian__1000-01-01__timeline:49872-49883	1.0
:Entity_EDL_0000679	nominal_mention	"headquarters"	iraqwar_guardian__1000-01-01__timeline:49872-49883	1.0
:Entity_EDL_0000679	link	NIL000000534
:Entity_EDL_0000680	type	Facility
:Entity_EDL_0000680	nominal_mention	"market"	iraqwar_guardian__1000-01-01__timeline:33793-33798	1.0
:Entity_EDL_0000680	link	NIL000000535
:Entity_EDL_0000681	type	Person
:Entity_EDL_0000681	canonical_mention	"driver"	iraqwar_guardian__1000-01-01__timeline:10191-10196	1.0
:Entity_EDL_0000681	nominal_mention	"driver"	iraqwar_guardian__1000-01-01__timeline:10191-10196	1.0
:Entity_EDL_0000681	link	NIL000000536
:Entity_EDL_0000682	type	Person
:Entity_EDL_0000682	nominal_mention	"prisoners"	iraqwar_guardian__1000-01-01__timeline:3981-3989	1.0
:Entity_EDL_0000682	link	NIL000000537
:Entity_EDL_0000683	type	Person
:Entity_EDL_0000683	nominal_mention	"forces"	iraqwar_guardian__1000-01-01__timeline:11611-11616	1.0
:Entity_EDL_0000683	link	NIL000000538
:Entity_EDL_0000684	type	Weapon
:Entity_EDL_0000684	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:21628-21631	1.0
:Entity_EDL_0000684	link	NIL000000539
:Entity_EDL_0000685	type	Person
:Entity_EDL_0000685	nominal_mention	"detainees"	iraqwar_guardian__1000-01-01__timeline:46059-46067	1.0
:Entity_EDL_0000685	link	NIL000000540
:Entity_EDL_0000686	type	Person
:Entity_EDL_0000686	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:49436-49443	1.0
:Entity_EDL_0000686	link	NIL000000541
:Entity_EDL_0000687	type	Person
:Entity_EDL_0000687	canonical_mention	"son"	iraqwar_guardian__1000-01-01__timeline:49185-49187	1.0
:Entity_EDL_0000687	nominal_mention	"son"	iraqwar_guardian__1000-01-01__timeline:49185-49187	1.0
:Entity_EDL_0000687	link	NIL000000542
:Entity_EDL_0000688	type	Person
:Entity_EDL_0000688	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:18571-18578	1.0
:Entity_EDL_0000688	link	NIL000000543
:Entity_EDL_0000689	type	Person
:Entity_EDL_0000689	canonical_mention	"130"	iraqwar_guardian__1000-01-01__timeline:44988-44990	1.0
:Entity_EDL_0000689	pronominal_mention	"130"	iraqwar_guardian__1000-01-01__timeline:44988-44990	1.0
:Entity_EDL_0000689	link	NIL000000544
:Entity_EDL_0000690	type	Person
:Entity_EDL_0000690	canonical_mention	"Hazim Shallan"	iraqwar_guardian__1000-01-01__timeline:12685-12697	1.0
:Entity_EDL_0000690	mention	"Hazim Shallan"	iraqwar_guardian__1000-01-01__timeline:12685-12697	1.0
:Entity_EDL_0000690	link	NIL000000545
:Entity_EDL_0000691	type	Person
:Entity_EDL_0000691	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:7934-7939	1.0
:Entity_EDL_0000691	link	NIL000000546
:Entity_EDL_0000692	type	GeopoliticalEntity
:Entity_EDL_0000692	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:21904-21907	1.0
:Entity_EDL_0000692	link	99237
:Entity_EDL_0000693	type	GeopoliticalEntity
:Entity_EDL_0000693	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:35732-35735	1.0
:Entity_EDL_0000693	link	99237
:Entity_EDL_0000694	type	Person
:Entity_EDL_0000694	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:9210-9215	1.0
:Entity_EDL_0000694	link	NIL000000547
:Entity_EDL_0000696	type	Weapon
:Entity_EDL_0000696	nominal_mention	"bombs"	iraqwar_guardian__1000-01-01__timeline:29233-29237	1.0
:Entity_EDL_0000696	link	NIL000000549
:Entity_EDL_0000697	type	Person
:Entity_EDL_0000697	nominal_mention	"policemen"	iraqwar_guardian__1000-01-01__timeline:49669-49677	1.0
:Entity_EDL_0000697	link	NIL000000550
:Entity_EDL_0000698	type	Facility
:Entity_EDL_0000698	canonical_mention	"complex"	iraqwar_guardian__1000-01-01__timeline:51224-51230	1.0
:Entity_EDL_0000698	nominal_mention	"complex"	iraqwar_guardian__1000-01-01__timeline:51224-51230	1.0
:Entity_EDL_0000698	link	NIL000000551
:Entity_EDL_0000699	type	GeopoliticalEntity
:Entity_EDL_0000699	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:21620-21623	1.0
:Entity_EDL_0000699	link	99237
:Entity_EDL_0000700	type	Person
:Entity_EDL_0000700	canonical_mention	"soldier"	iraqwar_guardian__1000-01-01__timeline:3569-3575	1.0
:Entity_EDL_0000700	nominal_mention	"soldier"	iraqwar_guardian__1000-01-01__timeline:3569-3575	1.0
:Entity_EDL_0000700	link	NIL000000552
:Entity_EDL_0000701	type	Person
:Entity_EDL_0000701	nominal_mention	"bomber"	iraqwar_guardian__1000-01-01__timeline:27599-27604	1.0
:Entity_EDL_0000701	link	NIL000000553
:Entity_EDL_0000702	type	Person
:Entity_EDL_0000702	nominal_mention	"Shias"	iraqwar_guardian__1000-01-01__timeline:24802-24806	1.0
:Entity_EDL_0000702	link	NIL000000554
:Entity_EDL_0000703	type	Person
:Entity_EDL_0000703	canonical_mention	"Steven Vincent"	iraqwar_guardian__1000-01-01__timeline:21144-21157	1.0
:Entity_EDL_0000703	mention	"Steven Vincent"	iraqwar_guardian__1000-01-01__timeline:21144-21157	1.0
:Entity_EDL_0000703	link	NIL000000555
:Entity_EDL_0000704	type	Person
:Entity_EDL_0000704	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:27941-27946	1.0
:Entity_EDL_0000704	link	NIL000000556
:Entity_EDL_0000705	type	Person
:Entity_EDL_0000705	nominal_mention	"insurgents"	iraqwar_guardian__1000-01-01__timeline:2374-2383	1.0
:Entity_EDL_0000705	link	NIL000000557
:Entity_EDL_0000706	type	Person
:Entity_EDL_0000706	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:50576-50583	1.0
:Entity_EDL_0000706	link	NIL000000558
:Entity_EDL_0000707	type	Person
:Entity_EDL_0000707	nominal_mention	"commanders"	iraqwar_guardian__1000-01-01__timeline:31410-31419	1.0
:Entity_EDL_0000707	link	NIL000000559
:Entity_EDL_0000708	type	Person
:Entity_EDL_0000708	nominal_mention	"Iraqis"	iraqwar_guardian__1000-01-01__timeline:11110-11115	1.0
:Entity_EDL_0000708	link	NIL000000560
:Entity_EDL_0000709	type	Person
:Entity_EDL_0000709	nominal_mention	"troops"	iraqwar_guardian__1000-01-01__timeline:41771-41776	1.0
:Entity_EDL_0000709	link	NIL000000561
:Entity_EDL_0000710	type	Organization
:Entity_EDL_0000710	nominal_mention	"government"	iraqwar_guardian__1000-01-01__timeline:44030-44039	1.0
:Entity_EDL_0000710	link	NIL000000562
:Entity_EDL_0000711	type	Facility
:Entity_EDL_0000711	nominal_mention	"station"	iraqwar_guardian__1000-01-01__timeline:51203-51209	1.0
:Entity_EDL_0000711	link	NIL000000563
:Entity_EDL_0000712	type	Facility
:Entity_EDL_0000712	canonical_mention	"bank"	iraqwar_guardian__1000-01-01__timeline:51238-51241	1.0
:Entity_EDL_0000712	nominal_mention	"bank"	iraqwar_guardian__1000-01-01__timeline:51238-51241	1.0
:Entity_EDL_0000712	link	NIL000000564
:Entity_EDL_0000713	type	Person
:Entity_EDL_0000713	nominal_mention	"police"	iraqwar_guardian__1000-01-01__timeline:13940-13945	1.0
:Entity_EDL_0000713	link	NIL000000565
:Entity_EDL_0000714	type	GeopoliticalEntity
:Entity_EDL_0000714	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:43188-43191	1.0
:Entity_EDL_0000714	link	99237
:Entity_EDL_0000715	type	Vehicle
:Entity_EDL_0000715	canonical_mention	"another"	iraqwar_guardian__1000-01-01__timeline:13126-13132	1.0
:Entity_EDL_0000715	nominal_mention	"another"	iraqwar_guardian__1000-01-01__timeline:13126-13132	1.0
:Entity_EDL_0000715	link	NIL000000566
:Entity_EDL_0000716	type	GeopoliticalEntity
:Entity_EDL_0000716	mention	"UK"	iraqwar_guardian__1000-01-01__timeline:39339-39340	1.0
:Entity_EDL_0000716	link	2635167
:Entity_EDL_0000717	type	GeopoliticalEntity
:Entity_EDL_0000717	mention	"US"	iraqwar_guardian__1000-01-01__timeline:44340-44341	1.0
:Entity_EDL_0000717	link	6252001
:Entity_EDL_0000718	type	Person
:Entity_EDL_0000718	canonical_mention	"teenager"	iraqwar_guardian__1000-01-01__timeline:4804-4811	1.0
:Entity_EDL_0000718	nominal_mention	"teenager"	iraqwar_guardian__1000-01-01__timeline:4804-4811	1.0
:Entity_EDL_0000718	link	NIL000000567
:Entity_EDL_0000719	type	Person
:Entity_EDL_0000719	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:38400-38405	1.0
:Entity_EDL_0000719	link	NIL000000568
:Entity_EDL_0000720	type	Person
:Entity_EDL_0000720	nominal_mention	"Troops"	iraqwar_guardian__1000-01-01__timeline:11852-11857	1.0
:Entity_EDL_0000720	link	NIL000000569
:Entity_EDL_0000721	type	Person
:Entity_EDL_0000721	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:51106-51111	1.0
:Entity_EDL_0000721	link	NIL000000570
:Entity_EDL_0000722	type	Person
:Entity_EDL_0000722	canonical_mention	"jailers"	iraqwar_guardian__1000-01-01__timeline:839-845	1.0
:Entity_EDL_0000722	nominal_mention	"jailers"	iraqwar_guardian__1000-01-01__timeline:839-845	1.0
:Entity_EDL_0000722	link	NIL000000571
:Entity_EDL_0000723	type	Person
:Entity_EDL_0000723	canonical_mention	"personnel"	iraqwar_guardian__1000-01-01__timeline:48143-48151	1.0
:Entity_EDL_0000723	nominal_mention	"personnel"	iraqwar_guardian__1000-01-01__timeline:48143-48151	1.0
:Entity_EDL_0000723	link	NIL000000572
:Entity_EDL_0000725	type	Person
:Entity_EDL_0000725	pronominal_mention	"Dozens"	iraqwar_guardian__1000-01-01__timeline:33605-33610	1.0
:Entity_EDL_0000725	link	NIL000000574
:Entity_EDL_0000726	type	GeopoliticalEntity
:Entity_EDL_0000726	mention	"US"	iraqwar_guardian__1000-01-01__timeline:27684-27685	1.0
:Entity_EDL_0000726	link	6252001
:Entity_EDL_0000727	type	Organization
:Entity_EDL_0000727	canonical_mention	"Labor"	iraqwar_guardian__1000-01-01__timeline:33238-33242	1.0
:Entity_EDL_0000727	mention	"Labor"	iraqwar_guardian__1000-01-01__timeline:33238-33242	1.0
:Entity_EDL_0000727	link	NIL000000575
:Entity_EDL_0000728	type	GeopoliticalEntity
:Entity_EDL_0000728	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:43402-43405	1.0
:Entity_EDL_0000728	link	99237
:Entity_EDL_0000729	type	GeopoliticalEntity
:Entity_EDL_0000729	mention	"Basra"	iraqwar_guardian__1000-01-01__timeline:21475-21479	1.0
:Entity_EDL_0000729	link	99532
:Entity_EDL_0000730	type	Weapon
:Entity_EDL_0000730	nominal_mention	"bombs"	iraqwar_guardian__1000-01-01__timeline:18212-18216	1.0
:Entity_EDL_0000730	link	NIL000000576
:Entity_EDL_0000731	type	Person
:Entity_EDL_0000731	canonical_mention	"businessmen"	iraqwar_guardian__1000-01-01__timeline:2965-2975	1.0
:Entity_EDL_0000731	nominal_mention	"businessmen"	iraqwar_guardian__1000-01-01__timeline:2965-2975	1.0
:Entity_EDL_0000731	link	NIL000000577
:Entity_EDL_0000732	type	Organization
:Entity_EDL_0000732	canonical_mention	"embassy"	iraqwar_guardian__1000-01-01__timeline:26543-26549	1.0
:Entity_EDL_0000732	nominal_mention	"embassy"	iraqwar_guardian__1000-01-01__timeline:26543-26549	1.0
:Entity_EDL_0000732	link	NIL000000578
:Entity_EDL_0000733	type	Organization
:Entity_EDL_0000733	nominal_mention	"government"	iraqwar_guardian__1000-01-01__timeline:42143-42152	1.0
:Entity_EDL_0000733	link	NIL000000579
:Entity_EDL_0000734	type	Organization
:Entity_EDL_0000734	mention	"UN"	iraqwar_guardian__1000-01-01__timeline:46852-46853	1.0
:Entity_EDL_0000734	link	20000193
:Entity_EDL_0000735	type	Organization
:Entity_EDL_0000735	canonical_mention	"assembly"	iraqwar_guardian__1000-01-01__timeline:40827-40834	1.0
:Entity_EDL_0000735	nominal_mention	"assembly"	iraqwar_guardian__1000-01-01__timeline:40827-40834	1.0
:Entity_EDL_0000735	link	NIL000000580
:Entity_EDL_0000736	type	Person
:Entity_EDL_0000736	nominal_mention	"bombers"	iraqwar_guardian__1000-01-01__timeline:14037-14043	1.0
:Entity_EDL_0000736	link	NIL000000581
:Entity_EDL_0000737	type	Location
:Entity_EDL_0000737	nominal_mention	"area"	iraqwar_guardian__1000-01-01__timeline:25411-25414	1.0
:Entity_EDL_0000737	link	NIL000000582
:Entity_EDL_0000738	type	Person
:Entity_EDL_0000738	mention	"Saddam Hussein"	iraqwar_guardian__1000-01-01__timeline:44815-44828	1.0
:Entity_EDL_0000738	link	NIL000000583
:Entity_EDL_0000739	type	Person
:Entity_EDL_0000739	nominal_mention	"soldiers"	iraqwar_guardian__1000-01-01__timeline:21261-21268	1.0
:Entity_EDL_0000739	link	NIL000000584
:Entity_EDL_0000740	type	GeopoliticalEntity
:Entity_EDL_0000740	mention	"Baghdad"	iraqwar_guardian__1000-01-01__timeline:49689-49695	1.0
:Entity_EDL_0000740	link	98182
:Entity_EDL_0000741	type	GeopoliticalEntity
:Entity_EDL_0000741	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:33542-33545	1.0
:Entity_EDL_0000741	link	99237
:Entity_EDL_0000742	type	Organization
:Entity_EDL_0000742	canonical_mention	"party"	iraqwar_guardian__1000-01-01__timeline:1141-1145	1.0
:Entity_EDL_0000742	nominal_mention	"party"	iraqwar_guardian__1000-01-01__timeline:1141-1145	1.0
:Entity_EDL_0000742	link	NIL000000585
:Entity_EDL_0000744	type	GeopoliticalEntity
:Entity_EDL_0000744	nominal_mention	"country"	iraqwar_guardian__1000-01-01__timeline:46298-46304	1.0
:Entity_EDL_0000744	link	NIL000000587
:Entity_EDL_0000745	type	GeopoliticalEntity
:Entity_EDL_0000745	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:45838-45841	1.0
:Entity_EDL_0000745	link	99237
:Entity_EDL_0000746	type	Person
:Entity_EDL_0000746	canonical_mention	"Qais Hashim Shameri"	iraqwar_guardian__1000-01-01__timeline:49157-49175	1.0
:Entity_EDL_0000746	mention	"Qais Hashim Shameri"	iraqwar_guardian__1000-01-01__timeline:49157-49175	1.0
:Entity_EDL_0000746	link	NIL000000588
:Entity_EDL_0000747	type	Person
:Entity_EDL_0000747	canonical_mention	"26"	iraqwar_guardian__1000-01-01__timeline:51311-51312	1.0
:Entity_EDL_0000747	pronominal_mention	"26"	iraqwar_guardian__1000-01-01__timeline:51311-51312	1.0
:Entity_EDL_0000747	link	NIL000000589
:Entity_EDL_0000748	type	Person
:Entity_EDL_0000748	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:42692-42697	1.0
:Entity_EDL_0000748	link	NIL000000590
:Entity_EDL_0000749	type	Person
:Entity_EDL_0000749	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:45290-45295	1.0
:Entity_EDL_0000749	link	NIL000000591
:Entity_EDL_0000750	type	Person
:Entity_EDL_0000750	canonical_mention	"forces"	iraqwar_guardian__1000-01-01__timeline:2493-2498	1.0
:Entity_EDL_0000750	nominal_mention	"forces"	iraqwar_guardian__1000-01-01__timeline:2493-2498	1.0
:Entity_EDL_0000750	link	NIL000000592
:Entity_EDL_0000751	type	GeopoliticalEntity
:Entity_EDL_0000751	nominal_mention	"towns"	iraqwar_guardian__1000-01-01__timeline:31473-31477	1.0
:Entity_EDL_0000751	link	NIL000000593
:Entity_EDL_0000752	type	Vehicle
:Entity_EDL_0000752	pronominal_mention	"it"	iraqwar_guardian__1000-01-01__timeline:48216-48217	1.0
:Entity_EDL_0000752	link	NIL000000594
:Entity_EDL_0000754	type	Person
:Entity_EDL_0000754	nominal_mention	"Iraqis"	iraqwar_guardian__1000-01-01__timeline:5518-5523	1.0
:Entity_EDL_0000754	link	NIL000000596
:Entity_EDL_0000755	type	Person
:Entity_EDL_0000755	canonical_mention	"Florence Aubenas"	iraqwar_guardian__1000-01-01__timeline:28534-28549	1.0
:Entity_EDL_0000755	mention	"Florence Aubenas"	iraqwar_guardian__1000-01-01__timeline:28534-28549	1.0
:Entity_EDL_0000755	link	NIL000000597
:Entity_EDL_0000756	type	Person
:Entity_EDL_0000756	canonical_mention	"serviceman"	iraqwar_guardian__1000-01-01__timeline:34548-34557	1.0
:Entity_EDL_0000756	nominal_mention	"serviceman"	iraqwar_guardian__1000-01-01__timeline:34548-34557	1.0
:Entity_EDL_0000756	link	NIL000000598
:Entity_EDL_0000757	type	Facility
:Entity_EDL_0000757	canonical_mention	"base"	iraqwar_guardian__1000-01-01__timeline:45234-45237	1.0
:Entity_EDL_0000757	nominal_mention	"base"	iraqwar_guardian__1000-01-01__timeline:45234-45237	1.0
:Entity_EDL_0000757	link	NIL000000599
:Entity_EDL_0000758	type	Person
:Entity_EDL_0000758	nominal_mention	"people"	iraqwar_guardian__1000-01-01__timeline:24156-24161	1.0
:Entity_EDL_0000758	link	NIL000000600
:Entity_EDL_0000759	type	Person
:Entity_EDL_0000759	nominal_mention	"journalist"	iraqwar_guardian__1000-01-01__timeline:28346-28355	1.0
:Entity_EDL_0000759	link	NIL000000601
:Entity_EDL_0000760	type	Weapon
:Entity_EDL_0000760	nominal_mention	"bombs"	iraqwar_guardian__1000-01-01__timeline:24433-24437	1.0
:Entity_EDL_0000760	link	NIL000000602
:Entity_EDL_0000761	type	Location
:Entity_EDL_0000761	mention	"Iraq"	iraqwar_guardian__1000-01-01__timeline:29541-29544	1.0
:Entity_EDL_0000761	link	99237
:Entity_EDL_0000762	type	Weapon
:Entity_EDL_0000762	nominal_mention	"bomb"	iraqwar_guardian__1000-01-01__timeline:18263-18266	1.0
:Entity_EDL_0000762	link	NIL000000603
