:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:6378-6386	1.000
:Event_0000000	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:6378-6386	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000003	bpoil_guardian__1000-01-01__timeline:6407-6409	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"fire"	bpoil_guardian__1000-01-01__timeline:25-28	1.000
:Event_0000000	canonical_mention.actual	"fire"	bpoil_guardian__1000-01-01__timeline:25-28	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000013	bpoil_guardian__1000-01-01__timeline:69-71	1.000
:Event_0000000	Conflict.Attack_Place.actual	:Entity_EDL_0000080	bpoil_guardian__1000-01-01__timeline:98-111	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"Explosion"	bpoil_guardian__1000-01-01__timeline:11-19	1.000
:Event_0000000	canonical_mention.actual	"Explosion"	bpoil_guardian__1000-01-01__timeline:11-19	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000013	bpoil_guardian__1000-01-01__timeline:69-71	1.000
:Event_0000000	Conflict.Attack_Place.actual	:Entity_EDL_0000080	bpoil_guardian__1000-01-01__timeline:98-111	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:16397-16405	1.000
:Event_0000000	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:16397-16405	1.000
:Event_0000000	Conflict.Attack_Place.actual	:Entity_EDL_0000048	bpoil_guardian__1000-01-01__timeline:16379-16395	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:23882-23890	1.000
:Event_0000000	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:23882-23890	1.000
:Event_0000000	Conflict.Attack_Place.actual	:Entity_EDL_0000087	bpoil_guardian__1000-01-01__timeline:23820-23836	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:31641-31649	1.000
:Event_0000000	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:31641-31649	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:9455-9463	1.000
:Event_0000000	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:9455-9463	1.000
:Event_0000000	Conflict.Attack_Place.actual	:Entity_EDL_0000004	bpoil_guardian__1000-01-01__timeline:9445-9453	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:2095-2103	1.000
:Event_0000000	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:2095-2103	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"exploded"	bpoil_guardian__1000-01-01__timeline:29246-29253	1.000
:Event_0000000	canonical_mention.actual	"exploded"	bpoil_guardian__1000-01-01__timeline:29246-29253	1.000
:Event_0000000	Conflict.Attack_Instrument.actual	:Entity_EDL_0000046	bpoil_guardian__1000-01-01__timeline:29242-29244	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:34651-34659	1.000
:Event_0000000	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:34651-34659	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000064	bpoil_guardian__1000-01-01__timeline:34633-34649	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	bpoil_guardian__1000-01-01__timeline:18022-18030	1.000
:Event_0000001	canonical_mention.actual	"step down"	bpoil_guardian__1000-01-01__timeline:18022-18030	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000086	bpoil_guardian__1000-01-01__timeline:18002-18013	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	bpoil_guardian__1000-01-01__timeline:17946-17954	1.000
:Event_0000001	canonical_mention.actual	"step down"	bpoil_guardian__1000-01-01__timeline:17946-17954	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000036	bpoil_guardian__1000-01-01__timeline:17935-17941	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"resigning"	bpoil_guardian__1000-01-01__timeline:17989-17997	1.000
:Event_0000001	canonical_mention.actual	"resigning"	bpoil_guardian__1000-01-01__timeline:17989-17997	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000089	bpoil_guardian__1000-01-01__timeline:17974-17975	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"leave"	bpoil_guardian__1000-01-01__timeline:24317-24321	1.000
:Event_0000001	canonical_mention.actual	"leave"	bpoil_guardian__1000-01-01__timeline:24317-24321	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000032	bpoil_guardian__1000-01-01__timeline:24284-24292	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000075	bpoil_guardian__1000-01-01__timeline:24296-24307	1.000
:Event_0000001	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000083	bpoil_guardian__1000-01-01__timeline:24327-24333	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"quit"	bpoil_guardian__1000-01-01__timeline:24424-24427	1.000
:Event_0000001	canonical_mention.actual	"quit"	bpoil_guardian__1000-01-01__timeline:24424-24427	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000043	bpoil_guardian__1000-01-01__timeline:24408-24419	1.000
:Event_0000001	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000100	bpoil_guardian__1000-01-01__timeline:24429-24430	1.000
:Event_0000002	type	Disaster.FireExplosion.FireExplosion
:Event_0000002	mention.actual	"fire"	bpoil_guardian__1000-01-01__timeline:296-299	1.000
:Event_0000002	canonical_mention.actual	"fire"	bpoil_guardian__1000-01-01__timeline:296-299	1.000
:Event_0000002	mention.actual	"fire"	bpoil_guardian__1000-01-01__timeline:296-299	1.000
:Event_0000002	canonical_mention.actual	"fire"	bpoil_guardian__1000-01-01__timeline:296-299	1.000
:Event_0000002	Disaster.FireExplosion.FireExplosion_FireExplosionObject.actual	:Entity_EDL_0000070	bpoil_guardian__1000-01-01__timeline:292-294	1.000
:Event_0000002	type	Disaster.FireExplosion.FireExplosion
:Event_0000002	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:7714-7722	1.000
:Event_0000002	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:7714-7722	1.000
:Event_0000002	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:7714-7722	1.000
:Event_0000002	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:7714-7722	1.000
:Event_0000002	type	Disaster.FireExplosion.FireExplosion
:Event_0000002	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:8971-8979	1.000
:Event_0000002	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:8971-8979	1.000
:Event_0000002	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:8971-8979	1.000
:Event_0000002	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:8971-8979	1.000
:Event_0000003	type	Contact.Meet
:Event_0000003	mention.actual	"meet"	bpoil_guardian__1000-01-01__timeline:21906-21909	1.000
:Event_0000003	canonical_mention.actual	"meet"	bpoil_guardian__1000-01-01__timeline:21906-21909	1.000
:Event_0000003	Contact.Meet_Participant.actual	:Entity_EDL_0000099	bpoil_guardian__1000-01-01__timeline:21882-21894	1.000
:Event_0000003	Contact.Meet_Participant.actual	:Entity_EDL_0000018	bpoil_guardian__1000-01-01__timeline:21919-21926	1.000
:Event_0000003	type	Contact.Meet
:Event_0000003	mention.actual	"meeting"	bpoil_guardian__1000-01-01__timeline:22200-22206	1.000
:Event_0000003	canonical_mention.actual	"meeting"	bpoil_guardian__1000-01-01__timeline:22200-22206	1.000
:Event_0000003	Contact.Meet_Participant.actual	:Entity_EDL_0000101	bpoil_guardian__1000-01-01__timeline:22101-22103	1.000
:Event_0000003	Contact.Meet_Place.actual	:Entity_EDL_0000015	bpoil_guardian__1000-01-01__timeline:22123-22124	1.000
:Event_0000003	type	Contact.Meet
:Event_0000003	mention.actual	"meeting"	bpoil_guardian__1000-01-01__timeline:14718-14724	1.000
:Event_0000003	canonical_mention.actual	"meeting"	bpoil_guardian__1000-01-01__timeline:14718-14724	1.000
:Event_0000003	Contact.Meet_Participant.actual	:Entity_EDL_0000007	bpoil_guardian__1000-01-01__timeline:14653-14665	1.000
:Event_0000003	Contact.Meet_Participant.actual	:Entity_EDL_0000091	bpoil_guardian__1000-01-01__timeline:14679-14686	1.000
:Event_0000003	Contact.Meet_Participant.actual	:Entity_EDL_0000041	bpoil_guardian__1000-01-01__timeline:14690-14709	1.000
:Event_0000003	Contact.Meet_Place.actual	:Entity_EDL_0000085	bpoil_guardian__1000-01-01__timeline:14729-14742	1.000
:Event_0000004	type	Justice.ReleaseParole
:Event_0000004	mention.actual	"release"	bpoil_guardian__1000-01-01__timeline:21062-21068	1.000
:Event_0000004	canonical_mention.actual	"release"	bpoil_guardian__1000-01-01__timeline:21062-21068	1.000
:Event_0000004	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000010	bpoil_guardian__1000-01-01__timeline:21087-21092	1.000
:Event_0000004	type	Justice.ReleaseParole
:Event_0000004	mention.actual	"release"	bpoil_guardian__1000-01-01__timeline:22241-22247	1.000
:Event_0000004	canonical_mention.actual	"release"	bpoil_guardian__1000-01-01__timeline:22241-22247	1.000
:Event_0000004	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000077	bpoil_guardian__1000-01-01__timeline:22230-22236	1.000
:Event_0000004	type	Justice.ReleaseParole
:Event_0000004	mention.actual	"release"	bpoil_guardian__1000-01-01__timeline:22012-22018	1.000
:Event_0000004	canonical_mention.actual	"release"	bpoil_guardian__1000-01-01__timeline:22012-22018	1.000
:Event_0000004	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000081	bpoil_guardian__1000-01-01__timeline:22034-22039	1.000
:Event_0000005	type	Personnel.StartPosition
:Event_0000005	mention.actual	"replaced"	bpoil_guardian__1000-01-01__timeline:24343-24350	1.000
:Event_0000005	canonical_mention.actual	"replaced"	bpoil_guardian__1000-01-01__timeline:24343-24350	1.000
:Event_0000005	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000083	bpoil_guardian__1000-01-01__timeline:24327-24333	1.000
:Event_0000005	Personnel.StartPosition_Person.actual	:Entity_EDL_0000006	bpoil_guardian__1000-01-01__timeline:24355-24364	1.000
:Event_0000005	type	Personnel.StartPosition
:Event_0000005	mention.actual	"takes over"	bpoil_guardian__1000-01-01__timeline:33430-33439	1.000
:Event_0000005	canonical_mention.actual	"takes over"	bpoil_guardian__1000-01-01__timeline:33430-33439	1.000
:Event_0000005	Personnel.StartPosition_Person.actual	:Entity_EDL_0000030	bpoil_guardian__1000-01-01__timeline:33419-33428	1.000
:Event_0000005	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000031	bpoil_guardian__1000-01-01__timeline:33463-33464	1.000
:Event_0000006	type	Transaction.TransferMoney
:Event_0000006	mention.actual	"downpayment"	bpoil_guardian__1000-01-01__timeline:15424-15434	1.000
:Event_0000006	canonical_mention.actual	"downpayment"	bpoil_guardian__1000-01-01__timeline:15424-15434	1.000
:Event_0000006	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000038	bpoil_guardian__1000-01-01__timeline:15378-15379	1.000
:Event_0000006	type	Transaction.TransferMoney
:Event_0000006	mention.actual	"pay"	bpoil_guardian__1000-01-01__timeline:13535-13537	1.000
:Event_0000006	canonical_mention.actual	"pay"	bpoil_guardian__1000-01-01__timeline:13535-13537	1.000
:Event_0000006	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000068	bpoil_guardian__1000-01-01__timeline:13519-13521	1.000
:Event_0000006	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000054	bpoil_guardian__1000-01-01__timeline:13599-13610	1.000
:Event_0000007	type	Contact.Contact
:Event_0000007	mention.actual	"interview"	bpoil_guardian__1000-01-01__timeline:22981-22989	1.000
:Event_0000007	canonical_mention.actual	"interview"	bpoil_guardian__1000-01-01__timeline:22981-22989	1.000
:Event_0000007	Contact.Contact_Participant.actual	:Entity_EDL_0000017	bpoil_guardian__1000-01-01__timeline:22994-23007	1.000
:Event_0000007	Contact.Contact_Participant.actual	:Entity_EDL_0000065	bpoil_guardian__1000-01-01__timeline:23009-23010	1.000
:Event_0000007	type	Contact.Contact
:Event_0000007	mention.actual	"interview"	bpoil_guardian__1000-01-01__timeline:14424-14432	1.000
:Event_0000007	canonical_mention.actual	"interview"	bpoil_guardian__1000-01-01__timeline:14424-14432	1.000
:Event_0000007	Contact.Contact_Participant.actual	:Entity_EDL_0000022	bpoil_guardian__1000-01-01__timeline:14437-14439	1.000
:Event_0000007	Contact.Contact_Participant.actual	:Entity_EDL_0000011	bpoil_guardian__1000-01-01__timeline:14441-14445	1.000
:Event_0000008	type	Conflict.Attack
:Event_0000008	mention.actual	"bomber"	bpoil_guardian__1000-01-01__timeline:21087-21092	1.000
:Event_0000008	canonical_mention.actual	"bomber"	bpoil_guardian__1000-01-01__timeline:21087-21092	1.000
:Event_0000008	Conflict.Attack_Place.actual	:Entity_EDL_0000035	bpoil_guardian__1000-01-01__timeline:21077-21085	1.000
:Event_0000008	Conflict.Attack_Attacker.actual	:Entity_EDL_0000010	bpoil_guardian__1000-01-01__timeline:21087-21092	1.000
:Event_0000008	type	Conflict.Attack
:Event_0000008	mention.actual	"bomber"	bpoil_guardian__1000-01-01__timeline:22034-22039	1.000
:Event_0000008	canonical_mention.actual	"bomber"	bpoil_guardian__1000-01-01__timeline:22034-22039	1.000
:Event_0000008	Conflict.Attack_Place.actual	:Entity_EDL_0000078	bpoil_guardian__1000-01-01__timeline:22024-22032	1.000
:Event_0000008	Conflict.Attack_Attacker.actual	:Entity_EDL_0000081	bpoil_guardian__1000-01-01__timeline:22034-22039	1.000
:Event_0000009	type	Transaction.TransferMoney
:Event_0000009	mention.actual	"pay"	bpoil_guardian__1000-01-01__timeline:18828-18830	1.000
:Event_0000009	canonical_mention.actual	"pay"	bpoil_guardian__1000-01-01__timeline:18828-18830	1.000
:Event_0000009	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000105	bpoil_guardian__1000-01-01__timeline:18816-18823	1.000
:Event_0000009	type	Transaction.TransferMoney
:Event_0000009	mention.actual	"contribute"	bpoil_guardian__1000-01-01__timeline:18770-18779	1.000
:Event_0000009	canonical_mention.actual	"contribute"	bpoil_guardian__1000-01-01__timeline:18770-18779	1.000
:Event_0000009	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000094	bpoil_guardian__1000-01-01__timeline:18701-18707	1.000
:Event_0000009	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000073	bpoil_guardian__1000-01-01__timeline:18718-18725	1.000
:Event_0000009	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000082	bpoil_guardian__1000-01-01__timeline:18729-18736	1.000
:Event_0000009	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000076	bpoil_guardian__1000-01-01__timeline:18742-18763	1.000
:Event_0000010	type	Personnel.EndPosition
:Event_0000010	mention.actual	"sack"	bpoil_guardian__1000-01-01__timeline:14561-14564	1.000
:Event_0000010	canonical_mention.actual	"sack"	bpoil_guardian__1000-01-01__timeline:14561-14564	1.000
:Event_0000010	Personnel.EndPosition_Person.actual	:Entity_EDL_0000069	bpoil_guardian__1000-01-01__timeline:14566-14568	1.000
:Event_0000010	type	Personnel.EndPosition
:Event_0000010	mention.actual	"sacked"	bpoil_guardian__1000-01-01__timeline:14466-14471	1.000
:Event_0000010	canonical_mention.actual	"sacked"	bpoil_guardian__1000-01-01__timeline:14466-14471	1.000
:Event_0000010	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000062	bpoil_guardian__1000-01-01__timeline:14473-14474	1.000
:Event_0000010	Personnel.EndPosition_Person.actual	:Entity_EDL_0000047	bpoil_guardian__1000-01-01__timeline:14485-14493	1.000
:Event_0000011	type	Contact.Meet
:Event_0000011	mention.actual	"hearings"	bpoil_guardian__1000-01-01__timeline:10825-10832	1.000
:Event_0000011	canonical_mention.actual	"hearings"	bpoil_guardian__1000-01-01__timeline:10825-10832	1.000
:Event_0000011	Contact.Meet_Participant.actual	:Entity_EDL_0000074	bpoil_guardian__1000-01-01__timeline:10811-10823	1.000
:Event_0000011	type	Contact.Meet
:Event_0000011	mention.actual	"hearing"	bpoil_guardian__1000-01-01__timeline:8437-8443	1.000
:Event_0000011	canonical_mention.actual	"hearing"	bpoil_guardian__1000-01-01__timeline:8437-8443	1.000
:Event_0000011	Contact.Meet_Participant.actual	:Entity_EDL_0000008	bpoil_guardian__1000-01-01__timeline:8507-8521	1.000
:Event_0000012	type	Justice.TrialHearing
:Event_0000012	mention.actual	"hearing"	bpoil_guardian__1000-01-01__timeline:12043-12049	1.000
:Event_0000012	canonical_mention.actual	"hearing"	bpoil_guardian__1000-01-01__timeline:12043-12049	1.000
:Event_0000012	type	Justice.TrialHearing
:Event_0000012	mention.actual	"hearing"	bpoil_guardian__1000-01-01__timeline:9349-9355	1.000
:Event_0000012	canonical_mention.actual	"hearing"	bpoil_guardian__1000-01-01__timeline:9349-9355	1.000
:Event_0000013	type	Life.Injure
:Event_0000013	mention.actual	"injured"	bpoil_guardian__1000-01-01__timeline:172-178	1.000
:Event_0000013	canonical_mention.actual	"injured"	bpoil_guardian__1000-01-01__timeline:172-178	1.000
:Event_0000013	Life.Injure_Victim.actual	:Entity_EDL_0000104	bpoil_guardian__1000-01-01__timeline:169-170	1.000
:Event_0000014	type	Transaction.TransferMoney
:Event_0000014	mention.actual	"billed"	bpoil_guardian__1000-01-01__timeline:26769-26774	1.000
:Event_0000014	canonical_mention.actual	"billed"	bpoil_guardian__1000-01-01__timeline:26769-26774	1.000
:Event_0000014	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000009	bpoil_guardian__1000-01-01__timeline:26757-26758	1.000
:Event_0000014	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000037	bpoil_guardian__1000-01-01__timeline:26806-26807	1.000
:Event_0000015	type	Movement.TransportArtifact
:Event_0000015	mention.actual	"return"	bpoil_guardian__1000-01-01__timeline:24075-24080	1.000
:Event_0000015	canonical_mention.actual	"return"	bpoil_guardian__1000-01-01__timeline:24075-24080	1.000
:Event_0000015	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000097	bpoil_guardian__1000-01-01__timeline:24069-24073	1.000
:Event_0000015	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000092	bpoil_guardian__1000-01-01__timeline:24089-24092	1.000
:Event_0000016	type	Contact.Broadcast
:Event_0000016	mention.actual	"announces"	bpoil_guardian__1000-01-01__timeline:27736-27744	1.000
:Event_0000016	canonical_mention.actual	"announces"	bpoil_guardian__1000-01-01__timeline:27736-27744	1.000
:Event_0000016	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000029	bpoil_guardian__1000-01-01__timeline:27725-27734	1.000
:Event_0000017	type	Justice.TrialHearing
:Event_0000017	mention.actual	"hear"	bpoil_guardian__1000-01-01__timeline:19814-19817	1.000
:Event_0000017	canonical_mention.actual	"hear"	bpoil_guardian__1000-01-01__timeline:19814-19817	1.000
:Event_0000017	Justice.TrialHearing_Adjudicator.actual	:Entity_EDL_0000000	bpoil_guardian__1000-01-01__timeline:19793-19797	1.000
:Event_0000018	type	Life.Die
:Event_0000018	mention.actual	"dead"	bpoil_guardian__1000-01-01__timeline:14366-14369	1.000
:Event_0000018	canonical_mention.actual	"dead"	bpoil_guardian__1000-01-01__timeline:14366-14369	1.000
:Event_0000018	Life.Die_Victim.actual	:Entity_EDL_0000052	bpoil_guardian__1000-01-01__timeline:14356-14361	1.000
:Event_0000019	type	Movement.TransportArtifact
:Event_0000019	mention.actual	"flies"	bpoil_guardian__1000-01-01__timeline:4797-4801	1.000
:Event_0000019	canonical_mention.actual	"flies"	bpoil_guardian__1000-01-01__timeline:4797-4801	1.000
:Event_0000019	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000012	bpoil_guardian__1000-01-01__timeline:4784-4795	1.000
:Event_0000019	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000096	bpoil_guardian__1000-01-01__timeline:4806-4814	1.000
:Event_0000020	type	Contact.Contact
:Event_0000020	mention.actual	"asks"	bpoil_guardian__1000-01-01__timeline:6318-6321	1.000
:Event_0000020	canonical_mention.actual	"asks"	bpoil_guardian__1000-01-01__timeline:6318-6321	1.000
:Event_0000020	Contact.Contact_Participant.actual	:Entity_EDL_0000014	bpoil_guardian__1000-01-01__timeline:6296-6316	1.000
:Event_0000020	Contact.Contact_Participant.actual	:Entity_EDL_0000023	bpoil_guardian__1000-01-01__timeline:6323-6332	1.000
:Event_0000021	type	Movement.TransportArtifact
:Event_0000021	mention.actual	"move"	bpoil_guardian__1000-01-01__timeline:6981-6984	1.000
:Event_0000021	canonical_mention.actual	"move"	bpoil_guardian__1000-01-01__timeline:6981-6984	1.000
:Event_0000021	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000061	bpoil_guardian__1000-01-01__timeline:6948-6956	1.000
:Event_0000021	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000045	bpoil_guardian__1000-01-01__timeline:6971-6976	1.000
:Event_0000021	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000034	bpoil_guardian__1000-01-01__timeline:7002-7008	1.000
:Event_0000022	type	Contact.Broadcast
:Event_0000022	mention.actual	"speech"	bpoil_guardian__1000-01-01__timeline:17334-17339	1.000
:Event_0000022	canonical_mention.actual	"speech"	bpoil_guardian__1000-01-01__timeline:17334-17339	1.000
:Event_0000022	Contact.Broadcast_Audience.actual	:Entity_EDL_0000059	bpoil_guardian__1000-01-01__timeline:17281-17290	1.000
:Event_0000022	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000049	bpoil_guardian__1000-01-01__timeline:17319-17329	1.000
:Event_0000023	type	ArtifactExistence.DamageDestroy.Destroy
:Event_0000023	mention.actual	"destruction"	bpoil_guardian__1000-01-01__timeline:31128-31138	1.000
:Event_0000023	canonical_mention.actual	"destruction"	bpoil_guardian__1000-01-01__timeline:31128-31138	1.000
:Event_0000024	type	Contact.Correspondence
:Event_0000024	mention.actual	"written"	bpoil_guardian__1000-01-01__timeline:21639-21645	1.000
:Event_0000024	canonical_mention.actual	"written"	bpoil_guardian__1000-01-01__timeline:21639-21645	1.000
:Event_0000024	Contact.Correspondence_Participant.actual	:Entity_EDL_0000106	bpoil_guardian__1000-01-01__timeline:21570-21579	1.000
:Event_0000024	Contact.Correspondence_Participant.actual	:Entity_EDL_0000067	bpoil_guardian__1000-01-01__timeline:21650-21651	1.000
:Event_0000025	type	Movement.TransportArtifact
:Event_0000025	mention.actual	"reach"	bpoil_guardian__1000-01-01__timeline:23654-23658	1.000
:Event_0000025	canonical_mention.actual	"reach"	bpoil_guardian__1000-01-01__timeline:23654-23658	1.000
:Event_0000025	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000060	bpoil_guardian__1000-01-01__timeline:23664-23667	1.000
:Event_0000026	type	Justice.TrialHearing
:Event_0000026	mention.actual	"hearing"	bpoil_guardian__1000-01-01__timeline:25394-25400	1.000
:Event_0000026	canonical_mention.actual	"hearing"	bpoil_guardian__1000-01-01__timeline:25394-25400	1.000
:Event_0000027	type	Personnel.EndPosition
:Event_0000027	mention.actual	"departure"	bpoil_guardian__1000-01-01__timeline:33480-33488	1.000
:Event_0000027	canonical_mention.actual	"departure"	bpoil_guardian__1000-01-01__timeline:33480-33488	1.000
:Event_0000027	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000031	bpoil_guardian__1000-01-01__timeline:33463-33464	1.000
:Event_0000027	Personnel.EndPosition_Person.actual	:Entity_EDL_0000021	bpoil_guardian__1000-01-01__timeline:33493-33504	1.000
:Event_0000028	type	Justice.Sue
:Event_0000028	mention.actual	"suit"	bpoil_guardian__1000-01-01__timeline:36008-36011	1.000
:Event_0000028	canonical_mention.actual	"suit"	bpoil_guardian__1000-01-01__timeline:36008-36011	1.000
:Event_0000028	Justice.Sue_Plaintiff.actual	:Entity_EDL_0000051	bpoil_guardian__1000-01-01__timeline:35989-35998	1.000
:Event_0000028	Justice.Sue_Defendant.actual	:Entity_EDL_0000095	bpoil_guardian__1000-01-01__timeline:36021-36022	1.000
:Event_0000028	Justice.Sue_Defendant.actual	:Entity_EDL_0000093	bpoil_guardian__1000-01-01__timeline:36028-36034	1.000
:Event_0000029	type	ArtifactExistence.DamageDestroy.Destroy
:Event_0000029	mention.actual	"blown"	bpoil_guardian__1000-01-01__timeline:8277-8281	1.000
:Event_0000029	canonical_mention.actual	"blown"	bpoil_guardian__1000-01-01__timeline:8277-8281	1.000
:Event_0000030	type	Movement.TransportArtifact
:Event_0000030	mention.actual	"visits"	bpoil_guardian__1000-01-01__timeline:4725-4730	1.000
:Event_0000030	canonical_mention.actual	"visits"	bpoil_guardian__1000-01-01__timeline:4725-4730	1.000
:Event_0000030	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000025	bpoil_guardian__1000-01-01__timeline:4719-4723	1.000
:Event_0000030	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000040	bpoil_guardian__1000-01-01__timeline:4741-4745	1.000
:Event_0000031	type	Life.Die
:Event_0000031	mention.actual	"died"	bpoil_guardian__1000-01-01__timeline:29427-29430	1.000
:Event_0000031	canonical_mention.actual	"died"	bpoil_guardian__1000-01-01__timeline:29427-29430	1.000
:Event_0000031	Life.Die_Victim.actual	:Entity_EDL_0000103	bpoil_guardian__1000-01-01__timeline:29423-29425	1.000
:Event_0000032	type	Movement.TransportArtifact
:Event_0000032	mention.actual	"visit"	bpoil_guardian__1000-01-01__timeline:22126-22130	1.000
:Event_0000032	canonical_mention.actual	"visit"	bpoil_guardian__1000-01-01__timeline:22126-22130	1.000
:Event_0000032	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000101	bpoil_guardian__1000-01-01__timeline:22101-22103	1.000
:Event_0000032	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000015	bpoil_guardian__1000-01-01__timeline:22123-22124	1.000
:Event_0000033	type	Transaction.TransferMoney
:Event_0000033	mention.actual	"payments"	bpoil_guardian__1000-01-01__timeline:25823-25830	1.000
:Event_0000033	canonical_mention.actual	"payments"	bpoil_guardian__1000-01-01__timeline:25823-25830	1.000
:Event_0000033	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000028	bpoil_guardian__1000-01-01__timeline:25796-25797	1.000
:Event_0000033	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000066	bpoil_guardian__1000-01-01__timeline:25835-25843	1.000
:Event_0000034	type	Contact.Correspondence
:Event_0000034	mention.actual	"letter"	bpoil_guardian__1000-01-01__timeline:18083-18088	1.000
:Event_0000034	canonical_mention.actual	"letter"	bpoil_guardian__1000-01-01__timeline:18083-18088	1.000
:Event_0000034	Contact.Correspondence_Participant.actual	:Entity_EDL_0000001	bpoil_guardian__1000-01-01__timeline:18058-18069	1.000
:Event_0000034	Contact.Correspondence_Participant.actual	:Entity_EDL_0000027	bpoil_guardian__1000-01-01__timeline:18099-18105	1.000
:Event_0000034	Contact.Correspondence_Participant.actual	:Entity_EDL_0000058	bpoil_guardian__1000-01-01__timeline:18109-18115	1.000
:Event_0000034	Contact.Correspondence_Participant.actual	:Entity_EDL_0000079	bpoil_guardian__1000-01-01__timeline:18121-18127	1.000
:Event_0000035	type	Contact.Meet
:Event_0000035	mention.actual	"gathering"	bpoil_guardian__1000-01-01__timeline:17158-17166	1.000
:Event_0000035	canonical_mention.actual	"gathering"	bpoil_guardian__1000-01-01__timeline:17158-17166	1.000
:Event_0000035	Contact.Meet_Participant.actual	:Entity_EDL_0000026	bpoil_guardian__1000-01-01__timeline:17179-17186	1.000
:Event_0000036	type	Disaster.FireExplosion.FireExplosion
:Event_0000036	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:32384-32392	1.000
:Event_0000036	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:32384-32392	1.000
:Event_0000036	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:32384-32392	1.000
:Event_0000036	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:32384-32392	1.000
:Event_0000037	type	Life.Die
:Event_0000037	mention.actual	"dead"	bpoil_guardian__1000-01-01__timeline:654-657	1.000
:Event_0000037	canonical_mention.actual	"dead"	bpoil_guardian__1000-01-01__timeline:654-657	1.000
:Event_0000037	Life.Die_Victim.actual	:Entity_EDL_0000102	bpoil_guardian__1000-01-01__timeline:623-629	1.000
:Event_0000038	type	Justice.TrialHearing
:Event_0000038	mention.actual	"testimony"	bpoil_guardian__1000-01-01__timeline:14247-14255	1.000
:Event_0000038	canonical_mention.actual	"testimony"	bpoil_guardian__1000-01-01__timeline:14247-14255	1.000
:Event_0000038	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000042	bpoil_guardian__1000-01-01__timeline:14205-14210	1.000
:Event_0000038	Justice.TrialHearing_Adjudicator.actual	:Entity_EDL_0000055	bpoil_guardian__1000-01-01__timeline:14280-14288	1.000
:Event_0000039	type	ArtifactExistence.DamageDestroy.Damage
:Event_0000039	mention.actual	"disrupt"	bpoil_guardian__1000-01-01__timeline:18245-18251	1.000
:Event_0000039	canonical_mention.actual	"disrupt"	bpoil_guardian__1000-01-01__timeline:18245-18251	1.000
:Event_0000039	ArtifactExistence.DamageDestroy.Damage_Artifact.actual	:Entity_EDL_0000056	bpoil_guardian__1000-01-01__timeline:18343-18347	1.000
:Event_0000040	type	Movement.TransportArtifact
:Event_0000040	mention.actual	"arrival"	bpoil_guardian__1000-01-01__timeline:6111-6117	1.000
:Event_0000040	canonical_mention.actual	"arrival"	bpoil_guardian__1000-01-01__timeline:6111-6117	1.000
:Event_0000041	type	Movement.TransportArtifact
:Event_0000041	mention.actual	"leaving"	bpoil_guardian__1000-01-01__timeline:23569-23575	1.000
:Event_0000041	canonical_mention.actual	"leaving"	bpoil_guardian__1000-01-01__timeline:23569-23575	1.000
:Event_0000041	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000063	bpoil_guardian__1000-01-01__timeline:23525-23529	1.000
:Event_0000041	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000053	bpoil_guardian__1000-01-01__timeline:23581-23584	1.000
:Event_0000042	type	Justice.Sue
:Event_0000042	mention.actual	"lawsuits"	bpoil_guardian__1000-01-01__timeline:26024-26031	1.000
:Event_0000042	canonical_mention.actual	"lawsuits"	bpoil_guardian__1000-01-01__timeline:26024-26031	1.000
:Event_0000042	Justice.Sue_Place.actual	:Entity_EDL_0000050	bpoil_guardian__1000-01-01__timeline:26009-26012	1.000
:Event_0000043	type	Life.Die
:Event_0000043	mention.actual	"fatal"	bpoil_guardian__1000-01-01__timeline:33948-33952	1.000
:Event_0000043	canonical_mention.actual	"fatal"	bpoil_guardian__1000-01-01__timeline:33948-33952	1.000
:Event_0000043	Life.Die_Place.actual	:Entity_EDL_0000098	bpoil_guardian__1000-01-01__timeline:33982-33989	1.000
:Event_0000044	type	Conflict.Attack
:Event_0000044	mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:33954-33962	1.000
:Event_0000044	canonical_mention.actual	"explosion"	bpoil_guardian__1000-01-01__timeline:33954-33962	1.000
:Event_0000044	Conflict.Attack_Place.actual	:Entity_EDL_0000019	bpoil_guardian__1000-01-01__timeline:33971-33980	1.000
:Event_0000044	Conflict.Attack_Place.actual	:Entity_EDL_0000098	bpoil_guardian__1000-01-01__timeline:33982-33989	1.000
:Event_0000045	type	Justice.Sue
:Event_0000045	mention.actual	"sue"	bpoil_guardian__1000-01-01__timeline:25870-25872	1.000
:Event_0000045	canonical_mention.actual	"sue"	bpoil_guardian__1000-01-01__timeline:25870-25872	1.000
:Event_0000045	Justice.Sue_Defendant.actual	:Entity_EDL_0000084	bpoil_guardian__1000-01-01__timeline:25878-25884	1.000
:Event_0000046	type	Contact.Correspondence
:Event_0000046	mention.actual	"calls"	bpoil_guardian__1000-01-01__timeline:14667-14671	1.000
:Event_0000046	canonical_mention.actual	"calls"	bpoil_guardian__1000-01-01__timeline:14667-14671	1.000
:Event_0000046	Contact.Correspondence_Participant.actual	:Entity_EDL_0000007	bpoil_guardian__1000-01-01__timeline:14653-14665	1.000
:Event_0000046	Contact.Correspondence_Participant.actual	:Entity_EDL_0000091	bpoil_guardian__1000-01-01__timeline:14679-14686	1.000
:Event_0000046	Contact.Correspondence_Participant.actual	:Entity_EDL_0000041	bpoil_guardian__1000-01-01__timeline:14690-14709	1.000
:Event_0000047	type	Justice.ChargeIndict
:Event_0000047	mention.actual	"charges"	bpoil_guardian__1000-01-01__timeline:26935-26941	1.000
:Event_0000047	canonical_mention.actual	"charges"	bpoil_guardian__1000-01-01__timeline:26935-26941	1.000
:Event_0000047	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000057	bpoil_guardian__1000-01-01__timeline:26956-26963	1.000
:Event_0000048	type	Transaction.TransferMoney
:Event_0000048	mention.actual	"payment"	bpoil_guardian__1000-01-01__timeline:35351-35357	1.000
:Event_0000048	canonical_mention.actual	"payment"	bpoil_guardian__1000-01-01__timeline:35351-35357	1.000
:Event_0000048	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000016	bpoil_guardian__1000-01-01__timeline:35327-35335	1.000
:Event_0000049	type	Transaction.TransferMoney
:Event_0000049	mention.actual	"pay"	bpoil_guardian__1000-01-01__timeline:35572-35574	1.000
:Event_0000049	canonical_mention.actual	"pay"	bpoil_guardian__1000-01-01__timeline:35572-35574	1.000
:Event_0000049	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000005	bpoil_guardian__1000-01-01__timeline:35548-35559	1.000
:Event_0000050	type	Personnel.EndPosition
:Event_0000050	mention.actual	"former"	bpoil_guardian__1000-01-01__timeline:9852-9857	1.000
:Event_0000050	canonical_mention.actual	"former"	bpoil_guardian__1000-01-01__timeline:9852-9857	1.000
:Event_0000050	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000039	bpoil_guardian__1000-01-01__timeline:9859-9864	1.000
:Event_0000050	Personnel.EndPosition_Person.actual	:Entity_EDL_0000033	bpoil_guardian__1000-01-01__timeline:9866-9875	1.000
:Event_0000050	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000090	bpoil_guardian__1000-01-01__timeline:9888-9914	1.000
:Event_0000051	type	Justice.TrialHearing
:Event_0000051	mention.actual	"hearing"	bpoil_guardian__1000-01-01__timeline:30153-30159	1.000
:Event_0000051	canonical_mention.actual	"hearing"	bpoil_guardian__1000-01-01__timeline:30153-30159	1.000
:Event_0000051	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000071	bpoil_guardian__1000-01-01__timeline:30163-30166	1.000
:Event_0000052	type	Transaction.TransferMoney
:Event_0000052	mention.actual	"billed"	bpoil_guardian__1000-01-01__timeline:26915-26920	1.000
:Event_0000052	canonical_mention.actual	"billed"	bpoil_guardian__1000-01-01__timeline:26915-26920	1.000
:Event_0000053	type	Business.End
:Event_0000053	mention.actual	"close"	bpoil_guardian__1000-01-01__timeline:24847-24851	1.000
:Event_0000053	canonical_mention.actual	"close"	bpoil_guardian__1000-01-01__timeline:24847-24851	1.000
:Event_0000053	Business.End_Place.actual	:Entity_EDL_0000044	bpoil_guardian__1000-01-01__timeline:24859-24865	1.000
:Event_0000053	Business.End_Place.actual	:Entity_EDL_0000024	bpoil_guardian__1000-01-01__timeline:24870-24883	1.000
:Event_0000054	type	Transaction.TransferOwnership
:Event_0000054	mention.actual	"stolen"	bpoil_guardian__1000-01-01__timeline:24971-24976	1.000
:Event_0000054	canonical_mention.actual	"stolen"	bpoil_guardian__1000-01-01__timeline:24971-24976	1.000
:Event_0000055	type	Business.Start
:Event_0000055	mention.actual	"establish"	bpoil_guardian__1000-01-01__timeline:11411-11419	1.000
:Event_0000055	canonical_mention.actual	"establish"	bpoil_guardian__1000-01-01__timeline:11411-11419	1.000
:Event_0000055	Business.Start_Agent.actual	:Entity_EDL_0000088	bpoil_guardian__1000-01-01__timeline:11396-11400	1.000
:Event_0000055	Business.Start_Organization.actual	:Entity_EDL_0000072	bpoil_guardian__1000-01-01__timeline:11436-11445	1.000
