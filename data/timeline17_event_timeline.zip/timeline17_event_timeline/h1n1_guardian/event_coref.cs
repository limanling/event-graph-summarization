:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"dies"	h1n1_guardian__1000-01-01__timeline:4797-4800	1.000
:Event_0000000	canonical_mention.actual	"dies"	h1n1_guardian__1000-01-01__timeline:4797-4800	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000005	h1n1_guardian__1000-01-01__timeline:4767-4771	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000010	h1n1_guardian__1000-01-01__timeline:4831-4845	1.000
:Event_0000001	type	Life.Die
:Event_0000001	mention.actual	"deaths"	h1n1_guardian__1000-01-01__timeline:1090-1095	1.000
:Event_0000001	canonical_mention.actual	"deaths"	h1n1_guardian__1000-01-01__timeline:1090-1095	1.000
:Event_0000001	Life.Die_Place.actual	:Entity_EDL_0000020	h1n1_guardian__1000-01-01__timeline:1100-1105	1.000
:Event_0000001	Life.Die_Victim.actual	:Entity_EDL_0000021	h1n1_guardian__1000-01-01__timeline:1116-1118	1.000
:Event_0000002	type	Movement.TransportArtifact
:Event_0000002	mention.actual	"returned"	h1n1_guardian__1000-01-01__timeline:1955-1962	1.000
:Event_0000002	canonical_mention.actual	"returned"	h1n1_guardian__1000-01-01__timeline:1955-1962	1.000
:Event_0000002	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000016	h1n1_guardian__1000-01-01__timeline:1941-1949	1.000
:Event_0000002	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000003	h1n1_guardian__1000-01-01__timeline:1975-1980	1.000
:Event_0000003	type	Life.Die
:Event_0000003	mention.actual	"died"	h1n1_guardian__1000-01-01__timeline:4101-4104	1.000
:Event_0000003	canonical_mention.actual	"died"	h1n1_guardian__1000-01-01__timeline:4101-4104	1.000
:Event_0000003	Life.Die_Victim.actual	:Entity_EDL_0000026	h1n1_guardian__1000-01-01__timeline:4070-4075	1.000
:Event_0000003	Life.Die_Place.actual	:Entity_EDL_0000015	h1n1_guardian__1000-01-01__timeline:4088-4094	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"deaths"	h1n1_guardian__1000-01-01__timeline:2699-2704	1.000
:Event_0000004	canonical_mention.actual	"deaths"	h1n1_guardian__1000-01-01__timeline:2699-2704	1.000
:Event_0000005	type	Disaster.DiseaseOutbreak.DiseaseOutbreak
:Event_0000005	mention.actual	"outbreak"	h1n1_guardian__1000-01-01__timeline:4697-4704	1.000
:Event_0000005	canonical_mention.actual	"outbreak"	h1n1_guardian__1000-01-01__timeline:4697-4704	1.000
:Event_0000005	Disaster.DiseaseOutbreak.DiseaseOutbreak_Disease.actual	:Entity_EDL_0000007	h1n1_guardian__1000-01-01__timeline:4693-4695	1.000
:Event_0000006	type	Movement.TransportArtifact
:Event_0000006	mention.actual	"bring"	h1n1_guardian__1000-01-01__timeline:1527-1531	1.000
:Event_0000006	canonical_mention.actual	"bring"	h1n1_guardian__1000-01-01__timeline:1527-1531	1.000
:Event_0000006	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000019	h1n1_guardian__1000-01-01__timeline:1448-1455	1.000
:Event_0000006	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000028	h1n1_guardian__1000-01-01__timeline:1494-1499	1.000
:Event_0000006	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000008	h1n1_guardian__1000-01-01__timeline:1541-1553	1.000
:Event_0000006	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000006	h1n1_guardian__1000-01-01__timeline:1555-1558	1.000
:Event_0000007	type	Life.Die
:Event_0000007	mention.actual	"deaths"	h1n1_guardian__1000-01-01__timeline:117-122	1.000
:Event_0000007	canonical_mention.actual	"deaths"	h1n1_guardian__1000-01-01__timeline:117-122	1.000
:Event_0000007	Life.Die_Place.actual	:Entity_EDL_0000023	h1n1_guardian__1000-01-01__timeline:77-82	1.000
:Event_0000008	type	Life.Die
:Event_0000008	mention.actual	"deaths"	h1n1_guardian__1000-01-01__timeline:351-356	1.000
:Event_0000008	canonical_mention.actual	"deaths"	h1n1_guardian__1000-01-01__timeline:351-356	1.000
:Event_0000009	type	Life.Die
:Event_0000009	mention.actual	"deaths"	h1n1_guardian__1000-01-01__timeline:3551-3556	1.000
:Event_0000009	canonical_mention.actual	"deaths"	h1n1_guardian__1000-01-01__timeline:3551-3556	1.000
:Event_0000009	Life.Die_Place.actual	:Entity_EDL_0000018	h1n1_guardian__1000-01-01__timeline:3465-3479	1.000
:Event_0000010	type	Movement.TransportArtifact
:Event_0000010	mention.actual	"traveled"	h1n1_guardian__1000-01-01__timeline:2462-2469	1.000
:Event_0000010	canonical_mention.actual	"traveled"	h1n1_guardian__1000-01-01__timeline:2462-2469	1.000
:Event_0000010	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000014	h1n1_guardian__1000-01-01__timeline:2449-2456	1.000
:Event_0000010	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000013	h1n1_guardian__1000-01-01__timeline:2474-2479	1.000
:Event_0000011	type	Life.Marry
:Event_0000011	mention.actual	"honeymoon"	h1n1_guardian__1000-01-01__timeline:1982-1990	1.000
:Event_0000011	canonical_mention.actual	"honeymoon"	h1n1_guardian__1000-01-01__timeline:1982-1990	1.000
:Event_0000011	Life.Marry_Person.actual	:Entity_EDL_0000016	h1n1_guardian__1000-01-01__timeline:1941-1949	1.000
:Event_0000011	Life.Marry_Place.actual	:Entity_EDL_0000003	h1n1_guardian__1000-01-01__timeline:1975-1980	1.000
:Event_0000012	type	Life.Die
:Event_0000012	mention.actual	"fatalities"	h1n1_guardian__1000-01-01__timeline:3675-3684	1.000
:Event_0000012	canonical_mention.actual	"fatalities"	h1n1_guardian__1000-01-01__timeline:3675-3684	1.000
:Event_0000012	Life.Die_Place.actual	:Entity_EDL_0000004	h1n1_guardian__1000-01-01__timeline:3564-3571	1.000
:Event_0000013	type	Contact.Correspondence
:Event_0000013	mention.actual	"notifies"	h1n1_guardian__1000-01-01__timeline:4597-4604	1.000
:Event_0000013	canonical_mention.actual	"notifies"	h1n1_guardian__1000-01-01__timeline:4597-4604	1.000
:Event_0000013	Contact.Correspondence_Participant.actual	:Entity_EDL_0000001	h1n1_guardian__1000-01-01__timeline:4586-4595	1.000
:Event_0000013	Contact.Correspondence_Participant.actual	:Entity_EDL_0000027	h1n1_guardian__1000-01-01__timeline:4610-4641	1.000
:Event_0000014	type	Life.Die
:Event_0000014	mention.actual	"fatal"	h1n1_guardian__1000-01-01__timeline:3453-3457	1.000
:Event_0000014	canonical_mention.actual	"fatal"	h1n1_guardian__1000-01-01__timeline:3453-3457	1.000
:Event_0000014	Life.Die_Place.actual	:Entity_EDL_0000009	h1n1_guardian__1000-01-01__timeline:3415-3425	1.000
:Event_0000015	type	Movement.TransportArtifact
:Event_0000015	mention.actual	"flights"	h1n1_guardian__1000-01-01__timeline:1483-1489	1.000
:Event_0000015	canonical_mention.actual	"flights"	h1n1_guardian__1000-01-01__timeline:1483-1489	1.000
:Event_0000015	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000019	h1n1_guardian__1000-01-01__timeline:1448-1455	1.000
:Event_0000015	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000012	h1n1_guardian__1000-01-01__timeline:1466-1474	1.000
:Event_0000015	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000028	h1n1_guardian__1000-01-01__timeline:1494-1499	1.000
:Event_0000016	type	Movement.TransportArtifact
:Event_0000016	mention.actual	"travel"	h1n1_guardian__1000-01-01__timeline:1619-1624	1.000
:Event_0000016	canonical_mention.actual	"travel"	h1n1_guardian__1000-01-01__timeline:1619-1624	1.000
:Event_0000016	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000017	h1n1_guardian__1000-01-01__timeline:1633-1639	1.000
:Event_0000017	type	Life.Die
:Event_0000017	mention.actual	"deaths"	h1n1_guardian__1000-01-01__timeline:3345-3350	1.000
:Event_0000017	canonical_mention.actual	"deaths"	h1n1_guardian__1000-01-01__timeline:3345-3350	1.000
:Event_0000018	type	Life.Die
:Event_0000018	mention.actual	"death"	h1n1_guardian__1000-01-01__timeline:2310-2314	1.000
:Event_0000018	canonical_mention.actual	"death"	h1n1_guardian__1000-01-01__timeline:2310-2314	1.000
:Event_0000018	Life.Die_Place.actual	:Entity_EDL_0000024	h1n1_guardian__1000-01-01__timeline:2324-2329	1.000
:Event_0000018	Life.Die_Victim.actual	:Entity_EDL_0000022	h1n1_guardian__1000-01-01__timeline:2343-2345	1.000
:Event_0000019	type	Life.Die
:Event_0000019	mention.actual	"died"	h1n1_guardian__1000-01-01__timeline:184-187	1.000
:Event_0000019	canonical_mention.actual	"died"	h1n1_guardian__1000-01-01__timeline:184-187	1.000
:Event_0000019	Life.Die_Victim.actual	:Entity_EDL_0000002	h1n1_guardian__1000-01-01__timeline:159-164	1.000
:Event_0000019	Life.Die_Place.actual	:Entity_EDL_0000000	h1n1_guardian__1000-01-01__timeline:207-212	1.000
:Event_0000020	type	Movement.TransportArtifact
:Event_0000020	mention.actual	"returned"	h1n1_guardian__1000-01-01__timeline:763-770	1.000
:Event_0000020	canonical_mention.actual	"returned"	h1n1_guardian__1000-01-01__timeline:763-770	1.000
:Event_0000020	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000025	h1n1_guardian__1000-01-01__timeline:669-679	1.000
:Event_0000020	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000011	h1n1_guardian__1000-01-01__timeline:777-782	1.000
