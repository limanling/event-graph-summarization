:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:1180-1185	1.000
:Event_0000000	canonical_mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:1180-1185	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000026	syriancrisis_bbc__1000-01-01__timeline:1109-1114	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000000	syriancrisis_bbc__1000-01-01__timeline:1171-1174	1.000
:Event_0000001	type	Movement.TransportArtifact
:Event_0000001	mention.actual	"fled"	syriancrisis_bbc__1000-01-01__timeline:843-846	1.000
:Event_0000001	canonical_mention.actual	"fled"	syriancrisis_bbc__1000-01-01__timeline:843-846	1.000
:Event_0000001	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000008	syriancrisis_bbc__1000-01-01__timeline:834-841	1.000
:Event_0000001	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000012	syriancrisis_bbc__1000-01-01__timeline:876-883	1.000
:Event_0000002	type	Life.Die
:Event_0000002	mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:3668-3673	1.000
:Event_0000002	canonical_mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:3668-3673	1.000
:Event_0000002	Life.Die_Victim.actual	:Entity_EDL_0000032	syriancrisis_bbc__1000-01-01__timeline:3656-3661	1.000
:Event_0000002	Life.Die_Place.actual	:Entity_EDL_0000016	syriancrisis_bbc__1000-01-01__timeline:3678-3684	1.000
:Event_0000002	Life.Die_Agent.actual	:Entity_EDL_0000044	syriancrisis_bbc__1000-01-01__timeline:3721-3726	1.000
:Event_0000003	type	Life.Die
:Event_0000003	mention.actual	"died"	syriancrisis_bbc__1000-01-01__timeline:2147-2150	1.000
:Event_0000003	canonical_mention.actual	"died"	syriancrisis_bbc__1000-01-01__timeline:2147-2150	1.000
:Event_0000003	Life.Die_Place.actual	:Entity_EDL_0000037	syriancrisis_bbc__1000-01-01__timeline:2118-2124	1.000
:Event_0000003	Life.Die_Victim.actual	:Entity_EDL_0000031	syriancrisis_bbc__1000-01-01__timeline:2140-2145	1.000
:Event_0000003	Life.Die_Place.actual	:Entity_EDL_0000049	syriancrisis_bbc__1000-01-01__timeline:2203-2210	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"attacks"	syriancrisis_bbc__1000-01-01__timeline:2227-2233	1.000
:Event_0000004	canonical_mention.actual	"attacks"	syriancrisis_bbc__1000-01-01__timeline:2227-2233	1.000
:Event_0000004	Conflict.Attack_Target.actual	:Entity_EDL_0000040	syriancrisis_bbc__1000-01-01__timeline:2258-2267	1.000
:Event_0000005	type	Life.Die
:Event_0000005	mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:3568-3573	1.000
:Event_0000005	canonical_mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:3568-3573	1.000
:Event_0000005	Life.Die_Victim.actual	:Entity_EDL_0000035	syriancrisis_bbc__1000-01-01__timeline:3556-3561	1.000
:Event_0000005	Life.Die_Victim.actual	:Entity_EDL_0000020	syriancrisis_bbc__1000-01-01__timeline:3605-3612	1.000
:Event_0000006	type	Conflict.Demonstrate
:Event_0000006	mention.actual	"protesters"	syriancrisis_bbc__1000-01-01__timeline:109-118	1.000
:Event_0000006	canonical_mention.actual	"protesters"	syriancrisis_bbc__1000-01-01__timeline:109-118	1.000
:Event_0000006	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000009	syriancrisis_bbc__1000-01-01__timeline:15-20	1.000
:Event_0000006	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000006	syriancrisis_bbc__1000-01-01__timeline:109-118	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"firing"	syriancrisis_bbc__1000-01-01__timeline:151-156	1.000
:Event_0000007	canonical_mention.actual	"firing"	syriancrisis_bbc__1000-01-01__timeline:151-156	1.000
:Event_0000007	Conflict.Attack_Place.actual	:Entity_EDL_0000009	syriancrisis_bbc__1000-01-01__timeline:15-20	1.000
:Event_0000007	Conflict.Attack_Target.actual	:Entity_EDL_0000006	syriancrisis_bbc__1000-01-01__timeline:109-118	1.000
:Event_0000007	Conflict.Attack_Attacker.actual	:Entity_EDL_0000019	syriancrisis_bbc__1000-01-01__timeline:144-149	1.000
:Event_0000007	Conflict.Attack_Target.actual	:Entity_EDL_0000021	syriancrisis_bbc__1000-01-01__timeline:161-166	1.000
:Event_0000008	type	Life.Injure
:Event_0000008	mention.actual	"stabbing"	syriancrisis_bbc__1000-01-01__timeline:3487-3494	1.000
:Event_0000008	canonical_mention.actual	"stabbing"	syriancrisis_bbc__1000-01-01__timeline:3487-3494	1.000
:Event_0000008	Life.Injure_Place.actual	:Entity_EDL_0000005	syriancrisis_bbc__1000-01-01__timeline:3404-3410	1.000
:Event_0000008	Life.Injure_Agent.actual	:Entity_EDL_0000013	syriancrisis_bbc__1000-01-01__timeline:3452-3461	1.000
:Event_0000008	Life.Injure_Victim.actual	:Entity_EDL_0000030	syriancrisis_bbc__1000-01-01__timeline:3496-3502	1.000
:Event_0000009	type	Life.Die
:Event_0000009	mention.actual	"mown down"	syriancrisis_bbc__1000-01-01__timeline:787-795	1.000
:Event_0000009	canonical_mention.actual	"mown down"	syriancrisis_bbc__1000-01-01__timeline:787-795	1.000
:Event_0000009	Life.Die_Victim.actual	:Entity_EDL_0000007	syriancrisis_bbc__1000-01-01__timeline:773-780	1.000
:Event_0000009	Life.Die_Instrument.actual	:Entity_EDL_0000003	syriancrisis_bbc__1000-01-01__timeline:800-811	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"overthrow"	syriancrisis_bbc__1000-01-01__timeline:380-388	1.000
:Event_0000010	canonical_mention.actual	"overthrow"	syriancrisis_bbc__1000-01-01__timeline:380-388	1.000
:Event_0000010	Conflict.Attack_Target.actual	:Entity_EDL_0000011	syriancrisis_bbc__1000-01-01__timeline:400-414	1.000
:Event_0000011	type	Conflict.Demonstrate
:Event_0000011	mention.actual	"uprising"	syriancrisis_bbc__1000-01-01__timeline:22-29	1.000
:Event_0000011	canonical_mention.actual	"uprising"	syriancrisis_bbc__1000-01-01__timeline:22-29	1.000
:Event_0000011	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000009	syriancrisis_bbc__1000-01-01__timeline:15-20	1.000
:Event_0000012	type	Life.Die
:Event_0000012	mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:4070-4075	1.000
:Event_0000012	canonical_mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:4070-4075	1.000
:Event_0000012	Life.Die_Victim.actual	:Entity_EDL_0000002	syriancrisis_bbc__1000-01-01__timeline:4006-4021	1.000
:Event_0000013	type	Conflict.Attack
:Event_0000013	mention.actual	"attacks"	syriancrisis_bbc__1000-01-01__timeline:2077-2083	1.000
:Event_0000013	canonical_mention.actual	"attacks"	syriancrisis_bbc__1000-01-01__timeline:2077-2083	1.000
:Event_0000013	Conflict.Attack_Attacker.actual	:Entity_EDL_0000051	syriancrisis_bbc__1000-01-01__timeline:2103-2109	1.000
:Event_0000013	Conflict.Attack_Place.actual	:Entity_EDL_0000037	syriancrisis_bbc__1000-01-01__timeline:2118-2124	1.000
:Event_0000014	type	Conflict.Attack
:Event_0000014	mention.actual	"attack"	syriancrisis_bbc__1000-01-01__timeline:3899-3904	1.000
:Event_0000014	canonical_mention.actual	"attack"	syriancrisis_bbc__1000-01-01__timeline:3899-3904	1.000
:Event_0000014	Conflict.Attack_Target.actual	:Entity_EDL_0000024	syriancrisis_bbc__1000-01-01__timeline:3795-3806	1.000
:Event_0000014	Conflict.Attack_Target.actual	:Entity_EDL_0000028	syriancrisis_bbc__1000-01-01__timeline:3816-3821	1.000
:Event_0000014	Conflict.Attack_Target.actual	:Entity_EDL_0000041	syriancrisis_bbc__1000-01-01__timeline:3823-3835	1.000
:Event_0000014	Conflict.Attack_Place.actual	:Entity_EDL_0000029	syriancrisis_bbc__1000-01-01__timeline:3959-3970	1.000
:Event_0000015	type	Conflict.Attack
:Event_0000015	mention.actual	"bombing"	syriancrisis_bbc__1000-01-01__timeline:4405-4411	1.000
:Event_0000015	canonical_mention.actual	"bombing"	syriancrisis_bbc__1000-01-01__timeline:4405-4411	1.000
:Event_0000015	Conflict.Attack_Attacker.actual	:Entity_EDL_0000014	syriancrisis_bbc__1000-01-01__timeline:4325-4329	1.000
:Event_0000016	type	Life.Die
:Event_0000016	mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:3879-3884	1.000
:Event_0000016	canonical_mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:3879-3884	1.000
:Event_0000016	Life.Die_Victim.actual	:Entity_EDL_0000024	syriancrisis_bbc__1000-01-01__timeline:3795-3806	1.000
:Event_0000016	Life.Die_Victim.actual	:Entity_EDL_0000028	syriancrisis_bbc__1000-01-01__timeline:3816-3821	1.000
:Event_0000016	Life.Die_Victim.actual	:Entity_EDL_0000041	syriancrisis_bbc__1000-01-01__timeline:3823-3835	1.000
:Event_0000016	Life.Die_Place.actual	:Entity_EDL_0000029	syriancrisis_bbc__1000-01-01__timeline:3959-3970	1.000
:Event_0000017	type	Life.Die
:Event_0000017	mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:2699-2704	1.000
:Event_0000017	canonical_mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:2699-2704	1.000
:Event_0000017	Life.Die_Victim.actual	:Entity_EDL_0000033	syriancrisis_bbc__1000-01-01__timeline:2685-2688	1.000
:Event_0000017	Life.Die_Instrument.actual	:Entity_EDL_0000042	syriancrisis_bbc__1000-01-01__timeline:2709-2713	1.000
:Event_0000018	type	Conflict.Attack
:Event_0000018	mention.actual	"massacre"	syriancrisis_bbc__1000-01-01__timeline:1219-1226	1.000
:Event_0000018	canonical_mention.actual	"massacre"	syriancrisis_bbc__1000-01-01__timeline:1219-1226	1.000
:Event_0000019	type	Conflict.Attack
:Event_0000019	mention.actual	"attack"	syriancrisis_bbc__1000-01-01__timeline:4084-4089	1.000
:Event_0000019	canonical_mention.actual	"attack"	syriancrisis_bbc__1000-01-01__timeline:4084-4089	1.000
:Event_0000019	Conflict.Attack_Target.actual	:Entity_EDL_0000002	syriancrisis_bbc__1000-01-01__timeline:4006-4021	1.000
:Event_0000020	type	Conflict.Attack
:Event_0000020	mention.actual	"massacre"	syriancrisis_bbc__1000-01-01__timeline:707-714	1.000
:Event_0000020	canonical_mention.actual	"massacre"	syriancrisis_bbc__1000-01-01__timeline:707-714	1.000
:Event_0000020	Conflict.Attack_Place.actual	:Entity_EDL_0000010	syriancrisis_bbc__1000-01-01__timeline:630-637	1.000
:Event_0000020	Conflict.Attack_Target.actual	:Entity_EDL_0000025	syriancrisis_bbc__1000-01-01__timeline:724-732	1.000
:Event_0000021	type	Conflict.Attack
:Event_0000021	mention.actual	"massacres"	syriancrisis_bbc__1000-01-01__timeline:2563-2571	1.000
:Event_0000021	canonical_mention.actual	"massacres"	syriancrisis_bbc__1000-01-01__timeline:2563-2571	1.000
:Event_0000021	Conflict.Attack_Place.actual	:Entity_EDL_0000004	syriancrisis_bbc__1000-01-01__timeline:2484-2490	1.000
:Event_0000021	Conflict.Attack_Place.actual	:Entity_EDL_0000038	syriancrisis_bbc__1000-01-01__timeline:2576-2580	1.000
:Event_0000022	type	Conflict.Attack
:Event_0000022	mention.actual	"attacks"	syriancrisis_bbc__1000-01-01__timeline:2382-2388	1.000
:Event_0000022	canonical_mention.actual	"attacks"	syriancrisis_bbc__1000-01-01__timeline:2382-2388	1.000
:Event_0000022	Conflict.Attack_Attacker.actual	:Entity_EDL_0000018	syriancrisis_bbc__1000-01-01__timeline:2326-2331	1.000
:Event_0000023	type	Life.Die
:Event_0000023	mention.actual	"suicide"	syriancrisis_bbc__1000-01-01__timeline:3891-3897	1.000
:Event_0000023	canonical_mention.actual	"suicide"	syriancrisis_bbc__1000-01-01__timeline:3891-3897	1.000
:Event_0000023	Life.Die_Place.actual	:Entity_EDL_0000029	syriancrisis_bbc__1000-01-01__timeline:3959-3970	1.000
:Event_0000024	type	Life.Die
:Event_0000024	mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:125-130	1.000
:Event_0000024	canonical_mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:125-130	1.000
:Event_0000024	Life.Die_Place.actual	:Entity_EDL_0000009	syriancrisis_bbc__1000-01-01__timeline:15-20	1.000
:Event_0000024	Life.Die_Victim.actual	:Entity_EDL_0000006	syriancrisis_bbc__1000-01-01__timeline:109-118	1.000
:Event_0000024	Life.Die_Agent.actual	:Entity_EDL_0000019	syriancrisis_bbc__1000-01-01__timeline:144-149	1.000
:Event_0000025	type	Conflict.Demonstrate
:Event_0000025	mention.actual	"uprising"	syriancrisis_bbc__1000-01-01__timeline:2585-2592	1.000
:Event_0000025	canonical_mention.actual	"uprising"	syriancrisis_bbc__1000-01-01__timeline:2585-2592	1.000
:Event_0000025	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000038	syriancrisis_bbc__1000-01-01__timeline:2576-2580	1.000
:Event_0000026	type	Conflict.Attack
:Event_0000026	mention.actual	"bombarded"	syriancrisis_bbc__1000-01-01__timeline:3390-3398	1.000
:Event_0000026	canonical_mention.actual	"bombarded"	syriancrisis_bbc__1000-01-01__timeline:3390-3398	1.000
:Event_0000026	Conflict.Attack_Instrument.actual	:Entity_EDL_0000015	syriancrisis_bbc__1000-01-01__timeline:3384-3388	1.000
:Event_0000026	Conflict.Attack_Target.actual	:Entity_EDL_0000005	syriancrisis_bbc__1000-01-01__timeline:3404-3410	1.000
:Event_0000027	type	Conflict.Attack
:Event_0000027	mention.actual	"violence"	syriancrisis_bbc__1000-01-01__timeline:1530-1537	1.000
:Event_0000027	canonical_mention.actual	"violence"	syriancrisis_bbc__1000-01-01__timeline:1530-1537	1.000
:Event_0000028	type	Contact.Meet
:Event_0000028	mention.actual	"meeting"	syriancrisis_bbc__1000-01-01__timeline:3926-3932	1.000
:Event_0000028	canonical_mention.actual	"meeting"	syriancrisis_bbc__1000-01-01__timeline:3926-3932	1.000
:Event_0000028	Contact.Meet_Place.actual	:Entity_EDL_0000029	syriancrisis_bbc__1000-01-01__timeline:3959-3970	1.000
:Event_0000029	type	Conflict.Attack
:Event_0000029	mention.actual	"shot"	syriancrisis_bbc__1000-01-01__timeline:2748-2751	1.000
:Event_0000029	canonical_mention.actual	"shot"	syriancrisis_bbc__1000-01-01__timeline:2748-2751	1.000
:Event_0000029	Conflict.Attack_Target.actual	:Entity_EDL_0000048	syriancrisis_bbc__1000-01-01__timeline:2730-2737	1.000
:Event_0000030	type	Business.Start
:Event_0000030	mention.actual	"formed"	syriancrisis_bbc__1000-01-01__timeline:331-336	1.000
:Event_0000030	canonical_mention.actual	"formed"	syriancrisis_bbc__1000-01-01__timeline:331-336	1.000
:Event_0000030	Business.Start_Agent.actual	:Entity_EDL_0000045	syriancrisis_bbc__1000-01-01__timeline:324-329	1.000
:Event_0000030	Business.Start_Organization.actual	:Entity_EDL_0000022	syriancrisis_bbc__1000-01-01__timeline:342-364	1.000
:Event_0000031	type	Life.Die
:Event_0000031	mention.actual	"deaths"	syriancrisis_bbc__1000-01-01__timeline:3269-3274	1.000
:Event_0000031	canonical_mention.actual	"deaths"	syriancrisis_bbc__1000-01-01__timeline:3269-3274	1.000
:Event_0000031	Life.Die_Victim.actual	:Entity_EDL_0000027	syriancrisis_bbc__1000-01-01__timeline:3289-3294	1.000
:Event_0000031	Life.Die_Place.actual	:Entity_EDL_0000036	syriancrisis_bbc__1000-01-01__timeline:3299-3305	1.000
:Event_0000032	type	Conflict.Attack
:Event_0000032	mention.actual	"fire"	syriancrisis_bbc__1000-01-01__timeline:2715-2718	1.000
:Event_0000032	canonical_mention.actual	"fire"	syriancrisis_bbc__1000-01-01__timeline:2715-2718	1.000
:Event_0000032	Conflict.Attack_Target.actual	:Entity_EDL_0000033	syriancrisis_bbc__1000-01-01__timeline:2685-2688	1.000
:Event_0000032	Conflict.Attack_Instrument.actual	:Entity_EDL_0000042	syriancrisis_bbc__1000-01-01__timeline:2709-2713	1.000
:Event_0000033	type	Life.Injure
:Event_0000033	mention.actual	"injured"	syriancrisis_bbc__1000-01-01__timeline:4160-4166	1.000
:Event_0000033	canonical_mention.actual	"injured"	syriancrisis_bbc__1000-01-01__timeline:4160-4166	1.000
:Event_0000033	Life.Injure_Victim.actual	:Entity_EDL_0000043	syriancrisis_bbc__1000-01-01__timeline:4107-4114	1.000
:Event_0000033	Life.Injure_Victim.actual	:Entity_EDL_0000034	syriancrisis_bbc__1000-01-01__timeline:4138-4142	1.000
:Event_0000034	type	Life.Die
:Event_0000034	mention.actual	"suicide"	syriancrisis_bbc__1000-01-01__timeline:2095-2101	1.000
:Event_0000034	canonical_mention.actual	"suicide"	syriancrisis_bbc__1000-01-01__timeline:2095-2101	1.000
:Event_0000034	Life.Die_Victim.actual	:Entity_EDL_0000051	syriancrisis_bbc__1000-01-01__timeline:2103-2109	1.000
:Event_0000034	Life.Die_Place.actual	:Entity_EDL_0000037	syriancrisis_bbc__1000-01-01__timeline:2118-2124	1.000
:Event_0000035	type	Life.Injure
:Event_0000035	mention.actual	"stabbed"	syriancrisis_bbc__1000-01-01__timeline:2777-2783	1.000
:Event_0000035	canonical_mention.actual	"stabbed"	syriancrisis_bbc__1000-01-01__timeline:2777-2783	1.000
:Event_0000035	Life.Injure_Victim.actual	:Entity_EDL_0000048	syriancrisis_bbc__1000-01-01__timeline:2730-2737	1.000
:Event_0000036	type	Movement.TransportArtifact
:Event_0000036	mention.actual	"swept in"	syriancrisis_bbc__1000-01-01__timeline:3463-3470	1.000
:Event_0000036	canonical_mention.actual	"swept in"	syriancrisis_bbc__1000-01-01__timeline:3463-3470	1.000
:Event_0000036	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000005	syriancrisis_bbc__1000-01-01__timeline:3404-3410	1.000
:Event_0000036	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000013	syriancrisis_bbc__1000-01-01__timeline:3452-3461	1.000
:Event_0000037	type	Conflict.Attack
:Event_0000037	mention.actual	"bombardment"	syriancrisis_bbc__1000-01-01__timeline:1383-1393	1.000
:Event_0000037	canonical_mention.actual	"bombardment"	syriancrisis_bbc__1000-01-01__timeline:1383-1393	1.000
:Event_0000037	Conflict.Attack_Attacker.actual	:Entity_EDL_0000023	syriancrisis_bbc__1000-01-01__timeline:1285-1290	1.000
:Event_0000038	type	Life.Die
:Event_0000038	mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:2641-2646	1.000
:Event_0000038	canonical_mention.actual	"killed"	syriancrisis_bbc__1000-01-01__timeline:2641-2646	1.000
:Event_0000038	Life.Die_Victim.actual	:Entity_EDL_0000050	syriancrisis_bbc__1000-01-01__timeline:2629-2634	1.000
:Event_0000038	Life.Die_Victim.actual	:Entity_EDL_0000001	syriancrisis_bbc__1000-01-01__timeline:2673-2680	1.000
:Event_0000039	type	Conflict.Attack
:Event_0000039	mention.actual	"shooting"	syriancrisis_bbc__1000-01-01__timeline:3474-3481	1.000
:Event_0000039	canonical_mention.actual	"shooting"	syriancrisis_bbc__1000-01-01__timeline:3474-3481	1.000
:Event_0000039	Conflict.Attack_Place.actual	:Entity_EDL_0000005	syriancrisis_bbc__1000-01-01__timeline:3404-3410	1.000
:Event_0000039	Conflict.Attack_Attacker.actual	:Entity_EDL_0000013	syriancrisis_bbc__1000-01-01__timeline:3452-3461	1.000
:Event_0000039	Conflict.Attack_Target.actual	:Entity_EDL_0000030	syriancrisis_bbc__1000-01-01__timeline:3496-3502	1.000
:Event_0000040	type	Conflict.Attack
:Event_0000040	mention.actual	"attack"	syriancrisis_bbc__1000-01-01__timeline:4175-4180	1.000
:Event_0000040	canonical_mention.actual	"attack"	syriancrisis_bbc__1000-01-01__timeline:4175-4180	1.000
:Event_0000040	Conflict.Attack_Target.actual	:Entity_EDL_0000043	syriancrisis_bbc__1000-01-01__timeline:4107-4114	1.000
:Event_0000040	Conflict.Attack_Target.actual	:Entity_EDL_0000034	syriancrisis_bbc__1000-01-01__timeline:4138-4142	1.000
:Event_0000041	type	Movement.TransportPerson
:Event_0000041	mention.actual	"fled"	syriancrisis_bbc__1000-01-01__timeline:3052-3055	1.000
:Event_0000041	canonical_mention.actual	"fled"	syriancrisis_bbc__1000-01-01__timeline:3052-3055	1.000
:Event_0000041	Movement.TransportPerson_Person.actual	:Entity_EDL_0000046	syriancrisis_bbc__1000-01-01__timeline:2987-2996	1.000
:Event_0000041	Movement.TransportPerson_Person.actual	:Entity_EDL_0000017	syriancrisis_bbc__1000-01-01__timeline:3002-3008	1.000
:Event_0000041	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000047	syriancrisis_bbc__1000-01-01__timeline:3057-3061	1.000
:Event_0000042	type	Conflict.Attack
:Event_0000042	mention.actual	"shelling"	syriancrisis_bbc__1000-01-01__timeline:1298-1305	1.000
:Event_0000042	canonical_mention.actual	"shelling"	syriancrisis_bbc__1000-01-01__timeline:1298-1305	1.000
:Event_0000042	Conflict.Attack_Attacker.actual	:Entity_EDL_0000023	syriancrisis_bbc__1000-01-01__timeline:1285-1290	1.000
:Event_0000042	Conflict.Attack_Place.actual	:Entity_EDL_0000039	syriancrisis_bbc__1000-01-01__timeline:1319-1322	1.000
