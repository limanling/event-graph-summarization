:Entity_EDL_0000000	type	Vehicle
:Entity_EDL_0000000	nominal_mention	"rig"	bpoil_washingtonpost__1000-01-01__timeline:148-150	1.0
:Entity_EDL_0000000	link	NIL000000001
:Entity_EDL_0000001	type	Person
:Entity_EDL_0000001	canonical_mention	"executive"	bpoil_washingtonpost__1000-01-01__timeline:1788-1796	1.0
:Entity_EDL_0000001	nominal_mention	"executive"	bpoil_washingtonpost__1000-01-01__timeline:1788-1796	1.0
:Entity_EDL_0000001	link	NIL000000002
:Entity_EDL_0000002	type	GeopoliticalEntity
:Entity_EDL_0000002	canonical_mention	"Louisiana"	bpoil_washingtonpost__1000-01-01__timeline:70-78	1.0
:Entity_EDL_0000002	mention	"Louisiana"	bpoil_washingtonpost__1000-01-01__timeline:70-78	1.0
:Entity_EDL_0000002	link	4331987
:Entity_EDL_0000003	type	Organization
:Entity_EDL_0000003	mention	"BP"	bpoil_washingtonpost__1000-01-01__timeline:1776-1777	1.0
:Entity_EDL_0000003	link	NIL000000003
:Entity_EDL_0000004	type	Person
:Entity_EDL_0000004	canonical_mention	"Tony Hayward"	bpoil_washingtonpost__1000-01-01__timeline:1761-1772	1.0
:Entity_EDL_0000004	mention	"Tony Hayward"	bpoil_washingtonpost__1000-01-01__timeline:1761-1772	1.0
:Entity_EDL_0000004	link	NIL000000004
:Entity_EDL_0000005	type	Person
:Entity_EDL_0000005	canonical_mention	"men"	bpoil_washingtonpost__1000-01-01__timeline:93-95	1.0
:Entity_EDL_0000005	nominal_mention	"men"	bpoil_washingtonpost__1000-01-01__timeline:93-95	1.0
:Entity_EDL_0000005	link	NIL000000005
