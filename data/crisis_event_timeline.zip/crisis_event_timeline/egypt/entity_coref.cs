:Entity_EDL_0000000	type	GeopoliticalEntity
:Entity_EDL_0000000	mention	"Egypt"	egypt_latimes__1000-01-01__timeline:1182-1186	1.0
:Entity_EDL_0000000	mention	"Egyptian"	egypt_guardian__1000-01-01__timeline:4565-4572	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_guardian__1000-01-01__timeline:1584-1588	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_guardian__1000-01-01__timeline:3127-3131	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_guardian__1000-01-01__timeline:307-311	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_latimes__1000-01-01__timeline:2986-2990	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_reuters__1000-01-01__timeline:51-55	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_latimes__1000-01-01__timeline:4495-4499	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_guardian__1000-01-01__timeline:4100-4104	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_guardian__1000-01-01__timeline:1392-1396	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_latimes__1000-01-01__timeline:543-547	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_reuters__1000-01-01__timeline:3008-3012	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_guardian__1000-01-01__timeline:3794-3798	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_guardian__1000-01-01__timeline:3902-3906	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_latimes__1000-01-01__timeline:6250-6254	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_guardian__1000-01-01__timeline:621-625	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_guardian__1000-01-01__timeline:5369-5373	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_latimes__1000-01-01__timeline:1682-1686	1.0
:Entity_EDL_0000000	mention	"Egyptian"	egypt_latimes__1000-01-01__timeline:3870-3877	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_guardian__1000-01-01__timeline:4322-4326	1.0
:Entity_EDL_0000000	mention	"Egyptians"	egypt_latimes__1000-01-01__timeline:7629-7637	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_guardian__1000-01-01__timeline:4210-4214	1.0
:Entity_EDL_0000000	mention	"Egypt"	egypt_latimes__1000-01-01__timeline:34-38	1.0
:Entity_EDL_0000000	link	357994
:Entity_EDL_0000001	type	Person
:Entity_EDL_0000001	mention	"Mubarak"	egypt_reuters__1000-01-01__timeline:1173-1179	1.0
:Entity_EDL_0000001	canonical_mention	"Mubarak"	egypt_guardian__1000-01-01__timeline:732-738	1.0
:Entity_EDL_0000001	mention	"Mubarak"	egypt_guardian__1000-01-01__timeline:732-738	1.0
:Entity_EDL_0000001	mention	"Mubarak"	egypt_reuters__1000-01-01__timeline:2006-2012	1.0
:Entity_EDL_0000001	mention	"Mubarak"	egypt_reuters__1000-01-01__timeline:2849-2855	1.0
:Entity_EDL_0000001	mention	"Mubarak"	egypt_guardian__1000-01-01__timeline:1316-1322	1.0
:Entity_EDL_0000001	mention	"Mubarak"	egypt_reuters__1000-01-01__timeline:789-795	1.0
:Entity_EDL_0000001	mention	"Mubarak"	egypt_latimes__1000-01-01__timeline:8763-8769	1.0
:Entity_EDL_0000001	mention	"Mubarak"	egypt_reuters__1000-01-01__timeline:3684-3690	1.0
:Entity_EDL_0000001	mention	"Mubarak"	egypt_ap__1000-01-01__timeline:6647-6653	1.0
:Entity_EDL_0000001	mention	"Mubarak"	egypt_ap__1000-01-01__timeline:1897-1903	1.0
:Entity_EDL_0000001	mention	"Mubarak"	egypt_guardian__1000-01-01__timeline:4739-4745	1.0
:Entity_EDL_0000001	canonical_mention	"Mubarak"	egypt_ap__1000-01-01__timeline:707-713	1.0
:Entity_EDL_0000001	mention	"Mubarak"	egypt_ap__1000-01-01__timeline:707-713	1.0
:Entity_EDL_0000001	mention	"Mubarak"	egypt_reuters__1000-01-01__timeline:2070-2076	1.0
:Entity_EDL_0000001	mention	"Mubarak"	egypt_reuters__1000-01-01__timeline:2140-2146	1.0
:Entity_EDL_0000001	link	30000327
:Entity_EDL_0000002	type	Person
:Entity_EDL_0000002	mention	"Hosni Mubarak"	egypt_guardian__1000-01-01__timeline:2788-2800	1.0
:Entity_EDL_0000002	mention	"Hosni Mubarak"	egypt_latimes__1000-01-01__timeline:1077-1089	1.0
:Entity_EDL_0000002	mention	"Hosni Mubarak"	egypt_guardian__1000-01-01__timeline:3338-3350	1.0
:Entity_EDL_0000002	mention	"Hosni Mubarak"	egypt_guardian__1000-01-01__timeline:5600-5612	1.0
:Entity_EDL_0000002	mention	"Hosni Mubarak"	egypt_latimes__1000-01-01__timeline:3100-3112	1.0
:Entity_EDL_0000002	mention	"Hosni Mubarak"	egypt_guardian__1000-01-01__timeline:1781-1793	1.0
:Entity_EDL_0000002	canonical_mention	"Hosni Mubarak"	egypt_latimes__1000-01-01__timeline:265-277	1.0
:Entity_EDL_0000002	mention	"Hosni Mubarak"	egypt_latimes__1000-01-01__timeline:265-277	1.0
:Entity_EDL_0000002	mention	"Hosni Mubarak"	egypt_latimes__1000-01-01__timeline:1978-1990	1.0
:Entity_EDL_0000002	link	NIL000000001
:Entity_EDL_0000003	type	Facility
:Entity_EDL_0000003	canonical_mention	"Tahrir Square"	egypt_latimes__1000-01-01__timeline:2728-2740	1.0
:Entity_EDL_0000003	mention	"Tahrir Square"	egypt_latimes__1000-01-01__timeline:2728-2740	1.0
:Entity_EDL_0000003	mention	"Tahrir Square"	egypt_reuters__1000-01-01__timeline:2323-2335	1.0
:Entity_EDL_0000003	mention	"Tahrir Square"	egypt_ap__1000-01-01__timeline:6543-6555	1.0
:Entity_EDL_0000003	canonical_mention	"Tahrir Square"	egypt_ap__1000-01-01__timeline:241-253	1.0
:Entity_EDL_0000003	mention	"Tahrir Square"	egypt_ap__1000-01-01__timeline:241-253	1.0
:Entity_EDL_0000003	mention	"Tahrir Square"	egypt_reuters__1000-01-01__timeline:1966-1978	1.0
:Entity_EDL_0000003	mention	"Tahrir Square"	egypt_latimes__1000-01-01__timeline:8686-8698	1.0
:Entity_EDL_0000003	mention	"Tahrir Square"	egypt_reuters__1000-01-01__timeline:2627-2639	1.0
:Entity_EDL_0000003	mention	"Tahrir Square"	egypt_guardian__1000-01-01__timeline:5460-5472	1.0
:Entity_EDL_0000003	link	NIL000000002
:Entity_EDL_0000004	type	Person
:Entity_EDL_0000004	mention	"Morsi"	egypt_ap__1000-01-01__timeline:8909-8913	1.0
:Entity_EDL_0000004	mention	"Morsi"	egypt_ap__1000-01-01__timeline:10238-10242	1.0
:Entity_EDL_0000004	mention	"Morsi"	egypt_ap__1000-01-01__timeline:9217-9221	1.0
:Entity_EDL_0000004	mention	"Morsi"	egypt_ap__1000-01-01__timeline:2611-2615	1.0
:Entity_EDL_0000004	mention	"Morsi"	egypt_ap__1000-01-01__timeline:8666-8670	1.0
:Entity_EDL_0000004	link	NIL000000003
:Entity_EDL_0000005	type	GeopoliticalEntity
:Entity_EDL_0000005	mention	"Cairo"	egypt_guardian__1000-01-01__timeline:4378-4382	1.0
:Entity_EDL_0000005	mention	"Cairo"	egypt_guardian__1000-01-01__timeline:5934-5938	1.0
:Entity_EDL_0000005	mention	"Cairo"	egypt_guardian__1000-01-01__timeline:3698-3702	1.0
:Entity_EDL_0000005	mention	"Cairo"	egypt_guardian__1000-01-01__timeline:3047-3051	1.0
:Entity_EDL_0000005	canonical_mention	"Cairo"	egypt_guardian__1000-01-01__timeline:1027-1031	1.0
:Entity_EDL_0000005	mention	"Cairo"	egypt_guardian__1000-01-01__timeline:1027-1031	1.0
:Entity_EDL_0000005	link	360630
:Entity_EDL_0000006	type	GeopoliticalEntity
:Entity_EDL_0000006	mention	"Cairo"	egypt_ap__1000-01-01__timeline:1545-1549	1.0
:Entity_EDL_0000006	mention	"Cairo"	egypt_ap__1000-01-01__timeline:387-391	1.0
:Entity_EDL_0000006	mention	"Cairo"	egypt_ap__1000-01-01__timeline:10678-10682	1.0
:Entity_EDL_0000006	mention	"Cairo"	egypt_ap__1000-01-01__timeline:7692-7696	1.0
:Entity_EDL_0000006	link	360630
:Entity_EDL_0000007	type	Person
:Entity_EDL_0000007	mention	"Mohamed Morsi"	egypt_latimes__1000-01-01__timeline:3889-3901	1.0
:Entity_EDL_0000007	mention	"Mohamed Morsi"	egypt_latimes__1000-01-01__timeline:3809-3821	1.0
:Entity_EDL_0000007	canonical_mention	"Mohamed Morsi"	egypt_latimes__1000-01-01__timeline:2960-2972	1.0
:Entity_EDL_0000007	mention	"Mohamed Morsi"	egypt_latimes__1000-01-01__timeline:2960-2972	1.0
:Entity_EDL_0000007	link	NIL000000004
:Entity_EDL_0000008	type	Facility
:Entity_EDL_0000008	mention	"Tahrir Square"	egypt_guardian__1000-01-01__timeline:2625-2637	1.0
:Entity_EDL_0000008	mention	"Tahrir Square"	egypt_guardian__1000-01-01__timeline:3098-3110	1.0
:Entity_EDL_0000008	mention	"Tahrir Square"	egypt_guardian__1000-01-01__timeline:2507-2519	1.0
:Entity_EDL_0000008	link	NIL000000005
:Entity_EDL_0000009	type	GeopoliticalEntity
:Entity_EDL_0000009	mention	"Israel"	egypt_guardian__1000-01-01__timeline:4891-4896	1.0
:Entity_EDL_0000009	mention	"Israel"	egypt_guardian__1000-01-01__timeline:5338-5343	1.0
:Entity_EDL_0000009	link	294640
:Entity_EDL_0000010	type	Location
:Entity_EDL_0000010	mention	"Gaza"	egypt_guardian__1000-01-01__timeline:5143-5146	1.0
:Entity_EDL_0000010	mention	"Gaza"	egypt_guardian__1000-01-01__timeline:5063-5066	1.0
:Entity_EDL_0000010	link	281133
:Entity_EDL_0000011	type	Organization
:Entity_EDL_0000011	canonical_mention	"air force"	egypt_reuters__1000-01-01__timeline:230-238	1.0
:Entity_EDL_0000011	mention	"air force"	egypt_reuters__1000-01-01__timeline:230-238	1.0
:Entity_EDL_0000011	mention	"air force"	egypt_reuters__1000-01-01__timeline:663-671	1.0
:Entity_EDL_0000011	link	NIL000000006
:Entity_EDL_0000012	type	Person
:Entity_EDL_0000012	canonical_mention	"Adly Mansour"	egypt_ap__1000-01-01__timeline:10265-10276	1.0
:Entity_EDL_0000012	mention	"Adly Mansour"	egypt_ap__1000-01-01__timeline:10265-10276	1.0
:Entity_EDL_0000012	mention	"Adly Mansour"	egypt_ap__1000-01-01__timeline:10369-10380	1.0
:Entity_EDL_0000012	link	NIL000000007
:Entity_EDL_0000013	type	Person
:Entity_EDL_0000013	canonical_mention	"protesters"	egypt_reuters__1000-01-01__timeline:2187-2196	1.0
:Entity_EDL_0000013	nominal_mention	"protesters"	egypt_reuters__1000-01-01__timeline:2187-2196	1.0
:Entity_EDL_0000013	canonical_mention	"protesters"	egypt_latimes__1000-01-01__timeline:1135-1144	1.0
:Entity_EDL_0000013	nominal_mention	"protesters"	egypt_latimes__1000-01-01__timeline:1135-1144	1.0
:Entity_EDL_0000013	link	NIL000000008
:Entity_EDL_0000014	type	Person
:Entity_EDL_0000014	canonical_mention	"Ahmed Shafik"	egypt_reuters__1000-01-01__timeline:683-694	1.0
:Entity_EDL_0000014	mention	"Ahmed Shafik"	egypt_reuters__1000-01-01__timeline:683-694	1.0
:Entity_EDL_0000014	canonical_mention	"Ahmed Shafiq"	egypt_ap__1000-01-01__timeline:2186-2197	1.0
:Entity_EDL_0000014	mention	"Ahmed Shafiq"	egypt_ap__1000-01-01__timeline:2186-2197	1.0
:Entity_EDL_0000014	link	NIL000000009
:Entity_EDL_0000015	type	Person
:Entity_EDL_0000015	canonical_mention	"soldiers"	egypt_latimes__1000-01-01__timeline:3289-3296	1.0
:Entity_EDL_0000015	nominal_mention	"soldiers"	egypt_latimes__1000-01-01__timeline:3289-3296	1.0
:Entity_EDL_0000015	canonical_mention	"soldiers"	egypt_guardian__1000-01-01__timeline:2609-2616	1.0
:Entity_EDL_0000015	nominal_mention	"soldiers"	egypt_guardian__1000-01-01__timeline:2609-2616	1.0
:Entity_EDL_0000015	link	NIL000000010
:Entity_EDL_0000016	type	Person
:Entity_EDL_0000016	mention	"Egyptians"	egypt_guardian__1000-01-01__timeline:5441-5449	1.0
:Entity_EDL_0000016	mention	"Egyptians"	egypt_guardian__1000-01-01__timeline:5717-5725	1.0
:Entity_EDL_0000016	link	357994
:Entity_EDL_0000017	type	Person
:Entity_EDL_0000017	canonical_mention	"Troops"	egypt_ap__1000-01-01__timeline:1505-1510	1.0
:Entity_EDL_0000017	nominal_mention	"Troops"	egypt_ap__1000-01-01__timeline:1505-1510	1.0
:Entity_EDL_0000017	canonical_mention	"troops"	egypt_reuters__1000-01-01__timeline:357-362	1.0
:Entity_EDL_0000017	nominal_mention	"troops"	egypt_reuters__1000-01-01__timeline:357-362	1.0
:Entity_EDL_0000017	link	NIL000000011
:Entity_EDL_0000018	type	Person
:Entity_EDL_0000018	canonical_mention	"1,000"	egypt_guardian__1000-01-01__timeline:3735-3739	1.0
:Entity_EDL_0000018	pronominal_mention	"1,000"	egypt_guardian__1000-01-01__timeline:3735-3739	1.0
:Entity_EDL_0000018	link	NIL000000012
:Entity_EDL_0000019	type	GeopoliticalEntity
:Entity_EDL_0000019	nominal_mention	"nation"	egypt_latimes__1000-01-01__timeline:3364-3369	1.0
:Entity_EDL_0000019	link	NIL000000013
:Entity_EDL_0000020	type	Facility
:Entity_EDL_0000020	canonical_mention	"church"	egypt_ap__1000-01-01__timeline:1558-1563	1.0
:Entity_EDL_0000020	nominal_mention	"church"	egypt_ap__1000-01-01__timeline:1558-1563	1.0
:Entity_EDL_0000020	link	NIL000000014
:Entity_EDL_0000021	type	GeopoliticalEntity
:Entity_EDL_0000021	nominal_mention	"government"	egypt_latimes__1000-01-01__timeline:5957-5966	1.0
:Entity_EDL_0000021	link	NIL000000015
:Entity_EDL_0000022	type	Person
:Entity_EDL_0000022	canonical_mention	"Millions"	egypt_ap__1000-01-01__timeline:8829-8836	1.0
:Entity_EDL_0000022	nominal_mention	"Millions"	egypt_ap__1000-01-01__timeline:8829-8836	1.0
:Entity_EDL_0000022	link	NIL000000016
:Entity_EDL_0000023	type	Person
:Entity_EDL_0000023	canonical_mention	"ambassador"	egypt_guardian__1000-01-01__timeline:5355-5364	1.0
:Entity_EDL_0000023	nominal_mention	"ambassador"	egypt_guardian__1000-01-01__timeline:5355-5364	1.0
:Entity_EDL_0000023	link	NIL000000017
:Entity_EDL_0000024	type	Organization
:Entity_EDL_0000024	nominal_mention	"parliament"	egypt_reuters__1000-01-01__timeline:4300-4309	1.0
:Entity_EDL_0000024	link	NIL000000018
:Entity_EDL_0000025	type	GeopoliticalEntity
:Entity_EDL_0000025	nominal_mention	"Egyptians"	egypt_ap__1000-01-01__timeline:11-19	1.0
:Entity_EDL_0000025	link	NIL000000019
:Entity_EDL_0000026	type	Organization
:Entity_EDL_0000026	nominal_mention	"military"	egypt_ap__1000-01-01__timeline:9446-9453	1.0
:Entity_EDL_0000026	link	NIL000000020
:Entity_EDL_0000027	type	Person
:Entity_EDL_0000027	canonical_mention	"chief"	egypt_latimes__1000-01-01__timeline:691-695	1.0
:Entity_EDL_0000027	nominal_mention	"chief"	egypt_latimes__1000-01-01__timeline:691-695	1.0
:Entity_EDL_0000027	link	NIL000000021
:Entity_EDL_0000028	type	GeopoliticalEntity
:Entity_EDL_0000028	canonical_mention	"Gaza"	egypt_guardian__1000-01-01__timeline:4902-4905	1.0
:Entity_EDL_0000028	mention	"Gaza"	egypt_guardian__1000-01-01__timeline:4902-4905	1.0
:Entity_EDL_0000028	link	281133
:Entity_EDL_0000029	type	Person
:Entity_EDL_0000029	nominal_mention	"Islamists"	egypt_ap__1000-01-01__timeline:5441-5449	1.0
:Entity_EDL_0000029	link	NIL000000022
:Entity_EDL_0000030	type	Organization
:Entity_EDL_0000030	canonical_mention	"house"	egypt_ap__1000-01-01__timeline:2408-2412	1.0
:Entity_EDL_0000030	nominal_mention	"house"	egypt_ap__1000-01-01__timeline:2408-2412	1.0
:Entity_EDL_0000030	link	NIL000000023
:Entity_EDL_0000031	type	Person
:Entity_EDL_0000031	canonical_mention	"more"	egypt_guardian__1000-01-01__timeline:32-35	1.0
:Entity_EDL_0000031	nominal_mention	"more"	egypt_guardian__1000-01-01__timeline:32-35	1.0
:Entity_EDL_0000031	link	NIL000000024
:Entity_EDL_0000032	type	Person
:Entity_EDL_0000032	canonical_mention	"Christians"	egypt_ap__1000-01-01__timeline:1531-1540	1.0
:Entity_EDL_0000032	nominal_mention	"Christians"	egypt_ap__1000-01-01__timeline:1531-1540	1.0
:Entity_EDL_0000032	link	NIL000000025
:Entity_EDL_0000033	type	Person
:Entity_EDL_0000033	pronominal_mention	"half"	egypt_ap__1000-01-01__timeline:9040-9043	1.0
:Entity_EDL_0000033	link	NIL000000026
:Entity_EDL_0000034	type	Facility
:Entity_EDL_0000034	nominal_mention	"cathedral"	egypt_ap__1000-01-01__timeline:7755-7763	1.0
:Entity_EDL_0000034	link	NIL000000027
:Entity_EDL_0000035	type	Organization
:Entity_EDL_0000035	nominal_mention	"military"	egypt_ap__1000-01-01__timeline:3378-3385	0.000
:Entity_EDL_0000035	link	NIL000000028
:Entity_EDL_0000036	type	Facility
:Entity_EDL_0000036	nominal_mention	"streets"	egypt_ap__1000-01-01__timeline:8863-8869	0.000
:Entity_EDL_0000036	link	NIL000000029
:Entity_EDL_0000037	type	GeopoliticalEntity
:Entity_EDL_0000037	canonical_mention	"Egyptians"	egypt_ap__1000-01-01__timeline:1023-1031	1.0
:Entity_EDL_0000037	mention	"Egyptians"	egypt_ap__1000-01-01__timeline:1023-1031	1.0
:Entity_EDL_0000037	link	357994
:Entity_EDL_0000038	type	Person
:Entity_EDL_0000038	pronominal_mention	"70"	egypt_guardian__1000-01-01__timeline:42-43	1.0
:Entity_EDL_0000038	link	NIL000000030
:Entity_EDL_0000039	type	Person
:Entity_EDL_0000039	canonical_mention	"officer"	egypt_guardian__1000-01-01__timeline:6265-6271	1.0
:Entity_EDL_0000039	nominal_mention	"officer"	egypt_guardian__1000-01-01__timeline:6265-6271	1.0
:Entity_EDL_0000039	link	NIL000000031
:Entity_EDL_0000040	type	Person
:Entity_EDL_0000040	nominal_mention	"wife"	egypt_guardian__1000-01-01__timeline:3150-3153	1.0
:Entity_EDL_0000040	link	NIL000000032
:Entity_EDL_0000041	type	Person
:Entity_EDL_0000041	canonical_mention	"900"	egypt_ap__1000-01-01__timeline:446-448	1.0
:Entity_EDL_0000041	pronominal_mention	"900"	egypt_ap__1000-01-01__timeline:446-448	1.0
:Entity_EDL_0000041	link	NIL000000033
:Entity_EDL_0000042	type	Facility
:Entity_EDL_0000042	canonical_mention	"cathedral"	egypt_ap__1000-01-01__timeline:7542-7550	1.0
:Entity_EDL_0000042	nominal_mention	"cathedral"	egypt_ap__1000-01-01__timeline:7542-7550	1.0
:Entity_EDL_0000042	link	NIL000000034
:Entity_EDL_0000044	type	Person
:Entity_EDL_0000044	nominal_mention	"protesters"	egypt_guardian__1000-01-01__timeline:2639-2648	1.0
:Entity_EDL_0000044	link	NIL000000036
:Entity_EDL_0000045	type	Organization
:Entity_EDL_0000045	canonical_mention	"it"	egypt_ap__1000-01-01__timeline:3099-3100	1.0
:Entity_EDL_0000045	pronominal_mention	"it"	egypt_ap__1000-01-01__timeline:3099-3100	1.0
:Entity_EDL_0000045	link	NIL000000037
:Entity_EDL_0000046	type	GeopoliticalEntity
:Entity_EDL_0000046	canonical_mention	"Alexandria"	egypt_guardian__1000-01-01__timeline:98-107	1.0
:Entity_EDL_0000046	mention	"Alexandria"	egypt_guardian__1000-01-01__timeline:98-107	1.0
:Entity_EDL_0000046	link	361058
:Entity_EDL_0000047	type	Person
:Entity_EDL_0000047	canonical_mention	"His"	egypt_latimes__1000-01-01__timeline:2579-2581	1.0
:Entity_EDL_0000047	pronominal_mention	"His"	egypt_latimes__1000-01-01__timeline:2579-2581	1.0
:Entity_EDL_0000047	link	NIL000000038
:Entity_EDL_0000048	type	Organization
:Entity_EDL_0000048	canonical_mention	"IMF"	egypt_reuters__1000-01-01__timeline:3036-3038	1.0
:Entity_EDL_0000048	nominal_mention	"IMF"	egypt_reuters__1000-01-01__timeline:3036-3038	1.0
:Entity_EDL_0000048	link	20000126
:Entity_EDL_0000049	type	Person
:Entity_EDL_0000049	canonical_mention	"Thousands"	egypt_guardian__1000-01-01__timeline:480-488	1.0
:Entity_EDL_0000049	pronominal_mention	"Thousands"	egypt_guardian__1000-01-01__timeline:480-488	1.0
:Entity_EDL_0000049	link	NIL000000039
:Entity_EDL_0000050	type	Organization
:Entity_EDL_0000050	canonical_mention	"groups"	egypt_latimes__1000-01-01__timeline:2778-2783	1.0
:Entity_EDL_0000050	nominal_mention	"groups"	egypt_latimes__1000-01-01__timeline:2778-2783	1.0
:Entity_EDL_0000050	link	NIL000000040
:Entity_EDL_0000051	type	Facility
:Entity_EDL_0000051	nominal_mention	"hospital"	egypt_latimes__1000-01-01__timeline:2384-2391	1.0
:Entity_EDL_0000051	link	NIL000000041
:Entity_EDL_0000052	type	Vehicle
:Entity_EDL_0000052	canonical_mention	"tanks"	egypt_reuters__1000-01-01__timeline:368-372	1.0
:Entity_EDL_0000052	nominal_mention	"tanks"	egypt_reuters__1000-01-01__timeline:368-372	1.0
:Entity_EDL_0000052	link	NIL000000042
:Entity_EDL_0000054	type	Facility
:Entity_EDL_0000054	canonical_mention	"street"	egypt_ap__1000-01-01__timeline:5517-5522	1.0
:Entity_EDL_0000054	nominal_mention	"street"	egypt_ap__1000-01-01__timeline:5517-5522	1.0
:Entity_EDL_0000054	link	NIL000000044
:Entity_EDL_0000055	type	Person
:Entity_EDL_0000055	canonical_mention	"Demonstrators"	egypt_latimes__1000-01-01__timeline:8651-8663	1.0
:Entity_EDL_0000055	nominal_mention	"Demonstrators"	egypt_latimes__1000-01-01__timeline:8651-8663	1.0
:Entity_EDL_0000055	link	NIL000000045
:Entity_EDL_0000056	type	Person
:Entity_EDL_0000056	canonical_mention	"commander"	egypt_reuters__1000-01-01__timeline:240-248	1.0
:Entity_EDL_0000056	nominal_mention	"commander"	egypt_reuters__1000-01-01__timeline:240-248	1.0
:Entity_EDL_0000056	link	NIL000000046
:Entity_EDL_0000057	type	Facility
:Entity_EDL_0000057	canonical_mention	"stadium"	egypt_ap__1000-01-01__timeline:6866-6872	1.0
:Entity_EDL_0000057	nominal_mention	"stadium"	egypt_ap__1000-01-01__timeline:6866-6872	1.0
:Entity_EDL_0000057	link	NIL000000047
:Entity_EDL_0000058	type	Location
:Entity_EDL_0000058	canonical_mention	"places"	egypt_ap__1000-01-01__timeline:6683-6688	1.0
:Entity_EDL_0000058	nominal_mention	"places"	egypt_ap__1000-01-01__timeline:6683-6688	1.0
:Entity_EDL_0000058	link	NIL000000048
:Entity_EDL_0000059	type	Person
:Entity_EDL_0000059	nominal_mention	"people"	egypt_ap__1000-01-01__timeline:9031-9036	1.0
:Entity_EDL_0000059	link	NIL000000049
:Entity_EDL_0000060	type	Person
:Entity_EDL_0000060	canonical_mention	"Kamal al-Ganzouri"	egypt_reuters__1000-01-01__timeline:2747-2763	1.0
:Entity_EDL_0000060	mention	"Kamal al-Ganzouri"	egypt_reuters__1000-01-01__timeline:2747-2763	1.0
:Entity_EDL_0000060	link	NIL000000050
:Entity_EDL_0000061	type	Person
:Entity_EDL_0000061	nominal_mention	"protesters"	egypt_guardian__1000-01-01__timeline:5282-5291	1.0
:Entity_EDL_0000061	link	NIL000000051
:Entity_EDL_0000062	type	Organization
:Entity_EDL_0000062	nominal_mention	"government"	egypt_reuters__1000-01-01__timeline:628-637	1.0
:Entity_EDL_0000062	link	NIL000000052
:Entity_EDL_0000063	type	Person
:Entity_EDL_0000063	nominal_mention	"protesters"	egypt_ap__1000-01-01__timeline:932-941	1.0
:Entity_EDL_0000063	link	NIL000000053
:Entity_EDL_0000064	type	Person
:Entity_EDL_0000064	canonical_mention	"thousands"	egypt_ap__1000-01-01__timeline:6516-6524	1.0
:Entity_EDL_0000064	pronominal_mention	"thousands"	egypt_ap__1000-01-01__timeline:6516-6524	1.0
:Entity_EDL_0000064	link	NIL000000054
:Entity_EDL_0000065	type	GeopoliticalEntity
:Entity_EDL_0000065	canonical_mention	"nation"	egypt_ap__1000-01-01__timeline:10401-10406	1.0
:Entity_EDL_0000065	nominal_mention	"nation"	egypt_ap__1000-01-01__timeline:10401-10406	1.0
:Entity_EDL_0000065	link	NIL000000055
:Entity_EDL_0000066	type	Person
:Entity_EDL_0000066	canonical_mention	"24"	egypt_guardian__1000-01-01__timeline:5963-5964	1.0
:Entity_EDL_0000066	nominal_mention	"24"	egypt_guardian__1000-01-01__timeline:5963-5964	1.0
:Entity_EDL_0000066	link	NIL000000056
:Entity_EDL_0000067	type	Person
:Entity_EDL_0000067	canonical_mention	"defendants"	egypt_latimes__1000-01-01__timeline:7684-7693	1.0
:Entity_EDL_0000067	nominal_mention	"defendants"	egypt_latimes__1000-01-01__timeline:7684-7693	1.0
:Entity_EDL_0000067	link	NIL000000057
:Entity_EDL_0000068	type	Person
:Entity_EDL_0000068	nominal_mention	"generals"	egypt_ap__1000-01-01__timeline:1733-1740	1.0
:Entity_EDL_0000068	link	NIL000000058
:Entity_EDL_0000069	type	Organization
:Entity_EDL_0000069	nominal_mention	"military"	egypt_reuters__1000-01-01__timeline:1494-1501	1.0
:Entity_EDL_0000069	link	NIL000000059
:Entity_EDL_0000070	type	Person
:Entity_EDL_0000070	nominal_mention	"they"	egypt_ap__1000-01-01__timeline:3894-3897	1.0
:Entity_EDL_0000070	link	NIL000000060
:Entity_EDL_0000071	type	Person
:Entity_EDL_0000071	nominal_mention	"Protesters"	egypt_latimes__1000-01-01__timeline:2690-2699	1.0
:Entity_EDL_0000071	link	NIL000000061
:Entity_EDL_0000072	type	Facility
:Entity_EDL_0000072	canonical_mention	"newsroom"	egypt_ap__1000-01-01__timeline:10145-10152	1.0
:Entity_EDL_0000072	nominal_mention	"newsroom"	egypt_ap__1000-01-01__timeline:10145-10152	1.0
:Entity_EDL_0000072	link	NIL000000062
:Entity_EDL_0000073	type	Person
:Entity_EDL_0000073	canonical_mention	"police"	egypt_guardian__1000-01-01__timeline:3814-3819	1.0
:Entity_EDL_0000073	nominal_mention	"police"	egypt_guardian__1000-01-01__timeline:3814-3819	1.0
:Entity_EDL_0000073	link	NIL000000063
:Entity_EDL_0000074	type	Person
:Entity_EDL_0000074	pronominal_mention	"Thousands"	egypt_reuters__1000-01-01__timeline:2578-2586	1.0
:Entity_EDL_0000074	link	NIL000000064
:Entity_EDL_0000075	type	Person
:Entity_EDL_0000075	canonical_mention	"third"	egypt_ap__1000-01-01__timeline:2446-2450	1.0
:Entity_EDL_0000075	nominal_mention	"third"	egypt_ap__1000-01-01__timeline:2446-2450	1.0
:Entity_EDL_0000075	link	NIL000000065
:Entity_EDL_0000076	type	Person
:Entity_EDL_0000076	nominal_mention	"protesters"	egypt_ap__1000-01-01__timeline:10664-10673	1.0
:Entity_EDL_0000076	link	NIL000000066
:Entity_EDL_0000077	type	Facility
:Entity_EDL_0000077	canonical_mention	"embassy"	egypt_guardian__1000-01-01__timeline:5381-5387	1.0
:Entity_EDL_0000077	nominal_mention	"embassy"	egypt_guardian__1000-01-01__timeline:5381-5387	1.0
:Entity_EDL_0000077	link	NIL000000067
:Entity_EDL_0000078	type	Organization
:Entity_EDL_0000078	nominal_mention	"parliament"	egypt_ap__1000-01-01__timeline:2949-2958	1.0
:Entity_EDL_0000078	link	NIL000000068
:Entity_EDL_0000079	type	Person
:Entity_EDL_0000079	canonical_mention	"soldiers"	egypt_ap__1000-01-01__timeline:10118-10125	1.0
:Entity_EDL_0000079	nominal_mention	"soldiers"	egypt_ap__1000-01-01__timeline:10118-10125	1.0
:Entity_EDL_0000079	link	NIL000000069
:Entity_EDL_0000080	type	Person
:Entity_EDL_0000080	canonical_mention	"president"	egypt_reuters__1000-01-01__timeline:106-114	1.0
:Entity_EDL_0000080	nominal_mention	"president"	egypt_reuters__1000-01-01__timeline:106-114	1.0
:Entity_EDL_0000080	link	NIL000000070
:Entity_EDL_0000081	type	Person
:Entity_EDL_0000081	pronominal_mention	"he"	egypt_latimes__1000-01-01__timeline:2321-2322	1.0
:Entity_EDL_0000081	link	NIL000000071
:Entity_EDL_0000082	type	Organization
:Entity_EDL_0000082	canonical_mention	"institutions"	egypt_latimes__1000-01-01__timeline:7659-7670	1.0
:Entity_EDL_0000082	nominal_mention	"institutions"	egypt_latimes__1000-01-01__timeline:7659-7670	1.0
:Entity_EDL_0000082	link	NIL000000072
:Entity_EDL_0000083	type	Facility
:Entity_EDL_0000083	canonical_mention	"home"	egypt_ap__1000-01-01__timeline:8464-8467	1.0
:Entity_EDL_0000083	nominal_mention	"home"	egypt_ap__1000-01-01__timeline:8464-8467	1.0
:Entity_EDL_0000083	link	NIL000000073
:Entity_EDL_0000084	type	GeopoliticalEntity
:Entity_EDL_0000084	canonical_mention	"Port Said"	egypt_latimes__1000-01-01__timeline:5672-5680	1.0
:Entity_EDL_0000084	mention	"Port Said"	egypt_latimes__1000-01-01__timeline:5672-5680	1.0
:Entity_EDL_0000084	link	358619
:Entity_EDL_0000085	type	Facility
:Entity_EDL_0000085	canonical_mention	"building"	egypt_ap__1000-01-01__timeline:7837-7844	1.0
:Entity_EDL_0000085	nominal_mention	"building"	egypt_ap__1000-01-01__timeline:7837-7844	1.0
:Entity_EDL_0000085	link	NIL000000074
:Entity_EDL_0000086	type	Person
:Entity_EDL_0000086	canonical_mention	"opponents"	egypt_ap__1000-01-01__timeline:4412-4420	1.0
:Entity_EDL_0000086	nominal_mention	"opponents"	egypt_ap__1000-01-01__timeline:4412-4420	1.0
:Entity_EDL_0000086	link	NIL000000075
:Entity_EDL_0000087	type	Location
:Entity_EDL_0000087	canonical_mention	"outside"	egypt_ap__1000-01-01__timeline:7681-7687	1.0
:Entity_EDL_0000087	nominal_mention	"outside"	egypt_ap__1000-01-01__timeline:7681-7687	1.0
:Entity_EDL_0000087	link	NIL000000076
:Entity_EDL_0000088	type	Person
:Entity_EDL_0000088	pronominal_mention	"Thousands"	egypt_reuters__1000-01-01__timeline:1945-1953	1.0
:Entity_EDL_0000088	link	NIL000000077
:Entity_EDL_0000089	type	Person
:Entity_EDL_0000089	nominal_mention	"protesters"	egypt_ap__1000-01-01__timeline:1685-1694	1.0
:Entity_EDL_0000089	link	NIL000000078
:Entity_EDL_0000090	type	Person
:Entity_EDL_0000090	canonical_mention	"ElBaradei"	egypt_ap__1000-01-01__timeline:10845-10853	1.0
:Entity_EDL_0000090	mention	"ElBaradei"	egypt_ap__1000-01-01__timeline:10845-10853	1.0
:Entity_EDL_0000090	link	NIL000000079
:Entity_EDL_0000091	type	Person
:Entity_EDL_0000091	canonical_mention	"civilians"	egypt_latimes__1000-01-01__timeline:3343-3351	1.0
:Entity_EDL_0000091	nominal_mention	"civilians"	egypt_latimes__1000-01-01__timeline:3343-3351	1.0
:Entity_EDL_0000091	link	NIL000000080
:Entity_EDL_0000092	type	Person
:Entity_EDL_0000092	nominal_mention	"activists"	egypt_latimes__1000-01-01__timeline:6718-6726	1.0
:Entity_EDL_0000092	link	NIL000000081
:Entity_EDL_0000093	type	GeopoliticalEntity
:Entity_EDL_0000093	nominal_mention	"city"	egypt_ap__1000-01-01__timeline:5855-5858	1.0
:Entity_EDL_0000093	link	NIL000000082
:Entity_EDL_0000094	type	Facility
:Entity_EDL_0000094	canonical_mention	"street"	egypt_guardian__1000-01-01__timeline:413-418	1.0
:Entity_EDL_0000094	nominal_mention	"street"	egypt_guardian__1000-01-01__timeline:413-418	1.0
:Entity_EDL_0000094	link	NIL000000083
:Entity_EDL_0000095	type	Person
:Entity_EDL_0000095	nominal_mention	"Shiites"	egypt_ap__1000-01-01__timeline:8447-8453	1.0
:Entity_EDL_0000095	link	NIL000000084
:Entity_EDL_0000096	type	Facility
:Entity_EDL_0000096	mention	"Supreme Constitutional Court"	egypt_ap__1000-01-01__timeline:5116-5143	1.0
:Entity_EDL_0000096	link	NIL000000085
:Entity_EDL_0000097	type	Person
:Entity_EDL_0000097	canonical_mention	"president"	egypt_guardian__1000-01-01__timeline:4574-4582	1.0
:Entity_EDL_0000097	nominal_mention	"president"	egypt_guardian__1000-01-01__timeline:4574-4582	1.0
:Entity_EDL_0000097	link	NIL000000086
:Entity_EDL_0000098	type	Person
:Entity_EDL_0000098	canonical_mention	"50"	egypt_latimes__1000-01-01__timeline:5730-5731	1.0
:Entity_EDL_0000098	nominal_mention	"50"	egypt_latimes__1000-01-01__timeline:5730-5731	1.0
:Entity_EDL_0000098	link	NIL000000087
:Entity_EDL_0000099	type	Organization
:Entity_EDL_0000099	canonical_mention	"chamber"	egypt_latimes__1000-01-01__timeline:3631-3637	1.0
:Entity_EDL_0000099	nominal_mention	"chamber"	egypt_latimes__1000-01-01__timeline:3631-3637	1.0
:Entity_EDL_0000099	link	NIL000000088
:Entity_EDL_0000100	type	Person
:Entity_EDL_0000100	canonical_mention	"Essam Sharaf"	egypt_reuters__1000-01-01__timeline:1534-1545	1.0
:Entity_EDL_0000100	mention	"Essam Sharaf"	egypt_reuters__1000-01-01__timeline:1534-1545	1.0
:Entity_EDL_0000100	link	NIL000000089
:Entity_EDL_0000101	type	GeopoliticalEntity
:Entity_EDL_0000101	canonical_mention	"Syria"	egypt_ap__1000-01-01__timeline:8627-8631	1.0
:Entity_EDL_0000101	mention	"Syria"	egypt_ap__1000-01-01__timeline:8627-8631	1.0
:Entity_EDL_0000101	link	163843
:Entity_EDL_0000102	type	GeopoliticalEntity
:Entity_EDL_0000102	canonical_mention	"cities"	egypt_reuters__1000-01-01__timeline:379-384	1.0
:Entity_EDL_0000102	nominal_mention	"cities"	egypt_reuters__1000-01-01__timeline:379-384	1.0
:Entity_EDL_0000102	link	NIL000000090
:Entity_EDL_0000103	type	Person
:Entity_EDL_0000103	nominal_mention	"Christians"	egypt_ap__1000-01-01__timeline:7641-7650	1.0
:Entity_EDL_0000103	link	NIL000000091
:Entity_EDL_0000104	type	Person
:Entity_EDL_0000104	canonical_mention	"he"	egypt_latimes__1000-01-01__timeline:2018-2019	1.0
:Entity_EDL_0000104	pronominal_mention	"he"	egypt_latimes__1000-01-01__timeline:2018-2019	1.0
:Entity_EDL_0000104	link	NIL000000092
:Entity_EDL_0000105	type	Facility
:Entity_EDL_0000105	nominal_mention	"hospital"	egypt_latimes__1000-01-01__timeline:2354-2361	1.0
:Entity_EDL_0000105	link	NIL000000093
:Entity_EDL_0000106	type	Weapon
:Entity_EDL_0000106	canonical_mention	"rockets"	egypt_guardian__1000-01-01__timeline:4926-4932	1.0
:Entity_EDL_0000106	nominal_mention	"rockets"	egypt_guardian__1000-01-01__timeline:4926-4932	1.0
:Entity_EDL_0000106	link	NIL000000094
:Entity_EDL_0000107	type	Person
:Entity_EDL_0000107	nominal_mention	"leadership"	egypt_ap__1000-01-01__timeline:3360-3369	1.0
:Entity_EDL_0000107	link	NIL000000095
:Entity_EDL_0000108	type	Organization
:Entity_EDL_0000108	canonical_mention	"establishment"	egypt_reuters__1000-01-01__timeline:4425-4437	1.0
:Entity_EDL_0000108	nominal_mention	"establishment"	egypt_reuters__1000-01-01__timeline:4425-4437	1.0
:Entity_EDL_0000108	link	NIL000000096
:Entity_EDL_0000109	type	Location
:Entity_EDL_0000109	canonical_mention	"border"	egypt_guardian__1000-01-01__timeline:4839-4844	1.0
:Entity_EDL_0000109	nominal_mention	"border"	egypt_guardian__1000-01-01__timeline:4839-4844	1.0
:Entity_EDL_0000109	link	NIL000000097
:Entity_EDL_0000110	type	Person
:Entity_EDL_0000110	nominal_mention	"minister"	egypt_ap__1000-01-01__timeline:11150-11157	1.0
:Entity_EDL_0000110	link	NIL000000098
:Entity_EDL_0000111	type	Person
:Entity_EDL_0000111	canonical_mention	"Hillary Rodham Clinton"	egypt_latimes__1000-01-01__timeline:3742-3763	1.0
:Entity_EDL_0000111	mention	"Hillary Rodham Clinton"	egypt_latimes__1000-01-01__timeline:3742-3763	1.0
:Entity_EDL_0000111	link	NIL000000099
:Entity_EDL_0000112	type	Organization
:Entity_EDL_0000112	nominal_mention	"parliament"	egypt_latimes__1000-01-01__timeline:3493-3502	1.0
:Entity_EDL_0000112	link	NIL000000100
:Entity_EDL_0000113	type	Organization
:Entity_EDL_0000113	canonical_mention	"International Monetary Fund"	egypt_latimes__1000-01-01__timeline:6336-6362	1.0
:Entity_EDL_0000113	mention	"International Monetary Fund"	egypt_latimes__1000-01-01__timeline:6336-6362	1.0
:Entity_EDL_0000113	link	20000126
:Entity_EDL_0000114	type	Person
:Entity_EDL_0000114	nominal_mention	"Islamists"	egypt_ap__1000-01-01__timeline:5819-5827	1.0
:Entity_EDL_0000114	link	NIL000000101
:Entity_EDL_0000115	type	Person
:Entity_EDL_0000115	nominal_mention	"protesters"	egypt_ap__1000-01-01__timeline:9488-9497	0.000
:Entity_EDL_0000115	link	NIL000000102
:Entity_EDL_0000116	type	Person
:Entity_EDL_0000116	canonical_mention	"Muslims"	egypt_guardian__1000-01-01__timeline:3030-3036	1.0
:Entity_EDL_0000116	nominal_mention	"Muslims"	egypt_guardian__1000-01-01__timeline:3030-3036	1.0
:Entity_EDL_0000116	link	NIL000000103
:Entity_EDL_0000117	type	Person
:Entity_EDL_0000117	canonical_mention	"visitors"	egypt_guardian__1000-01-01__timeline:1196-1203	1.0
:Entity_EDL_0000117	nominal_mention	"visitors"	egypt_guardian__1000-01-01__timeline:1196-1203	1.0
:Entity_EDL_0000117	link	NIL000000104
:Entity_EDL_0000118	type	Person
:Entity_EDL_0000118	canonical_mention	"Shafik"	egypt_reuters__1000-01-01__timeline:1475-1480	1.0
:Entity_EDL_0000118	mention	"Shafik"	egypt_reuters__1000-01-01__timeline:1475-1480	1.0
:Entity_EDL_0000118	link	NIL000000105
:Entity_EDL_0000119	type	Person
:Entity_EDL_0000119	nominal_mention	"protesters"	egypt_ap__1000-01-01__timeline:279-288	1.0
:Entity_EDL_0000119	link	NIL000000106
:Entity_EDL_0000120	type	Person
:Entity_EDL_0000120	canonical_mention	"Copts"	egypt_guardian__1000-01-01__timeline:3020-3024	1.0
:Entity_EDL_0000120	nominal_mention	"Copts"	egypt_guardian__1000-01-01__timeline:3020-3024	1.0
:Entity_EDL_0000120	link	NIL000000107
:Entity_EDL_0000121	type	Organization
:Entity_EDL_0000121	canonical_mention	"Arab League"	egypt_latimes__1000-01-01__timeline:5539-5549	1.0
:Entity_EDL_0000121	mention	"Arab League"	egypt_latimes__1000-01-01__timeline:5539-5549	1.0
:Entity_EDL_0000121	link	20000138
:Entity_EDL_0000122	type	Person
:Entity_EDL_0000122	nominal_mention	"protesters"	egypt_ap__1000-01-01__timeline:6941-6950	1.0
:Entity_EDL_0000122	link	NIL000000108
:Entity_EDL_0000123	type	Person
:Entity_EDL_0000123	mention	"Shafik"	egypt_reuters__1000-01-01__timeline:4475-4480	1.0
:Entity_EDL_0000123	link	NIL000000109
:Entity_EDL_0000124	type	Person
:Entity_EDL_0000124	canonical_mention	"mob"	egypt_ap__1000-01-01__timeline:7521-7523	1.0
:Entity_EDL_0000124	nominal_mention	"mob"	egypt_ap__1000-01-01__timeline:7521-7523	1.0
:Entity_EDL_0000124	link	NIL000000110
:Entity_EDL_0000125	type	GeopoliticalEntity
:Entity_EDL_0000125	nominal_mention	"nation"	egypt_latimes__1000-01-01__timeline:671-676	1.0
:Entity_EDL_0000125	link	NIL000000111
:Entity_EDL_0000126	type	Facility
:Entity_EDL_0000126	canonical_mention	"church"	egypt_guardian__1000-01-01__timeline:88-93	1.0
:Entity_EDL_0000126	nominal_mention	"church"	egypt_guardian__1000-01-01__timeline:88-93	1.0
:Entity_EDL_0000126	link	NIL000000112
:Entity_EDL_0000127	type	Person
:Entity_EDL_0000127	canonical_mention	"21"	egypt_guardian__1000-01-01__timeline:20-21	1.0
:Entity_EDL_0000127	pronominal_mention	"21"	egypt_guardian__1000-01-01__timeline:20-21	1.0
:Entity_EDL_0000127	link	NIL000000113
:Entity_EDL_0000128	type	Person
:Entity_EDL_0000128	canonical_mention	"chief"	egypt_ap__1000-01-01__timeline:10061-10065	1.0
:Entity_EDL_0000128	nominal_mention	"chief"	egypt_ap__1000-01-01__timeline:10061-10065	1.0
:Entity_EDL_0000128	link	NIL000000114
:Entity_EDL_0000129	type	Weapon
:Entity_EDL_0000129	canonical_mention	"explosive"	egypt_guardian__1000-01-01__timeline:4024-4032	1.0
:Entity_EDL_0000129	nominal_mention	"explosive"	egypt_guardian__1000-01-01__timeline:4024-4032	1.0
:Entity_EDL_0000129	link	NIL000000115
:Entity_EDL_0000130	type	Person
:Entity_EDL_0000130	canonical_mention	"Lawmakers"	egypt_latimes__1000-01-01__timeline:3436-3444	1.0
:Entity_EDL_0000130	nominal_mention	"Lawmakers"	egypt_latimes__1000-01-01__timeline:3436-3444	1.0
:Entity_EDL_0000130	link	NIL000000116
:Entity_EDL_0000131	type	Person
:Entity_EDL_0000131	canonical_mention	"him"	egypt_guardian__1000-01-01__timeline:1666-1668	1.0
:Entity_EDL_0000131	pronominal_mention	"him"	egypt_guardian__1000-01-01__timeline:1666-1668	1.0
:Entity_EDL_0000131	link	NIL000000117
:Entity_EDL_0000132	type	Person
:Entity_EDL_0000132	canonical_mention	"dozens"	egypt_guardian__1000-01-01__timeline:4356-4361	1.0
:Entity_EDL_0000132	nominal_mention	"dozens"	egypt_guardian__1000-01-01__timeline:4356-4361	1.0
:Entity_EDL_0000132	link	NIL000000118
:Entity_EDL_0000133	type	Organization
:Entity_EDL_0000133	canonical_mention	"International Monetary Fund"	egypt_ap__1000-01-01__timeline:8151-8177	1.0
:Entity_EDL_0000133	mention	"International Monetary Fund"	egypt_ap__1000-01-01__timeline:8151-8177	1.0
:Entity_EDL_0000133	link	20000126
:Entity_EDL_0000134	type	Facility
:Entity_EDL_0000134	canonical_mention	"palace"	egypt_ap__1000-01-01__timeline:5331-5336	1.0
:Entity_EDL_0000134	nominal_mention	"palace"	egypt_ap__1000-01-01__timeline:5331-5336	1.0
:Entity_EDL_0000134	link	NIL000000119
:Entity_EDL_0000135	type	Person
:Entity_EDL_0000135	canonical_mention	"Americans"	egypt_latimes__1000-01-01__timeline:7527-7535	1.0
:Entity_EDL_0000135	nominal_mention	"Americans"	egypt_latimes__1000-01-01__timeline:7527-7535	1.0
:Entity_EDL_0000135	link	NIL000000120
:Entity_EDL_0000136	type	Person
:Entity_EDL_0000136	nominal_mention	"person"	egypt_ap__1000-01-01__timeline:10738-10743	1.0
:Entity_EDL_0000136	link	NIL000000121
:Entity_EDL_0000137	type	Person
:Entity_EDL_0000137	canonical_mention	"Bassem Youssef"	egypt_latimes__1000-01-01__timeline:6486-6499	1.0
:Entity_EDL_0000137	mention	"Bassem Youssef"	egypt_latimes__1000-01-01__timeline:6486-6499	1.0
:Entity_EDL_0000137	link	NIL000000122
:Entity_EDL_0000138	type	Facility
:Entity_EDL_0000138	canonical_mention	"headquarters"	egypt_ap__1000-01-01__timeline:558-569	1.0
:Entity_EDL_0000138	nominal_mention	"headquarters"	egypt_ap__1000-01-01__timeline:558-569	1.0
:Entity_EDL_0000138	link	NIL000000123
:Entity_EDL_0000139	type	Person
:Entity_EDL_0000139	canonical_mention	"journalist"	egypt_guardian__1000-01-01__timeline:600-609	1.0
:Entity_EDL_0000139	nominal_mention	"journalist"	egypt_guardian__1000-01-01__timeline:600-609	1.0
:Entity_EDL_0000139	link	NIL000000124
:Entity_EDL_0000140	type	Weapon
:Entity_EDL_0000140	canonical_mention	"missiles"	egypt_guardian__1000-01-01__timeline:4913-4920	1.0
:Entity_EDL_0000140	nominal_mention	"missiles"	egypt_guardian__1000-01-01__timeline:4913-4920	1.0
:Entity_EDL_0000140	link	NIL000000125
:Entity_EDL_0000141	type	Organization
:Entity_EDL_0000141	nominal_mention	"court"	egypt_ap__1000-01-01__timeline:6778-6782	1.0
:Entity_EDL_0000141	link	NIL000000126
:Entity_EDL_0000142	type	Person
:Entity_EDL_0000142	canonical_mention	"him"	egypt_reuters__1000-01-01__timeline:807-809	1.0
:Entity_EDL_0000142	pronominal_mention	"him"	egypt_reuters__1000-01-01__timeline:807-809	1.0
:Entity_EDL_0000142	link	NIL000000127
:Entity_EDL_0000143	type	Person
:Entity_EDL_0000143	canonical_mention	"cabinet"	egypt_guardian__1000-01-01__timeline:1405-1411	1.0
:Entity_EDL_0000143	nominal_mention	"cabinet"	egypt_guardian__1000-01-01__timeline:1405-1411	1.0
:Entity_EDL_0000143	link	NIL000000128
:Entity_EDL_0000144	type	Organization
:Entity_EDL_0000144	canonical_mention	"it"	egypt_latimes__1000-01-01__timeline:3571-3572	1.0
:Entity_EDL_0000144	pronominal_mention	"it"	egypt_latimes__1000-01-01__timeline:3571-3572	1.0
:Entity_EDL_0000144	link	NIL000000129
:Entity_EDL_0000145	type	Person
:Entity_EDL_0000145	canonical_mention	"person"	egypt_ap__1000-01-01__timeline:7720-7725	1.0
:Entity_EDL_0000145	nominal_mention	"person"	egypt_ap__1000-01-01__timeline:7720-7725	1.0
:Entity_EDL_0000145	link	NIL000000130
:Entity_EDL_0000146	type	Facility
:Entity_EDL_0000146	nominal_mention	"headquarters"	egypt_ap__1000-01-01__timeline:9104-9115	1.0
:Entity_EDL_0000146	link	NIL000000131
:Entity_EDL_0000147	type	Person
:Entity_EDL_0000147	nominal_mention	"protesters"	egypt_ap__1000-01-01__timeline:5294-5303	1.0
:Entity_EDL_0000147	link	NIL000000132
:Entity_EDL_0000148	type	Facility
:Entity_EDL_0000148	nominal_mention	"street"	egypt_guardian__1000-01-01__timeline:3704-3709	1.0
:Entity_EDL_0000148	link	NIL000000133
:Entity_EDL_0000149	type	GeopoliticalEntity
:Entity_EDL_0000149	canonical_mention	"Ismailia"	egypt_latimes__1000-01-01__timeline:5661-5668	1.0
:Entity_EDL_0000149	mention	"Ismailia"	egypt_latimes__1000-01-01__timeline:5661-5668	1.0
:Entity_EDL_0000149	link	361056
:Entity_EDL_0000150	type	Person
:Entity_EDL_0000150	canonical_mention	"He"	egypt_reuters__1000-01-01__timeline:2811-2812	1.0
:Entity_EDL_0000150	pronominal_mention	"He"	egypt_reuters__1000-01-01__timeline:2811-2812	1.0
:Entity_EDL_0000150	link	NIL000000134
:Entity_EDL_0000151	type	Person
:Entity_EDL_0000151	canonical_mention	"his"	egypt_reuters__1000-01-01__timeline:3727-3729	1.0
:Entity_EDL_0000151	pronominal_mention	"his"	egypt_reuters__1000-01-01__timeline:3727-3729	1.0
:Entity_EDL_0000151	link	NIL000000135
:Entity_EDL_0000152	type	Person
:Entity_EDL_0000152	canonical_mention	"Organizers"	egypt_ap__1000-01-01__timeline:9172-9181	1.0
:Entity_EDL_0000152	nominal_mention	"Organizers"	egypt_ap__1000-01-01__timeline:9172-9181	1.0
:Entity_EDL_0000152	link	NIL000000136
:Entity_EDL_0000153	type	GeopoliticalEntity
:Entity_EDL_0000153	nominal_mention	"government"	egypt_latimes__1000-01-01__timeline:5905-5914	1.0
:Entity_EDL_0000153	link	NIL000000137
:Entity_EDL_0000154	type	Person
:Entity_EDL_0000154	canonical_mention	"force"	egypt_ap__1000-01-01__timeline:215-219	1.0
:Entity_EDL_0000154	nominal_mention	"force"	egypt_ap__1000-01-01__timeline:215-219	1.0
:Entity_EDL_0000154	link	NIL000000138
:Entity_EDL_0000155	type	Person
:Entity_EDL_0000155	canonical_mention	"activists"	egypt_latimes__1000-01-01__timeline:3943-3951	1.0
:Entity_EDL_0000155	nominal_mention	"activists"	egypt_latimes__1000-01-01__timeline:3943-3951	1.0
:Entity_EDL_0000155	link	NIL000000139
:Entity_EDL_0000156	type	Person
:Entity_EDL_0000156	nominal_mention	"president"	egypt_latimes__1000-01-01__timeline:8359-8367	0.000
:Entity_EDL_0000156	link	NIL000000140
:Entity_EDL_0000157	type	Facility
:Entity_EDL_0000157	canonical_mention	"there"	egypt_ap__1000-01-01__timeline:7625-7629	1.0
:Entity_EDL_0000157	nominal_mention	"there"	egypt_ap__1000-01-01__timeline:7625-7629	1.0
:Entity_EDL_0000157	link	NIL000000141
:Entity_EDL_0000158	type	GeopoliticalEntity
:Entity_EDL_0000158	canonical_mention	"nation"	egypt_latimes__1000-01-01__timeline:146-151	1.0
:Entity_EDL_0000158	nominal_mention	"nation"	egypt_latimes__1000-01-01__timeline:146-151	1.0
:Entity_EDL_0000158	link	NIL000000142
:Entity_EDL_0000159	type	Person
:Entity_EDL_0000159	canonical_mention	"people"	egypt_reuters__1000-01-01__timeline:2698-2703	1.0
:Entity_EDL_0000159	nominal_mention	"people"	egypt_reuters__1000-01-01__timeline:2698-2703	1.0
:Entity_EDL_0000159	link	NIL000000143
:Entity_EDL_0000160	type	Weapon
:Entity_EDL_0000160	canonical_mention	"bomb"	egypt_guardian__1000-01-01__timeline:59-62	1.0
:Entity_EDL_0000160	nominal_mention	"bomb"	egypt_guardian__1000-01-01__timeline:59-62	1.0
:Entity_EDL_0000160	link	NIL000000144
:Entity_EDL_0000161	type	Person
:Entity_EDL_0000161	canonical_mention	"forces"	egypt_reuters__1000-01-01__timeline:844-849	1.0
:Entity_EDL_0000161	nominal_mention	"forces"	egypt_reuters__1000-01-01__timeline:844-849	1.0
:Entity_EDL_0000161	link	NIL000000145
:Entity_EDL_0000162	type	GeopoliticalEntity
:Entity_EDL_0000162	canonical_mention	"village"	egypt_ap__1000-01-01__timeline:8474-8480	1.0
:Entity_EDL_0000162	nominal_mention	"village"	egypt_ap__1000-01-01__timeline:8474-8480	1.0
:Entity_EDL_0000162	link	NIL000000146
:Entity_EDL_0000163	type	Person
:Entity_EDL_0000163	canonical_mention	"residents"	egypt_ap__1000-01-01__timeline:6713-6721	1.0
:Entity_EDL_0000163	nominal_mention	"residents"	egypt_ap__1000-01-01__timeline:6713-6721	1.0
:Entity_EDL_0000163	link	NIL000000147
:Entity_EDL_0000164	type	Person
:Entity_EDL_0000164	canonical_mention	"Mohammed Morsi"	egypt_ap__1000-01-01__timeline:10497-10510	1.0
:Entity_EDL_0000164	mention	"Mohammed Morsi"	egypt_ap__1000-01-01__timeline:10497-10510	1.0
:Entity_EDL_0000164	link	NIL000000148
:Entity_EDL_0000165	type	Person
:Entity_EDL_0000165	nominal_mention	"president"	egypt_reuters__1000-01-01__timeline:2459-2467	1.0
:Entity_EDL_0000165	link	NIL000000149
:Entity_EDL_0000166	type	GeopoliticalEntity
:Entity_EDL_0000166	pronominal_mention	"it"	egypt_reuters__1000-01-01__timeline:3019-3020	1.0
:Entity_EDL_0000166	link	NIL000000150
:Entity_EDL_0000167	type	Person
:Entity_EDL_0000167	canonical_mention	"10"	egypt_ap__1000-01-01__timeline:5552-5553	1.0
:Entity_EDL_0000167	nominal_mention	"10"	egypt_ap__1000-01-01__timeline:5552-5553	1.0
:Entity_EDL_0000167	link	NIL000000151
:Entity_EDL_0000168	type	Person
:Entity_EDL_0000168	nominal_mention	"Israelis"	egypt_guardian__1000-01-01__timeline:4801-4808	1.0
:Entity_EDL_0000168	link	NIL000000152
:Entity_EDL_0000169	type	Organization
:Entity_EDL_0000169	nominal_mention	"government"	egypt_reuters__1000-01-01__timeline:2281-2290	1.0
:Entity_EDL_0000169	link	NIL000000153
:Entity_EDL_0000170	type	GeopoliticalEntity
:Entity_EDL_0000170	mention	"Port Said"	egypt_ap__1000-01-01__timeline:6908-6916	1.0
:Entity_EDL_0000170	link	358619
:Entity_EDL_0000171	type	GeopoliticalEntity
:Entity_EDL_0000171	canonical_mention	"Tunisia"	egypt_reuters__1000-01-01__timeline:95-101	1.0
:Entity_EDL_0000171	mention	"Tunisia"	egypt_reuters__1000-01-01__timeline:95-101	1.0
:Entity_EDL_0000171	link	2464461
:Entity_EDL_0000172	type	GeopoliticalEntity
:Entity_EDL_0000172	mention	"Egyptian"	egypt_guardian__1000-01-01__timeline:3992-3999	1.0
:Entity_EDL_0000172	link	357994
:Entity_EDL_0000173	type	Person
:Entity_EDL_0000173	mention	"Morsi"	egypt_ap__1000-01-01__timeline:11107-11111	1.0
:Entity_EDL_0000173	link	NIL000000154
:Entity_EDL_0000174	type	Organization
:Entity_EDL_0000174	nominal_mention	"Police"	egypt_ap__1000-01-01__timeline:6882-6887	1.0
:Entity_EDL_0000174	link	NIL000000155
:Entity_EDL_0000175	type	Person
:Entity_EDL_0000175	nominal_mention	"supporters"	egypt_ap__1000-01-01__timeline:4397-4406	1.0
:Entity_EDL_0000175	link	NIL000000156
:Entity_EDL_0000176	type	Person
:Entity_EDL_0000176	nominal_mention	"mob"	egypt_ap__1000-01-01__timeline:8414-8416	1.0
:Entity_EDL_0000176	link	NIL000000157
:Entity_EDL_0000177	type	Person
:Entity_EDL_0000177	nominal_mention	"protesters"	egypt_reuters__1000-01-01__timeline:3754-3763	1.0
:Entity_EDL_0000177	link	NIL000000158
:Entity_EDL_0000178	type	Person
:Entity_EDL_0000178	canonical_mention	"leaders"	egypt_ap__1000-01-01__timeline:10101-10107	1.0
:Entity_EDL_0000178	nominal_mention	"leaders"	egypt_ap__1000-01-01__timeline:10101-10107	1.0
:Entity_EDL_0000178	link	NIL000000159
:Entity_EDL_0000179	type	Person
:Entity_EDL_0000179	nominal_mention	"protesters"	egypt_ap__1000-01-01__timeline:1595-1604	1.0
:Entity_EDL_0000179	link	NIL000000160
:Entity_EDL_0000180	type	Organization
:Entity_EDL_0000180	canonical_mention	"organizations"	egypt_latimes__1000-01-01__timeline:7592-7604	1.0
:Entity_EDL_0000180	nominal_mention	"organizations"	egypt_latimes__1000-01-01__timeline:7592-7604	1.0
:Entity_EDL_0000180	link	NIL000000161
:Entity_EDL_0000181	type	Person
:Entity_EDL_0000181	canonical_mention	"protesters"	egypt_guardian__1000-01-01__timeline:2538-2547	1.0
:Entity_EDL_0000181	nominal_mention	"protesters"	egypt_guardian__1000-01-01__timeline:2538-2547	1.0
:Entity_EDL_0000181	link	NIL000000162
:Entity_EDL_0000182	type	Facility
:Entity_EDL_0000182	canonical_mention	"pipeline"	egypt_guardian__1000-01-01__timeline:4001-4008	1.0
:Entity_EDL_0000182	nominal_mention	"pipeline"	egypt_guardian__1000-01-01__timeline:4001-4008	1.0
:Entity_EDL_0000182	link	NIL000000163
:Entity_EDL_0000183	type	Organization
:Entity_EDL_0000183	canonical_mention	"services"	egypt_latimes__1000-01-01__timeline:3324-3331	1.0
:Entity_EDL_0000183	nominal_mention	"services"	egypt_latimes__1000-01-01__timeline:3324-3331	1.0
:Entity_EDL_0000183	link	NIL000000164
:Entity_EDL_0000184	type	Weapon
:Entity_EDL_0000184	nominal_mention	"bullets"	egypt_ap__1000-01-01__timeline:307-313	0.000
:Entity_EDL_0000184	link	NIL000000165
:Entity_EDL_0000185	type	Organization
:Entity_EDL_0000185	nominal_mention	"Parliament"	egypt_ap__1000-01-01__timeline:3036-3045	1.0
:Entity_EDL_0000185	link	NIL000000166
:Entity_EDL_0000186	type	Person
:Entity_EDL_0000186	canonical_mention	"Amr Moussa"	egypt_latimes__1000-01-01__timeline:5569-5578	1.0
:Entity_EDL_0000186	mention	"Amr Moussa"	egypt_latimes__1000-01-01__timeline:5569-5578	1.0
:Entity_EDL_0000186	link	NIL000000167
:Entity_EDL_0000187	type	Person
:Entity_EDL_0000187	nominal_mention	"clerics"	egypt_ap__1000-01-01__timeline:8702-8708	1.0
:Entity_EDL_0000187	link	NIL000000168
:Entity_EDL_0000188	type	Organization
:Entity_EDL_0000188	nominal_mention	"chamber"	egypt_latimes__1000-01-01__timeline:4711-4717	1.0
:Entity_EDL_0000188	link	NIL000000169
:Entity_EDL_0000189	type	Person
:Entity_EDL_0000189	pronominal_mention	"he"	egypt_guardian__1000-01-01__timeline:6373-6374	1.0
:Entity_EDL_0000189	link	NIL000000170
:Entity_EDL_0000190	type	Person
:Entity_EDL_0000190	canonical_mention	"Mubarak"	egypt_latimes__1000-01-01__timeline:2273-2279	1.0
:Entity_EDL_0000190	mention	"Mubarak"	egypt_latimes__1000-01-01__timeline:2273-2279	1.0
:Entity_EDL_0000190	link	30000327
:Entity_EDL_0000191	type	Person
:Entity_EDL_0000191	canonical_mention	"blogger"	egypt_guardian__1000-01-01__timeline:6341-6347	1.0
:Entity_EDL_0000191	nominal_mention	"blogger"	egypt_guardian__1000-01-01__timeline:6341-6347	1.0
:Entity_EDL_0000191	link	NIL000000171
:Entity_EDL_0000192	type	Person
:Entity_EDL_0000192	nominal_mention	"minister"	egypt_guardian__1000-01-01__timeline:4225-4232	1.0
:Entity_EDL_0000192	link	NIL000000172
:Entity_EDL_0000193	type	Organization
:Entity_EDL_0000193	canonical_mention	"Egyptian Central Bank"	egypt_ap__1000-01-01__timeline:6085-6105	1.0
:Entity_EDL_0000193	mention	"Egyptian Central Bank"	egypt_ap__1000-01-01__timeline:6085-6105	1.0
:Entity_EDL_0000193	link	NIL000000173
:Entity_EDL_0000194	type	Person
:Entity_EDL_0000194	nominal_mention	"Islamists"	egypt_ap__1000-01-01__timeline:5086-5094	1.0
:Entity_EDL_0000194	link	NIL000000174
:Entity_EDL_0000195	type	Organization
:Entity_EDL_0000195	nominal_mention	"parliament"	egypt_latimes__1000-01-01__timeline:1468-1477	1.0
:Entity_EDL_0000195	link	NIL000000175
:Entity_EDL_0000196	type	Person
:Entity_EDL_0000196	canonical_mention	"him"	egypt_latimes__1000-01-01__timeline:8601-8603	1.0
:Entity_EDL_0000196	pronominal_mention	"him"	egypt_latimes__1000-01-01__timeline:8601-8603	1.0
:Entity_EDL_0000196	link	NIL000000176
:Entity_EDL_0000197	type	Organization
:Entity_EDL_0000197	nominal_mention	"assembly"	egypt_ap__1000-01-01__timeline:4202-4209	1.0
:Entity_EDL_0000197	link	NIL000000177
:Entity_EDL_0000198	type	Person
:Entity_EDL_0000198	nominal_mention	"police"	egypt_guardian__1000-01-01__timeline:5251-5256	1.0
:Entity_EDL_0000198	link	NIL000000178
:Entity_EDL_0000199	type	Weapon
:Entity_EDL_0000199	canonical_mention	"tear gas"	egypt_ap__1000-01-01__timeline:319-326	1.0
:Entity_EDL_0000199	nominal_mention	"tear gas"	egypt_ap__1000-01-01__timeline:319-326	1.0
:Entity_EDL_0000199	link	NIL000000179
:Entity_EDL_0000200	type	Person
:Entity_EDL_0000200	nominal_mention	"soldiers"	egypt_ap__1000-01-01__timeline:10626-10633	1.0
:Entity_EDL_0000200	link	NIL000000180
:Entity_EDL_0000201	type	Person
:Entity_EDL_0000201	canonical_mention	"group"	egypt_ap__1000-01-01__timeline:6828-6832	1.0
:Entity_EDL_0000201	nominal_mention	"group"	egypt_ap__1000-01-01__timeline:6828-6832	1.0
:Entity_EDL_0000201	link	NIL000000181
:Entity_EDL_0000202	type	GeopoliticalEntity
:Entity_EDL_0000202	nominal_mention	"country"	egypt_latimes__1000-01-01__timeline:8545-8551	1.0
:Entity_EDL_0000202	link	NIL000000182
:Entity_EDL_0000203	type	Person
:Entity_EDL_0000203	nominal_mention	"forces"	egypt_guardian__1000-01-01__timeline:6144-6149	0.000
:Entity_EDL_0000203	link	NIL000000183
:Entity_EDL_0000204	type	Person
:Entity_EDL_0000204	nominal_mention	"Protesters"	egypt_ap__1000-01-01__timeline:517-526	1.0
:Entity_EDL_0000204	link	NIL000000184
:Entity_EDL_0000205	type	Person
:Entity_EDL_0000205	nominal_mention	"protesters"	egypt_ap__1000-01-01__timeline:337-346	1.0
:Entity_EDL_0000205	link	NIL000000185
:Entity_EDL_0000206	type	Person
:Entity_EDL_0000206	canonical_mention	"dozens"	egypt_ap__1000-01-01__timeline:1786-1791	1.0
:Entity_EDL_0000206	nominal_mention	"dozens"	egypt_ap__1000-01-01__timeline:1786-1791	1.0
:Entity_EDL_0000206	link	NIL000000186
