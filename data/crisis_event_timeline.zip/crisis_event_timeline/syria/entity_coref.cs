:Entity_EDL_0000000	type	GeopoliticalEntity
:Entity_EDL_0000000	mention	"Syria"	syria_latimes__1000-01-01__timeline:4971-4975	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_washington__1000-01-01__timeline:4266-4270	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_bbc__1000-01-01__timeline:2576-2580	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_latimes__1000-01-01__timeline:5178-5182	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_latimes__1000-01-01__timeline:8002-8006	1.0
:Entity_EDL_0000000	mention	"Syrian"	syria_latimes__1000-01-01__timeline:10080-10085	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_latimes__1000-01-01__timeline:13319-13323	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_sbs__1000-01-01__timeline:2149-2153	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_bbc__1000-01-01__timeline:3058-3062	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_dailystar__1000-01-01__timeline:1375-1379	1.0
:Entity_EDL_0000000	canonical_mention	"Syrian"	syria_bbc__1000-01-01__timeline:15-20	1.0
:Entity_EDL_0000000	mention	"Syrian"	syria_bbc__1000-01-01__timeline:15-20	1.0
:Entity_EDL_0000000	mention	"Syrian"	syria_washington__1000-01-01__timeline:2188-2193	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_sbs__1000-01-01__timeline:1625-1629	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_latimes__1000-01-01__timeline:15551-15555	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_latimes__1000-01-01__timeline:13668-13672	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_latimes__1000-01-01__timeline:11987-11991	1.0
:Entity_EDL_0000000	mention	"Syrian"	syria_latimes__1000-01-01__timeline:10827-10832	1.0
:Entity_EDL_0000000	mention	"Syrian"	syria_latimes__1000-01-01__timeline:14531-14536	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_latimes__1000-01-01__timeline:8880-8884	1.0
:Entity_EDL_0000000	mention	"Syria"	syria_washington__1000-01-01__timeline:3398-3402	1.0
:Entity_EDL_0000000	link	163843
:Entity_EDL_0000001	type	GeopoliticalEntity
:Entity_EDL_0000001	mention	"Damascus"	syria_latimes__1000-01-01__timeline:12980-12987	1.0
:Entity_EDL_0000001	canonical_mention	"Damascus"	syria_sbs__1000-01-01__timeline:847-854	1.0
:Entity_EDL_0000001	mention	"Damascus"	syria_sbs__1000-01-01__timeline:847-854	1.0
:Entity_EDL_0000001	mention	"Damascus"	syria_sbs__1000-01-01__timeline:1121-1128	1.0
:Entity_EDL_0000001	mention	"Damascus"	syria_latimes__1000-01-01__timeline:3845-3852	1.0
:Entity_EDL_0000001	mention	"Damascus"	syria_dailystar__1000-01-01__timeline:1856-1863	1.0
:Entity_EDL_0000001	mention	"Damascus"	syria_latimes__1000-01-01__timeline:13880-13887	1.0
:Entity_EDL_0000001	canonical_mention	"Damascus"	syria_dailystar__1000-01-01__timeline:498-505	1.0
:Entity_EDL_0000001	mention	"Damascus"	syria_dailystar__1000-01-01__timeline:498-505	1.0
:Entity_EDL_0000001	mention	"Damascus"	syria_latimes__1000-01-01__timeline:389-396	1.0
:Entity_EDL_0000001	link	170654
:Entity_EDL_0000002	type	Person
:Entity_EDL_0000002	mention	"Bashar Assad"	syria_latimes__1000-01-01__timeline:7127-7138	1.0
:Entity_EDL_0000002	canonical_mention	"Bashar al-Assad"	syria_bbc__1000-01-01__timeline:400-414	1.0
:Entity_EDL_0000002	mention	"Bashar al-Assad"	syria_bbc__1000-01-01__timeline:400-414	1.0
:Entity_EDL_0000002	canonical_mention	"Assad"	syria_washington__1000-01-01__timeline:573-577	1.0
:Entity_EDL_0000002	mention	"Assad"	syria_washington__1000-01-01__timeline:573-577	1.0
:Entity_EDL_0000002	canonical_mention	"Assad"	syria_sbs__1000-01-01__timeline:170-174	1.0
:Entity_EDL_0000002	mention	"Assad"	syria_sbs__1000-01-01__timeline:170-174	1.0
:Entity_EDL_0000002	canonical_mention	"Assad"	syria_dailystar__1000-01-01__timeline:170-174	1.0
:Entity_EDL_0000002	mention	"Assad"	syria_dailystar__1000-01-01__timeline:170-174	1.0
:Entity_EDL_0000002	link	30004507
:Entity_EDL_0000003	type	GeopoliticalEntity
:Entity_EDL_0000003	mention	"Damascus"	syria_washington__1000-01-01__timeline:2039-2046	1.0
:Entity_EDL_0000003	mention	"Damascus"	syria_washington__1000-01-01__timeline:2500-2507	1.0
:Entity_EDL_0000003	link	170654
:Entity_EDL_0000004	type	GeopoliticalEntity
:Entity_EDL_0000004	canonical_mention	"Aleppo"	syria_latimes__1000-01-01__timeline:1272-1277	1.0
:Entity_EDL_0000004	mention	"Aleppo"	syria_latimes__1000-01-01__timeline:1272-1277	1.0
:Entity_EDL_0000004	mention	"Aleppo"	syria_sbs__1000-01-01__timeline:2225-2230	1.0
:Entity_EDL_0000004	link	170063
:Entity_EDL_0000005	type	GeopoliticalEntity
:Entity_EDL_0000005	canonical_mention	"Turkey"	syria_dailystar__1000-01-01__timeline:434-439	1.0
:Entity_EDL_0000005	mention	"Turkey"	syria_dailystar__1000-01-01__timeline:434-439	1.0
:Entity_EDL_0000005	mention	"Turkey"	syria_latimes__1000-01-01__timeline:14441-14446	1.0
:Entity_EDL_0000005	link	298795
:Entity_EDL_0000006	type	Organization
:Entity_EDL_0000006	mention	"United Nations"	syria_latimes__1000-01-01__timeline:10509-10522	1.0
:Entity_EDL_0000006	mention	"U.N"	syria_latimes__1000-01-01__timeline:9721-9723	1.0
:Entity_EDL_0000006	link	20000193
:Entity_EDL_0000007	type	GeopoliticalEntity
:Entity_EDL_0000007	canonical_mention	"Tremseh"	syria_bbc__1000-01-01__timeline:3300-3306	1.0
:Entity_EDL_0000007	mention	"Tremseh"	syria_bbc__1000-01-01__timeline:3300-3306	1.0
:Entity_EDL_0000007	mention	"Tremseh"	syria_bbc__1000-01-01__timeline:3679-3685	1.0
:Entity_EDL_0000007	link	9847679
:Entity_EDL_0000008	type	Organization
:Entity_EDL_0000008	nominal_mention	"regime"	syria_sbs__1000-01-01__timeline:2201-2206	1.0
:Entity_EDL_0000008	link	NIL000000001
:Entity_EDL_0000009	type	Organization
:Entity_EDL_0000009	canonical_mention	"court"	syria_latimes__1000-01-01__timeline:1896-1900	1.0
:Entity_EDL_0000009	nominal_mention	"court"	syria_latimes__1000-01-01__timeline:1896-1900	1.0
:Entity_EDL_0000009	link	NIL000000002
:Entity_EDL_0000010	type	Vehicle
:Entity_EDL_0000010	canonical_mention	"jet"	syria_washington__1000-01-01__timeline:1590-1592	1.0
:Entity_EDL_0000010	nominal_mention	"jet"	syria_washington__1000-01-01__timeline:1590-1592	1.0
:Entity_EDL_0000010	link	NIL000000003
:Entity_EDL_0000011	type	GeopoliticalEntity
:Entity_EDL_0000011	pronominal_mention	"where"	syria_dailystar__1000-01-01__timeline:2159-2163	1.0
:Entity_EDL_0000011	link	NIL000000004
:Entity_EDL_0000012	type	GeopoliticalEntity
:Entity_EDL_0000012	nominal_mention	"government"	syria_washington__1000-01-01__timeline:4448-4457	1.0
:Entity_EDL_0000012	link	NIL000000005
:Entity_EDL_0000013	type	Person
:Entity_EDL_0000013	canonical_mention	"officials"	syria_sbs__1000-01-01__timeline:775-783	1.0
:Entity_EDL_0000013	nominal_mention	"officials"	syria_sbs__1000-01-01__timeline:775-783	1.0
:Entity_EDL_0000013	link	NIL000000006
:Entity_EDL_0000014	type	Person
:Entity_EDL_0000014	nominal_mention	"activists"	syria_latimes__1000-01-01__timeline:5200-5208	1.0
:Entity_EDL_0000014	link	NIL000000007
:Entity_EDL_0000015	type	Location
:Entity_EDL_0000015	nominal_mention	"suburbs"	syria_latimes__1000-01-01__timeline:6283-6289	1.0
:Entity_EDL_0000015	link	NIL000000008
:Entity_EDL_0000016	type	Person
:Entity_EDL_0000016	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:3315-3320	0.000
:Entity_EDL_0000016	link	NIL000000009
:Entity_EDL_0000017	type	Person
:Entity_EDL_0000017	nominal_mention	"cabinet"	syria_latimes__1000-01-01__timeline:1710-1716	1.0
:Entity_EDL_0000017	link	NIL000000010
:Entity_EDL_0000018	type	Person
:Entity_EDL_0000018	canonical_mention	"members"	syria_washington__1000-01-01__timeline:2064-2070	1.0
:Entity_EDL_0000018	nominal_mention	"members"	syria_washington__1000-01-01__timeline:2064-2070	1.0
:Entity_EDL_0000018	link	NIL000000011
:Entity_EDL_0000019	type	Location
:Entity_EDL_0000019	canonical_mention	"neighborhood"	syria_washington__1000-01-01__timeline:1059-1070	1.0
:Entity_EDL_0000019	nominal_mention	"neighborhood"	syria_washington__1000-01-01__timeline:1059-1070	1.0
:Entity_EDL_0000019	link	NIL000000012
:Entity_EDL_0000020	type	Person
:Entity_EDL_0000020	canonical_mention	"Kofi Annan"	syria_latimes__1000-01-01__timeline:9744-9753	1.0
:Entity_EDL_0000020	mention	"Kofi Annan"	syria_latimes__1000-01-01__timeline:9744-9753	1.0
:Entity_EDL_0000020	link	NIL000000013
:Entity_EDL_0000021	type	Weapon
:Entity_EDL_0000021	canonical_mention	"artillery"	syria_dailystar__1000-01-01__timeline:2241-2249	1.0
:Entity_EDL_0000021	nominal_mention	"artillery"	syria_dailystar__1000-01-01__timeline:2241-2249	1.0
:Entity_EDL_0000021	link	NIL000000014
:Entity_EDL_0000022	type	Person
:Entity_EDL_0000022	canonical_mention	"victims"	syria_bbc__1000-01-01__timeline:3497-3503	1.0
:Entity_EDL_0000022	nominal_mention	"victims"	syria_bbc__1000-01-01__timeline:3497-3503	1.0
:Entity_EDL_0000022	link	NIL000000015
:Entity_EDL_0000023	type	Person
:Entity_EDL_0000023	canonical_mention	"prisoners"	syria_latimes__1000-01-01__timeline:272-280	1.0
:Entity_EDL_0000023	nominal_mention	"prisoners"	syria_latimes__1000-01-01__timeline:272-280	1.0
:Entity_EDL_0000023	link	NIL000000016
:Entity_EDL_0000024	type	Person
:Entity_EDL_0000024	nominal_mention	"militiamen"	syria_bbc__1000-01-01__timeline:3453-3462	1.0
:Entity_EDL_0000024	link	NIL000000017
:Entity_EDL_0000025	type	Person
:Entity_EDL_0000025	canonical_mention	"residents"	syria_latimes__1000-01-01__timeline:2016-2024	1.0
:Entity_EDL_0000025	nominal_mention	"residents"	syria_latimes__1000-01-01__timeline:2016-2024	1.0
:Entity_EDL_0000025	link	NIL000000018
:Entity_EDL_0000026	type	Vehicle
:Entity_EDL_0000026	canonical_mention	"helicopter"	syria_washington__1000-01-01__timeline:2400-2409	1.0
:Entity_EDL_0000026	nominal_mention	"helicopter"	syria_washington__1000-01-01__timeline:2400-2409	1.0
:Entity_EDL_0000026	link	NIL000000019
:Entity_EDL_0000027	type	GeopoliticalEntity
:Entity_EDL_0000027	canonical_mention	"town"	syria_latimes__1000-01-01__timeline:14363-14366	1.0
:Entity_EDL_0000027	nominal_mention	"town"	syria_latimes__1000-01-01__timeline:14363-14366	1.0
:Entity_EDL_0000027	link	NIL000000020
:Entity_EDL_0000028	type	Organization
:Entity_EDL_0000028	canonical_mention	"NATO"	syria_latimes__1000-01-01__timeline:9585-9588	1.0
:Entity_EDL_0000028	mention	"NATO"	syria_latimes__1000-01-01__timeline:9585-9588	1.0
:Entity_EDL_0000028	link	20000153
:Entity_EDL_0000029	type	GeopoliticalEntity
:Entity_EDL_0000029	pronominal_mention	"where"	syria_washington__1000-01-01__timeline:179-183	1.0
:Entity_EDL_0000029	link	NIL000000021
:Entity_EDL_0000030	type	GeopoliticalEntity
:Entity_EDL_0000030	canonical_mention	"Syrians"	syria_washington__1000-01-01__timeline:11-17	1.0
:Entity_EDL_0000030	nominal_mention	"Syrians"	syria_washington__1000-01-01__timeline:11-17	1.0
:Entity_EDL_0000030	link	NIL000000022
:Entity_EDL_0000031	type	Person
:Entity_EDL_0000031	nominal_mention	"people"	syria_latimes__1000-01-01__timeline:2224-2229	1.0
:Entity_EDL_0000031	link	NIL000000023
:Entity_EDL_0000032	type	GeopoliticalEntity
:Entity_EDL_0000032	canonical_mention	"Libya"	syria_latimes__1000-01-01__timeline:9661-9665	1.0
:Entity_EDL_0000032	mention	"Libya"	syria_latimes__1000-01-01__timeline:9661-9665	1.0
:Entity_EDL_0000032	link	2215636
:Entity_EDL_0000033	type	Person
:Entity_EDL_0000033	canonical_mention	"women"	syria_dailystar__1000-01-01__timeline:966-970	1.0
:Entity_EDL_0000033	nominal_mention	"women"	syria_dailystar__1000-01-01__timeline:966-970	1.0
:Entity_EDL_0000033	link	NIL000000024
:Entity_EDL_0000034	type	Facility
:Entity_EDL_0000034	canonical_mention	"houses"	syria_latimes__1000-01-01__timeline:4582-4587	1.0
:Entity_EDL_0000034	nominal_mention	"houses"	syria_latimes__1000-01-01__timeline:4582-4587	1.0
:Entity_EDL_0000034	link	NIL000000025
:Entity_EDL_0000035	type	Person
:Entity_EDL_0000035	nominal_mention	"protesters"	syria_latimes__1000-01-01__timeline:3119-3128	1.0
:Entity_EDL_0000035	link	NIL000000026
:Entity_EDL_0000036	type	Organization
:Entity_EDL_0000036	canonical_mention	"Free Syrian Army"	syria_washington__1000-01-01__timeline:975-990	1.0
:Entity_EDL_0000036	mention	"Free Syrian Army"	syria_washington__1000-01-01__timeline:975-990	1.0
:Entity_EDL_0000036	link	NIL000000027
:Entity_EDL_0000037	type	Person
:Entity_EDL_0000037	canonical_mention	"Manaf Tlass"	syria_bbc__1000-01-01__timeline:2987-2997	1.0
:Entity_EDL_0000037	mention	"Manaf Tlass"	syria_bbc__1000-01-01__timeline:2987-2997	1.0
:Entity_EDL_0000037	link	NIL000000028
:Entity_EDL_0000038	type	Person
:Entity_EDL_0000038	canonical_mention	"people"	syria_bbc__1000-01-01__timeline:1109-1114	1.0
:Entity_EDL_0000038	nominal_mention	"people"	syria_bbc__1000-01-01__timeline:1109-1114	1.0
:Entity_EDL_0000038	link	NIL000000029
:Entity_EDL_0000039	type	GeopoliticalEntity
:Entity_EDL_0000039	nominal_mention	"cities"	syria_latimes__1000-01-01__timeline:3878-3883	1.0
:Entity_EDL_0000039	link	NIL000000030
:Entity_EDL_0000040	type	Vehicle
:Entity_EDL_0000040	nominal_mention	"tanks"	syria_washington__1000-01-01__timeline:444-448	1.0
:Entity_EDL_0000040	link	NIL000000031
:Entity_EDL_0000041	type	Weapon
:Entity_EDL_0000041	canonical_mention	"tear gas"	syria_latimes__1000-01-01__timeline:936-943	1.0
:Entity_EDL_0000041	nominal_mention	"tear gas"	syria_latimes__1000-01-01__timeline:936-943	1.0
:Entity_EDL_0000041	link	NIL000000032
:Entity_EDL_0000042	type	Location
:Entity_EDL_0000042	nominal_mention	"heart"	syria_latimes__1000-01-01__timeline:12899-12903	1.0
:Entity_EDL_0000042	link	NIL000000033
:Entity_EDL_0000043	type	Person
:Entity_EDL_0000043	canonical_mention	"Riad Hijab"	syria_dailystar__1000-01-01__timeline:2671-2680	1.0
:Entity_EDL_0000043	mention	"Riad Hijab"	syria_dailystar__1000-01-01__timeline:2671-2680	1.0
:Entity_EDL_0000043	link	NIL000000034
:Entity_EDL_0000044	type	Person
:Entity_EDL_0000044	nominal_mention	"activists"	syria_latimes__1000-01-01__timeline:4606-4614	1.0
:Entity_EDL_0000044	link	NIL000000035
:Entity_EDL_0000045	type	Person
:Entity_EDL_0000045	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:8124-8129	0.000
:Entity_EDL_0000045	link	NIL000000036
:Entity_EDL_0000046	type	Person
:Entity_EDL_0000046	nominal_mention	"people"	syria_washington__1000-01-01__timeline:1720-1725	1.0
:Entity_EDL_0000046	link	NIL000000037
:Entity_EDL_0000047	type	GeopoliticalEntity
:Entity_EDL_0000047	canonical_mention	"Homs"	syria_latimes__1000-01-01__timeline:3856-3859	1.0
:Entity_EDL_0000047	mention	"Homs"	syria_latimes__1000-01-01__timeline:3856-3859	1.0
:Entity_EDL_0000047	link	169577
:Entity_EDL_0000048	type	GeopoliticalEntity
:Entity_EDL_0000048	nominal_mention	"country"	syria_latimes__1000-01-01__timeline:6971-6977	1.0
:Entity_EDL_0000048	link	NIL000000038
:Entity_EDL_0000049	type	Person
:Entity_EDL_0000049	canonical_mention	"delegation"	syria_latimes__1000-01-01__timeline:7089-7098	1.0
:Entity_EDL_0000049	nominal_mention	"delegation"	syria_latimes__1000-01-01__timeline:7089-7098	1.0
:Entity_EDL_0000049	link	NIL000000039
:Entity_EDL_0000050	type	Person
:Entity_EDL_0000050	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:909-914	0.000
:Entity_EDL_0000050	link	NIL000000040
:Entity_EDL_0000051	type	Person
:Entity_EDL_0000051	canonical_mention	"them"	syria_latimes__1000-01-01__timeline:971-974	1.0
:Entity_EDL_0000051	pronominal_mention	"them"	syria_latimes__1000-01-01__timeline:971-974	1.0
:Entity_EDL_0000051	link	NIL000000041
:Entity_EDL_0000052	type	Weapon
:Entity_EDL_0000052	canonical_mention	"artillery"	syria_latimes__1000-01-01__timeline:11467-11475	1.0
:Entity_EDL_0000052	nominal_mention	"artillery"	syria_latimes__1000-01-01__timeline:11467-11475	1.0
:Entity_EDL_0000052	link	NIL000000042
:Entity_EDL_0000053	type	Person
:Entity_EDL_0000053	canonical_mention	"crowds"	syria_bbc__1000-01-01__timeline:161-166	1.0
:Entity_EDL_0000053	nominal_mention	"crowds"	syria_bbc__1000-01-01__timeline:161-166	1.0
:Entity_EDL_0000053	link	NIL000000043
:Entity_EDL_0000054	type	Person
:Entity_EDL_0000054	nominal_mention	"deserter"	syria_dailystar__1000-01-01__timeline:446-453	1.0
:Entity_EDL_0000054	link	NIL000000044
:Entity_EDL_0000055	type	Person
:Entity_EDL_0000055	nominal_mention	"protesters"	syria_latimes__1000-01-01__timeline:4299-4308	1.0
:Entity_EDL_0000055	link	NIL000000045
:Entity_EDL_0000056	type	GeopoliticalEntity
:Entity_EDL_0000056	nominal_mention	"members"	syria_latimes__1000-01-01__timeline:7821-7827	1.0
:Entity_EDL_0000056	link	NIL000000046
:Entity_EDL_0000057	type	Weapon
:Entity_EDL_0000057	canonical_mention	"weaponry"	syria_washington__1000-01-01__timeline:1843-1850	1.0
:Entity_EDL_0000057	nominal_mention	"weaponry"	syria_washington__1000-01-01__timeline:1843-1850	1.0
:Entity_EDL_0000057	link	NIL000000047
:Entity_EDL_0000058	type	Facility
:Entity_EDL_0000058	nominal_mention	"streets"	syria_latimes__1000-01-01__timeline:814-820	1.0
:Entity_EDL_0000058	link	NIL000000048
:Entity_EDL_0000059	type	Person
:Entity_EDL_0000059	canonical_mention	"people"	syria_washington__1000-01-01__timeline:219-224	1.0
:Entity_EDL_0000059	nominal_mention	"people"	syria_washington__1000-01-01__timeline:219-224	1.0
:Entity_EDL_0000059	link	NIL000000049
:Entity_EDL_0000060	type	Facility
:Entity_EDL_0000060	canonical_mention	"facility"	syria_washington__1000-01-01__timeline:3531-3538	1.0
:Entity_EDL_0000060	nominal_mention	"facility"	syria_washington__1000-01-01__timeline:3531-3538	1.0
:Entity_EDL_0000060	link	NIL000000050
:Entity_EDL_0000061	type	Facility
:Entity_EDL_0000061	canonical_mention	"barriers"	syria_latimes__1000-01-01__timeline:13821-13828	1.0
:Entity_EDL_0000061	nominal_mention	"barriers"	syria_latimes__1000-01-01__timeline:13821-13828	1.0
:Entity_EDL_0000061	link	NIL000000051
:Entity_EDL_0000062	type	Person
:Entity_EDL_0000062	nominal_mention	"troops"	syria_latimes__1000-01-01__timeline:4455-4460	1.0
:Entity_EDL_0000062	link	NIL000000052
:Entity_EDL_0000063	type	Organization
:Entity_EDL_0000063	canonical_mention	"military"	syria_sbs__1000-01-01__timeline:1217-1224	1.0
:Entity_EDL_0000063	nominal_mention	"military"	syria_sbs__1000-01-01__timeline:1217-1224	1.0
:Entity_EDL_0000063	link	NIL000000053
:Entity_EDL_0000064	type	GeopoliticalEntity
:Entity_EDL_0000064	nominal_mention	"country"	syria_latimes__1000-01-01__timeline:8408-8414	1.0
:Entity_EDL_0000064	link	NIL000000054
:Entity_EDL_0000065	type	Person
:Entity_EDL_0000065	canonical_mention	"minister"	syria_bbc__1000-01-01__timeline:4108-4115	1.0
:Entity_EDL_0000065	nominal_mention	"minister"	syria_bbc__1000-01-01__timeline:4108-4115	1.0
:Entity_EDL_0000065	link	NIL000000055
:Entity_EDL_0000066	type	Person
:Entity_EDL_0000066	canonical_mention	"officers"	syria_latimes__1000-01-01__timeline:4047-4054	1.0
:Entity_EDL_0000066	nominal_mention	"officers"	syria_latimes__1000-01-01__timeline:4047-4054	1.0
:Entity_EDL_0000066	link	NIL000000056
:Entity_EDL_0000067	type	GeopoliticalEntity
:Entity_EDL_0000067	nominal_mention	"cities"	syria_latimes__1000-01-01__timeline:2678-2683	1.0
:Entity_EDL_0000067	link	NIL000000057
:Entity_EDL_0000068	type	Organization
:Entity_EDL_0000068	nominal_mention	"army"	syria_bbc__1000-01-01__timeline:1171-1174	1.0
:Entity_EDL_0000068	link	NIL000000058
:Entity_EDL_0000069	type	Location
:Entity_EDL_0000069	canonical_mention	"regions"	syria_latimes__1000-01-01__timeline:9215-9221	1.0
:Entity_EDL_0000069	nominal_mention	"regions"	syria_latimes__1000-01-01__timeline:9215-9221	1.0
:Entity_EDL_0000069	link	NIL000000059
:Entity_EDL_0000070	type	GeopoliticalEntity
:Entity_EDL_0000070	mention	"Daraa"	syria_washington__1000-01-01__timeline:352-356	1.0
:Entity_EDL_0000070	link	170905
:Entity_EDL_0000071	type	Vehicle
:Entity_EDL_0000071	canonical_mention	"tank"	syria_latimes__1000-01-01__timeline:11481-11484	1.0
:Entity_EDL_0000071	nominal_mention	"tank"	syria_latimes__1000-01-01__timeline:11481-11484	1.0
:Entity_EDL_0000071	link	NIL000000060
:Entity_EDL_0000072	type	GeopoliticalEntity
:Entity_EDL_0000072	canonical_mention	"neighborhood"	syria_latimes__1000-01-01__timeline:11509-11520	1.0
:Entity_EDL_0000072	nominal_mention	"neighborhood"	syria_latimes__1000-01-01__timeline:11509-11520	1.0
:Entity_EDL_0000072	link	NIL000000061
:Entity_EDL_0000073	type	Vehicle
:Entity_EDL_0000073	nominal_mention	"tanks"	syria_latimes__1000-01-01__timeline:5382-5386	1.0
:Entity_EDL_0000073	link	NIL000000062
:Entity_EDL_0000074	type	Facility
:Entity_EDL_0000074	canonical_mention	"base"	syria_sbs__1000-01-01__timeline:1850-1853	1.0
:Entity_EDL_0000074	nominal_mention	"base"	syria_sbs__1000-01-01__timeline:1850-1853	1.0
:Entity_EDL_0000074	link	NIL000000063
:Entity_EDL_0000075	type	Person
:Entity_EDL_0000075	canonical_mention	"leader"	syria_washington__1000-01-01__timeline:4712-4717	1.0
:Entity_EDL_0000075	nominal_mention	"leader"	syria_washington__1000-01-01__timeline:4712-4717	1.0
:Entity_EDL_0000075	link	NIL000000064
:Entity_EDL_0000076	type	Person
:Entity_EDL_0000076	nominal_mention	"people"	syria_latimes__1000-01-01__timeline:5873-5878	1.0
:Entity_EDL_0000076	link	NIL000000065
:Entity_EDL_0000077	type	Person
:Entity_EDL_0000077	nominal_mention	"protesters"	syria_latimes__1000-01-01__timeline:4069-4078	1.0
:Entity_EDL_0000077	link	NIL000000066
:Entity_EDL_0000078	type	Facility
:Entity_EDL_0000078	canonical_mention	"base"	syria_dailystar__1000-01-01__timeline:516-519	1.0
:Entity_EDL_0000078	nominal_mention	"base"	syria_dailystar__1000-01-01__timeline:516-519	1.0
:Entity_EDL_0000078	link	NIL000000067
:Entity_EDL_0000079	type	GeopoliticalEntity
:Entity_EDL_0000079	nominal_mention	"city"	syria_latimes__1000-01-01__timeline:9122-9125	1.0
:Entity_EDL_0000079	link	NIL000000068
:Entity_EDL_0000080	type	Person
:Entity_EDL_0000080	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:5010-5015	0.000
:Entity_EDL_0000080	link	NIL000000069
:Entity_EDL_0000081	type	GeopoliticalEntity
:Entity_EDL_0000081	mention	"Latakia"	syria_latimes__1000-01-01__timeline:5847-5853	1.0
:Entity_EDL_0000081	link	173576
:Entity_EDL_0000082	type	GeopoliticalEntity
:Entity_EDL_0000082	nominal_mention	"country"	syria_latimes__1000-01-01__timeline:11201-11207	1.0
:Entity_EDL_0000082	link	NIL000000070
:Entity_EDL_0000083	type	GeopoliticalEntity
:Entity_EDL_0000083	nominal_mention	"villages"	syria_bbc__1000-01-01__timeline:876-883	1.0
:Entity_EDL_0000083	link	NIL000000071
:Entity_EDL_0000084	type	Person
:Entity_EDL_0000084	canonical_mention	"Scores"	syria_washington__1000-01-01__timeline:421-426	1.0
:Entity_EDL_0000084	pronominal_mention	"Scores"	syria_washington__1000-01-01__timeline:421-426	1.0
:Entity_EDL_0000084	link	NIL000000072
:Entity_EDL_0000085	type	Person
:Entity_EDL_0000085	pronominal_mention	"them"	syria_latimes__1000-01-01__timeline:1139-1142	1.0
:Entity_EDL_0000085	link	NIL000000073
:Entity_EDL_0000086	type	Person
:Entity_EDL_0000086	nominal_mention	"officials"	syria_latimes__1000-01-01__timeline:12967-12975	1.0
:Entity_EDL_0000086	link	NIL000000074
:Entity_EDL_0000087	type	GeopoliticalEntity
:Entity_EDL_0000087	canonical_mention	"capital"	syria_dailystar__1000-01-01__timeline:1671-1677	1.0
:Entity_EDL_0000087	nominal_mention	"capital"	syria_dailystar__1000-01-01__timeline:1671-1677	1.0
:Entity_EDL_0000087	link	NIL000000075
:Entity_EDL_0000088	type	GeopoliticalEntity
:Entity_EDL_0000088	canonical_mention	"village"	syria_bbc__1000-01-01__timeline:3405-3411	1.0
:Entity_EDL_0000088	nominal_mention	"village"	syria_bbc__1000-01-01__timeline:3405-3411	1.0
:Entity_EDL_0000088	link	NIL000000076
:Entity_EDL_0000089	type	Person
:Entity_EDL_0000089	nominal_mention	"protesters"	syria_latimes__1000-01-01__timeline:7016-7025	1.0
:Entity_EDL_0000089	link	NIL000000077
:Entity_EDL_0000090	type	Facility
:Entity_EDL_0000090	canonical_mention	"headquarters"	syria_bbc__1000-01-01__timeline:3960-3971	1.0
:Entity_EDL_0000090	nominal_mention	"headquarters"	syria_bbc__1000-01-01__timeline:3960-3971	1.0
:Entity_EDL_0000090	link	NIL000000078
:Entity_EDL_0000091	type	Person
:Entity_EDL_0000091	nominal_mention	"protesters"	syria_latimes__1000-01-01__timeline:3414-3423	1.0
:Entity_EDL_0000091	link	NIL000000079
:Entity_EDL_0000092	type	Person
:Entity_EDL_0000092	nominal_mention	"demonstrators"	syria_latimes__1000-01-01__timeline:361-373	1.0
:Entity_EDL_0000092	link	NIL000000080
:Entity_EDL_0000093	type	Person
:Entity_EDL_0000093	nominal_mention	"rebel"	syria_sbs__1000-01-01__timeline:2265-2269	1.0
:Entity_EDL_0000093	link	NIL000000081
:Entity_EDL_0000094	type	Person
:Entity_EDL_0000094	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:5837-5842	0.000
:Entity_EDL_0000094	link	NIL000000082
:Entity_EDL_0000095	type	GeopoliticalEntity
:Entity_EDL_0000095	nominal_mention	"suburb"	syria_latimes__1000-01-01__timeline:13547-13552	1.0
:Entity_EDL_0000095	link	NIL000000083
:Entity_EDL_0000096	type	Organization
:Entity_EDL_0000096	nominal_mention	"groups"	syria_bbc__1000-01-01__timeline:3722-3727	1.0
:Entity_EDL_0000096	link	NIL000000084
:Entity_EDL_0000097	type	Person
:Entity_EDL_0000097	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:6471-6476	1.0
:Entity_EDL_0000097	link	NIL000000085
:Entity_EDL_0000098	type	Facility
:Entity_EDL_0000098	canonical_mention	"headquarters"	syria_latimes__1000-01-01__timeline:10776-10787	1.0
:Entity_EDL_0000098	nominal_mention	"headquarters"	syria_latimes__1000-01-01__timeline:10776-10787	1.0
:Entity_EDL_0000098	link	NIL000000086
:Entity_EDL_0000099	type	GeopoliticalEntity
:Entity_EDL_0000099	nominal_mention	"capital"	syria_sbs__1000-01-01__timeline:1271-1277	1.0
:Entity_EDL_0000099	link	NIL000000087
:Entity_EDL_0000100	type	GeopoliticalEntity
:Entity_EDL_0000100	canonical_mention	"Hama"	syria_latimes__1000-01-01__timeline:4483-4486	1.0
:Entity_EDL_0000100	mention	"Hama"	syria_latimes__1000-01-01__timeline:4483-4486	1.0
:Entity_EDL_0000100	link	170017
:Entity_EDL_0000101	type	GeopoliticalEntity
:Entity_EDL_0000101	nominal_mention	"government"	syria_latimes__1000-01-01__timeline:9032-9041	1.0
:Entity_EDL_0000101	link	NIL000000088
:Entity_EDL_0000102	type	Person
:Entity_EDL_0000102	canonical_mention	"thousands"	syria_latimes__1000-01-01__timeline:2096-2104	1.0
:Entity_EDL_0000102	pronominal_mention	"thousands"	syria_latimes__1000-01-01__timeline:2096-2104	1.0
:Entity_EDL_0000102	link	NIL000000089
:Entity_EDL_0000103	type	GeopoliticalEntity
:Entity_EDL_0000103	canonical_mention	"Houla"	syria_washington__1000-01-01__timeline:2310-2314	1.0
:Entity_EDL_0000103	mention	"Houla"	syria_washington__1000-01-01__timeline:2310-2314	1.0
:Entity_EDL_0000103	link	11287703
:Entity_EDL_0000104	type	GeopoliticalEntity
:Entity_EDL_0000104	nominal_mention	"cities"	syria_latimes__1000-01-01__timeline:159-164	1.0
:Entity_EDL_0000104	link	NIL000000090
:Entity_EDL_0000105	type	Person
:Entity_EDL_0000105	nominal_mention	"forces"	syria_washington__1000-01-01__timeline:1562-1567	0.000
:Entity_EDL_0000105	link	NIL000000091
:Entity_EDL_0000106	type	Weapon
:Entity_EDL_0000106	nominal_mention	"weapons"	syria_washington__1000-01-01__timeline:4473-4479	1.0
:Entity_EDL_0000106	link	NIL000000092
:Entity_EDL_0000107	type	Organization
:Entity_EDL_0000107	nominal_mention	"coalition"	syria_latimes__1000-01-01__timeline:14837-14845	1.0
:Entity_EDL_0000107	link	NIL000000093
:Entity_EDL_0000108	type	GeopoliticalEntity
:Entity_EDL_0000108	nominal_mention	"city"	syria_latimes__1000-01-01__timeline:5474-5477	1.0
:Entity_EDL_0000108	link	NIL000000094
:Entity_EDL_0000109	type	Vehicle
:Entity_EDL_0000109	nominal_mention	"jet"	syria_latimes__1000-01-01__timeline:12249-12251	1.0
:Entity_EDL_0000109	link	NIL000000095
:Entity_EDL_0000110	type	Person
:Entity_EDL_0000110	nominal_mention	"people"	syria_bbc__1000-01-01__timeline:3290-3295	1.0
:Entity_EDL_0000110	link	NIL000000096
:Entity_EDL_0000111	type	Organization
:Entity_EDL_0000111	pronominal_mention	"it"	syria_latimes__1000-01-01__timeline:15505-15506	1.0
:Entity_EDL_0000111	link	NIL000000097
:Entity_EDL_0000112	type	Organization
:Entity_EDL_0000112	canonical_mention	"military"	syria_washington__1000-01-01__timeline:2195-2202	1.0
:Entity_EDL_0000112	nominal_mention	"military"	syria_washington__1000-01-01__timeline:2195-2202	1.0
:Entity_EDL_0000112	link	NIL000000098
:Entity_EDL_0000113	type	Person
:Entity_EDL_0000113	canonical_mention	"20"	syria_latimes__1000-01-01__timeline:4101-4102	1.0
:Entity_EDL_0000113	pronominal_mention	"20"	syria_latimes__1000-01-01__timeline:4101-4102	1.0
:Entity_EDL_0000113	link	NIL000000099
:Entity_EDL_0000114	type	GeopoliticalEntity
:Entity_EDL_0000114	nominal_mention	"cities"	syria_latimes__1000-01-01__timeline:4367-4372	1.0
:Entity_EDL_0000114	link	NIL000000100
:Entity_EDL_0000115	type	Person
:Entity_EDL_0000115	canonical_mention	"bombers"	syria_bbc__1000-01-01__timeline:2103-2109	1.0
:Entity_EDL_0000115	nominal_mention	"bombers"	syria_bbc__1000-01-01__timeline:2103-2109	1.0
:Entity_EDL_0000115	link	NIL000000101
:Entity_EDL_0000116	type	Person
:Entity_EDL_0000116	nominal_mention	"people"	syria_latimes__1000-01-01__timeline:4777-4782	1.0
:Entity_EDL_0000116	link	NIL000000102
:Entity_EDL_0000117	type	Person
:Entity_EDL_0000117	nominal_mention	"forces"	syria_washington__1000-01-01__timeline:4405-4410	0.000
:Entity_EDL_0000117	link	NIL000000103
:Entity_EDL_0000118	type	Person
:Entity_EDL_0000118	nominal_mention	"forces"	syria_washington__1000-01-01__timeline:3444-3449	0.000
:Entity_EDL_0000118	link	NIL000000104
:Entity_EDL_0000119	type	Person
:Entity_EDL_0000119	canonical_mention	"forces"	syria_bbc__1000-01-01__timeline:1285-1290	1.0
:Entity_EDL_0000119	nominal_mention	"forces"	syria_bbc__1000-01-01__timeline:1285-1290	1.0
:Entity_EDL_0000119	link	NIL000000105
:Entity_EDL_0000120	type	Person
:Entity_EDL_0000120	nominal_mention	"forces"	syria_washington__1000-01-01__timeline:194-199	0.000
:Entity_EDL_0000120	link	NIL000000106
:Entity_EDL_0000121	type	Person
:Entity_EDL_0000121	nominal_mention	"people"	syria_latimes__1000-01-01__timeline:14409-14414	1.0
:Entity_EDL_0000121	link	NIL000000107
:Entity_EDL_0000122	type	Location
:Entity_EDL_0000122	canonical_mention	"border"	syria_washington__1000-01-01__timeline:1603-1608	1.0
:Entity_EDL_0000122	nominal_mention	"border"	syria_washington__1000-01-01__timeline:1603-1608	1.0
:Entity_EDL_0000122	link	NIL000000108
:Entity_EDL_0000123	type	Organization
:Entity_EDL_0000123	mention	"Arab League"	syria_latimes__1000-01-01__timeline:7790-7800	1.0
:Entity_EDL_0000123	link	20000138
:Entity_EDL_0000124	type	GeopoliticalEntity
:Entity_EDL_0000124	canonical_mention	"US"	syria_sbs__1000-01-01__timeline:124-125	1.0
:Entity_EDL_0000124	mention	"US"	syria_sbs__1000-01-01__timeline:124-125	1.0
:Entity_EDL_0000124	link	6252001
:Entity_EDL_0000125	type	GeopoliticalEntity
:Entity_EDL_0000125	nominal_mention	"capital"	syria_dailystar__1000-01-01__timeline:2142-2148	1.0
:Entity_EDL_0000125	link	NIL000000109
:Entity_EDL_0000126	type	Person
:Entity_EDL_0000126	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:1954-1959	0.000
:Entity_EDL_0000126	link	NIL000000110
:Entity_EDL_0000127	type	Organization
:Entity_EDL_0000127	nominal_mention	"military"	syria_dailystar__1000-01-01__timeline:2088-2095	1.0
:Entity_EDL_0000127	link	NIL000000111
:Entity_EDL_0000128	type	Person
:Entity_EDL_0000128	canonical_mention	"dozens"	syria_washington__1000-01-01__timeline:2879-2884	1.0
:Entity_EDL_0000128	nominal_mention	"dozens"	syria_washington__1000-01-01__timeline:2879-2884	1.0
:Entity_EDL_0000128	link	NIL000000112
:Entity_EDL_0000129	type	Person
:Entity_EDL_0000129	canonical_mention	"forces"	syria_dailystar__1000-01-01__timeline:1616-1621	1.0
:Entity_EDL_0000129	nominal_mention	"forces"	syria_dailystar__1000-01-01__timeline:1616-1621	1.0
:Entity_EDL_0000129	link	NIL000000113
:Entity_EDL_0000130	type	Person
:Entity_EDL_0000130	canonical_mention	"Daoud Rajiha"	syria_bbc__1000-01-01__timeline:3796-3807	1.0
:Entity_EDL_0000130	mention	"Daoud Rajiha"	syria_bbc__1000-01-01__timeline:3796-3807	1.0
:Entity_EDL_0000130	link	NIL000000114
:Entity_EDL_0000131	type	Person
:Entity_EDL_0000131	nominal_mention	"forces"	syria_washington__1000-01-01__timeline:326-331	0.000
:Entity_EDL_0000131	link	NIL000000115
:Entity_EDL_0000132	type	Organization
:Entity_EDL_0000132	canonical_mention	"movement"	syria_latimes__1000-01-01__timeline:2839-2846	1.0
:Entity_EDL_0000132	nominal_mention	"movement"	syria_latimes__1000-01-01__timeline:2839-2846	1.0
:Entity_EDL_0000132	link	NIL000000116
:Entity_EDL_0000133	type	Person
:Entity_EDL_0000133	nominal_mention	"rebels"	syria_washington__1000-01-01__timeline:3822-3827	1.0
:Entity_EDL_0000133	link	NIL000000117
:Entity_EDL_0000134	type	Person
:Entity_EDL_0000134	nominal_mention	"people"	syria_washington__1000-01-01__timeline:4297-4302	1.0
:Entity_EDL_0000134	link	NIL000000118
:Entity_EDL_0000135	type	Person
:Entity_EDL_0000135	canonical_mention	"people"	syria_dailystar__1000-01-01__timeline:928-933	1.0
:Entity_EDL_0000135	nominal_mention	"people"	syria_dailystar__1000-01-01__timeline:928-933	1.0
:Entity_EDL_0000135	link	NIL000000119
:Entity_EDL_0000136	type	Person
:Entity_EDL_0000136	nominal_mention	"Syrians"	syria_latimes__1000-01-01__timeline:6671-6677	1.0
:Entity_EDL_0000136	link	NIL000000120
:Entity_EDL_0000137	type	Person
:Entity_EDL_0000137	nominal_mention	"people"	syria_latimes__1000-01-01__timeline:9083-9088	1.0
:Entity_EDL_0000137	link	NIL000000121
:Entity_EDL_0000138	type	GeopoliticalEntity
:Entity_EDL_0000138	nominal_mention	"city"	syria_latimes__1000-01-01__timeline:61-64	1.0
:Entity_EDL_0000138	link	NIL000000122
:Entity_EDL_0000139	type	Location
:Entity_EDL_0000139	canonical_mention	"northwest"	syria_latimes__1000-01-01__timeline:9917-9925	1.0
:Entity_EDL_0000139	nominal_mention	"northwest"	syria_latimes__1000-01-01__timeline:9917-9925	1.0
:Entity_EDL_0000139	link	NIL000000123
:Entity_EDL_0000140	type	GeopoliticalEntity
:Entity_EDL_0000140	nominal_mention	"country"	syria_latimes__1000-01-01__timeline:11836-11842	1.0
:Entity_EDL_0000140	link	NIL000000124
:Entity_EDL_0000141	type	GeopoliticalEntity
:Entity_EDL_0000141	nominal_mention	"country"	syria_latimes__1000-01-01__timeline:4754-4760	1.0
:Entity_EDL_0000141	link	NIL000000125
:Entity_EDL_0000142	type	Person
:Entity_EDL_0000142	nominal_mention	"Rebels"	syria_washington__1000-01-01__timeline:2465-2470	1.0
:Entity_EDL_0000142	link	NIL000000126
:Entity_EDL_0000143	type	Facility
:Entity_EDL_0000143	nominal_mention	"headquarters"	syria_latimes__1000-01-01__timeline:13864-13875	1.0
:Entity_EDL_0000143	link	NIL000000127
:Entity_EDL_0000144	type	Person
:Entity_EDL_0000144	pronominal_mention	"Thousands"	syria_latimes__1000-01-01__timeline:3796-3804	1.0
:Entity_EDL_0000144	link	NIL000000128
:Entity_EDL_0000145	type	Facility
:Entity_EDL_0000145	canonical_mention	"stadium"	syria_latimes__1000-01-01__timeline:5887-5893	1.0
:Entity_EDL_0000145	nominal_mention	"stadium"	syria_latimes__1000-01-01__timeline:5887-5893	1.0
:Entity_EDL_0000145	link	NIL000000129
:Entity_EDL_0000146	type	Person
:Entity_EDL_0000146	canonical_mention	"soldiers"	syria_bbc__1000-01-01__timeline:773-780	1.0
:Entity_EDL_0000146	nominal_mention	"soldiers"	syria_bbc__1000-01-01__timeline:773-780	1.0
:Entity_EDL_0000146	link	NIL000000130
:Entity_EDL_0000147	type	Person
:Entity_EDL_0000147	nominal_mention	"observers"	syria_latimes__1000-01-01__timeline:12540-12548	1.0
:Entity_EDL_0000147	link	NIL000000131
:Entity_EDL_0000148	type	Person
:Entity_EDL_0000148	canonical_mention	"protesters"	syria_bbc__1000-01-01__timeline:109-118	1.0
:Entity_EDL_0000148	nominal_mention	"protesters"	syria_bbc__1000-01-01__timeline:109-118	1.0
:Entity_EDL_0000148	link	NIL000000132
:Entity_EDL_0000149	type	Vehicle
:Entity_EDL_0000149	canonical_mention	"bulldozers"	syria_latimes__1000-01-01__timeline:4466-4475	1.0
:Entity_EDL_0000149	nominal_mention	"bulldozers"	syria_latimes__1000-01-01__timeline:4466-4475	1.0
:Entity_EDL_0000149	link	NIL000000133
:Entity_EDL_0000150	type	Person
:Entity_EDL_0000150	nominal_mention	"protesters"	syria_latimes__1000-01-01__timeline:11282-11291	1.0
:Entity_EDL_0000150	link	NIL000000134
:Entity_EDL_0000151	type	Person
:Entity_EDL_0000151	nominal_mention	"minister"	syria_latimes__1000-01-01__timeline:13334-13341	1.0
:Entity_EDL_0000151	link	NIL000000135
:Entity_EDL_0000152	type	Vehicle
:Entity_EDL_0000152	canonical_mention	"tanks"	syria_bbc__1000-01-01__timeline:3385-3389	1.0
:Entity_EDL_0000152	nominal_mention	"tanks"	syria_bbc__1000-01-01__timeline:3385-3389	1.0
:Entity_EDL_0000152	link	NIL000000136
:Entity_EDL_0000153	type	GeopoliticalEntity
:Entity_EDL_0000153	nominal_mention	"sides"	syria_latimes__1000-01-01__timeline:10814-10818	1.0
:Entity_EDL_0000153	link	NIL000000137
:Entity_EDL_0000154	type	Person
:Entity_EDL_0000154	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:3614-3619	1.0
:Entity_EDL_0000154	link	NIL000000138
:Entity_EDL_0000155	type	Person
:Entity_EDL_0000155	canonical_mention	"detainees"	syria_dailystar__1000-01-01__timeline:1413-1421	1.0
:Entity_EDL_0000155	nominal_mention	"detainees"	syria_dailystar__1000-01-01__timeline:1413-1421	1.0
:Entity_EDL_0000155	link	NIL000000139
:Entity_EDL_0000156	type	Person
:Entity_EDL_0000156	canonical_mention	"Assef Shawkat"	syria_bbc__1000-01-01__timeline:3824-3836	1.0
:Entity_EDL_0000156	mention	"Assef Shawkat"	syria_bbc__1000-01-01__timeline:3824-3836	1.0
:Entity_EDL_0000156	link	NIL000000140
:Entity_EDL_0000157	type	Facility
:Entity_EDL_0000157	nominal_mention	"building"	syria_washington__1000-01-01__timeline:2027-2034	1.0
:Entity_EDL_0000157	link	NIL000000141
:Entity_EDL_0000158	type	GeopoliticalEntity
:Entity_EDL_0000158	pronominal_mention	"where"	syria_latimes__1000-01-01__timeline:5715-5719	1.0
:Entity_EDL_0000158	link	NIL000000142
:Entity_EDL_0000159	type	Facility
:Entity_EDL_0000159	nominal_mention	"streets"	syria_latimes__1000-01-01__timeline:2143-2149	1.0
:Entity_EDL_0000159	link	NIL000000143
:Entity_EDL_0000160	type	Person
:Entity_EDL_0000160	canonical_mention	"34"	syria_latimes__1000-01-01__timeline:3444-3445	1.0
:Entity_EDL_0000160	pronominal_mention	"34"	syria_latimes__1000-01-01__timeline:3444-3445	1.0
:Entity_EDL_0000160	link	NIL000000144
:Entity_EDL_0000161	type	Person
:Entity_EDL_0000161	nominal_mention	"protesters"	syria_latimes__1000-01-01__timeline:4732-4741	1.0
:Entity_EDL_0000161	link	NIL000000145
:Entity_EDL_0000162	type	Person
:Entity_EDL_0000162	nominal_mention	"general"	syria_bbc__1000-01-01__timeline:3003-3009	1.0
:Entity_EDL_0000162	link	NIL000000146
:Entity_EDL_0000163	type	Person
:Entity_EDL_0000163	canonical_mention	"who"	syria_latimes__1000-01-01__timeline:916-918	1.0
:Entity_EDL_0000163	pronominal_mention	"who"	syria_latimes__1000-01-01__timeline:916-918	1.0
:Entity_EDL_0000163	link	NIL000000147
:Entity_EDL_0000164	type	Facility
:Entity_EDL_0000164	nominal_mention	"streets"	syria_latimes__1000-01-01__timeline:10264-10270	1.0
:Entity_EDL_0000164	link	NIL000000148
:Entity_EDL_0000165	type	Vehicle
:Entity_EDL_0000165	canonical_mention	"jet"	syria_latimes__1000-01-01__timeline:12024-12026	1.0
:Entity_EDL_0000165	nominal_mention	"jet"	syria_latimes__1000-01-01__timeline:12024-12026	1.0
:Entity_EDL_0000165	link	NIL000000149
:Entity_EDL_0000166	type	Vehicle
:Entity_EDL_0000166	canonical_mention	"gunships"	syria_dailystar__1000-01-01__timeline:2230-2237	1.0
:Entity_EDL_0000166	nominal_mention	"gunships"	syria_dailystar__1000-01-01__timeline:2230-2237	1.0
:Entity_EDL_0000166	link	NIL000000150
:Entity_EDL_0000167	type	Organization
:Entity_EDL_0000167	canonical_mention	"Syrian National Coalition for Opposition and Revolutionary Forces"	syria_latimes__1000-01-01__timeline:15089-15153	1.0
:Entity_EDL_0000167	mention	"Syrian National Coalition for Opposition and Revolutionary Forces"	syria_latimes__1000-01-01__timeline:15089-15153	1.0
:Entity_EDL_0000167	link	NIL000000151
:Entity_EDL_0000168	type	Person
:Entity_EDL_0000168	nominal_mention	"forces"	syria_washington__1000-01-01__timeline:4513-4518	1.0
:Entity_EDL_0000168	link	NIL000000152
:Entity_EDL_0000169	type	Person
:Entity_EDL_0000169	canonical_mention	"ambassador"	syria_latimes__1000-01-01__timeline:6865-6874	1.0
:Entity_EDL_0000169	nominal_mention	"ambassador"	syria_latimes__1000-01-01__timeline:6865-6874	1.0
:Entity_EDL_0000169	link	NIL000000153
:Entity_EDL_0000170	type	Facility
:Entity_EDL_0000170	canonical_mention	"bases"	syria_washington__1000-01-01__timeline:2489-2493	1.0
:Entity_EDL_0000170	nominal_mention	"bases"	syria_washington__1000-01-01__timeline:2489-2493	1.0
:Entity_EDL_0000170	link	NIL000000154
:Entity_EDL_0000171	type	Person
:Entity_EDL_0000171	nominal_mention	"forces"	syria_washington__1000-01-01__timeline:3793-3798	1.0
:Entity_EDL_0000171	link	NIL000000155
:Entity_EDL_0000172	type	Person
:Entity_EDL_0000172	canonical_mention	"officials"	syria_dailystar__1000-01-01__timeline:1780-1788	1.0
:Entity_EDL_0000172	nominal_mention	"officials"	syria_dailystar__1000-01-01__timeline:1780-1788	1.0
:Entity_EDL_0000172	link	NIL000000156
:Entity_EDL_0000173	type	Vehicle
:Entity_EDL_0000173	nominal_mention	"jet"	syria_dailystar__1000-01-01__timeline:2474-2476	0.000
:Entity_EDL_0000173	link	NIL000000157
:Entity_EDL_0000174	type	GeopoliticalEntity
:Entity_EDL_0000174	nominal_mention	"village"	syria_washington__1000-01-01__timeline:2299-2305	1.0
:Entity_EDL_0000174	link	NIL000000158
:Entity_EDL_0000175	type	Weapon
:Entity_EDL_0000175	canonical_mention	"weapons"	syria_latimes__1000-01-01__timeline:15287-15293	1.0
:Entity_EDL_0000175	nominal_mention	"weapons"	syria_latimes__1000-01-01__timeline:15287-15293	1.0
:Entity_EDL_0000175	link	NIL000000159
:Entity_EDL_0000176	type	Person
:Entity_EDL_0000176	canonical_mention	"200"	syria_washington__1000-01-01__timeline:2909-2911	1.0
:Entity_EDL_0000176	pronominal_mention	"200"	syria_washington__1000-01-01__timeline:2909-2911	1.0
:Entity_EDL_0000176	link	NIL000000160
:Entity_EDL_0000177	type	Location
:Entity_EDL_0000177	canonical_mention	"heart"	syria_latimes__1000-01-01__timeline:5397-5401	1.0
:Entity_EDL_0000177	nominal_mention	"heart"	syria_latimes__1000-01-01__timeline:5397-5401	1.0
:Entity_EDL_0000177	link	NIL000000161
:Entity_EDL_0000178	type	Organization
:Entity_EDL_0000178	canonical_mention	"NATO"	syria_washington__1000-01-01__timeline:1634-1637	1.0
:Entity_EDL_0000178	mention	"NATO"	syria_washington__1000-01-01__timeline:1634-1637	1.0
:Entity_EDL_0000178	link	20000153
:Entity_EDL_0000179	type	Person
:Entity_EDL_0000179	canonical_mention	"scores"	syria_latimes__1000-01-01__timeline:1496-1501	1.0
:Entity_EDL_0000179	nominal_mention	"scores"	syria_latimes__1000-01-01__timeline:1496-1501	1.0
:Entity_EDL_0000179	link	NIL000000162
:Entity_EDL_0000180	type	Organization
:Entity_EDL_0000180	nominal_mention	"group"	syria_bbc__1000-01-01__timeline:4314-4318	1.0
:Entity_EDL_0000180	link	NIL000000163
:Entity_EDL_0000181	type	Person
:Entity_EDL_0000181	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:10596-10601	0.000
:Entity_EDL_0000181	link	NIL000000164
:Entity_EDL_0000182	type	Person
:Entity_EDL_0000182	nominal_mention	"people"	syria_dailystar__1000-01-01__timeline:2542-2547	1.0
:Entity_EDL_0000182	link	NIL000000165
:Entity_EDL_0000183	type	Organization
:Entity_EDL_0000183	canonical_mention	"Syrian National Council SNC"	syria_sbs__1000-01-01__timeline:322-348	1.0
:Entity_EDL_0000183	mention	"Syrian National Council SNC"	syria_sbs__1000-01-01__timeline:322-348	1.0
:Entity_EDL_0000183	link	NIL000000166
:Entity_EDL_0000184	type	Person
:Entity_EDL_0000184	nominal_mention	"rebels"	syria_latimes__1000-01-01__timeline:13782-13787	1.0
:Entity_EDL_0000184	link	NIL000000167
:Entity_EDL_0000185	type	GeopoliticalEntity
:Entity_EDL_0000185	nominal_mention	"city"	syria_washington__1000-01-01__timeline:2620-2623	1.0
:Entity_EDL_0000185	link	NIL000000168
:Entity_EDL_0000186	type	GeopoliticalEntity
:Entity_EDL_0000186	canonical_mention	"country"	syria_latimes__1000-01-01__timeline:2242-2248	1.0
:Entity_EDL_0000186	nominal_mention	"country"	syria_latimes__1000-01-01__timeline:2242-2248	1.0
:Entity_EDL_0000186	link	NIL000000169
:Entity_EDL_0000187	type	Person
:Entity_EDL_0000187	pronominal_mention	"Some"	syria_bbc__1000-01-01__timeline:2685-2688	1.0
:Entity_EDL_0000187	link	NIL000000170
:Entity_EDL_0000188	type	Person
:Entity_EDL_0000188	nominal_mention	"people"	syria_latimes__1000-01-01__timeline:11532-11537	1.0
:Entity_EDL_0000188	link	NIL000000171
:Entity_EDL_0000189	type	Person
:Entity_EDL_0000189	canonical_mention	"Thousands"	syria_latimes__1000-01-01__timeline:783-791	1.0
:Entity_EDL_0000189	pronominal_mention	"Thousands"	syria_latimes__1000-01-01__timeline:783-791	1.0
:Entity_EDL_0000189	link	NIL000000172
:Entity_EDL_0000190	type	Person
:Entity_EDL_0000190	canonical_mention	"children"	syria_dailystar__1000-01-01__timeline:950-957	1.0
:Entity_EDL_0000190	nominal_mention	"children"	syria_dailystar__1000-01-01__timeline:950-957	1.0
:Entity_EDL_0000190	link	NIL000000173
:Entity_EDL_0000191	type	Location
:Entity_EDL_0000191	canonical_mention	"parts"	syria_washington__1000-01-01__timeline:3832-3836	1.0
:Entity_EDL_0000191	nominal_mention	"parts"	syria_washington__1000-01-01__timeline:3832-3836	1.0
:Entity_EDL_0000191	link	NIL000000174
:Entity_EDL_0000192	type	Person
:Entity_EDL_0000192	canonical_mention	"brotherinlaw Assef Shawkat"	syria_sbs__1000-01-01__timeline:806-831	1.0
:Entity_EDL_0000192	mention	"brotherinlaw Assef Shawkat"	syria_sbs__1000-01-01__timeline:806-831	1.0
:Entity_EDL_0000192	link	NIL000000175
:Entity_EDL_0000193	type	Organization
:Entity_EDL_0000193	nominal_mention	"regime"	syria_dailystar__1000-01-01__timeline:2725-2730	1.0
:Entity_EDL_0000193	link	NIL000000176
:Entity_EDL_0000194	type	GeopoliticalEntity
:Entity_EDL_0000194	canonical_mention	"archipelago"	syria_dailystar__1000-01-01__timeline:1439-1449	1.0
:Entity_EDL_0000194	nominal_mention	"archipelago"	syria_dailystar__1000-01-01__timeline:1439-1449	1.0
:Entity_EDL_0000194	link	NIL000000177
:Entity_EDL_0000195	type	Organization
:Entity_EDL_0000195	canonical_mention	"Syrian National Council SNC"	syria_dailystar__1000-01-01__timeline:322-348	1.0
:Entity_EDL_0000195	mention	"Syrian National Council SNC"	syria_dailystar__1000-01-01__timeline:322-348	1.0
:Entity_EDL_0000195	link	NIL000000178
:Entity_EDL_0000196	type	Person
:Entity_EDL_0000196	canonical_mention	"prisoners"	syria_washington__1000-01-01__timeline:93-101	1.0
:Entity_EDL_0000196	nominal_mention	"prisoners"	syria_washington__1000-01-01__timeline:93-101	1.0
:Entity_EDL_0000196	link	NIL000000179
:Entity_EDL_0000197	type	Person
:Entity_EDL_0000197	canonical_mention	"members"	syria_latimes__1000-01-01__timeline:10698-10704	1.0
:Entity_EDL_0000197	nominal_mention	"members"	syria_latimes__1000-01-01__timeline:10698-10704	1.0
:Entity_EDL_0000197	link	NIL000000180
:Entity_EDL_0000198	type	GeopoliticalEntity
:Entity_EDL_0000198	canonical_mention	"towns"	syria_latimes__1000-01-01__timeline:3636-3640	1.0
:Entity_EDL_0000198	nominal_mention	"towns"	syria_latimes__1000-01-01__timeline:3636-3640	1.0
:Entity_EDL_0000198	link	NIL000000181
:Entity_EDL_0000199	type	Vehicle
:Entity_EDL_0000199	canonical_mention	"tanks"	syria_washington__1000-01-01__timeline:341-345	1.0
:Entity_EDL_0000199	nominal_mention	"tanks"	syria_washington__1000-01-01__timeline:341-345	1.0
:Entity_EDL_0000199	link	NIL000000182
:Entity_EDL_0000200	type	GeopoliticalEntity
:Entity_EDL_0000200	nominal_mention	"capital"	syria_latimes__1000-01-01__timeline:15045-15051	1.0
:Entity_EDL_0000200	link	NIL000000183
:Entity_EDL_0000201	type	GeopoliticalEntity
:Entity_EDL_0000201	nominal_mention	"country"	syria_latimes__1000-01-01__timeline:9991-9997	1.0
:Entity_EDL_0000201	link	NIL000000184
:Entity_EDL_0000202	type	Person
:Entity_EDL_0000202	canonical_mention	"dissidents"	syria_latimes__1000-01-01__timeline:15069-15078	1.0
:Entity_EDL_0000202	nominal_mention	"dissidents"	syria_latimes__1000-01-01__timeline:15069-15078	1.0
:Entity_EDL_0000202	link	NIL000000185
:Entity_EDL_0000203	type	Weapon
:Entity_EDL_0000203	canonical_mention	"shell"	syria_bbc__1000-01-01__timeline:2709-2713	1.0
:Entity_EDL_0000203	nominal_mention	"shell"	syria_bbc__1000-01-01__timeline:2709-2713	1.0
:Entity_EDL_0000203	link	NIL000000186
:Entity_EDL_0000204	type	Person
:Entity_EDL_0000204	nominal_mention	"troops"	syria_latimes__1000-01-01__timeline:12729-12734	0.000
:Entity_EDL_0000204	link	NIL000000187
:Entity_EDL_0000205	type	Person
:Entity_EDL_0000205	canonical_mention	"children"	syria_bbc__1000-01-01__timeline:2673-2680	1.0
:Entity_EDL_0000205	nominal_mention	"children"	syria_bbc__1000-01-01__timeline:2673-2680	1.0
:Entity_EDL_0000205	link	NIL000000188
:Entity_EDL_0000206	type	Organization
:Entity_EDL_0000206	nominal_mention	"administration"	syria_latimes__1000-01-01__timeline:6824-6837	1.0
:Entity_EDL_0000206	link	NIL000000189
:Entity_EDL_0000207	type	GeopoliticalEntity
:Entity_EDL_0000207	canonical_mention	"Tresmeh"	syria_washington__1000-01-01__timeline:1730-1736	1.0
:Entity_EDL_0000207	mention	"Tresmeh"	syria_washington__1000-01-01__timeline:1730-1736	1.0
:Entity_EDL_0000207	link	NIL000000190
:Entity_EDL_0000208	type	Person
:Entity_EDL_0000208	canonical_mention	"many"	syria_washington__1000-01-01__timeline:2636-2639	1.0
:Entity_EDL_0000208	pronominal_mention	"many"	syria_washington__1000-01-01__timeline:2636-2639	1.0
:Entity_EDL_0000208	link	NIL000000191
:Entity_EDL_0000209	type	Person
:Entity_EDL_0000209	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:3000-3005	0.000
:Entity_EDL_0000209	link	NIL000000192
:Entity_EDL_0000210	type	Person
:Entity_EDL_0000210	nominal_mention	"civilians"	syria_washington__1000-01-01__timeline:2258-2266	1.0
:Entity_EDL_0000210	link	NIL000000193
:Entity_EDL_0000211	type	GeopoliticalEntity
:Entity_EDL_0000211	nominal_mention	"city"	syria_washington__1000-01-01__timeline:164-167	1.0
:Entity_EDL_0000211	link	NIL000000194
:Entity_EDL_0000212	type	Location
:Entity_EDL_0000212	canonical_mention	"site"	syria_latimes__1000-01-01__timeline:12576-12579	1.0
:Entity_EDL_0000212	nominal_mention	"site"	syria_latimes__1000-01-01__timeline:12576-12579	1.0
:Entity_EDL_0000212	link	NIL000000195
:Entity_EDL_0000213	type	GeopoliticalEntity
:Entity_EDL_0000213	nominal_mention	"cities"	syria_latimes__1000-01-01__timeline:11262-11267	1.0
:Entity_EDL_0000213	link	NIL000000196
:Entity_EDL_0000214	type	GeopoliticalEntity
:Entity_EDL_0000214	canonical_mention	"Cairo"	syria_latimes__1000-01-01__timeline:7813-7817	1.0
:Entity_EDL_0000214	mention	"Cairo"	syria_latimes__1000-01-01__timeline:7813-7817	1.0
:Entity_EDL_0000214	link	360630
:Entity_EDL_0000215	type	Person
:Entity_EDL_0000215	canonical_mention	"Police"	syria_latimes__1000-01-01__timeline:11-16	1.0
:Entity_EDL_0000215	nominal_mention	"Police"	syria_latimes__1000-01-01__timeline:11-16	1.0
:Entity_EDL_0000215	link	NIL000000197
:Entity_EDL_0000216	type	Location
:Entity_EDL_0000216	canonical_mention	"areas"	syria_latimes__1000-01-01__timeline:4867-4871	1.0
:Entity_EDL_0000216	nominal_mention	"areas"	syria_latimes__1000-01-01__timeline:4867-4871	1.0
:Entity_EDL_0000216	link	NIL000000198
:Entity_EDL_0000217	type	Person
:Entity_EDL_0000217	canonical_mention	"autocrat"	syria_latimes__1000-01-01__timeline:7715-7722	1.0
:Entity_EDL_0000217	nominal_mention	"autocrat"	syria_latimes__1000-01-01__timeline:7715-7722	1.0
:Entity_EDL_0000217	link	NIL000000199
:Entity_EDL_0000218	type	Person
:Entity_EDL_0000218	nominal_mention	"forces"	syria_bbc__1000-01-01__timeline:144-149	0.000
:Entity_EDL_0000218	link	NIL000000200
:Entity_EDL_0000219	type	GeopoliticalEntity
:Entity_EDL_0000219	nominal_mention	"city"	syria_washington__1000-01-01__timeline:460-463	1.0
:Entity_EDL_0000219	link	NIL000000201
:Entity_EDL_0000220	type	Organization
:Entity_EDL_0000220	canonical_mention	"groups"	syria_bbc__1000-01-01__timeline:324-329	1.0
:Entity_EDL_0000220	nominal_mention	"groups"	syria_bbc__1000-01-01__timeline:324-329	1.0
:Entity_EDL_0000220	link	NIL000000202
:Entity_EDL_0000221	type	Facility
:Entity_EDL_0000221	nominal_mention	"streets"	syria_latimes__1000-01-01__timeline:4135-4141	0.000
:Entity_EDL_0000221	link	NIL000000203
:Entity_EDL_0000222	type	Organization
:Entity_EDL_0000222	canonical_mention	"FSA"	syria_dailystar__1000-01-01__timeline:418-420	1.0
:Entity_EDL_0000222	mention	"FSA"	syria_dailystar__1000-01-01__timeline:418-420	1.0
:Entity_EDL_0000222	link	NIL000000204
:Entity_EDL_0000223	type	GeopoliticalEntity
:Entity_EDL_0000223	mention	"Aleppo"	syria_washington__1000-01-01__timeline:4433-4438	1.0
:Entity_EDL_0000223	link	170063
:Entity_EDL_0000224	type	Person
:Entity_EDL_0000224	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:11648-11653	0.000
:Entity_EDL_0000224	link	NIL000000205
:Entity_EDL_0000225	type	Person
:Entity_EDL_0000225	nominal_mention	"fighters"	syria_bbc__1000-01-01__timeline:3606-3613	0.000
:Entity_EDL_0000225	link	NIL000000206
:Entity_EDL_0000226	type	GeopoliticalEntity
:Entity_EDL_0000226	canonical_mention	"Treimseh"	syria_latimes__1000-01-01__timeline:12584-12591	1.0
:Entity_EDL_0000226	mention	"Treimseh"	syria_latimes__1000-01-01__timeline:12584-12591	1.0
:Entity_EDL_0000226	link	9847679
:Entity_EDL_0000227	type	GeopoliticalEntity
:Entity_EDL_0000227	nominal_mention	"village"	syria_bbc__1000-01-01__timeline:2484-2490	1.0
:Entity_EDL_0000227	link	NIL000000207
:Entity_EDL_0000228	type	Person
:Entity_EDL_0000228	canonical_mention	"civilians"	syria_washington__1000-01-01__timeline:1869-1877	1.0
:Entity_EDL_0000228	nominal_mention	"civilians"	syria_washington__1000-01-01__timeline:1869-1877	1.0
:Entity_EDL_0000228	link	NIL000000208
:Entity_EDL_0000229	type	Person
:Entity_EDL_0000229	nominal_mention	"people"	syria_latimes__1000-01-01__timeline:4114-4119	1.0
:Entity_EDL_0000229	link	NIL000000209
:Entity_EDL_0000230	type	Person
:Entity_EDL_0000230	canonical_mention	"authorities"	syria_latimes__1000-01-01__timeline:2362-2372	1.0
:Entity_EDL_0000230	nominal_mention	"authorities"	syria_latimes__1000-01-01__timeline:2362-2372	1.0
:Entity_EDL_0000230	link	NIL000000210
:Entity_EDL_0000231	type	Weapon
:Entity_EDL_0000231	nominal_mention	"machine-guns"	syria_bbc__1000-01-01__timeline:800-811	0.000
:Entity_EDL_0000231	link	NIL000000211
:Entity_EDL_0000232	type	Location
:Entity_EDL_0000232	canonical_mention	"radius"	syria_sbs__1000-01-01__timeline:1518-1523	1.0
:Entity_EDL_0000232	nominal_mention	"radius"	syria_sbs__1000-01-01__timeline:1518-1523	1.0
:Entity_EDL_0000232	link	NIL000000212
:Entity_EDL_0000233	type	Person
:Entity_EDL_0000233	nominal_mention	"rebels"	syria_latimes__1000-01-01__timeline:10607-10612	1.0
:Entity_EDL_0000233	link	NIL000000213
:Entity_EDL_0000234	type	GeopoliticalEntity
:Entity_EDL_0000234	nominal_mention	"city"	syria_latimes__1000-01-01__timeline:6754-6757	1.0
:Entity_EDL_0000234	link	NIL000000214
:Entity_EDL_0000235	type	Person
:Entity_EDL_0000235	nominal_mention	"people"	syria_bbc__1000-01-01__timeline:3557-3562	1.0
:Entity_EDL_0000235	link	NIL000000215
:Entity_EDL_0000236	type	GeopoliticalEntity
:Entity_EDL_0000236	canonical_mention	"Damascus"	syria_washington__1000-01-01__timeline:52-59	1.0
:Entity_EDL_0000236	mention	"Damascus"	syria_washington__1000-01-01__timeline:52-59	1.0
:Entity_EDL_0000236	link	170654
:Entity_EDL_0000237	type	Facility
:Entity_EDL_0000237	canonical_mention	"National Security"	syria_washington__1000-01-01__timeline:2009-2025	1.0
:Entity_EDL_0000237	mention	"National Security"	syria_washington__1000-01-01__timeline:2009-2025	1.0
:Entity_EDL_0000237	link	NIL000000216
:Entity_EDL_0000238	type	Person
:Entity_EDL_0000238	nominal_mention	"troops"	syria_latimes__1000-01-01__timeline:5370-5375	1.0
:Entity_EDL_0000238	link	NIL000000217
:Entity_EDL_0000239	type	Person
:Entity_EDL_0000239	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:4335-4340	0.000
:Entity_EDL_0000239	link	NIL000000218
:Entity_EDL_0000240	type	Organization
:Entity_EDL_0000240	canonical_mention	"army"	syria_latimes__1000-01-01__timeline:11462-11465	1.0
:Entity_EDL_0000240	nominal_mention	"army"	syria_latimes__1000-01-01__timeline:11462-11465	1.0
:Entity_EDL_0000240	link	NIL000000219
:Entity_EDL_0000241	type	Weapon
:Entity_EDL_0000241	canonical_mention	"weapons"	syria_washington__1000-01-01__timeline:3422-3428	1.0
:Entity_EDL_0000241	nominal_mention	"weapons"	syria_washington__1000-01-01__timeline:3422-3428	1.0
:Entity_EDL_0000241	link	NIL000000220
:Entity_EDL_0000242	type	GeopoliticalEntity
:Entity_EDL_0000242	canonical_mention	"Israeli"	syria_washington__1000-01-01__timeline:3496-3502	1.0
:Entity_EDL_0000242	mention	"Israeli"	syria_washington__1000-01-01__timeline:3496-3502	1.0
:Entity_EDL_0000242	link	294640
:Entity_EDL_0000243	type	Person
:Entity_EDL_0000243	canonical_mention	"majority"	syria_bbc__1000-01-01__timeline:2730-2737	1.0
:Entity_EDL_0000243	nominal_mention	"majority"	syria_bbc__1000-01-01__timeline:2730-2737	1.0
:Entity_EDL_0000243	link	NIL000000221
:Entity_EDL_0000244	type	Person
:Entity_EDL_0000244	canonical_mention	"fighters"	syria_washington__1000-01-01__timeline:4151-4158	1.0
:Entity_EDL_0000244	nominal_mention	"fighters"	syria_washington__1000-01-01__timeline:4151-4158	1.0
:Entity_EDL_0000244	link	NIL000000222
:Entity_EDL_0000245	type	Weapon
:Entity_EDL_0000245	canonical_mention	"bomb"	syria_dailystar__1000-01-01__timeline:2888-2891	1.0
:Entity_EDL_0000245	nominal_mention	"bomb"	syria_dailystar__1000-01-01__timeline:2888-2891	1.0
:Entity_EDL_0000245	link	NIL000000223
:Entity_EDL_0000246	type	Facility
:Entity_EDL_0000246	canonical_mention	"checkpoint"	syria_washington__1000-01-01__timeline:2791-2800	1.0
:Entity_EDL_0000246	nominal_mention	"checkpoint"	syria_washington__1000-01-01__timeline:2791-2800	1.0
:Entity_EDL_0000246	link	NIL000000224
:Entity_EDL_0000247	type	Person
:Entity_EDL_0000247	canonical_mention	"Hassan Turkomani"	syria_bbc__1000-01-01__timeline:4007-4022	1.0
:Entity_EDL_0000247	mention	"Hassan Turkomani"	syria_bbc__1000-01-01__timeline:4007-4022	1.0
:Entity_EDL_0000247	link	NIL000000225
:Entity_EDL_0000248	type	Person
:Entity_EDL_0000248	nominal_mention	"rebels"	syria_latimes__1000-01-01__timeline:9885-9890	1.0
:Entity_EDL_0000248	link	NIL000000226
:Entity_EDL_0000249	type	Person
:Entity_EDL_0000249	nominal_mention	"people"	syria_washington__1000-01-01__timeline:2566-2571	1.0
:Entity_EDL_0000249	link	NIL000000227
:Entity_EDL_0000250	type	Person
:Entity_EDL_0000250	nominal_mention	"people"	syria_latimes__1000-01-01__timeline:3666-3671	1.0
:Entity_EDL_0000250	link	NIL000000228
:Entity_EDL_0000251	type	Person
:Entity_EDL_0000251	nominal_mention	"deputy"	syria_bbc__1000-01-01__timeline:3817-3822	1.0
:Entity_EDL_0000251	link	NIL000000229
:Entity_EDL_0000252	type	GeopoliticalEntity
:Entity_EDL_0000252	canonical_mention	"US"	syria_dailystar__1000-01-01__timeline:124-125	1.0
:Entity_EDL_0000252	mention	"US"	syria_dailystar__1000-01-01__timeline:124-125	1.0
:Entity_EDL_0000252	link	6252001
:Entity_EDL_0000253	type	Person
:Entity_EDL_0000253	nominal_mention	"protesters"	syria_latimes__1000-01-01__timeline:3825-3834	1.0
:Entity_EDL_0000253	link	NIL000000230
:Entity_EDL_0000254	type	Person
:Entity_EDL_0000254	nominal_mention	"people"	syria_bbc__1000-01-01__timeline:2629-2634	1.0
:Entity_EDL_0000254	link	NIL000000231
:Entity_EDL_0000255	type	Vehicle
:Entity_EDL_0000255	pronominal_mention	"it"	syria_latimes__1000-01-01__timeline:12071-12072	1.0
:Entity_EDL_0000255	link	NIL000000232
:Entity_EDL_0000256	type	Person
:Entity_EDL_0000256	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:1523-1528	0.000
:Entity_EDL_0000256	link	NIL000000233
:Entity_EDL_0000257	type	GeopoliticalEntity
:Entity_EDL_0000257	canonical_mention	"capital"	syria_bbc__1000-01-01__timeline:2118-2124	1.0
:Entity_EDL_0000257	nominal_mention	"capital"	syria_bbc__1000-01-01__timeline:2118-2124	1.0
:Entity_EDL_0000257	link	NIL000000234
:Entity_EDL_0000258	type	Person
:Entity_EDL_0000258	nominal_mention	"Rebels"	syria_washington__1000-01-01__timeline:2373-2378	1.0
:Entity_EDL_0000258	link	NIL000000235
:Entity_EDL_0000259	type	Facility
:Entity_EDL_0000259	canonical_mention	"building"	syria_bbc__1000-01-01__timeline:2203-2210	1.0
:Entity_EDL_0000259	nominal_mention	"building"	syria_bbc__1000-01-01__timeline:2203-2210	1.0
:Entity_EDL_0000259	link	NIL000000236
:Entity_EDL_0000260	type	Location
:Entity_EDL_0000260	canonical_mention	"airspace"	syria_latimes__1000-01-01__timeline:12106-12113	1.0
:Entity_EDL_0000260	nominal_mention	"airspace"	syria_latimes__1000-01-01__timeline:12106-12113	1.0
:Entity_EDL_0000260	link	NIL000000237
:Entity_EDL_0000261	type	Organization
:Entity_EDL_0000261	canonical_mention	"Syrian National Council"	syria_bbc__1000-01-01__timeline:342-364	1.0
:Entity_EDL_0000261	mention	"Syrian National Council"	syria_bbc__1000-01-01__timeline:342-364	1.0
:Entity_EDL_0000261	link	NIL000000238
:Entity_EDL_0000262	type	Person
:Entity_EDL_0000262	nominal_mention	"Syrians"	syria_latimes__1000-01-01__timeline:796-802	1.0
:Entity_EDL_0000262	link	NIL000000239
:Entity_EDL_0000263	type	Person
:Entity_EDL_0000263	canonical_mention	"defectors"	syria_bbc__1000-01-01__timeline:724-732	1.0
:Entity_EDL_0000263	nominal_mention	"defectors"	syria_bbc__1000-01-01__timeline:724-732	1.0
:Entity_EDL_0000263	link	NIL000000240
:Entity_EDL_0000264	type	Person
:Entity_EDL_0000264	canonical_mention	"Ahmad al-Jarba"	syria_washington__1000-01-01__timeline:4674-4687	1.0
:Entity_EDL_0000264	mention	"Ahmad al-Jarba"	syria_washington__1000-01-01__timeline:4674-4687	1.0
:Entity_EDL_0000264	link	NIL000000241
:Entity_EDL_0000265	type	Person
:Entity_EDL_0000265	canonical_mention	"people"	syria_latimes__1000-01-01__timeline:1474-1479	1.0
:Entity_EDL_0000265	nominal_mention	"people"	syria_latimes__1000-01-01__timeline:1474-1479	1.0
:Entity_EDL_0000265	link	NIL000000242
:Entity_EDL_0000266	type	Person
:Entity_EDL_0000266	canonical_mention	"staff"	syria_latimes__1000-01-01__timeline:15540-15544	1.0
:Entity_EDL_0000266	nominal_mention	"staff"	syria_latimes__1000-01-01__timeline:15540-15544	1.0
:Entity_EDL_0000266	link	NIL000000243
:Entity_EDL_0000267	type	GeopoliticalEntity
:Entity_EDL_0000267	canonical_mention	"Villages"	syria_bbc__1000-01-01__timeline:630-637	1.0
:Entity_EDL_0000267	nominal_mention	"Villages"	syria_bbc__1000-01-01__timeline:630-637	1.0
:Entity_EDL_0000267	link	NIL000000244
:Entity_EDL_0000268	type	Person
:Entity_EDL_0000268	nominal_mention	"people"	syria_bbc__1000-01-01__timeline:2140-2145	1.0
:Entity_EDL_0000268	link	NIL000000245
:Entity_EDL_0000269	type	Organization
:Entity_EDL_0000269	canonical_mention	"Syrian Opposition Coalition"	syria_washington__1000-01-01__timeline:4781-4807	1.0
:Entity_EDL_0000269	mention	"Syrian Opposition Coalition"	syria_washington__1000-01-01__timeline:4781-4807	1.0
:Entity_EDL_0000269	link	NIL000000246
:Entity_EDL_0000270	type	Person
:Entity_EDL_0000270	nominal_mention	"people"	syria_bbc__1000-01-01__timeline:3657-3662	1.0
:Entity_EDL_0000270	link	NIL000000247
:Entity_EDL_0000271	type	GeopoliticalEntity
:Entity_EDL_0000271	nominal_mention	"town"	syria_latimes__1000-01-01__timeline:1567-1570	1.0
:Entity_EDL_0000271	link	NIL000000248
:Entity_EDL_0000272	type	Person
:Entity_EDL_0000272	canonical_mention	"citizens"	syria_latimes__1000-01-01__timeline:13125-13132	1.0
:Entity_EDL_0000272	nominal_mention	"citizens"	syria_latimes__1000-01-01__timeline:13125-13132	1.0
:Entity_EDL_0000272	link	NIL000000249
:Entity_EDL_0000273	type	Person
:Entity_EDL_0000273	canonical_mention	"children"	syria_latimes__1000-01-01__timeline:11564-11571	1.0
:Entity_EDL_0000273	nominal_mention	"children"	syria_latimes__1000-01-01__timeline:11564-11571	1.0
:Entity_EDL_0000273	link	NIL000000250
:Entity_EDL_0000274	type	Organization
:Entity_EDL_0000274	canonical_mention	"Free Syrian Army"	syria_dailystar__1000-01-01__timeline:401-416	1.0
:Entity_EDL_0000274	mention	"Free Syrian Army"	syria_dailystar__1000-01-01__timeline:401-416	1.0
:Entity_EDL_0000274	link	NIL000000251
:Entity_EDL_0000275	type	Location
:Entity_EDL_0000275	nominal_mention	"Damascus"	syria_dailystar__1000-01-01__timeline:2913-2920	1.0
:Entity_EDL_0000275	link	NIL000000252
:Entity_EDL_0000276	type	GeopoliticalEntity
:Entity_EDL_0000276	nominal_mention	"city"	syria_bbc__1000-01-01__timeline:1319-1322	1.0
:Entity_EDL_0000276	link	NIL000000253
:Entity_EDL_0000277	type	Person
:Entity_EDL_0000277	nominal_mention	"people"	syria_latimes__1000-01-01__timeline:2443-2448	1.0
:Entity_EDL_0000277	link	NIL000000254
:Entity_EDL_0000278	type	Weapon
:Entity_EDL_0000278	canonical_mention	"bullets"	syria_latimes__1000-01-01__timeline:2188-2194	1.0
:Entity_EDL_0000278	nominal_mention	"bullets"	syria_latimes__1000-01-01__timeline:2188-2194	1.0
:Entity_EDL_0000278	link	NIL000000255
:Entity_EDL_0000279	type	GeopoliticalEntity
:Entity_EDL_0000279	nominal_mention	"city"	syria_latimes__1000-01-01__timeline:5060-5063	1.0
:Entity_EDL_0000279	link	NIL000000256
:Entity_EDL_0000280	type	Person
:Entity_EDL_0000280	nominal_mention	"people"	syria_latimes__1000-01-01__timeline:11313-11318	1.0
:Entity_EDL_0000280	link	NIL000000257
:Entity_EDL_0000281	type	Person
:Entity_EDL_0000281	canonical_mention	"demonstrators"	syria_latimes__1000-01-01__timeline:31-43	1.0
:Entity_EDL_0000281	nominal_mention	"demonstrators"	syria_latimes__1000-01-01__timeline:31-43	1.0
:Entity_EDL_0000281	link	NIL000000258
:Entity_EDL_0000282	type	Organization
:Entity_EDL_0000282	nominal_mention	"regime"	syria_sbs__1000-01-01__timeline:1479-1484	1.0
:Entity_EDL_0000282	link	NIL000000259
:Entity_EDL_0000283	type	Person
:Entity_EDL_0000283	canonical_mention	"Annan"	syria_dailystar__1000-01-01__timeline:2333-2337	1.0
:Entity_EDL_0000283	mention	"Annan"	syria_dailystar__1000-01-01__timeline:2333-2337	1.0
:Entity_EDL_0000283	link	NIL000000260
:Entity_EDL_0000284	type	GeopoliticalEntity
:Entity_EDL_0000284	canonical_mention	"Houla"	syria_dailystar__1000-01-01__timeline:984-988	1.0
:Entity_EDL_0000284	mention	"Houla"	syria_dailystar__1000-01-01__timeline:984-988	1.0
:Entity_EDL_0000284	link	11287703
:Entity_EDL_0000285	type	Person
:Entity_EDL_0000285	canonical_mention	"women"	syria_latimes__1000-01-01__timeline:11554-11558	1.0
:Entity_EDL_0000285	nominal_mention	"women"	syria_latimes__1000-01-01__timeline:11554-11558	1.0
:Entity_EDL_0000285	link	NIL000000261
:Entity_EDL_0000286	type	Weapon
:Entity_EDL_0000286	nominal_mention	"car bomb"	syria_washington__1000-01-01__timeline:2762-2769	0.000
:Entity_EDL_0000286	link	NIL000000262
:Entity_EDL_0000287	type	Person
:Entity_EDL_0000287	nominal_mention	"Secretary-General"	syria_latimes__1000-01-01__timeline:9726-9742	1.0
:Entity_EDL_0000287	link	NIL000000263
:Entity_EDL_0000288	type	Facility
:Entity_EDL_0000288	nominal_mention	"streets"	syria_latimes__1000-01-01__timeline:2899-2905	0.000
:Entity_EDL_0000288	link	NIL000000264
:Entity_EDL_0000289	type	GeopoliticalEntity
:Entity_EDL_0000289	canonical_mention	"Idlib"	syria_washington__1000-01-01__timeline:2414-2418	1.0
:Entity_EDL_0000289	mention	"Idlib"	syria_washington__1000-01-01__timeline:2414-2418	1.0
:Entity_EDL_0000289	link	169387
:Entity_EDL_0000290	type	Person
:Entity_EDL_0000290	nominal_mention	"people"	syria_latimes__1000-01-01__timeline:12799-12804	1.0
:Entity_EDL_0000290	link	NIL000000265
:Entity_EDL_0000291	type	Person
:Entity_EDL_0000291	canonical_mention	"chief"	syria_bbc__1000-01-01__timeline:4139-4143	1.0
:Entity_EDL_0000291	nominal_mention	"chief"	syria_bbc__1000-01-01__timeline:4139-4143	1.0
:Entity_EDL_0000291	link	NIL000000266
:Entity_EDL_0000292	type	Person
:Entity_EDL_0000292	canonical_mention	"they"	syria_dailystar__1000-01-01__timeline:2452-2455	1.0
:Entity_EDL_0000292	nominal_mention	"they"	syria_dailystar__1000-01-01__timeline:2452-2455	1.0
:Entity_EDL_0000292	link	NIL000000267
:Entity_EDL_0000293	type	GeopoliticalEntity
:Entity_EDL_0000293	pronominal_mention	"it"	syria_latimes__1000-01-01__timeline:12235-12236	1.0
:Entity_EDL_0000293	link	NIL000000268
:Entity_EDL_0000294	type	Person
:Entity_EDL_0000294	canonical_mention	"hundreds"	syria_bbc__1000-01-01__timeline:834-841	1.0
:Entity_EDL_0000294	pronominal_mention	"hundreds"	syria_bbc__1000-01-01__timeline:834-841	1.0
:Entity_EDL_0000294	link	NIL000000269
:Entity_EDL_0000295	type	Facility
:Entity_EDL_0000295	canonical_mention	"facilities"	syria_bbc__1000-01-01__timeline:2258-2267	1.0
:Entity_EDL_0000295	nominal_mention	"facilities"	syria_bbc__1000-01-01__timeline:2258-2267	1.0
:Entity_EDL_0000295	link	NIL000000270
:Entity_EDL_0000296	type	Person
:Entity_EDL_0000296	nominal_mention	"civilians"	syria_latimes__1000-01-01__timeline:12675-12683	1.0
:Entity_EDL_0000296	link	NIL000000271
:Entity_EDL_0000297	type	Person
:Entity_EDL_0000297	canonical_mention	"brotherinlaw Assef Shawkat"	syria_dailystar__1000-01-01__timeline:1811-1836	1.0
:Entity_EDL_0000297	mention	"brotherinlaw Assef Shawkat"	syria_dailystar__1000-01-01__timeline:1811-1836	1.0
:Entity_EDL_0000297	link	NIL000000272
:Entity_EDL_0000298	type	Person
:Entity_EDL_0000298	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:4718-4723	0.000
:Entity_EDL_0000298	link	NIL000000273
:Entity_EDL_0000299	type	Person
:Entity_EDL_0000299	nominal_mention	"people"	syria_latimes__1000-01-01__timeline:6488-6493	1.0
:Entity_EDL_0000299	link	NIL000000274
:Entity_EDL_0000300	type	Organization
:Entity_EDL_0000300	nominal_mention	"government"	syria_latimes__1000-01-01__timeline:13082-13091	1.0
:Entity_EDL_0000300	link	NIL000000275
:Entity_EDL_0000301	type	GeopoliticalEntity
:Entity_EDL_0000301	nominal_mention	"province"	syria_latimes__1000-01-01__timeline:12292-12299	1.0
:Entity_EDL_0000301	link	NIL000000276
:Entity_EDL_0000302	type	Vehicle
:Entity_EDL_0000302	canonical_mention	"tanks"	syria_latimes__1000-01-01__timeline:4447-4451	1.0
:Entity_EDL_0000302	nominal_mention	"tanks"	syria_latimes__1000-01-01__timeline:4447-4451	1.0
:Entity_EDL_0000302	link	NIL000000277
:Entity_EDL_0000303	type	GeopoliticalEntity
:Entity_EDL_0000303	nominal_mention	"city"	syria_latimes__1000-01-01__timeline:5697-5700	1.0
:Entity_EDL_0000303	link	NIL000000278
:Entity_EDL_0000304	type	Person
:Entity_EDL_0000304	nominal_mention	"people"	syria_dailystar__1000-01-01__timeline:2995-3000	1.0
:Entity_EDL_0000304	link	NIL000000279
:Entity_EDL_0000305	type	Person
:Entity_EDL_0000305	canonical_mention	"faction"	syria_sbs__1000-01-01__timeline:1822-1828	1.0
:Entity_EDL_0000305	nominal_mention	"faction"	syria_sbs__1000-01-01__timeline:1822-1828	1.0
:Entity_EDL_0000305	link	NIL000000280
:Entity_EDL_0000306	type	Person
:Entity_EDL_0000306	canonical_mention	"insurgents"	syria_latimes__1000-01-01__timeline:12740-12749	1.0
:Entity_EDL_0000306	nominal_mention	"insurgents"	syria_latimes__1000-01-01__timeline:12740-12749	1.0
:Entity_EDL_0000306	link	NIL000000281
:Entity_EDL_0000307	type	GeopoliticalEntity
:Entity_EDL_0000307	pronominal_mention	"its"	syria_washington__1000-01-01__timeline:4484-4486	1.0
:Entity_EDL_0000307	link	NIL000000282
:Entity_EDL_0000308	type	Location
:Entity_EDL_0000308	canonical_mention	"suburbs"	syria_latimes__1000-01-01__timeline:4843-4849	1.0
:Entity_EDL_0000308	nominal_mention	"suburbs"	syria_latimes__1000-01-01__timeline:4843-4849	1.0
:Entity_EDL_0000308	link	NIL000000283
:Entity_EDL_0000309	type	Person
:Entity_EDL_0000309	nominal_mention	"forces"	syria_latimes__1000-01-01__timeline:11237-11242	1.0
:Entity_EDL_0000309	link	NIL000000284
:Entity_EDL_0000310	type	Person
:Entity_EDL_0000310	nominal_mention	"protesters"	syria_latimes__1000-01-01__timeline:2118-2127	1.0
:Entity_EDL_0000310	link	NIL000000285
:Entity_EDL_0000311	type	Person
:Entity_EDL_0000311	nominal_mention	"demonstrators"	syria_latimes__1000-01-01__timeline:4350-4362	1.0
:Entity_EDL_0000311	link	NIL000000286
:Entity_EDL_0000312	type	Organization
:Entity_EDL_0000312	nominal_mention	"groups"	syria_bbc__1000-01-01__timeline:2326-2331	1.0
:Entity_EDL_0000312	link	NIL000000287
