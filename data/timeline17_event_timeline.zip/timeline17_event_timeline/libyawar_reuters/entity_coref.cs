:Entity_EDL_0000000	type	GeopoliticalEntity
:Entity_EDL_0000000	canonical_mention	"Algeria"	libyawar_reuters__1000-01-01__timeline:1875-1881	1.0
:Entity_EDL_0000000	mention	"Algeria"	libyawar_reuters__1000-01-01__timeline:1875-1881	1.0
:Entity_EDL_0000000	link	2589581
:Entity_EDL_0000001	type	Person
:Entity_EDL_0000001	nominal_mention	"son"	libyawar_reuters__1000-01-01__timeline:4683-4685	1.0
:Entity_EDL_0000001	link	NIL000000001
:Entity_EDL_0000002	type	GeopoliticalEntity
:Entity_EDL_0000002	canonical_mention	"Libyans"	libyawar_reuters__1000-01-01__timeline:1566-1572	1.0
:Entity_EDL_0000002	nominal_mention	"Libyans"	libyawar_reuters__1000-01-01__timeline:1566-1572	1.0
:Entity_EDL_0000002	link	NIL000000002
:Entity_EDL_0000003	type	Person
:Entity_EDL_0000003	mention	"Gaddafi"	libyawar_reuters__1000-01-01__timeline:1503-1509	1.0
:Entity_EDL_0000003	link	NIL000000003
:Entity_EDL_0000004	type	Person
:Entity_EDL_0000004	canonical_mention	"militias"	libyawar_reuters__1000-01-01__timeline:149-156	1.0
:Entity_EDL_0000004	nominal_mention	"militias"	libyawar_reuters__1000-01-01__timeline:149-156	1.0
:Entity_EDL_0000004	link	NIL000000004
:Entity_EDL_0000005	type	GeopoliticalEntity
:Entity_EDL_0000005	mention	"Tripoli"	libyawar_reuters__1000-01-01__timeline:1469-1475	1.0
:Entity_EDL_0000005	link	2210247
:Entity_EDL_0000006	type	Person
:Entity_EDL_0000006	canonical_mention	"David Cameron"	libyawar_reuters__1000-01-01__timeline:2742-2754	1.0
:Entity_EDL_0000006	mention	"David Cameron"	libyawar_reuters__1000-01-01__timeline:2742-2754	1.0
:Entity_EDL_0000006	link	30005047
:Entity_EDL_0000007	type	GeopoliticalEntity
:Entity_EDL_0000007	mention	"Tripoli"	libyawar_reuters__1000-01-01__timeline:3302-3308	1.0
:Entity_EDL_0000007	link	2210247
:Entity_EDL_0000008	type	GeopoliticalEntity
:Entity_EDL_0000008	canonical_mention	"Tripoli"	libyawar_reuters__1000-01-01__timeline:1130-1136	1.0
:Entity_EDL_0000008	mention	"Tripoli"	libyawar_reuters__1000-01-01__timeline:1130-1136	1.0
:Entity_EDL_0000008	link	2210247
:Entity_EDL_0000009	type	Person
:Entity_EDL_0000009	canonical_mention	"crowd"	libyawar_reuters__1000-01-01__timeline:2632-2636	1.0
:Entity_EDL_0000009	nominal_mention	"crowd"	libyawar_reuters__1000-01-01__timeline:2632-2636	1.0
:Entity_EDL_0000009	link	NIL000000005
:Entity_EDL_0000010	type	GeopoliticalEntity
:Entity_EDL_0000010	canonical_mention	"town"	libyawar_reuters__1000-01-01__timeline:1936-1939	1.0
:Entity_EDL_0000010	nominal_mention	"town"	libyawar_reuters__1000-01-01__timeline:1936-1939	1.0
:Entity_EDL_0000010	link	NIL000000006
:Entity_EDL_0000011	type	Person
:Entity_EDL_0000011	pronominal_mention	"his"	libyawar_reuters__1000-01-01__timeline:2157-2159	1.0
:Entity_EDL_0000011	link	NIL000000007
:Entity_EDL_0000012	type	Person
:Entity_EDL_0000012	canonical_mention	"ambassador"	libyawar_reuters__1000-01-01__timeline:3288-3297	1.0
:Entity_EDL_0000012	nominal_mention	"ambassador"	libyawar_reuters__1000-01-01__timeline:3288-3297	1.0
:Entity_EDL_0000012	link	NIL000000008
:Entity_EDL_0000013	type	Person
:Entity_EDL_0000013	canonical_mention	"Fethi Tarbel"	libyawar_reuters__1000-01-01__timeline:47-58	1.0
:Entity_EDL_0000013	mention	"Fethi Tarbel"	libyawar_reuters__1000-01-01__timeline:47-58	1.0
:Entity_EDL_0000013	link	NIL000000009
:Entity_EDL_0000014	type	Organization
:Entity_EDL_0000014	canonical_mention	"NATO"	libyawar_reuters__1000-01-01__timeline:1096-1099	1.0
:Entity_EDL_0000014	mention	"NATO"	libyawar_reuters__1000-01-01__timeline:1096-1099	1.0
:Entity_EDL_0000014	link	20000153
:Entity_EDL_0000015	type	GeopoliticalEntity
:Entity_EDL_0000015	mention	"Tripoli"	libyawar_reuters__1000-01-01__timeline:2619-2625	1.0
:Entity_EDL_0000015	link	2210247
:Entity_EDL_0000016	type	Person
:Entity_EDL_0000016	nominal_mention	"son"	libyawar_reuters__1000-01-01__timeline:2473-2475	1.0
:Entity_EDL_0000016	link	NIL000000010
:Entity_EDL_0000017	type	Person
:Entity_EDL_0000017	canonical_mention	"Hilary Clinton"	libyawar_reuters__1000-01-01__timeline:4816-4829	1.0
:Entity_EDL_0000017	mention	"Hilary Clinton"	libyawar_reuters__1000-01-01__timeline:4816-4829	1.0
:Entity_EDL_0000017	link	NIL000000011
:Entity_EDL_0000018	type	GeopoliticalEntity
:Entity_EDL_0000018	mention	"Tripoli"	libyawar_reuters__1000-01-01__timeline:1722-1728	1.0
:Entity_EDL_0000018	link	2210247
:Entity_EDL_0000019	type	GeopoliticalEntity
:Entity_EDL_0000019	nominal_mention	"city"	libyawar_reuters__1000-01-01__timeline:190-193	1.0
:Entity_EDL_0000019	link	NIL000000012
:Entity_EDL_0000020	type	Person
:Entity_EDL_0000020	canonical_mention	"Aisha Gaddafi"	libyawar_reuters__1000-01-01__timeline:1886-1898	1.0
:Entity_EDL_0000020	mention	"Aisha Gaddafi"	libyawar_reuters__1000-01-01__timeline:1886-1898	1.0
:Entity_EDL_0000020	link	NIL000000013
:Entity_EDL_0000021	type	Person
:Entity_EDL_0000021	canonical_mention	"Nicolas Sarkozy"	libyawar_reuters__1000-01-01__timeline:2711-2725	1.0
:Entity_EDL_0000021	mention	"Nicolas Sarkozy"	libyawar_reuters__1000-01-01__timeline:2711-2725	1.0
:Entity_EDL_0000021	link	NIL000000014
:Entity_EDL_0000022	type	GeopoliticalEntity
:Entity_EDL_0000022	mention	"Benghazi"	libyawar_reuters__1000-01-01__timeline:1005-1012	1.0
:Entity_EDL_0000022	link	88319
:Entity_EDL_0000023	type	Person
:Entity_EDL_0000023	pronominal_mention	"he"	libyawar_reuters__1000-01-01__timeline:4111-4112	1.0
:Entity_EDL_0000023	link	NIL000000015
:Entity_EDL_0000024	type	GeopoliticalEntity
:Entity_EDL_0000024	mention	"Libya"	libyawar_reuters__1000-01-01__timeline:4842-4846	1.0
:Entity_EDL_0000024	link	2215636
:Entity_EDL_0000025	type	Person
:Entity_EDL_0000025	canonical_mention	"grandchildren"	libyawar_reuters__1000-01-01__timeline:1178-1190	1.0
:Entity_EDL_0000025	nominal_mention	"grandchildren"	libyawar_reuters__1000-01-01__timeline:1178-1190	1.0
:Entity_EDL_0000025	link	NIL000000016
:Entity_EDL_0000026	type	Person
:Entity_EDL_0000026	canonical_mention	"leaders"	libyawar_reuters__1000-01-01__timeline:2057-2063	1.0
:Entity_EDL_0000026	nominal_mention	"leaders"	libyawar_reuters__1000-01-01__timeline:2057-2063	1.0
:Entity_EDL_0000026	link	NIL000000017
:Entity_EDL_0000027	type	Person
:Entity_EDL_0000027	mention	"Gaddafi"	libyawar_reuters__1000-01-01__timeline:3313-3319	1.0
:Entity_EDL_0000027	link	NIL000000018
:Entity_EDL_0000028	type	Person
:Entity_EDL_0000028	nominal_mention	"supporters"	libyawar_reuters__1000-01-01__timeline:4403-4412	1.0
:Entity_EDL_0000028	link	NIL000000019
:Entity_EDL_0000029	type	GeopoliticalEntity
:Entity_EDL_0000029	canonical_mention	"Benghazi"	libyawar_reuters__1000-01-01__timeline:77-84	1.0
:Entity_EDL_0000029	mention	"Benghazi"	libyawar_reuters__1000-01-01__timeline:77-84	1.0
:Entity_EDL_0000029	link	88319
:Entity_EDL_0000030	type	Location
:Entity_EDL_0000030	canonical_mention	"frontier"	libyawar_reuters__1000-01-01__timeline:1966-1973	1.0
:Entity_EDL_0000030	nominal_mention	"frontier"	libyawar_reuters__1000-01-01__timeline:1966-1973	1.0
:Entity_EDL_0000030	link	NIL000000020
:Entity_EDL_0000031	type	Person
:Entity_EDL_0000031	canonical_mention	"Mahmoud Jibril"	libyawar_reuters__1000-01-01__timeline:2282-2295	1.0
:Entity_EDL_0000031	mention	"Mahmoud Jibril"	libyawar_reuters__1000-01-01__timeline:2282-2295	1.0
:Entity_EDL_0000031	link	NIL000000021
:Entity_EDL_0000032	type	Person
:Entity_EDL_0000032	canonical_mention	"Mustafa Abdel Jalil"	libyawar_reuters__1000-01-01__timeline:2573-2591	1.0
:Entity_EDL_0000032	mention	"Mustafa Abdel Jalil"	libyawar_reuters__1000-01-01__timeline:2573-2591	1.0
:Entity_EDL_0000032	link	NIL000000022
:Entity_EDL_0000033	type	Person
:Entity_EDL_0000033	nominal_mention	"forces"	libyawar_reuters__1000-01-01__timeline:4422-4427	1.0
:Entity_EDL_0000033	link	NIL000000023
:Entity_EDL_0000034	type	GeopoliticalEntity
:Entity_EDL_0000034	mention	"Tripoli"	libyawar_reuters__1000-01-01__timeline:4724-4730	1.0
:Entity_EDL_0000034	link	2210247
:Entity_EDL_0000035	type	GeopoliticalEntity
:Entity_EDL_0000035	mention	"Sirte"	libyawar_reuters__1000-01-01__timeline:4130-4134	1.0
:Entity_EDL_0000035	link	2210554
:Entity_EDL_0000036	type	Person
:Entity_EDL_0000036	mention	"Gaddafi"	libyawar_reuters__1000-01-01__timeline:1296-1302	1.0
:Entity_EDL_0000036	link	NIL000000024
:Entity_EDL_0000037	type	Facility
:Entity_EDL_0000037	canonical_mention	"clinic"	libyawar_reuters__1000-01-01__timeline:1917-1922	1.0
:Entity_EDL_0000037	nominal_mention	"clinic"	libyawar_reuters__1000-01-01__timeline:1917-1922	1.0
:Entity_EDL_0000037	link	NIL000000025
:Entity_EDL_0000038	type	Person
:Entity_EDL_0000038	canonical_mention	"Saif al-Islam"	libyawar_reuters__1000-01-01__timeline:1314-1326	1.0
:Entity_EDL_0000038	mention	"Saif al-Islam"	libyawar_reuters__1000-01-01__timeline:1314-1326	1.0
:Entity_EDL_0000038	link	NIL000000026
:Entity_EDL_0000039	type	Person
:Entity_EDL_0000039	canonical_mention	"Khamis"	libyawar_reuters__1000-01-01__timeline:4687-4692	1.0
:Entity_EDL_0000039	mention	"Khamis"	libyawar_reuters__1000-01-01__timeline:4687-4692	1.0
:Entity_EDL_0000039	link	30004519
:Entity_EDL_0000040	type	Facility
:Entity_EDL_0000040	canonical_mention	"port"	libyawar_reuters__1000-01-01__timeline:3795-3798	1.0
:Entity_EDL_0000040	nominal_mention	"port"	libyawar_reuters__1000-01-01__timeline:3795-3798	1.0
:Entity_EDL_0000040	link	NIL000000027
:Entity_EDL_0000041	type	Organization
:Entity_EDL_0000041	mention	"ICC"	libyawar_reuters__1000-01-01__timeline:1265-1267	1.0
:Entity_EDL_0000041	link	20000115
:Entity_EDL_0000042	type	Weapon
:Entity_EDL_0000042	canonical_mention	"missile"	libyawar_reuters__1000-01-01__timeline:1101-1107	1.0
:Entity_EDL_0000042	nominal_mention	"missile"	libyawar_reuters__1000-01-01__timeline:1101-1107	1.0
:Entity_EDL_0000042	link	NIL000000028
:Entity_EDL_0000043	type	Person
:Entity_EDL_0000043	nominal_mention	"Rebels"	libyawar_reuters__1000-01-01__timeline:1456-1461	1.0
:Entity_EDL_0000043	link	NIL000000029
:Entity_EDL_0000044	type	GeopoliticalEntity
:Entity_EDL_0000044	mention	"Libya"	libyawar_reuters__1000-01-01__timeline:2764-2768	1.0
:Entity_EDL_0000044	link	2215636
:Entity_EDL_0000045	type	GeopoliticalEntity
:Entity_EDL_0000045	mention	"Tripoli"	libyawar_reuters__1000-01-01__timeline:4379-4385	1.0
:Entity_EDL_0000045	link	2210247
:Entity_EDL_0000046	type	Person
:Entity_EDL_0000046	canonical_mention	"forces"	libyawar_reuters__1000-01-01__timeline:221-226	1.0
:Entity_EDL_0000046	nominal_mention	"forces"	libyawar_reuters__1000-01-01__timeline:221-226	1.0
:Entity_EDL_0000046	link	NIL000000030
:Entity_EDL_0000047	type	Person
:Entity_EDL_0000047	canonical_mention	"Saadi"	libyawar_reuters__1000-01-01__timeline:2477-2481	1.0
:Entity_EDL_0000047	mention	"Saadi"	libyawar_reuters__1000-01-01__timeline:2477-2481	1.0
:Entity_EDL_0000047	link	NIL000000031
:Entity_EDL_0000048	type	Person
:Entity_EDL_0000048	canonical_mention	"Aisha"	libyawar_reuters__1000-01-01__timeline:1843-1847	1.0
:Entity_EDL_0000048	mention	"Aisha"	libyawar_reuters__1000-01-01__timeline:1843-1847	1.0
:Entity_EDL_0000048	link	NIL000000032
:Entity_EDL_0000049	type	GeopoliticalEntity
:Entity_EDL_0000049	canonical_mention	"there"	libyawar_reuters__1000-01-01__timeline:2495-2499	1.0
:Entity_EDL_0000049	nominal_mention	"there"	libyawar_reuters__1000-01-01__timeline:2495-2499	1.0
:Entity_EDL_0000049	link	NIL000000033
:Entity_EDL_0000050	type	GeopoliticalEntity
:Entity_EDL_0000050	canonical_mention	"Paris"	libyawar_reuters__1000-01-01__timeline:2084-2088	1.0
:Entity_EDL_0000050	mention	"Paris"	libyawar_reuters__1000-01-01__timeline:2084-2088	1.0
:Entity_EDL_0000050	link	2988507
:Entity_EDL_0000051	type	FAC
:Entity_EDL_0000051	canonical_mention	"symbols"	libyawar_reuters__1000-01-01__timeline:1745-1751	1.0
:Entity_EDL_0000051	nominal_mention	"symbols"	libyawar_reuters__1000-01-01__timeline:1745-1751	1.0
:Entity_EDL_0000051	link	NIL000000034
:Entity_EDL_0000052	type	Person
:Entity_EDL_0000052	canonical_mention	"rulers"	libyawar_reuters__1000-01-01__timeline:2039-2044	1.0
:Entity_EDL_0000052	nominal_mention	"rulers"	libyawar_reuters__1000-01-01__timeline:2039-2044	1.0
:Entity_EDL_0000052	link	NIL000000035
:Entity_EDL_0000053	type	Organization
:Entity_EDL_0000053	canonical_mention	"station"	libyawar_reuters__1000-01-01__timeline:3388-3394	1.0
:Entity_EDL_0000053	nominal_mention	"station"	libyawar_reuters__1000-01-01__timeline:3388-3394	1.0
:Entity_EDL_0000053	link	NIL000000036
:Entity_EDL_0000054	type	Person
:Entity_EDL_0000054	nominal_mention	"forces"	libyawar_reuters__1000-01-01__timeline:995-1000	1.0
:Entity_EDL_0000054	link	NIL000000037
:Entity_EDL_0000055	type	Facility
:Entity_EDL_0000055	nominal_mention	"compound"	libyawar_reuters__1000-01-01__timeline:1710-1717	1.0
:Entity_EDL_0000055	link	NIL000000038
:Entity_EDL_0000056	type	Person
:Entity_EDL_0000056	nominal_mention	"two"	libyawar_reuters__1000-01-01__timeline:1853-1855	1.0
:Entity_EDL_0000056	pronominal_mention	"two"	libyawar_reuters__1000-01-01__timeline:1853-1855	1.0
:Entity_EDL_0000056	link	NIL000000039
:Entity_EDL_0000057	type	Person
:Entity_EDL_0000057	canonical_mention	"son"	libyawar_reuters__1000-01-01__timeline:1164-1166	1.0
:Entity_EDL_0000057	nominal_mention	"son"	libyawar_reuters__1000-01-01__timeline:1164-1166	1.0
:Entity_EDL_0000057	link	NIL000000040
:Entity_EDL_0000058	type	GeopoliticalEntity
:Entity_EDL_0000058	mention	"Tripoli"	libyawar_reuters__1000-01-01__timeline:2308-2314	1.0
:Entity_EDL_0000058	link	2210247
:Entity_EDL_0000059	type	Person
:Entity_EDL_0000059	nominal_mention	"fighters"	libyawar_reuters__1000-01-01__timeline:4949-4956	1.0
:Entity_EDL_0000059	link	NIL000000041
:Entity_EDL_0000060	type	Person
:Entity_EDL_0000060	nominal_mention	"rebels"	libyawar_reuters__1000-01-01__timeline:1659-1664	0.000
:Entity_EDL_0000060	link	NIL000000042
:Entity_EDL_0000061	type	Person
:Entity_EDL_0000061	canonical_mention	"Abdullah al-Senussi"	libyawar_reuters__1000-01-01__timeline:1351-1369	1.0
:Entity_EDL_0000061	mention	"Abdullah al-Senussi"	libyawar_reuters__1000-01-01__timeline:1351-1369	1.0
:Entity_EDL_0000061	link	NIL000000043
:Entity_EDL_0000062	type	Facility
:Entity_EDL_0000062	canonical_mention	"house"	libyawar_reuters__1000-01-01__timeline:1121-1125	1.0
:Entity_EDL_0000062	nominal_mention	"house"	libyawar_reuters__1000-01-01__timeline:1121-1125	1.0
:Entity_EDL_0000062	link	NIL000000044
:Entity_EDL_0000063	type	GeopoliticalEntity
:Entity_EDL_0000063	canonical_mention	"Italy"	libyawar_reuters__1000-01-01__timeline:3823-3827	1.0
:Entity_EDL_0000063	mention	"Italy"	libyawar_reuters__1000-01-01__timeline:3823-3827	1.0
:Entity_EDL_0000063	link	3175395
