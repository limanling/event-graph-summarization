:Event_0000000	type	Movement.TransportArtifact
:Event_0000000	mention.actual	"visiting"	h1n1_reuters__1000-01-01__timeline:1612-1619	1.000
:Event_0000000	canonical_mention.actual	"visiting"	h1n1_reuters__1000-01-01__timeline:1612-1619	1.000
:Event_0000000	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000011	h1n1_reuters__1000-01-01__timeline:1573-1575	1.000
:Event_0000000	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000008	h1n1_reuters__1000-01-01__timeline:1621-1625	1.000
:Event_0000001	type	Business.End
:Event_0000001	mention.actual	"closes"	h1n1_reuters__1000-01-01__timeline:824-829	1.000
:Event_0000001	canonical_mention.actual	"closes"	h1n1_reuters__1000-01-01__timeline:824-829	1.000
:Event_0000001	Business.End_Place.actual	:Entity_EDL_0000001	h1n1_reuters__1000-01-01__timeline:842-852	1.000
:Event_0000001	Business.End_Place.actual	:Entity_EDL_0000004	h1n1_reuters__1000-01-01__timeline:870-873	1.000
:Event_0000002	type	Life.Die
:Event_0000002	mention.actual	"deaths"	h1n1_reuters__1000-01-01__timeline:1137-1142	1.000
:Event_0000002	canonical_mention.actual	"deaths"	h1n1_reuters__1000-01-01__timeline:1137-1142	1.000
:Event_0000003	type	Movement.TransportArtifact
:Event_0000003	mention.actual	"travel"	h1n1_reuters__1000-01-01__timeline:1751-1756	1.000
:Event_0000003	canonical_mention.actual	"travel"	h1n1_reuters__1000-01-01__timeline:1751-1756	1.000
:Event_0000003	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000005	h1n1_reuters__1000-01-01__timeline:1761-1766	1.000
:Event_0000004	type	Contact.Correspondence
:Event_0000004	mention.actual	"notifies"	h1n1_reuters__1000-01-01__timeline:264-271	1.000
:Event_0000004	canonical_mention.actual	"notifies"	h1n1_reuters__1000-01-01__timeline:264-271	1.000
:Event_0000004	Contact.Correspondence_Participant.actual	:Entity_EDL_0000000	h1n1_reuters__1000-01-01__timeline:238-262	1.000
:Event_0000004	Contact.Correspondence_Participant.actual	:Entity_EDL_0000002	h1n1_reuters__1000-01-01__timeline:273-278	1.000
:Event_0000005	type	Contact.Meet
:Event_0000005	mention.actual	"teleconference"	h1n1_reuters__1000-01-01__timeline:436-449	1.000
:Event_0000005	canonical_mention.actual	"teleconference"	h1n1_reuters__1000-01-01__timeline:436-449	1.000
:Event_0000005	Contact.Meet_Participant.actual	:Entity_EDL_0000006	h1n1_reuters__1000-01-01__timeline:381-422	1.000
:Event_0000005	Contact.Meet_Participant.actual	:Entity_EDL_0000010	h1n1_reuters__1000-01-01__timeline:456-461	1.000
:Event_0000005	Contact.Meet_Participant.actual	:Entity_EDL_0000003	h1n1_reuters__1000-01-01__timeline:473-476	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"dies"	h1n1_reuters__1000-01-01__timeline:1601-1604	1.000
:Event_0000006	canonical_mention.actual	"dies"	h1n1_reuters__1000-01-01__timeline:1601-1604	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000011	h1n1_reuters__1000-01-01__timeline:1573-1575	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000008	h1n1_reuters__1000-01-01__timeline:1621-1625	1.000
:Event_0000007	type	Life.Die
:Event_0000007	mention.actual	"dies"	h1n1_reuters__1000-01-01__timeline:182-185	1.000
:Event_0000007	canonical_mention.actual	"dies"	h1n1_reuters__1000-01-01__timeline:182-185	1.000
:Event_0000007	Life.Die_Victim.actual	:Entity_EDL_0000007	h1n1_reuters__1000-01-01__timeline:166-170	1.000
:Event_0000007	Life.Die_Place.actual	:Entity_EDL_0000009	h1n1_reuters__1000-01-01__timeline:175-180	1.000
