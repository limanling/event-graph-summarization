:Event_0000000	type	Life.Injure.IllnessDegredationSickness
:Event_0000000	mention.actual	"contracted"	h1n1_bbc__1000-01-01__timeline:1587-1596	1.000
:Event_0000000	canonical_mention.actual	"contracted"	h1n1_bbc__1000-01-01__timeline:1587-1596	1.000
:Event_0000000	Life.Injure.IllnessDegredationSickness_Victim.actual	:Entity_EDL_0000011	h1n1_bbc__1000-01-01__timeline:1576-1581	1.000
:Event_0000000	Life.Injure.IllnessDegredationSickness_Victim.actual	:Entity_EDL_0000006	h1n1_bbc__1000-01-01__timeline:1583-1585	1.000
:Event_0000001	type	Life.Marry
:Event_0000001	mention.actual	"wed"	h1n1_bbc__1000-01-01__timeline:4904-4906	1.000
:Event_0000001	canonical_mention.actual	"wed"	h1n1_bbc__1000-01-01__timeline:4904-4906	1.000
:Event_0000001	Life.Marry_Person.actual	:Entity_EDL_0000014	h1n1_bbc__1000-01-01__timeline:4915-4918	1.000
:Event_0000001	Life.Marry_Person.actual	:Entity_EDL_0000004	h1n1_bbc__1000-01-01__timeline:4924-4934	1.000
:Event_0000002	type	Movement.TransportArtifact
:Event_0000002	mention.actual	"returned"	h1n1_bbc__1000-01-01__timeline:4955-4962	1.000
:Event_0000002	canonical_mention.actual	"returned"	h1n1_bbc__1000-01-01__timeline:4955-4962	1.000
:Event_0000002	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000014	h1n1_bbc__1000-01-01__timeline:4915-4918	1.000
:Event_0000002	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000004	h1n1_bbc__1000-01-01__timeline:4924-4934	1.000
:Event_0000002	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000003	h1n1_bbc__1000-01-01__timeline:4988-4993	1.000
:Event_0000002	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000002	h1n1_bbc__1000-01-01__timeline:5048-5065	1.000
:Event_0000003	type	Contact.Contact
:Event_0000003	mention.actual	"contact"	h1n1_bbc__1000-01-01__timeline:3795-3801	1.000
:Event_0000003	canonical_mention.actual	"contact"	h1n1_bbc__1000-01-01__timeline:3795-3801	1.000
:Event_0000003	Contact.Contact_Participant.actual	:Entity_EDL_0000008	h1n1_bbc__1000-01-01__timeline:3776-3781	1.000
:Event_0000003	Contact.Contact_Participant.actual	:Entity_EDL_0000013	h1n1_bbc__1000-01-01__timeline:3819-3824	1.000
:Event_0000004	type	Movement.TransportArtifact
:Event_0000004	mention.actual	"returning"	h1n1_bbc__1000-01-01__timeline:787-795	1.000
:Event_0000004	canonical_mention.actual	"returning"	h1n1_bbc__1000-01-01__timeline:787-795	1.000
:Event_0000004	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000019	h1n1_bbc__1000-01-01__timeline:726-736	1.000
:Event_0000004	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000009	h1n1_bbc__1000-01-01__timeline:766-774	1.000
:Event_0000004	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000000	h1n1_bbc__1000-01-01__timeline:802-807	1.000
:Event_0000005	type	Contact.Contact
:Event_0000005	mention.actual	"contact"	h1n1_bbc__1000-01-01__timeline:3455-3461	1.000
:Event_0000005	canonical_mention.actual	"contact"	h1n1_bbc__1000-01-01__timeline:3455-3461	1.000
:Event_0000005	Contact.Contact_Participant.actual	:Entity_EDL_0000012	h1n1_bbc__1000-01-01__timeline:3417-3422	1.000
:Event_0000005	Contact.Contact_Participant.actual	:Entity_EDL_0000015	h1n1_bbc__1000-01-01__timeline:3447-3449	1.000
:Event_0000005	Contact.Contact_Participant.actual	:Entity_EDL_0000005	h1n1_bbc__1000-01-01__timeline:3472-3478	1.000
:Event_0000006	type	Justice.ReleaseParole
:Event_0000006	mention.actual	"released"	h1n1_bbc__1000-01-01__timeline:2542-2549	1.000
:Event_0000006	canonical_mention.actual	"released"	h1n1_bbc__1000-01-01__timeline:2542-2549	1.000
:Event_0000006	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000021	h1n1_bbc__1000-01-01__timeline:2521-2530	1.000
:Event_0000006	Justice.ReleaseParole_Place.actual	:Entity_EDL_0000017	h1n1_bbc__1000-01-01__timeline:2556-2563	1.000
:Event_0000007	type	Transaction.TransferOwnership
:Event_0000007	mention.actual	"send"	h1n1_bbc__1000-01-01__timeline:243-246	1.000
:Event_0000007	canonical_mention.actual	"send"	h1n1_bbc__1000-01-01__timeline:243-246	1.000
:Event_0000007	Transaction.TransferOwnership_Giver.actual	:Entity_EDL_0000016	h1n1_bbc__1000-01-01__timeline:227-234	1.000
:Event_0000007	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000018	h1n1_bbc__1000-01-01__timeline:284-290	1.000
:Event_0000008	type	Movement.TransportArtifact
:Event_0000008	mention.actual	"returned"	h1n1_bbc__1000-01-01__timeline:4700-4707	1.000
:Event_0000008	canonical_mention.actual	"returned"	h1n1_bbc__1000-01-01__timeline:4700-4707	1.000
:Event_0000008	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000001	h1n1_bbc__1000-01-01__timeline:4660-4665	1.000
:Event_0000008	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000020	h1n1_bbc__1000-01-01__timeline:4736-4740	1.000
:Event_0000009	type	Contact.Correspondence
:Event_0000009	mention.actual	"came into contact"	h1n1_bbc__1000-01-01__timeline:4554-4570	1.000
:Event_0000009	canonical_mention.actual	"came into contact"	h1n1_bbc__1000-01-01__timeline:4554-4570	1.000
:Event_0000009	Contact.Correspondence_Participant.actual	:Entity_EDL_0000010	h1n1_bbc__1000-01-01__timeline:4543-4548	1.000
:Event_0000009	Contact.Correspondence_Participant.actual	:Entity_EDL_0000007	h1n1_bbc__1000-01-01__timeline:4584-4593	1.000
