:Entity_EDL_0000000	type	Organization
:Entity_EDL_0000000	canonical_mention	"World Health Organization"	h1n1_reuters__1000-01-01__timeline:238-262	1.0
:Entity_EDL_0000000	mention	"World Health Organization"	h1n1_reuters__1000-01-01__timeline:238-262	1.0
:Entity_EDL_0000000	link	20000237
:Entity_EDL_0000001	type	GeopoliticalEntity
:Entity_EDL_0000001	canonical_mention	"Mexico City"	h1n1_reuters__1000-01-01__timeline:842-852	1.0
:Entity_EDL_0000001	mention	"Mexico City"	h1n1_reuters__1000-01-01__timeline:842-852	1.0
:Entity_EDL_0000001	link	3530597
:Entity_EDL_0000002	type	GeopoliticalEntity
:Entity_EDL_0000002	mention	"Mexico"	h1n1_reuters__1000-01-01__timeline:273-278	1.0
:Entity_EDL_0000002	link	3996063
:Entity_EDL_0000003	type	Person
:Entity_EDL_0000003	canonical_mention	"team"	h1n1_reuters__1000-01-01__timeline:473-476	1.0
:Entity_EDL_0000003	nominal_mention	"team"	h1n1_reuters__1000-01-01__timeline:473-476	1.0
:Entity_EDL_0000003	link	NIL000000001
:Entity_EDL_0000004	type	Location
:Entity_EDL_0000004	canonical_mention	"area"	h1n1_reuters__1000-01-01__timeline:870-873	1.0
:Entity_EDL_0000004	nominal_mention	"area"	h1n1_reuters__1000-01-01__timeline:870-873	1.0
:Entity_EDL_0000004	link	NIL000000002
:Entity_EDL_0000005	type	GeopoliticalEntity
:Entity_EDL_0000005	mention	"Mexico"	h1n1_reuters__1000-01-01__timeline:1761-1766	1.0
:Entity_EDL_0000005	link	3996063
:Entity_EDL_0000006	type	Organization
:Entity_EDL_0000006	canonical_mention	"Centers for Disease Control and Prevention"	h1n1_reuters__1000-01-01__timeline:381-422	1.0
:Entity_EDL_0000006	mention	"Centers for Disease Control and Prevention"	h1n1_reuters__1000-01-01__timeline:381-422	1.0
:Entity_EDL_0000006	link	NIL000000003
:Entity_EDL_0000007	type	Person
:Entity_EDL_0000007	nominal_mention	"woman"	h1n1_reuters__1000-01-01__timeline:166-170	1.0
:Entity_EDL_0000007	link	NIL000000004
:Entity_EDL_0000008	type	GeopoliticalEntity
:Entity_EDL_0000008	canonical_mention	"Texas"	h1n1_reuters__1000-01-01__timeline:1621-1625	1.0
:Entity_EDL_0000008	mention	"Texas"	h1n1_reuters__1000-01-01__timeline:1621-1625	1.0
:Entity_EDL_0000008	link	4736286
:Entity_EDL_0000009	type	GeopoliticalEntity
:Entity_EDL_0000009	mention	"Oaxaca"	h1n1_reuters__1000-01-01__timeline:175-180	1.0
:Entity_EDL_0000009	link	3522509
:Entity_EDL_0000010	type	GeopoliticalEntity
:Entity_EDL_0000010	mention	"Mexico"	h1n1_reuters__1000-01-01__timeline:456-461	1.0
:Entity_EDL_0000010	link	3996063
:Entity_EDL_0000011	type	Person
:Entity_EDL_0000011	canonical_mention	"boy"	h1n1_reuters__1000-01-01__timeline:1573-1575	1.0
:Entity_EDL_0000011	nominal_mention	"boy"	h1n1_reuters__1000-01-01__timeline:1573-1575	1.0
:Entity_EDL_0000011	link	NIL000000005
