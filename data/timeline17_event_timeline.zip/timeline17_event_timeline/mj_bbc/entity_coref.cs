:Entity_EDL_0000000	type	Person
:Entity_EDL_0000000	mention	"Jackson"	mj_bbc__1000-01-01__timeline:8281-8287	1.0
:Entity_EDL_0000000	link	NIL000000001
:Entity_EDL_0000001	type	Person
:Entity_EDL_0000001	canonical_mention	"Paramedics"	mj_bbc__1000-01-01__timeline:92-101	1.0
:Entity_EDL_0000001	nominal_mention	"Paramedics"	mj_bbc__1000-01-01__timeline:92-101	1.0
:Entity_EDL_0000001	link	NIL000000002
:Entity_EDL_0000002	type	Person
:Entity_EDL_0000002	pronominal_mention	"He"	mj_bbc__1000-01-01__timeline:3154-3155	1.0
:Entity_EDL_0000002	link	NIL000000003
:Entity_EDL_0000003	type	Person
:Entity_EDL_0000003	pronominal_mention	"He"	mj_bbc__1000-01-01__timeline:6326-6327	1.0
:Entity_EDL_0000003	link	NIL000000004
:Entity_EDL_0000004	type	GeopoliticalEntity
:Entity_EDL_0000004	mention	"Los Angeles"	mj_bbc__1000-01-01__timeline:1962-1972	1.0
:Entity_EDL_0000004	link	5368361
:Entity_EDL_0000006	type	Person
:Entity_EDL_0000006	mention	"Jackson"	mj_bbc__1000-01-01__timeline:1352-1358	1.0
:Entity_EDL_0000006	link	NIL000000006
:Entity_EDL_0000007	type	Facility
:Entity_EDL_0000007	canonical_mention	"home"	mj_bbc__1000-01-01__timeline:710-713	1.0
:Entity_EDL_0000007	nominal_mention	"home"	mj_bbc__1000-01-01__timeline:710-713	1.0
:Entity_EDL_0000007	link	NIL000000007
:Entity_EDL_0000008	type	Person
:Entity_EDL_0000008	nominal_mention	"paramedics"	mj_bbc__1000-01-01__timeline:2882-2891	1.0
:Entity_EDL_0000008	link	NIL000000008
:Entity_EDL_0000009	type	Person
:Entity_EDL_0000009	pronominal_mention	"I"	mj_bbc__1000-01-01__timeline:7997-7997	1.0
:Entity_EDL_0000009	link	NIL000000009
:Entity_EDL_0000010	type	Person
:Entity_EDL_0000010	mention	"Murray"	mj_bbc__1000-01-01__timeline:6159-6164	1.0
:Entity_EDL_0000010	link	30003421
:Entity_EDL_0000011	type	Person
:Entity_EDL_0000011	nominal_mention	"police"	mj_bbc__1000-01-01__timeline:6203-6208	1.0
:Entity_EDL_0000011	link	NIL000000010
:Entity_EDL_0000012	type	Person
:Entity_EDL_0000012	mention	"Murray"	mj_bbc__1000-01-01__timeline:3089-3094	1.0
:Entity_EDL_0000012	link	30003421
:Entity_EDL_0000013	type	Person
:Entity_EDL_0000013	pronominal_mention	"his"	mj_bbc__1000-01-01__timeline:8494-8496	1.0
:Entity_EDL_0000013	link	NIL000000011
:Entity_EDL_0000015	type	Vehicle
:Entity_EDL_0000015	canonical_mention	"ambulance"	mj_bbc__1000-01-01__timeline:250-258	1.0
:Entity_EDL_0000015	nominal_mention	"ambulance"	mj_bbc__1000-01-01__timeline:250-258	1.0
:Entity_EDL_0000015	link	NIL000000013
:Entity_EDL_0000016	type	Person
:Entity_EDL_0000016	mention	"Jackson"	mj_bbc__1000-01-01__timeline:2904-2910	1.0
:Entity_EDL_0000016	link	NIL000000014
:Entity_EDL_0000017	type	Person
:Entity_EDL_0000017	mention	"Murray"	mj_bbc__1000-01-01__timeline:1098-1103	1.0
:Entity_EDL_0000017	link	30003421
:Entity_EDL_0000018	type	Person
:Entity_EDL_0000018	pronominal_mention	"his"	mj_bbc__1000-01-01__timeline:4425-4427	1.0
:Entity_EDL_0000018	link	NIL000000015
:Entity_EDL_0000019	type	Person
:Entity_EDL_0000019	mention	"Jackson"	mj_bbc__1000-01-01__timeline:289-295	1.0
:Entity_EDL_0000019	link	NIL000000016
:Entity_EDL_0000020	type	Person
:Entity_EDL_0000020	nominal_mention	"jury"	mj_bbc__1000-01-01__timeline:9633-9636	1.0
:Entity_EDL_0000020	link	NIL000000017
:Entity_EDL_0000021	type	Person
:Entity_EDL_0000021	mention	"Murray"	mj_bbc__1000-01-01__timeline:3865-3870	1.0
:Entity_EDL_0000021	link	30003421
:Entity_EDL_0000022	type	Facility
:Entity_EDL_0000022	canonical_mention	"center"	mj_bbc__1000-01-01__timeline:276-281	1.0
:Entity_EDL_0000022	nominal_mention	"center"	mj_bbc__1000-01-01__timeline:276-281	1.0
:Entity_EDL_0000022	link	NIL000000018
:Entity_EDL_0000023	type	Person
:Entity_EDL_0000023	canonical_mention	"officers"	mj_bbc__1000-01-01__timeline:555-562	1.0
:Entity_EDL_0000023	nominal_mention	"officers"	mj_bbc__1000-01-01__timeline:555-562	1.0
:Entity_EDL_0000023	link	NIL000000019
:Entity_EDL_0000024	type	Facility
:Entity_EDL_0000024	canonical_mention	"pharmacy"	mj_bbc__1000-01-01__timeline:940-947	1.0
:Entity_EDL_0000024	nominal_mention	"pharmacy"	mj_bbc__1000-01-01__timeline:940-947	1.0
:Entity_EDL_0000024	link	NIL000000020
:Entity_EDL_0000025	type	Person
:Entity_EDL_0000025	mention	"Murray"	mj_bbc__1000-01-01__timeline:7280-7285	1.0
:Entity_EDL_0000025	link	30003421
:Entity_EDL_0000026	type	Person
:Entity_EDL_0000026	canonical_mention	"police"	mj_bbc__1000-01-01__timeline:367-372	1.0
:Entity_EDL_0000026	nominal_mention	"police"	mj_bbc__1000-01-01__timeline:367-372	1.0
:Entity_EDL_0000026	link	NIL000000021
:Entity_EDL_0000027	type	GeopoliticalEntity
:Entity_EDL_0000027	mention	"Las Vegas"	mj_bbc__1000-01-01__timeline:1923-1931	1.0
:Entity_EDL_0000027	link	5506956
:Entity_EDL_0000028	type	GeopoliticalEntity
:Entity_EDL_0000028	canonical_mention	"sides"	mj_bbc__1000-01-01__timeline:3441-3445	1.0
:Entity_EDL_0000028	nominal_mention	"sides"	mj_bbc__1000-01-01__timeline:3441-3445	1.0
:Entity_EDL_0000028	link	NIL000000022
:Entity_EDL_0000029	type	Person
:Entity_EDL_0000029	canonical_mention	"He"	mj_bbc__1000-01-01__timeline:217-218	1.0
:Entity_EDL_0000029	pronominal_mention	"He"	mj_bbc__1000-01-01__timeline:217-218	1.0
:Entity_EDL_0000029	link	NIL000000023
:Entity_EDL_0000030	type	Facility
:Entity_EDL_0000030	pronominal_mention	"where"	mj_bbc__1000-01-01__timeline:283-287	1.0
:Entity_EDL_0000030	link	NIL000000024
:Entity_EDL_0000031	type	Person
:Entity_EDL_0000031	canonical_mention	"singer"	mj_bbc__1000-01-01__timeline:237-242	1.0
:Entity_EDL_0000031	nominal_mention	"singer"	mj_bbc__1000-01-01__timeline:237-242	1.0
:Entity_EDL_0000031	link	NIL000000025
:Entity_EDL_0000032	type	GeopoliticalEntity
:Entity_EDL_0000032	mention	"Los Angeles"	mj_bbc__1000-01-01__timeline:355-365	1.0
:Entity_EDL_0000032	link	5368361
:Entity_EDL_0000033	type	Person
:Entity_EDL_0000033	nominal_mention	"doctor"	mj_bbc__1000-01-01__timeline:3257-3262	1.0
:Entity_EDL_0000033	link	NIL000000026
:Entity_EDL_0000034	type	Person
:Entity_EDL_0000034	nominal_mention	"star"	mj_bbc__1000-01-01__timeline:5995-5998	1.0
:Entity_EDL_0000034	link	NIL000000027
:Entity_EDL_0000035	type	Facility
:Entity_EDL_0000035	canonical_mention	"clinic"	mj_bbc__1000-01-01__timeline:524-529	1.0
:Entity_EDL_0000035	nominal_mention	"clinic"	mj_bbc__1000-01-01__timeline:524-529	1.0
:Entity_EDL_0000035	link	NIL000000028
:Entity_EDL_0000036	type	Facility
:Entity_EDL_0000036	canonical_mention	"house"	mj_bbc__1000-01-01__timeline:121-125	1.0
:Entity_EDL_0000036	nominal_mention	"house"	mj_bbc__1000-01-01__timeline:121-125	1.0
:Entity_EDL_0000036	link	NIL000000029
:Entity_EDL_0000037	type	Person
:Entity_EDL_0000037	canonical_mention	"him"	mj_bbc__1000-01-01__timeline:1198-1200	1.0
:Entity_EDL_0000037	pronominal_mention	"him"	mj_bbc__1000-01-01__timeline:1198-1200	1.0
:Entity_EDL_0000037	link	NIL000000030
:Entity_EDL_0000038	type	Person
:Entity_EDL_0000038	pronominal_mention	"he"	mj_bbc__1000-01-01__timeline:1795-1796	1.0
:Entity_EDL_0000038	link	NIL000000031
:Entity_EDL_0000039	type	Person
:Entity_EDL_0000039	mention	"Jackson"	mj_bbc__1000-01-01__timeline:5195-5201	1.0
:Entity_EDL_0000039	link	NIL000000032
:Entity_EDL_0000040	type	Person
:Entity_EDL_0000040	nominal_mention	"singer"	mj_bbc__1000-01-01__timeline:9339-9344	1.0
:Entity_EDL_0000040	link	NIL000000033
:Entity_EDL_0000041	type	GeopoliticalEntity
:Entity_EDL_0000041	canonical_mention	"Houston"	mj_bbc__1000-01-01__timeline:534-540	1.0
:Entity_EDL_0000041	mention	"Houston"	mj_bbc__1000-01-01__timeline:534-540	1.0
:Entity_EDL_0000041	link	4699066
:Entity_EDL_0000042	type	Person
:Entity_EDL_0000042	pronominal_mention	"his"	mj_bbc__1000-01-01__timeline:9353-9355	1.0
:Entity_EDL_0000042	link	NIL000000034
:Entity_EDL_0000043	type	Person
:Entity_EDL_0000043	mention	"Murray"	mj_bbc__1000-01-01__timeline:387-392	1.0
:Entity_EDL_0000043	link	30003421
:Entity_EDL_0000044	type	Person
:Entity_EDL_0000044	canonical_mention	"physician"	mj_bbc__1000-01-01__timeline:2613-2621	1.0
:Entity_EDL_0000044	nominal_mention	"physician"	mj_bbc__1000-01-01__timeline:2613-2621	1.0
:Entity_EDL_0000044	link	NIL000000035
:Entity_EDL_0000045	type	Person
:Entity_EDL_0000045	mention	"Murray"	mj_bbc__1000-01-01__timeline:2844-2849	1.0
:Entity_EDL_0000045	link	30003421
:Entity_EDL_0000046	type	Person
:Entity_EDL_0000046	nominal_mention	"witnesses"	mj_bbc__1000-01-01__timeline:7315-7323	1.0
:Entity_EDL_0000046	link	NIL000000036
:Entity_EDL_0000047	type	Person
:Entity_EDL_0000047	mention	"Murray"	mj_bbc__1000-01-01__timeline:1718-1723	1.0
:Entity_EDL_0000047	link	30003421
:Entity_EDL_0000048	type	Person
:Entity_EDL_0000048	mention	"Murray"	mj_bbc__1000-01-01__timeline:2079-2084	1.0
:Entity_EDL_0000048	link	30003421
:Entity_EDL_0000049	type	Person
:Entity_EDL_0000049	canonical_mention	"Conrad Murray"	mj_bbc__1000-01-01__timeline:9555-9567	1.0
:Entity_EDL_0000049	mention	"Conrad Murray"	mj_bbc__1000-01-01__timeline:9555-9567	1.0
:Entity_EDL_0000049	link	NIL000000037
:Entity_EDL_0000050	type	Person
:Entity_EDL_0000050	nominal_mention	"father"	mj_bbc__1000-01-01__timeline:2552-2557	1.0
:Entity_EDL_0000050	link	NIL000000038
:Entity_EDL_0000051	type	Person
:Entity_EDL_0000051	nominal_mention	"lawyers"	mj_bbc__1000-01-01__timeline:7290-7296	1.0
:Entity_EDL_0000051	link	NIL000000039
:Entity_EDL_0000052	type	Facility
:Entity_EDL_0000052	canonical_mention	"here"	mj_bbc__1000-01-01__timeline:8004-8007	1.0
:Entity_EDL_0000052	pronominal_mention	"here"	mj_bbc__1000-01-01__timeline:8004-8007	1.0
:Entity_EDL_0000052	link	NIL000000040
:Entity_EDL_0000054	type	GeopoliticalEntity
:Entity_EDL_0000054	canonical_mention	"Las Vegas"	mj_bbc__1000-01-01__timeline:952-960	1.0
:Entity_EDL_0000054	mention	"Las Vegas"	mj_bbc__1000-01-01__timeline:952-960	1.0
:Entity_EDL_0000054	link	5506956
:Entity_EDL_0000055	type	Person
:Entity_EDL_0000055	nominal_mention	"jury"	mj_bbc__1000-01-01__timeline:9145-9148	1.0
:Entity_EDL_0000055	link	NIL000000042
:Entity_EDL_0000056	type	Person
:Entity_EDL_0000056	canonical_mention	"detectives"	mj_bbc__1000-01-01__timeline:6346-6355	1.0
:Entity_EDL_0000056	nominal_mention	"detectives"	mj_bbc__1000-01-01__timeline:6346-6355	1.0
:Entity_EDL_0000056	link	NIL000000043
:Entity_EDL_0000057	type	Person
:Entity_EDL_0000057	pronominal_mention	"He"	mj_bbc__1000-01-01__timeline:2130-2131	1.0
:Entity_EDL_0000057	link	NIL000000044
:Entity_EDL_0000058	type	Person
:Entity_EDL_0000058	nominal_mention	"doctor"	mj_bbc__1000-01-01__timeline:1860-1865	1.0
:Entity_EDL_0000058	link	NIL000000045
