:Entity_EDL_0000000	type	Facility
:Entity_EDL_0000000	mention	"White House"	bpoil_foxnews__1000-01-01__timeline:5201-5211	1.0
:Entity_EDL_0000000	link	NIL000000001
:Entity_EDL_0000001	type	Location
:Entity_EDL_0000001	canonical_mention	"Gulf"	bpoil_foxnews__1000-01-01__timeline:6585-6588	1.0
:Entity_EDL_0000001	nominal_mention	"Gulf"	bpoil_foxnews__1000-01-01__timeline:6585-6588	1.0
:Entity_EDL_0000001	link	NIL000000002
:Entity_EDL_0000002	type	Person
:Entity_EDL_0000002	nominal_mention	"executive"	bpoil_foxnews__1000-01-01__timeline:4089-4097	1.0
:Entity_EDL_0000002	link	NIL000000003
:Entity_EDL_0000003	type	Person
:Entity_EDL_0000003	canonical_mention	"Barack Obama"	bpoil_foxnews__1000-01-01__timeline:999-1010	1.0
:Entity_EDL_0000003	mention	"Barack Obama"	bpoil_foxnews__1000-01-01__timeline:999-1010	1.0
:Entity_EDL_0000003	link	NIL000000004
:Entity_EDL_0000004	type	Person
:Entity_EDL_0000004	canonical_mention	"executives"	bpoil_foxnews__1000-01-01__timeline:4134-4143	1.0
:Entity_EDL_0000004	nominal_mention	"executives"	bpoil_foxnews__1000-01-01__timeline:4134-4143	1.0
:Entity_EDL_0000004	link	NIL000000005
:Entity_EDL_0000005	type	Person
:Entity_EDL_0000005	mention	"Obama"	bpoil_foxnews__1000-01-01__timeline:6568-6572	1.0
:Entity_EDL_0000005	link	30001628
:Entity_EDL_0000006	type	Facility
:Entity_EDL_0000006	canonical_mention	"Situation Room"	bpoil_foxnews__1000-01-01__timeline:5276-5289	1.0
:Entity_EDL_0000006	mention	"Situation Room"	bpoil_foxnews__1000-01-01__timeline:5276-5289	1.0
:Entity_EDL_0000006	link	NIL000000006
:Entity_EDL_0000007	type	Person
:Entity_EDL_0000007	canonical_mention	"officials"	bpoil_foxnews__1000-01-01__timeline:3892-3900	1.0
:Entity_EDL_0000007	nominal_mention	"officials"	bpoil_foxnews__1000-01-01__timeline:3892-3900	1.0
:Entity_EDL_0000007	link	NIL000000007
:Entity_EDL_0000008	type	Person
:Entity_EDL_0000008	canonical_mention	"Janet Napolitano"	bpoil_foxnews__1000-01-01__timeline:3945-3960	1.0
:Entity_EDL_0000008	mention	"Janet Napolitano"	bpoil_foxnews__1000-01-01__timeline:3945-3960	1.0
:Entity_EDL_0000008	link	NIL000000008
:Entity_EDL_0000009	type	Location
:Entity_EDL_0000009	nominal_mention	"site"	bpoil_foxnews__1000-01-01__timeline:550-553	1.0
:Entity_EDL_0000009	link	NIL000000009
:Entity_EDL_0000010	type	Person
:Entity_EDL_0000010	mention	"Salazar"	bpoil_foxnews__1000-01-01__timeline:6242-6248	1.0
:Entity_EDL_0000010	link	NIL000000010
:Entity_EDL_0000011	type	Person
:Entity_EDL_0000011	mention	"Obama"	bpoil_foxnews__1000-01-01__timeline:4552-4556	1.0
:Entity_EDL_0000011	link	30001628
:Entity_EDL_0000012	type	Person
:Entity_EDL_0000012	mention	"Napolitano"	bpoil_foxnews__1000-01-01__timeline:6229-6238	1.0
:Entity_EDL_0000012	link	NIL000000011
:Entity_EDL_0000013	type	Person
:Entity_EDL_0000013	nominal_mention	"executives"	bpoil_foxnews__1000-01-01__timeline:6159-6168	1.0
:Entity_EDL_0000013	link	NIL000000012
:Entity_EDL_0000014	type	Location
:Entity_EDL_0000014	mention	"Gulf Coast"	bpoil_foxnews__1000-01-01__timeline:6683-6692	1.0
:Entity_EDL_0000014	link	3523271
:Entity_EDL_0000015	type	Person
:Entity_EDL_0000015	mention	"Obama"	bpoil_foxnews__1000-01-01__timeline:6217-6221	1.0
:Entity_EDL_0000015	link	30001628
:Entity_EDL_0000016	type	Person
:Entity_EDL_0000016	canonical_mention	"Valerie Jarrett"	bpoil_foxnews__1000-01-01__timeline:4001-4015	1.0
:Entity_EDL_0000016	mention	"Valerie Jarrett"	bpoil_foxnews__1000-01-01__timeline:4001-4015	1.0
:Entity_EDL_0000016	link	NIL000000013
:Entity_EDL_0000017	type	Location
:Entity_EDL_0000017	mention	"Gulf Coast"	bpoil_foxnews__1000-01-01__timeline:6277-6286	1.0
:Entity_EDL_0000017	link	3523271
:Entity_EDL_0000018	type	Facility
:Entity_EDL_0000018	canonical_mention	"Oval Office"	bpoil_foxnews__1000-01-01__timeline:1024-1034	1.0
:Entity_EDL_0000018	mention	"Oval Office"	bpoil_foxnews__1000-01-01__timeline:1024-1034	1.0
:Entity_EDL_0000018	link	NIL000000014
:Entity_EDL_0000019	type	GeopoliticalEntity
:Entity_EDL_0000019	canonical_mention	"New Orleans"	bpoil_foxnews__1000-01-01__timeline:442-452	1.0
:Entity_EDL_0000019	mention	"New Orleans"	bpoil_foxnews__1000-01-01__timeline:442-452	1.0
:Entity_EDL_0000019	link	4335045
:Entity_EDL_0000020	type	Person
:Entity_EDL_0000020	nominal_mention	"responders"	bpoil_foxnews__1000-01-01__timeline:6656-6665	1.0
:Entity_EDL_0000020	link	NIL000000015
:Entity_EDL_0000021	type	Person
:Entity_EDL_0000021	canonical_mention	"Carol Browner"	bpoil_foxnews__1000-01-01__timeline:4048-4060	1.0
:Entity_EDL_0000021	mention	"Carol Browner"	bpoil_foxnews__1000-01-01__timeline:4048-4060	1.0
:Entity_EDL_0000021	link	NIL000000016
:Entity_EDL_0000022	type	Person
:Entity_EDL_0000022	canonical_mention	"David Hayes"	bpoil_foxnews__1000-01-01__timeline:415-425	1.0
:Entity_EDL_0000022	mention	"David Hayes"	bpoil_foxnews__1000-01-01__timeline:415-425	1.0
:Entity_EDL_0000022	link	NIL000000017
:Entity_EDL_0000023	type	Location
:Entity_EDL_0000023	nominal_mention	"shoreline"	bpoil_foxnews__1000-01-01__timeline:4939-4947	1.0
:Entity_EDL_0000023	link	NIL000000018
:Entity_EDL_0000024	type	Vehicle
:Entity_EDL_0000024	nominal_mention	"vessels"	bpoil_foxnews__1000-01-01__timeline:6638-6644	1.0
:Entity_EDL_0000024	link	NIL000000019
:Entity_EDL_0000025	type	Facility
:Entity_EDL_0000025	canonical_mention	"plant"	bpoil_foxnews__1000-01-01__timeline:4601-4605	1.0
:Entity_EDL_0000025	nominal_mention	"plant"	bpoil_foxnews__1000-01-01__timeline:4601-4605	1.0
:Entity_EDL_0000025	link	NIL000000020
:Entity_EDL_0000026	type	Person
:Entity_EDL_0000026	mention	"Salazar"	bpoil_foxnews__1000-01-01__timeline:6128-6134	1.0
:Entity_EDL_0000026	link	NIL000000021
:Entity_EDL_0000027	type	Person
:Entity_EDL_0000027	canonical_mention	"Salazar"	bpoil_foxnews__1000-01-01__timeline:3964-3970	1.0
:Entity_EDL_0000027	mention	"Salazar"	bpoil_foxnews__1000-01-01__timeline:3964-3970	1.0
:Entity_EDL_0000027	link	NIL000000022
:Entity_EDL_0000028	type	Person
:Entity_EDL_0000028	canonical_mention	"Tony Hayward"	bpoil_foxnews__1000-01-01__timeline:4101-4112	1.0
:Entity_EDL_0000028	mention	"Tony Hayward"	bpoil_foxnews__1000-01-01__timeline:4101-4112	1.0
:Entity_EDL_0000028	link	NIL000000023
:Entity_EDL_0000029	type	Person
:Entity_EDL_0000029	nominal_mention	"officials"	bpoil_foxnews__1000-01-01__timeline:6264-6272	1.0
:Entity_EDL_0000029	link	NIL000000024
