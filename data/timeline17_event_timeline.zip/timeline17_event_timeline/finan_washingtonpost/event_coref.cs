:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"aid"	finan_washingtonpost__1000-01-01__timeline:6844-6846	1.000
:Event_0000000	canonical_mention.actual	"aid"	finan_washingtonpost__1000-01-01__timeline:6844-6846	1.000
:Event_0000000	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000129	finan_washingtonpost__1000-01-01__timeline:6752-6761	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"loan"	finan_washingtonpost__1000-01-01__timeline:43021-43024	1.000
:Event_0000000	canonical_mention.actual	"loan"	finan_washingtonpost__1000-01-01__timeline:43021-43024	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"loan"	finan_washingtonpost__1000-01-01__timeline:12668-12671	1.000
:Event_0000000	canonical_mention.actual	"loan"	finan_washingtonpost__1000-01-01__timeline:12668-12671	1.000
:Event_0000000	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000156	finan_washingtonpost__1000-01-01__timeline:12594-12603	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"aid"	finan_washingtonpost__1000-01-01__timeline:13973-13975	1.000
:Event_0000000	canonical_mention.actual	"aid"	finan_washingtonpost__1000-01-01__timeline:13973-13975	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"loan"	finan_washingtonpost__1000-01-01__timeline:34037-34040	1.000
:Event_0000000	canonical_mention.actual	"loan"	finan_washingtonpost__1000-01-01__timeline:34037-34040	1.000
:Event_0000000	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000011	finan_washingtonpost__1000-01-01__timeline:33989-33995	1.000
:Event_0000000	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000216	finan_washingtonpost__1000-01-01__timeline:34006-34008	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"aid"	finan_washingtonpost__1000-01-01__timeline:8098-8100	1.000
:Event_0000000	canonical_mention.actual	"aid"	finan_washingtonpost__1000-01-01__timeline:8098-8100	1.000
:Event_0000000	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000163	finan_washingtonpost__1000-01-01__timeline:7992-8001	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"bailout"	finan_washingtonpost__1000-01-01__timeline:39669-39675	1.000
:Event_0000000	canonical_mention.actual	"bailout"	finan_washingtonpost__1000-01-01__timeline:39669-39675	1.000
:Event_0000000	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000025	finan_washingtonpost__1000-01-01__timeline:39574-39580	1.000
:Event_0000000	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000259	finan_washingtonpost__1000-01-01__timeline:39686-39695	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"loans"	finan_washingtonpost__1000-01-01__timeline:39503-39507	1.000
:Event_0000000	canonical_mention.actual	"loans"	finan_washingtonpost__1000-01-01__timeline:39503-39507	1.000
:Event_0000000	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000256	finan_washingtonpost__1000-01-01__timeline:39492-39501	1.000
:Event_0000000	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000278	finan_washingtonpost__1000-01-01__timeline:39509-39511	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"funding"	finan_washingtonpost__1000-01-01__timeline:30750-30756	1.000
:Event_0000000	canonical_mention.actual	"funding"	finan_washingtonpost__1000-01-01__timeline:30750-30756	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"assistance"	finan_washingtonpost__1000-01-01__timeline:22161-22170	1.000
:Event_0000000	canonical_mention.actual	"assistance"	finan_washingtonpost__1000-01-01__timeline:22161-22170	1.000
:Event_0000000	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000101	finan_washingtonpost__1000-01-01__timeline:22108-22117	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"committing"	finan_washingtonpost__1000-01-01__timeline:10288-10297	1.000
:Event_0000000	canonical_mention.actual	"committing"	finan_washingtonpost__1000-01-01__timeline:10288-10297	1.000
:Event_0000000	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000215	finan_washingtonpost__1000-01-01__timeline:10194-10208	1.000
:Event_0000000	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000020	finan_washingtonpost__1000-01-01__timeline:10214-10221	1.000
:Event_0000000	Transaction.TransferMoney_Beneficiary.actual	:Entity_EDL_0000290	finan_washingtonpost__1000-01-01__timeline:10341-10350	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"funding"	finan_washingtonpost__1000-01-01__timeline:6585-6591	1.000
:Event_0000000	canonical_mention.actual	"funding"	finan_washingtonpost__1000-01-01__timeline:6585-6591	1.000
:Event_0000000	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000124	finan_washingtonpost__1000-01-01__timeline:6532-6541	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"loan"	finan_washingtonpost__1000-01-01__timeline:3640-3643	1.000
:Event_0000000	canonical_mention.actual	"loan"	finan_washingtonpost__1000-01-01__timeline:3640-3643	1.000
:Event_0000000	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000090	finan_washingtonpost__1000-01-01__timeline:3595-3605	1.000
:Event_0000000	Transaction.TransferMoney_Beneficiary.actual	:Entity_EDL_0000108	finan_washingtonpost__1000-01-01__timeline:3670-3679	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"bailed out"	finan_washingtonpost__1000-01-01__timeline:35630-35639	1.000
:Event_0000000	canonical_mention.actual	"bailed out"	finan_washingtonpost__1000-01-01__timeline:35630-35639	1.000
:Event_0000000	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000175	finan_washingtonpost__1000-01-01__timeline:35541-35547	1.000
:Event_0000000	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000255	finan_washingtonpost__1000-01-01__timeline:35618-35619	1.000
:Event_0000000	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000232	finan_washingtonpost__1000-01-01__timeline:35652-35660	1.000
:Event_0000000	type	Transaction.TransferMoney
:Event_0000000	mention.actual	"provide"	finan_washingtonpost__1000-01-01__timeline:20294-20300	1.000
:Event_0000000	canonical_mention.actual	"provide"	finan_washingtonpost__1000-01-01__timeline:20294-20300	1.000
:Event_0000000	Transaction.TransferMoney_Beneficiary.actual	:Entity_EDL_0000072	finan_washingtonpost__1000-01-01__timeline:20354-20361	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:34389-34391	1.000
:Event_0000001	canonical_mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:34389-34391	1.000
:Event_0000001	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000221	finan_washingtonpost__1000-01-01__timeline:34342-34343	1.000
:Event_0000001	Transaction.TransferOwnership_Giver.actual	:Entity_EDL_0000212	finan_washingtonpost__1000-01-01__timeline:34424-34426	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:46037-46039	1.000
:Event_0000001	canonical_mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:46037-46039	1.000
:Event_0000001	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000069	finan_washingtonpost__1000-01-01__timeline:46017-46025	1.000
:Event_0000001	Transaction.TransferOwnership_Giver.actual	:Entity_EDL_0000081	finan_washingtonpost__1000-01-01__timeline:46067-46074	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"takeover"	finan_washingtonpost__1000-01-01__timeline:54331-54338	1.000
:Event_0000001	canonical_mention.actual	"takeover"	finan_washingtonpost__1000-01-01__timeline:54331-54338	1.000
:Event_0000001	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000204	finan_washingtonpost__1000-01-01__timeline:54327-54329	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:36206-36208	1.000
:Event_0000001	canonical_mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:36206-36208	1.000
:Event_0000001	Transaction.TransferOwnership_Place.actual	:Entity_EDL_0000061	finan_washingtonpost__1000-01-01__timeline:36156-36161	1.000
:Event_0000001	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000144	finan_washingtonpost__1000-01-01__timeline:36195-36204	1.000
:Event_0000001	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000197	finan_washingtonpost__1000-01-01__timeline:36228-36232	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:38563-38565	1.000
:Event_0000001	canonical_mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:38563-38565	1.000
:Event_0000001	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000043	finan_washingtonpost__1000-01-01__timeline:38549-38558	1.000
:Event_0000001	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000007	finan_washingtonpost__1000-01-01__timeline:38577-38581	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"takeover"	finan_washingtonpost__1000-01-01__timeline:38785-38792	1.000
:Event_0000001	canonical_mention.actual	"takeover"	finan_washingtonpost__1000-01-01__timeline:38785-38792	1.000
:Event_0000001	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000022	finan_washingtonpost__1000-01-01__timeline:38781-38783	1.000
:Event_0000001	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000277	finan_washingtonpost__1000-01-01__timeline:38802-38809	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"purchased"	finan_washingtonpost__1000-01-01__timeline:51630-51638	1.000
:Event_0000001	canonical_mention.actual	"purchased"	finan_washingtonpost__1000-01-01__timeline:51630-51638	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:52683-52685	1.000
:Event_0000001	canonical_mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:52683-52685	1.000
:Event_0000001	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000173	finan_washingtonpost__1000-01-01__timeline:52658-52661	1.000
:Event_0000001	Transaction.TransferOwnership_Giver.actual	:Entity_EDL_0000252	finan_washingtonpost__1000-01-01__timeline:52718-52722	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"purchase"	finan_washingtonpost__1000-01-01__timeline:38848-38855	1.000
:Event_0000001	canonical_mention.actual	"purchase"	finan_washingtonpost__1000-01-01__timeline:38848-38855	1.000
:Event_0000001	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000265	finan_washingtonpost__1000-01-01__timeline:38822-38832	1.000
:Event_0000001	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000171	finan_washingtonpost__1000-01-01__timeline:38870-38873	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:42654-42656	1.000
:Event_0000001	canonical_mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:42654-42656	1.000
:Event_0000001	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000234	finan_washingtonpost__1000-01-01__timeline:42629-42637	1.000
:Event_0000001	Transaction.TransferOwnership_Giver.actual	:Entity_EDL_0000268	finan_washingtonpost__1000-01-01__timeline:42663-42670	1.000
:Event_0000001	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000093	finan_washingtonpost__1000-01-01__timeline:42683-42690	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:34710-34712	1.000
:Event_0000001	canonical_mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:34710-34712	1.000
:Event_0000001	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000225	finan_washingtonpost__1000-01-01__timeline:34692-34693	1.000
:Event_0000001	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000258	finan_washingtonpost__1000-01-01__timeline:34716-34719	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"bought"	finan_washingtonpost__1000-01-01__timeline:42576-42581	1.000
:Event_0000001	canonical_mention.actual	"bought"	finan_washingtonpost__1000-01-01__timeline:42576-42581	1.000
:Event_0000001	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000182	finan_washingtonpost__1000-01-01__timeline:42534-42541	1.000
:Event_0000001	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000148	finan_washingtonpost__1000-01-01__timeline:42586-42596	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"acquire"	finan_washingtonpost__1000-01-01__timeline:34738-34744	1.000
:Event_0000001	canonical_mention.actual	"acquire"	finan_washingtonpost__1000-01-01__timeline:34738-34744	1.000
:Event_0000001	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000225	finan_washingtonpost__1000-01-01__timeline:34692-34693	1.000
:Event_0000001	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000014	finan_washingtonpost__1000-01-01__timeline:34727-34729	1.000
:Event_0000001	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000176	finan_washingtonpost__1000-01-01__timeline:34746-34753	1.000
:Event_0000001	type	Transaction.TransferOwnership
:Event_0000001	mention.actual	"sell"	finan_washingtonpost__1000-01-01__timeline:48660-48663	1.000
:Event_0000001	canonical_mention.actual	"sell"	finan_washingtonpost__1000-01-01__timeline:48660-48663	1.000
:Event_0000001	Transaction.TransferOwnership_Giver.actual	:Entity_EDL_0000012	finan_washingtonpost__1000-01-01__timeline:48537-48546	1.000
:Event_0000001	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000297	finan_washingtonpost__1000-01-01__timeline:48688-48704	1.000
:Event_0000002	type	Personnel.Elect
:Event_0000002	mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:9758-9762	1.000
:Event_0000002	canonical_mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:9758-9762	1.000
:Event_0000002	Personnel.Elect_Elect.actual	:Entity_EDL_0000155	finan_washingtonpost__1000-01-01__timeline:9764-9775	1.000
:Event_0000002	type	Personnel.Elect
:Event_0000002	mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:11495-11499	1.000
:Event_0000002	canonical_mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:11495-11499	1.000
:Event_0000002	Personnel.Elect_Elect.actual	:Entity_EDL_0000222	finan_washingtonpost__1000-01-01__timeline:11501-11512	1.000
:Event_0000002	type	Personnel.Elect
:Event_0000002	mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:24634-24638	1.000
:Event_0000002	canonical_mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:24634-24638	1.000
:Event_0000002	Personnel.Elect_Elect.actual	:Entity_EDL_0000205	finan_washingtonpost__1000-01-01__timeline:24624-24633	1.000
:Event_0000002	Personnel.Elect_Elect.actual	:Entity_EDL_0000192	finan_washingtonpost__1000-01-01__timeline:24640-24651	1.000
:Event_0000002	type	Personnel.Elect
:Event_0000002	mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:11783-11787	1.000
:Event_0000002	canonical_mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:11783-11787	1.000
:Event_0000002	Personnel.Elect_Elect.actual	:Entity_EDL_0000161	finan_washingtonpost__1000-01-01__timeline:11789-11800	1.000
:Event_0000002	type	Personnel.Elect
:Event_0000002	mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:21783-21787	1.000
:Event_0000002	canonical_mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:21783-21787	1.000
:Event_0000002	Personnel.Elect_Elect.actual	:Entity_EDL_0000104	finan_washingtonpost__1000-01-01__timeline:21789-21793	1.000
:Event_0000002	type	Personnel.Elect
:Event_0000002	mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:11098-11102	1.000
:Event_0000002	canonical_mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:11098-11102	1.000
:Event_0000002	Personnel.Elect_Elect.actual	:Entity_EDL_0000121	finan_washingtonpost__1000-01-01__timeline:11104-11115	1.000
:Event_0000002	type	Personnel.Elect
:Event_0000002	mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:22185-22189	1.000
:Event_0000002	canonical_mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:22185-22189	1.000
:Event_0000002	Personnel.Elect_Elect.actual	:Entity_EDL_0000004	finan_washingtonpost__1000-01-01__timeline:22191-22202	1.000
:Event_0000002	type	Personnel.Elect
:Event_0000002	mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:12063-12067	1.000
:Event_0000002	canonical_mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:12063-12067	1.000
:Event_0000002	Personnel.Elect_Elect.actual	:Entity_EDL_0000019	finan_washingtonpost__1000-01-01__timeline:12069-12080	1.000
:Event_0000002	type	Personnel.Elect
:Event_0000002	mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:9112-9116	1.000
:Event_0000002	canonical_mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:9112-9116	1.000
:Event_0000002	Personnel.Elect_Elector.actual	:Entity_EDL_0000269	finan_washingtonpost__1000-01-01__timeline:9118-9129	1.000
:Event_0000002	Personnel.Elect_Elect.actual	:Entity_EDL_0000023	finan_washingtonpost__1000-01-01__timeline:9169-9180	1.000
:Event_0000002	type	Personnel.Elect
:Event_0000002	mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:4570-4574	1.000
:Event_0000002	canonical_mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:4570-4574	1.000
:Event_0000003	type	Business.DeclareBankruptcy
:Event_0000003	mention.actual	"bankruptcy"	finan_washingtonpost__1000-01-01__timeline:21132-21141	1.000
:Event_0000003	canonical_mention.actual	"bankruptcy"	finan_washingtonpost__1000-01-01__timeline:21132-21141	1.000
:Event_0000003	Business.DeclareBankruptcy_Organization.actual	:Entity_EDL_0000159	finan_washingtonpost__1000-01-01__timeline:21098-21109	1.000
:Event_0000003	type	Business.DeclareBankruptcy
:Event_0000003	mention.actual	"bankruptcy"	finan_washingtonpost__1000-01-01__timeline:30827-30836	1.000
:Event_0000003	canonical_mention.actual	"bankruptcy"	finan_washingtonpost__1000-01-01__timeline:30827-30836	1.000
:Event_0000003	Business.DeclareBankruptcy_Organization.actual	:Entity_EDL_0000200	finan_washingtonpost__1000-01-01__timeline:30819-30820	1.000
:Event_0000003	type	Business.DeclareBankruptcy
:Event_0000003	mention.actual	"bankruptcy"	finan_washingtonpost__1000-01-01__timeline:38729-38738	1.000
:Event_0000003	canonical_mention.actual	"bankruptcy"	finan_washingtonpost__1000-01-01__timeline:38729-38738	1.000
:Event_0000003	Business.DeclareBankruptcy_Organization.actual	:Entity_EDL_0000283	finan_washingtonpost__1000-01-01__timeline:38700-38701	1.000
:Event_0000003	type	Business.DeclareBankruptcy
:Event_0000003	mention.actual	"Chapter"	finan_washingtonpost__1000-01-01__timeline:21121-21127	1.000
:Event_0000003	canonical_mention.actual	"Chapter"	finan_washingtonpost__1000-01-01__timeline:21121-21127	1.000
:Event_0000003	Business.DeclareBankruptcy_Organization.actual	:Entity_EDL_0000159	finan_washingtonpost__1000-01-01__timeline:21098-21109	1.000
:Event_0000004	type	Personnel.StartPosition
:Event_0000004	mention.actual	"hires"	finan_washingtonpost__1000-01-01__timeline:31442-31446	1.000
:Event_0000004	canonical_mention.actual	"hires"	finan_washingtonpost__1000-01-01__timeline:31442-31446	1.000
:Event_0000004	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000179	finan_washingtonpost__1000-01-01__timeline:31433-31440	1.000
:Event_0000004	Personnel.StartPosition_Person.actual	:Entity_EDL_0000034	finan_washingtonpost__1000-01-01__timeline:31448-31465	1.000
:Event_0000004	type	Personnel.StartPosition
:Event_0000004	mention.actual	"hires"	finan_washingtonpost__1000-01-01__timeline:34939-34943	1.000
:Event_0000004	canonical_mention.actual	"hires"	finan_washingtonpost__1000-01-01__timeline:34939-34943	1.000
:Event_0000004	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000003	finan_washingtonpost__1000-01-01__timeline:34953-34956	1.000
:Event_0000004	type	Personnel.StartPosition
:Event_0000004	mention.actual	"hired"	finan_washingtonpost__1000-01-01__timeline:32395-32399	1.000
:Event_0000004	canonical_mention.actual	"hired"	finan_washingtonpost__1000-01-01__timeline:32395-32399	1.000
:Event_0000004	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000015	finan_washingtonpost__1000-01-01__timeline:32364-32371	1.000
:Event_0000004	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000276	finan_washingtonpost__1000-01-01__timeline:32388-32389	1.000
:Event_0000004	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000089	finan_washingtonpost__1000-01-01__timeline:32401-32422	1.000
:Event_0000004	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000193	finan_washingtonpost__1000-01-01__timeline:32428-32440	1.000
:Event_0000005	type	Personnel.Nominate
:Event_0000005	mention.actual	"selects"	finan_washingtonpost__1000-01-01__timeline:12082-12088	1.000
:Event_0000005	canonical_mention.actual	"selects"	finan_washingtonpost__1000-01-01__timeline:12082-12088	1.000
:Event_0000005	Personnel.Nominate_Nominator.actual	:Entity_EDL_0000019	finan_washingtonpost__1000-01-01__timeline:12069-12080	1.000
:Event_0000005	Personnel.Nominate_Nominee.actual	:Entity_EDL_0000264	finan_washingtonpost__1000-01-01__timeline:12130-12145	1.000
:Event_0000005	type	Personnel.Nominate
:Event_0000005	mention.actual	"names"	finan_washingtonpost__1000-01-01__timeline:16957-16961	1.000
:Event_0000005	canonical_mention.actual	"names"	finan_washingtonpost__1000-01-01__timeline:16957-16961	1.000
:Event_0000005	Personnel.Nominate_Nominator.actual	:Entity_EDL_0000167	finan_washingtonpost__1000-01-01__timeline:16952-16955	1.000
:Event_0000005	Personnel.Nominate_Nominee.actual	:Entity_EDL_0000077	finan_washingtonpost__1000-01-01__timeline:16991-17003	1.000
:Event_0000005	type	Personnel.Nominate
:Event_0000005	mention.actual	"names"	finan_washingtonpost__1000-01-01__timeline:9777-9781	1.000
:Event_0000005	canonical_mention.actual	"names"	finan_washingtonpost__1000-01-01__timeline:9777-9781	1.000
:Event_0000005	Personnel.Nominate_Nominator.actual	:Entity_EDL_0000155	finan_washingtonpost__1000-01-01__timeline:9764-9775	1.000
:Event_0000005	Personnel.Nominate_Nominee.actual	:Entity_EDL_0000186	finan_washingtonpost__1000-01-01__timeline:9815-9826	1.000
:Event_0000006	type	Justice.Sue
:Event_0000006	mention.actual	"lawsuit"	finan_washingtonpost__1000-01-01__timeline:38945-38951	1.000
:Event_0000006	canonical_mention.actual	"lawsuit"	finan_washingtonpost__1000-01-01__timeline:38945-38951	1.000
:Event_0000006	Justice.Sue_Plaintiff.actual	:Entity_EDL_0000073	finan_washingtonpost__1000-01-01__timeline:38903-38904	1.000
:Event_0000006	Justice.Sue_Defendant.actual	:Entity_EDL_0000049	finan_washingtonpost__1000-01-01__timeline:38969-38977	1.000
:Event_0000006	type	Justice.Sue
:Event_0000006	mention.actual	"lawsuit"	finan_washingtonpost__1000-01-01__timeline:41249-41255	1.000
:Event_0000006	canonical_mention.actual	"lawsuit"	finan_washingtonpost__1000-01-01__timeline:41249-41255	1.000
:Event_0000006	Justice.Sue_Plaintiff.actual	:Entity_EDL_0000117	finan_washingtonpost__1000-01-01__timeline:41218-41226	1.000
:Event_0000006	Justice.Sue_Defendant.actual	:Entity_EDL_0000236	finan_washingtonpost__1000-01-01__timeline:41265-41272	1.000
:Event_0000006	Justice.Sue_Defendant.actual	:Entity_EDL_0000279	finan_washingtonpost__1000-01-01__timeline:41278-41288	1.000
:Event_0000006	type	Justice.Sue
:Event_0000006	mention.actual	"lawsuits"	finan_washingtonpost__1000-01-01__timeline:41506-41513	1.000
:Event_0000006	canonical_mention.actual	"lawsuits"	finan_washingtonpost__1000-01-01__timeline:41506-41513	1.000
:Event_0000006	Justice.Sue_Plaintiff.actual	:Entity_EDL_0000226	finan_washingtonpost__1000-01-01__timeline:41486-41494	1.000
:Event_0000006	Justice.Sue_Defendant.actual	:Entity_EDL_0000084	finan_washingtonpost__1000-01-01__timeline:41531-41551	1.000
:Event_0000007	type	Personnel.EndPosition
:Event_0000007	mention.actual	"cut"	finan_washingtonpost__1000-01-01__timeline:29915-29917	1.000
:Event_0000007	canonical_mention.actual	"cut"	finan_washingtonpost__1000-01-01__timeline:29915-29917	1.000
:Event_0000007	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000113	finan_washingtonpost__1000-01-01__timeline:29907-29908	1.000
:Event_0000007	Personnel.EndPosition_Person.actual	:Entity_EDL_0000280	finan_washingtonpost__1000-01-01__timeline:29922-29928	1.000
:Event_0000007	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000240	finan_washingtonpost__1000-01-01__timeline:29933-29935	1.000
:Event_0000007	Personnel.EndPosition_Person.actual	:Entity_EDL_0000031	finan_washingtonpost__1000-01-01__timeline:29950-29958	1.000
:Event_0000007	type	Personnel.EndPosition
:Event_0000007	mention.actual	"cut"	finan_washingtonpost__1000-01-01__timeline:19488-19490	1.000
:Event_0000007	canonical_mention.actual	"cut"	finan_washingtonpost__1000-01-01__timeline:19488-19490	1.000
:Event_0000007	Personnel.EndPosition_Person.actual	:Entity_EDL_0000244	finan_washingtonpost__1000-01-01__timeline:19547-19553	1.000
:Event_0000008	type	Business.DeclareBankruptcy
:Event_0000008	mention.actual	"bankruptcy"	finan_washingtonpost__1000-01-01__timeline:4057-4066	1.000
:Event_0000008	canonical_mention.actual	"bankruptcy"	finan_washingtonpost__1000-01-01__timeline:4057-4066	1.000
:Event_0000008	Business.DeclareBankruptcy_Organization.actual	:Entity_EDL_0000098	finan_washingtonpost__1000-01-01__timeline:4024-4034	1.000
:Event_0000008	type	Business.DeclareBankruptcy
:Event_0000008	mention.actual	"Chapter 11"	finan_washingtonpost__1000-01-01__timeline:4046-4055	1.000
:Event_0000008	canonical_mention.actual	"Chapter 11"	finan_washingtonpost__1000-01-01__timeline:4046-4055	1.000
:Event_0000008	Business.DeclareBankruptcy_Organization.actual	:Entity_EDL_0000098	finan_washingtonpost__1000-01-01__timeline:4024-4034	1.000
:Event_0000009	type	Business.DeclareBankruptcy
:Event_0000009	mention.actual	"bankruptcy"	finan_washingtonpost__1000-01-01__timeline:54800-54809	1.000
:Event_0000009	canonical_mention.actual	"bankruptcy"	finan_washingtonpost__1000-01-01__timeline:54800-54809	1.000
:Event_0000009	Business.DeclareBankruptcy_Organization.actual	:Entity_EDL_0000153	finan_washingtonpost__1000-01-01__timeline:54775-54789	1.000
:Event_0000009	type	Business.DeclareBankruptcy
:Event_0000009	mention.actual	"bankruptcy"	finan_washingtonpost__1000-01-01__timeline:54869-54878	1.000
:Event_0000009	canonical_mention.actual	"bankruptcy"	finan_washingtonpost__1000-01-01__timeline:54869-54878	1.000
:Event_0000009	Business.DeclareBankruptcy_Organization.actual	:Entity_EDL_0000153	finan_washingtonpost__1000-01-01__timeline:54775-54789	1.000
:Event_0000010	type	Contact.Meet
:Event_0000010	mention.actual	"meeting"	finan_washingtonpost__1000-01-01__timeline:40753-40759	1.000
:Event_0000010	canonical_mention.actual	"meeting"	finan_washingtonpost__1000-01-01__timeline:40753-40759	1.000
:Event_0000010	Contact.Meet_Participant.actual	:Entity_EDL_0000033	finan_washingtonpost__1000-01-01__timeline:40679-40690	1.000
:Event_0000010	Contact.Meet_Participant.actual	:Entity_EDL_0000135	finan_washingtonpost__1000-01-01__timeline:40741-40743	1.000
:Event_0000010	type	Contact.Meet
:Event_0000010	mention.actual	"meeting"	finan_washingtonpost__1000-01-01__timeline:48167-48173	1.000
:Event_0000010	canonical_mention.actual	"meeting"	finan_washingtonpost__1000-01-01__timeline:48167-48173	1.000
:Event_0000010	Contact.Meet_Participant.actual	:Entity_EDL_0000110	finan_washingtonpost__1000-01-01__timeline:48070-48083	1.000
:Event_0000010	Contact.Meet_Participant.actual	:Entity_EDL_0000145	finan_washingtonpost__1000-01-01__timeline:48152-48156	1.000
:Event_0000010	Contact.Meet_Participant.actual	:Entity_EDL_0000001	finan_washingtonpost__1000-01-01__timeline:48190-48193	1.000
:Event_0000010	Contact.Meet_Participant.actual	:Entity_EDL_0000134	finan_washingtonpost__1000-01-01__timeline:48211-48217	1.000
:Event_0000010	Contact.Meet_Participant.actual	:Entity_EDL_0000021	finan_washingtonpost__1000-01-01__timeline:48240-48247	1.000
:Event_0000011	type	Personnel.EndPosition
:Event_0000011	mention.actual	"former"	finan_washingtonpost__1000-01-01__timeline:9137-9142	1.000
:Event_0000011	canonical_mention.actual	"former"	finan_washingtonpost__1000-01-01__timeline:9137-9142	1.000
:Event_0000011	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000164	finan_washingtonpost__1000-01-01__timeline:9144-9158	1.000
:Event_0000011	Personnel.EndPosition_Person.actual	:Entity_EDL_0000023	finan_washingtonpost__1000-01-01__timeline:9169-9180	1.000
:Event_0000011	type	Personnel.EndPosition
:Event_0000011	mention.actual	"former"	finan_washingtonpost__1000-01-01__timeline:9783-9788	1.000
:Event_0000011	canonical_mention.actual	"former"	finan_washingtonpost__1000-01-01__timeline:9783-9788	1.000
:Event_0000011	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000184	finan_washingtonpost__1000-01-01__timeline:9790-9804	1.000
:Event_0000011	Personnel.EndPosition_Person.actual	:Entity_EDL_0000186	finan_washingtonpost__1000-01-01__timeline:9815-9826	1.000
:Event_0000012	type	Contact.Meet
:Event_0000012	mention.actual	"Conference"	finan_washingtonpost__1000-01-01__timeline:16318-16327	1.000
:Event_0000012	canonical_mention.actual	"Conference"	finan_washingtonpost__1000-01-01__timeline:16318-16327	1.000
:Event_0000012	Contact.Meet_Participant.actual	:Entity_EDL_0000105	finan_washingtonpost__1000-01-01__timeline:16252-16263	1.000
:Event_0000012	Contact.Meet_Place.actual	:Entity_EDL_0000092	finan_washingtonpost__1000-01-01__timeline:16332-16340	1.000
:Event_0000012	type	Contact.Meet
:Event_0000012	mention.actual	"summit"	finan_washingtonpost__1000-01-01__timeline:17923-17928	1.000
:Event_0000012	canonical_mention.actual	"summit"	finan_washingtonpost__1000-01-01__timeline:17923-17928	1.000
:Event_0000012	Contact.Meet_Participant.actual	:Entity_EDL_0000048	finan_washingtonpost__1000-01-01__timeline:17942-17945	1.000
:Event_0000013	type	Contact.Meet
:Event_0000013	mention.actual	"hearing"	finan_washingtonpost__1000-01-01__timeline:2329-2335	1.000
:Event_0000013	canonical_mention.actual	"hearing"	finan_washingtonpost__1000-01-01__timeline:2329-2335	1.000
:Event_0000013	Contact.Meet_Participant.actual	:Entity_EDL_0000261	finan_washingtonpost__1000-01-01__timeline:2291-2303	1.000
:Event_0000013	Contact.Meet_Participant.actual	:Entity_EDL_0000018	finan_washingtonpost__1000-01-01__timeline:2323-2327	1.000
:Event_0000013	type	Contact.Meet
:Event_0000013	mention.actual	"hearing"	finan_washingtonpost__1000-01-01__timeline:14890-14896	1.000
:Event_0000013	canonical_mention.actual	"hearing"	finan_washingtonpost__1000-01-01__timeline:14890-14896	1.000
:Event_0000013	Contact.Meet_Participant.actual	:Entity_EDL_0000253	finan_washingtonpost__1000-01-01__timeline:14907-14940	1.000
:Event_0000013	Contact.Meet_Participant.actual	:Entity_EDL_0000079	finan_washingtonpost__1000-01-01__timeline:14963-14975	1.000
:Event_0000014	type	Business.End
:Event_0000014	mention.actual	"collapse"	finan_washingtonpost__1000-01-01__timeline:1748-1755	1.000
:Event_0000014	canonical_mention.actual	"collapse"	finan_washingtonpost__1000-01-01__timeline:1748-1755	1.000
:Event_0000014	Business.End_Organization.actual	:Entity_EDL_0000288	finan_washingtonpost__1000-01-01__timeline:1794-1801	1.000
:Event_0000014	type	Business.End
:Event_0000014	mention.actual	"collapse"	finan_washingtonpost__1000-01-01__timeline:353-360	1.000
:Event_0000014	canonical_mention.actual	"collapse"	finan_washingtonpost__1000-01-01__timeline:353-360	1.000
:Event_0000014	Business.End_Organization.actual	:Entity_EDL_0000229	finan_washingtonpost__1000-01-01__timeline:379-388	1.000
:Event_0000015	type	Contact.Meet
:Event_0000015	mention.actual	"debate"	finan_washingtonpost__1000-01-01__timeline:49657-49662	1.000
:Event_0000015	canonical_mention.actual	"debate"	finan_washingtonpost__1000-01-01__timeline:49657-49662	1.000
:Event_0000015	type	Contact.Meet
:Event_0000015	mention.actual	"debate"	finan_washingtonpost__1000-01-01__timeline:47813-47818	1.000
:Event_0000015	canonical_mention.actual	"debate"	finan_washingtonpost__1000-01-01__timeline:47813-47818	1.000
:Event_0000015	Contact.Meet_Participant.actual	:Entity_EDL_0000202	finan_washingtonpost__1000-01-01__timeline:47777-47778	1.000
:Event_0000015	Contact.Meet_Participant.actual	:Entity_EDL_0000239	finan_washingtonpost__1000-01-01__timeline:47790-47801	1.000
:Event_0000015	Contact.Meet_Participant.actual	:Entity_EDL_0000188	finan_washingtonpost__1000-01-01__timeline:47807-47811	1.000
:Event_0000015	Contact.Meet_Place.actual	:Entity_EDL_0000143	finan_washingtonpost__1000-01-01__timeline:47823-47833	1.000
:Event_0000016	type	Transaction.TransferOwnership
:Event_0000016	mention.actual	"buying"	finan_washingtonpost__1000-01-01__timeline:29771-29776	1.000
:Event_0000016	canonical_mention.actual	"buying"	finan_washingtonpost__1000-01-01__timeline:29771-29776	1.000
:Event_0000016	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000165	finan_washingtonpost__1000-01-01__timeline:29765-29766	1.000
:Event_0000016	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000133	finan_washingtonpost__1000-01-01__timeline:29778-29790	1.000
:Event_0000016	type	Transaction.TransferOwnership
:Event_0000016	mention.actual	"acquire"	finan_washingtonpost__1000-01-01__timeline:18460-18466	1.000
:Event_0000016	canonical_mention.actual	"acquire"	finan_washingtonpost__1000-01-01__timeline:18460-18466	1.000
:Event_0000016	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000183	finan_washingtonpost__1000-01-01__timeline:18446-18454	1.000
:Event_0000016	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000131	finan_washingtonpost__1000-01-01__timeline:18468-18483	1.000
:Event_0000017	type	Business.End
:Event_0000017	mention.actual	"failure"	finan_washingtonpost__1000-01-01__timeline:44349-44355	1.000
:Event_0000017	canonical_mention.actual	"failure"	finan_washingtonpost__1000-01-01__timeline:44349-44355	1.000
:Event_0000017	Business.End_Organization.actual	:Entity_EDL_0000196	finan_washingtonpost__1000-01-01__timeline:44360-44362	1.000
:Event_0000017	type	Business.End
:Event_0000017	mention.actual	"collapse"	finan_washingtonpost__1000-01-01__timeline:50825-50832	1.000
:Event_0000017	canonical_mention.actual	"collapse"	finan_washingtonpost__1000-01-01__timeline:50825-50832	1.000
:Event_0000017	Business.End_Organization.actual	:Entity_EDL_0000091	finan_washingtonpost__1000-01-01__timeline:50845-50850	1.000
:Event_0000017	Business.End_Organization.actual	:Entity_EDL_0000026	finan_washingtonpost__1000-01-01__timeline:50852-50861	1.000
:Event_0000017	Business.End_Organization.actual	:Entity_EDL_0000099	finan_washingtonpost__1000-01-01__timeline:50865-50875	1.000
:Event_0000017	Business.End_Organization.actual	:Entity_EDL_0000213	finan_washingtonpost__1000-01-01__timeline:50879-50893	1.000
:Event_0000017	Business.End_Organization.actual	:Entity_EDL_0000070	finan_washingtonpost__1000-01-01__timeline:50899-50901	1.000
:Event_0000018	type	Transaction.TransferOwnership
:Event_0000018	mention.actual	"purchase"	finan_washingtonpost__1000-01-01__timeline:18836-18843	1.000
:Event_0000018	canonical_mention.actual	"purchase"	finan_washingtonpost__1000-01-01__timeline:18836-18843	1.000
:Event_0000018	Transaction.TransferOwnership_Giver.actual	:Entity_EDL_0000071	finan_washingtonpost__1000-01-01__timeline:18790-18799	1.000
:Event_0000018	type	Transaction.TransferOwnership
:Event_0000018	mention.actual	"purchase"	finan_washingtonpost__1000-01-01__timeline:19004-19011	1.000
:Event_0000018	canonical_mention.actual	"purchase"	finan_washingtonpost__1000-01-01__timeline:19004-19011	1.000
:Event_0000018	Transaction.TransferOwnership_Giver.actual	:Entity_EDL_0000162	finan_washingtonpost__1000-01-01__timeline:18958-18967	1.000
:Event_0000019	type	Transaction.TransferMoney
:Event_0000019	mention.actual	"getting"	finan_washingtonpost__1000-01-01__timeline:27136-27142	1.000
:Event_0000019	canonical_mention.actual	"getting"	finan_washingtonpost__1000-01-01__timeline:27136-27142	1.000
:Event_0000019	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000024	finan_washingtonpost__1000-01-01__timeline:27130-27134	1.000
:Event_0000019	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000009	finan_washingtonpost__1000-01-01__timeline:27177-27195	1.000
:Event_0000020	type	Contact.Meet
:Event_0000020	mention.actual	"meeting"	finan_washingtonpost__1000-01-01__timeline:36960-36966	1.000
:Event_0000020	canonical_mention.actual	"meeting"	finan_washingtonpost__1000-01-01__timeline:36960-36966	1.000
:Event_0000020	Contact.Meet_Participant.actual	:Entity_EDL_0000170	finan_washingtonpost__1000-01-01__timeline:36938-36950	1.000
:Event_0000020	Contact.Meet_Place.actual	:Entity_EDL_0000217	finan_washingtonpost__1000-01-01__timeline:36975-36993	1.000
:Event_0000021	type	Personnel.EndPosition
:Event_0000021	mention.actual	"laid off"	finan_washingtonpost__1000-01-01__timeline:6397-6404	1.000
:Event_0000021	canonical_mention.actual	"laid off"	finan_washingtonpost__1000-01-01__timeline:6397-6404	1.000
:Event_0000021	Personnel.EndPosition_Person.actual	:Entity_EDL_0000257	finan_washingtonpost__1000-01-01__timeline:6406-6412	1.000
:Event_0000022	type	Justice.TrialHearing
:Event_0000022	mention.actual	"hearing"	finan_washingtonpost__1000-01-01__timeline:14375-14381	1.000
:Event_0000022	canonical_mention.actual	"hearing"	finan_washingtonpost__1000-01-01__timeline:14375-14381	1.000
:Event_0000022	Justice.TrialHearing_Adjudicator.actual	:Entity_EDL_0000029	finan_washingtonpost__1000-01-01__timeline:14329-14352	1.000
:Event_0000022	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000064	finan_washingtonpost__1000-01-01__timeline:14387-14402	1.000
:Event_0000023	type	Contact.Meet
:Event_0000023	mention.actual	"speaks"	finan_washingtonpost__1000-01-01__timeline:26027-26032	1.000
:Event_0000023	canonical_mention.actual	"speaks"	finan_washingtonpost__1000-01-01__timeline:26027-26032	1.000
:Event_0000023	Contact.Meet_Participant.actual	:Entity_EDL_0000209	finan_washingtonpost__1000-01-01__timeline:26014-26025	1.000
:Event_0000023	Contact.Meet_Participant.actual	:Entity_EDL_0000042	finan_washingtonpost__1000-01-01__timeline:26041-26083	1.000
:Event_0000023	Contact.Meet_Place.actual	:Entity_EDL_0000106	finan_washingtonpost__1000-01-01__timeline:26088-26097	1.000
:Event_0000024	type	Contact.Correspondence
:Event_0000024	mention.actual	"sends"	finan_washingtonpost__1000-01-01__timeline:42877-42881	1.000
:Event_0000024	canonical_mention.actual	"sends"	finan_washingtonpost__1000-01-01__timeline:42877-42881	1.000
:Event_0000024	Contact.Correspondence_Participant.actual	:Entity_EDL_0000294	finan_washingtonpost__1000-01-01__timeline:42855-42875	1.000
:Event_0000024	Contact.Correspondence_Participant.actual	:Entity_EDL_0000114	finan_washingtonpost__1000-01-01__timeline:42895-42899	1.000
:Event_0000025	type	Transaction.TransferMoney
:Event_0000025	mention.actual	"refinance"	finan_washingtonpost__1000-01-01__timeline:9553-9561	1.000
:Event_0000025	canonical_mention.actual	"refinance"	finan_washingtonpost__1000-01-01__timeline:9553-9561	1.000
:Event_0000025	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000247	finan_washingtonpost__1000-01-01__timeline:9535-9543	1.000
:Event_0000026	type	Transaction.TransferMoney
:Event_0000026	mention.actual	"lending"	finan_washingtonpost__1000-01-01__timeline:53994-54000	1.000
:Event_0000026	canonical_mention.actual	"lending"	finan_washingtonpost__1000-01-01__timeline:53994-54000	1.000
:Event_0000026	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000082	finan_washingtonpost__1000-01-01__timeline:53974-53978	1.000
:Event_0000026	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000284	finan_washingtonpost__1000-01-01__timeline:54005-54014	1.000
:Event_0000027	type	Personnel.StartPosition
:Event_0000027	mention.actual	"new"	finan_washingtonpost__1000-01-01__timeline:49074-49076	1.000
:Event_0000027	canonical_mention.actual	"new"	finan_washingtonpost__1000-01-01__timeline:49074-49076	1.000
:Event_0000027	Personnel.StartPosition_Person.actual	:Entity_EDL_0000062	finan_washingtonpost__1000-01-01__timeline:49078-49083	1.000
:Event_0000027	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000051	finan_washingtonpost__1000-01-01__timeline:49088-49097	1.000
:Event_0000027	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000116	finan_washingtonpost__1000-01-01__timeline:49103-49113	1.000
:Event_0000028	type	Transaction.TransferMoney
:Event_0000028	mention.actual	"pump"	finan_washingtonpost__1000-01-01__timeline:46831-46834	1.000
:Event_0000028	canonical_mention.actual	"pump"	finan_washingtonpost__1000-01-01__timeline:46831-46834	1.000
:Event_0000028	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000059	finan_washingtonpost__1000-01-01__timeline:46769-46775	1.000
:Event_0000028	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000066	finan_washingtonpost__1000-01-01__timeline:46783-46793	1.000
:Event_0000028	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000060	finan_washingtonpost__1000-01-01__timeline:46799-46808	1.000
:Event_0000028	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000191	finan_washingtonpost__1000-01-01__timeline:46856-46861	1.000
:Event_0000029	type	Contact.Meet
:Event_0000029	mention.actual	"reconvenes"	finan_washingtonpost__1000-01-01__timeline:15744-15753	1.000
:Event_0000029	canonical_mention.actual	"reconvenes"	finan_washingtonpost__1000-01-01__timeline:15744-15753	1.000
:Event_0000029	Contact.Meet_Participant.actual	:Entity_EDL_0000095	finan_washingtonpost__1000-01-01__timeline:15735-15742	1.000
:Event_0000030	type	Transaction.TransferMoney
:Event_0000030	mention.actual	"pay"	finan_washingtonpost__1000-01-01__timeline:4298-4300	1.000
:Event_0000030	canonical_mention.actual	"pay"	finan_washingtonpost__1000-01-01__timeline:4298-4300	1.000
:Event_0000030	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000147	finan_washingtonpost__1000-01-01__timeline:4285-4293	1.000
:Event_0000030	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000271	finan_washingtonpost__1000-01-01__timeline:4307-4315	1.000
:Event_0000031	type	Contact.Meet
:Event_0000031	mention.actual	"hearings"	finan_washingtonpost__1000-01-01__timeline:18244-18251	1.000
:Event_0000031	canonical_mention.actual	"hearings"	finan_washingtonpost__1000-01-01__timeline:18244-18251	1.000
:Event_0000031	Contact.Meet_Participant.actual	:Entity_EDL_0000199	finan_washingtonpost__1000-01-01__timeline:18213-18236	1.000
:Event_0000032	type	Manufacture.Artifact
:Event_0000032	mention.actual	"manufacturing"	finan_washingtonpost__1000-01-01__timeline:25627-25639	1.000
:Event_0000032	canonical_mention.actual	"manufacturing"	finan_washingtonpost__1000-01-01__timeline:25627-25639	1.000
:Event_0000032	Manufacture.Artifact_Place.actual	:Entity_EDL_0000115	finan_washingtonpost__1000-01-01__timeline:25622-25625	1.000
:Event_0000033	type	Contact.Correspondence
:Event_0000033	mention.actual	"letter"	finan_washingtonpost__1000-01-01__timeline:12507-12512	1.000
:Event_0000033	canonical_mention.actual	"letter"	finan_washingtonpost__1000-01-01__timeline:12507-12512	1.000
:Event_0000033	Contact.Correspondence_Participant.actual	:Entity_EDL_0000260	finan_washingtonpost__1000-01-01__timeline:12521-12525	1.000
:Event_0000033	Contact.Correspondence_Participant.actual	:Entity_EDL_0000156	finan_washingtonpost__1000-01-01__timeline:12594-12603	1.000
:Event_0000034	type	Personnel.EndPosition
:Event_0000034	mention.actual	"layoffs"	finan_washingtonpost__1000-01-01__timeline:23046-23052	1.000
:Event_0000034	canonical_mention.actual	"layoffs"	finan_washingtonpost__1000-01-01__timeline:23046-23052	1.000
:Event_0000034	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000074	finan_washingtonpost__1000-01-01__timeline:22960-22961	1.000
:Event_0000034	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000146	finan_washingtonpost__1000-01-01__timeline:23007-23009	1.000
:Event_0000035	type	ArtifactExistence.Shortage.Shortage
:Event_0000035	mention.actual	"low"	finan_washingtonpost__1000-01-01__timeline:42971-42973	1.000
:Event_0000035	canonical_mention.actual	"low"	finan_washingtonpost__1000-01-01__timeline:42971-42973	1.000
:Event_0000035	ArtifactExistence.Shortage.Shortage_Supply.actual	:Entity_EDL_0000058	finan_washingtonpost__1000-01-01__timeline:42978-42981	1.000
:Event_0000036	type	Contact.Meet
:Event_0000036	mention.actual	"talks"	finan_washingtonpost__1000-01-01__timeline:682-686	1.000
:Event_0000036	canonical_mention.actual	"talks"	finan_washingtonpost__1000-01-01__timeline:682-686	1.000
:Event_0000037	type	Transaction.TransferMoney
:Event_0000037	mention.actual	"salaries"	finan_washingtonpost__1000-01-01__timeline:49128-49135	1.000
:Event_0000037	canonical_mention.actual	"salaries"	finan_washingtonpost__1000-01-01__timeline:49128-49135	1.000
:Event_0000037	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000062	finan_washingtonpost__1000-01-01__timeline:49078-49083	1.000
:Event_0000038	type	Business.Merge
:Event_0000038	mention.actual	"merger talks"	finan_washingtonpost__1000-01-01__timeline:54232-54243	1.000
:Event_0000038	canonical_mention.actual	"merger talks"	finan_washingtonpost__1000-01-01__timeline:54232-54243	1.000
:Event_0000038	Business.Merge_Organization.actual	:Entity_EDL_0000125	finan_washingtonpost__1000-01-01__timeline:54198-54211	1.000
:Event_0000038	Business.Merge_Organization.actual	:Entity_EDL_0000083	finan_washingtonpost__1000-01-01__timeline:54217-54224	1.000
:Event_0000039	type	Contact.Meet
:Event_0000039	mention.actual	"meet"	finan_washingtonpost__1000-01-01__timeline:4661-4664	1.000
:Event_0000039	canonical_mention.actual	"meet"	finan_washingtonpost__1000-01-01__timeline:4661-4664	1.000
:Event_0000039	Contact.Meet_Participant.actual	:Entity_EDL_0000076	finan_washingtonpost__1000-01-01__timeline:4603-4606	1.000
:Event_0000039	Contact.Meet_Participant.actual	:Entity_EDL_0000005	finan_washingtonpost__1000-01-01__timeline:4648-4656	1.000
:Event_0000039	Contact.Meet_Participant.actual	:Entity_EDL_0000046	finan_washingtonpost__1000-01-01__timeline:4684-4690	1.000
:Event_0000040	type	Transaction.TransferOwnership
:Event_0000040	mention.actual	"purchased"	finan_washingtonpost__1000-01-01__timeline:41586-41594	1.000
:Event_0000040	canonical_mention.actual	"purchased"	finan_washingtonpost__1000-01-01__timeline:41586-41594	1.000
:Event_0000040	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000040	finan_washingtonpost__1000-01-01__timeline:41576-41581	1.000
:Event_0000040	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000103	finan_washingtonpost__1000-01-01__timeline:41583-41584	1.000
:Event_0000041	type	Manufacture.Artifact
:Event_0000041	mention.actual	"construction"	finan_washingtonpost__1000-01-01__timeline:20798-20809	1.000
:Event_0000041	canonical_mention.actual	"construction"	finan_washingtonpost__1000-01-01__timeline:20798-20809	1.000
:Event_0000041	Manufacture.Artifact_Manufacturer.actual	:Entity_EDL_0000158	finan_washingtonpost__1000-01-01__timeline:20622-20626	1.000
:Event_0000041	Manufacture.Artifact_Place.actual	:Entity_EDL_0000057	finan_washingtonpost__1000-01-01__timeline:20692-20698	1.000
:Event_0000041	Manufacture.Artifact_Artifact.actual	:Entity_EDL_0000181	finan_washingtonpost__1000-01-01__timeline:20818-20825	1.000
:Event_0000041	Manufacture.Artifact_Artifact.actual	:Entity_EDL_0000088	finan_washingtonpost__1000-01-01__timeline:20839-20846	1.000
:Event_0000042	type	Personnel.EndPosition
:Event_0000042	mention.actual	"cut"	finan_washingtonpost__1000-01-01__timeline:43811-43813	1.000
:Event_0000042	canonical_mention.actual	"cut"	finan_washingtonpost__1000-01-01__timeline:43811-43813	1.000
:Event_0000042	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000036	finan_washingtonpost__1000-01-01__timeline:43796-43797	1.000
:Event_0000043	type	ArtifactExistence.Shortage.Shortage
:Event_0000043	mention.actual	"shortage"	finan_washingtonpost__1000-01-01__timeline:27861-27868	1.000
:Event_0000043	canonical_mention.actual	"shortage"	finan_washingtonpost__1000-01-01__timeline:27861-27868	1.000
:Event_0000043	ArtifactExistence.Shortage.Shortage_Supply.actual	:Entity_EDL_0000169	finan_washingtonpost__1000-01-01__timeline:27873-27879	1.000
:Event_0000044	type	Contact.Contact
:Event_0000044	mention.actual	"surveys"	finan_washingtonpost__1000-01-01__timeline:25841-25847	1.000
:Event_0000044	canonical_mention.actual	"surveys"	finan_washingtonpost__1000-01-01__timeline:25841-25847	1.000
:Event_0000044	Contact.Contact_Participant.actual	:Entity_EDL_0000254	finan_washingtonpost__1000-01-01__timeline:25797-25839	1.000
:Event_0000044	Contact.Contact_Participant.actual	:Entity_EDL_0000292	finan_washingtonpost__1000-01-01__timeline:25857-25866	1.000
:Event_0000045	type	Personnel.EndPosition
:Event_0000045	mention.actual	"shed"	finan_washingtonpost__1000-01-01__timeline:6180-6183	1.000
:Event_0000045	canonical_mention.actual	"shed"	finan_washingtonpost__1000-01-01__timeline:6180-6183	1.000
:Event_0000045	Personnel.EndPosition_Place.actual	:Entity_EDL_0000281	finan_washingtonpost__1000-01-01__timeline:6145-6157	1.000
:Event_0000045	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000282	finan_washingtonpost__1000-01-01__timeline:6170-6178	1.000
:Event_0000046	type	Transaction.TransferMoney
:Event_0000046	mention.actual	"pays"	finan_washingtonpost__1000-01-01__timeline:6392-6395	1.000
:Event_0000046	canonical_mention.actual	"pays"	finan_washingtonpost__1000-01-01__timeline:6392-6395	1.000
:Event_0000046	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000257	finan_washingtonpost__1000-01-01__timeline:6406-6412	1.000
:Event_0000047	type	Transaction.TransferOwnership
:Event_0000047	mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:32316-32318	1.000
:Event_0000047	canonical_mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:32316-32318	1.000
:Event_0000047	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000241	finan_washingtonpost__1000-01-01__timeline:32258-32261	1.000
:Event_0000047	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000056	finan_washingtonpost__1000-01-01__timeline:32326-32330	1.000
:Event_0000048	type	Personnel.EndPosition
:Event_0000048	mention.actual	"shed"	finan_washingtonpost__1000-01-01__timeline:4470-4473	1.000
:Event_0000048	canonical_mention.actual	"shed"	finan_washingtonpost__1000-01-01__timeline:4470-4473	1.000
:Event_0000048	Personnel.EndPosition_Place.actual	:Entity_EDL_0000109	finan_washingtonpost__1000-01-01__timeline:4455-4458	1.000
:Event_0000048	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000100	finan_washingtonpost__1000-01-01__timeline:4460-4468	1.000
:Event_0000049	type	Personnel.EndPosition
:Event_0000049	mention.actual	"Former"	finan_washingtonpost__1000-01-01__timeline:2555-2560	1.000
:Event_0000049	canonical_mention.actual	"Former"	finan_washingtonpost__1000-01-01__timeline:2555-2560	1.000
:Event_0000049	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000180	finan_washingtonpost__1000-01-01__timeline:2562-2571	1.000
:Event_0000049	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000287	finan_washingtonpost__1000-01-01__timeline:2577-2587	1.000
:Event_0000049	Personnel.EndPosition_Person.actual	:Entity_EDL_0000211	finan_washingtonpost__1000-01-01__timeline:2589-2598	1.000
:Event_0000050	type	Justice.ChargeIndict
:Event_0000050	mention.actual	"charged"	finan_washingtonpost__1000-01-01__timeline:1319-1325	1.000
:Event_0000050	canonical_mention.actual	"charged"	finan_washingtonpost__1000-01-01__timeline:1319-1325	1.000
:Event_0000050	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000150	finan_washingtonpost__1000-01-01__timeline:1288-1301	1.000
:Event_0000051	type	Personnel.StartPosition
:Event_0000051	mention.actual	"named"	finan_washingtonpost__1000-01-01__timeline:9131-9135	1.000
:Event_0000051	canonical_mention.actual	"named"	finan_washingtonpost__1000-01-01__timeline:9131-9135	1.000
:Event_0000051	Personnel.StartPosition_Person.actual	:Entity_EDL_0000023	finan_washingtonpost__1000-01-01__timeline:9169-9180	1.000
:Event_0000051	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000235	finan_washingtonpost__1000-01-01__timeline:9198-9229	1.000
:Event_0000052	type	Personnel.EndPosition
:Event_0000052	mention.actual	"retirements"	finan_washingtonpost__1000-01-01__timeline:23070-23080	1.000
:Event_0000052	canonical_mention.actual	"retirements"	finan_washingtonpost__1000-01-01__timeline:23070-23080	1.000
:Event_0000052	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000146	finan_washingtonpost__1000-01-01__timeline:23007-23009	1.000
:Event_0000053	type	Transaction.TransferMoney
:Event_0000053	mention.actual	"inject"	finan_washingtonpost__1000-01-01__timeline:16596-16601	1.000
:Event_0000053	canonical_mention.actual	"inject"	finan_washingtonpost__1000-01-01__timeline:16596-16601	1.000
:Event_0000053	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000157	finan_washingtonpost__1000-01-01__timeline:16570-16579	1.000
:Event_0000053	Transaction.TransferMoney_Beneficiary.actual	:Entity_EDL_0000039	finan_washingtonpost__1000-01-01__timeline:16625-16631	1.000
:Event_0000054	type	Transaction.TransferMoney
:Event_0000054	mention.actual	"provide"	finan_washingtonpost__1000-01-01__timeline:33377-33383	1.000
:Event_0000054	canonical_mention.actual	"provide"	finan_washingtonpost__1000-01-01__timeline:33377-33383	1.000
:Event_0000054	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000195	finan_washingtonpost__1000-01-01__timeline:33308-33318	1.000
:Event_0000054	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000065	finan_washingtonpost__1000-01-01__timeline:33401-33405	1.000
:Event_0000054	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000002	finan_washingtonpost__1000-01-01__timeline:33411-33419	1.000
:Event_0000055	type	Personnel.EndPosition
:Event_0000055	mention.actual	"cut"	finan_washingtonpost__1000-01-01__timeline:21365-21367	1.000
:Event_0000055	canonical_mention.actual	"cut"	finan_washingtonpost__1000-01-01__timeline:21365-21367	1.000
:Event_0000055	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000248	finan_washingtonpost__1000-01-01__timeline:21357-21358	1.000
:Event_0000056	type	Justice.TrialHearing
:Event_0000056	mention.actual	"testimony"	finan_washingtonpost__1000-01-01__timeline:49788-49796	1.000
:Event_0000056	canonical_mention.actual	"testimony"	finan_washingtonpost__1000-01-01__timeline:49788-49796	1.000
:Event_0000056	Justice.TrialHearing_Place.actual	:Entity_EDL_0000249	finan_washingtonpost__1000-01-01__timeline:49801-49812	1.000
:Event_0000057	type	Justice.ChargeIndict
:Event_0000057	mention.actual	"charges"	finan_washingtonpost__1000-01-01__timeline:43587-43593	1.000
:Event_0000057	canonical_mention.actual	"charges"	finan_washingtonpost__1000-01-01__timeline:43587-43593	1.000
:Event_0000057	Justice.ChargeIndict_Prosecutor.actual	:Entity_EDL_0000035	finan_washingtonpost__1000-01-01__timeline:43565-43566	1.000
:Event_0000057	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000166	finan_washingtonpost__1000-01-01__timeline:43614-43620	1.000
:Event_0000057	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000038	finan_washingtonpost__1000-01-01__timeline:43626-43632	1.000
:Event_0000058	type	Personnel.EndPosition
:Event_0000058	mention.actual	"layoffs"	finan_washingtonpost__1000-01-01__timeline:3734-3740	1.000
:Event_0000058	canonical_mention.actual	"layoffs"	finan_washingtonpost__1000-01-01__timeline:3734-3740	1.000
:Event_0000058	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000178	finan_washingtonpost__1000-01-01__timeline:3705-3716	1.000
:Event_0000058	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000245	finan_washingtonpost__1000-01-01__timeline:3722-3723	1.000
:Event_0000059	type	Transaction.TransferOwnership
:Event_0000059	mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:6043-6045	1.000
:Event_0000059	canonical_mention.actual	"buy"	finan_washingtonpost__1000-01-01__timeline:6043-6045	1.000
:Event_0000059	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000010	finan_washingtonpost__1000-01-01__timeline:6014-6024	1.000
:Event_0000059	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000086	finan_washingtonpost__1000-01-01__timeline:6031-6032	1.000
:Event_0000059	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000168	finan_washingtonpost__1000-01-01__timeline:6047-6062	1.000
:Event_0000060	type	Contact.Broadcast
:Event_0000060	mention.actual	"address"	finan_washingtonpost__1000-01-01__timeline:49341-49347	1.000
:Event_0000060	canonical_mention.actual	"address"	finan_washingtonpost__1000-01-01__timeline:49341-49347	1.000
:Event_0000060	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000219	finan_washingtonpost__1000-01-01__timeline:49247-49250	1.000
:Event_0000061	type	Contact.Meet
:Event_0000061	mention.actual	"Forum"	finan_washingtonpost__1000-01-01__timeline:7476-7480	1.000
:Event_0000061	canonical_mention.actual	"Forum"	finan_washingtonpost__1000-01-01__timeline:7476-7480	1.000
:Event_0000061	Contact.Meet_Participant.actual	:Entity_EDL_0000127	finan_washingtonpost__1000-01-01__timeline:7389-7401	1.000
:Event_0000061	Contact.Meet_Participant.actual	:Entity_EDL_0000053	finan_washingtonpost__1000-01-01__timeline:7464-7474	1.000
:Event_0000061	Contact.Meet_Place.actual	:Entity_EDL_0000262	finan_washingtonpost__1000-01-01__timeline:7485-7494	1.000
:Event_0000062	type	Personnel.EndPosition
:Event_0000062	mention.actual	"Former"	finan_washingtonpost__1000-01-01__timeline:2268-2273	1.000
:Event_0000062	canonical_mention.actual	"Former"	finan_washingtonpost__1000-01-01__timeline:2268-2273	1.000
:Event_0000062	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000198	finan_washingtonpost__1000-01-01__timeline:2275-2285	1.000
:Event_0000062	Personnel.EndPosition_Person.actual	:Entity_EDL_0000261	finan_washingtonpost__1000-01-01__timeline:2291-2303	1.000
:Event_0000063	type	Contact.Broadcast
:Event_0000063	mention.actual	"announces"	finan_washingtonpost__1000-01-01__timeline:26902-26910	1.000
:Event_0000063	canonical_mention.actual	"announces"	finan_washingtonpost__1000-01-01__timeline:26902-26910	1.000
:Event_0000063	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000251	finan_washingtonpost__1000-01-01__timeline:26896-26900	1.000
:Event_0000064	type	Contact.Meet
:Event_0000064	mention.actual	"plead"	finan_washingtonpost__1000-01-01__timeline:13939-13943	1.000
:Event_0000064	canonical_mention.actual	"plead"	finan_washingtonpost__1000-01-01__timeline:13939-13943	1.000
:Event_0000064	Contact.Meet_Participant.actual	:Entity_EDL_0000032	finan_washingtonpost__1000-01-01__timeline:13868-13877	1.000
:Event_0000064	Contact.Meet_Place.actual	:Entity_EDL_0000030	finan_washingtonpost__1000-01-01__timeline:13923-13934	1.000
:Event_0000065	type	Personnel.EndPosition
:Event_0000065	mention.actual	"cut"	finan_washingtonpost__1000-01-01__timeline:2807-2809	1.000
:Event_0000065	canonical_mention.actual	"cut"	finan_washingtonpost__1000-01-01__timeline:2807-2809	1.000
:Event_0000065	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000075	finan_washingtonpost__1000-01-01__timeline:2824-2826	1.000
:Event_0000065	Personnel.EndPosition_Person.actual	:Entity_EDL_0000275	finan_washingtonpost__1000-01-01__timeline:2828-2836	1.000
:Event_0000066	type	Business.End
:Event_0000066	mention.actual	"close"	finan_washingtonpost__1000-01-01__timeline:25415-25419	1.000
:Event_0000066	canonical_mention.actual	"close"	finan_washingtonpost__1000-01-01__timeline:25415-25419	1.000
:Event_0000066	Business.End_Organization.actual	:Entity_EDL_0000119	finan_washingtonpost__1000-01-01__timeline:25407-25408	1.000
:Event_0000067	type	Transaction.TransferMoney
:Event_0000067	mention.actual	"lending"	finan_washingtonpost__1000-01-01__timeline:9323-9329	1.000
:Event_0000067	canonical_mention.actual	"lending"	finan_washingtonpost__1000-01-01__timeline:9323-9329	1.000
:Event_0000067	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000174	finan_washingtonpost__1000-01-01__timeline:9277-9299	1.000
:Event_0000068	type	Transaction.TransferMoney
:Event_0000068	mention.actual	"collect"	finan_washingtonpost__1000-01-01__timeline:17163-17169	1.000
:Event_0000068	canonical_mention.actual	"collect"	finan_washingtonpost__1000-01-01__timeline:17163-17169	1.000
:Event_0000068	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000052	finan_washingtonpost__1000-01-01__timeline:17116-17120	1.000
:Event_0000068	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000141	finan_washingtonpost__1000-01-01__timeline:17201-17206	1.000
:Event_0000069	type	Transaction.TransferMoney
:Event_0000069	mention.actual	"lends"	finan_washingtonpost__1000-01-01__timeline:54558-54562	1.000
:Event_0000069	canonical_mention.actual	"lends"	finan_washingtonpost__1000-01-01__timeline:54558-54562	1.000
:Event_0000069	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000172	finan_washingtonpost__1000-01-01__timeline:54554-54556	1.000
:Event_0000069	Transaction.TransferMoney_Beneficiary.actual	:Entity_EDL_0000218	finan_washingtonpost__1000-01-01__timeline:54574-54578	1.000
:Event_0000069	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000201	finan_washingtonpost__1000-01-01__timeline:54580-54607	1.000
:Event_0000070	type	Business.Start
:Event_0000070	mention.actual	"create"	finan_washingtonpost__1000-01-01__timeline:29833-29838	1.000
:Event_0000070	canonical_mention.actual	"create"	finan_washingtonpost__1000-01-01__timeline:29833-29838	1.000
:Event_0000070	Business.Start_Organization.actual	:Entity_EDL_0000165	finan_washingtonpost__1000-01-01__timeline:29765-29766	1.000
:Event_0000071	type	Transaction.TransferMoney
:Event_0000071	mention.actual	"pay"	finan_washingtonpost__1000-01-01__timeline:17573-17575	1.000
:Event_0000071	canonical_mention.actual	"pay"	finan_washingtonpost__1000-01-01__timeline:17573-17575	1.000
:Event_0000071	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000123	finan_washingtonpost__1000-01-01__timeline:17568-17571	1.000
:Event_0000072	type	Business.End
:Event_0000072	mention.actual	"closing"	finan_washingtonpost__1000-01-01__timeline:21608-21614	1.000
:Event_0000072	canonical_mention.actual	"closing"	finan_washingtonpost__1000-01-01__timeline:21608-21614	1.000
:Event_0000073	type	Transaction.TransferMoney
:Event_0000073	mention.actual	"inject"	finan_washingtonpost__1000-01-01__timeline:40052-40057	1.000
:Event_0000073	canonical_mention.actual	"inject"	finan_washingtonpost__1000-01-01__timeline:40052-40057	1.000
:Event_0000073	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000008	finan_washingtonpost__1000-01-01__timeline:40029-40038	1.000
:Event_0000073	Transaction.TransferMoney_Beneficiary.actual	:Entity_EDL_0000139	finan_washingtonpost__1000-01-01__timeline:40108-40112	1.000
:Event_0000074	type	Personnel.EndPosition
:Event_0000074	mention.actual	"shed"	finan_washingtonpost__1000-01-01__timeline:42728-42731	1.000
:Event_0000074	canonical_mention.actual	"shed"	finan_washingtonpost__1000-01-01__timeline:42728-42731	1.000
:Event_0000074	Personnel.EndPosition_Place.actual	:Entity_EDL_0000227	finan_washingtonpost__1000-01-01__timeline:42713-42716	1.000
:Event_0000074	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000296	finan_washingtonpost__1000-01-01__timeline:42718-42726	1.000
:Event_0000075	type	Personnel.EndPosition
:Event_0000075	mention.actual	"former"	finan_washingtonpost__1000-01-01__timeline:42000-42005	1.000
:Event_0000075	canonical_mention.actual	"former"	finan_washingtonpost__1000-01-01__timeline:42000-42005	1.000
:Event_0000075	Personnel.EndPosition_Person.actual	:Entity_EDL_0000050	finan_washingtonpost__1000-01-01__timeline:41930-41942	1.000
:Event_0000075	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000142	finan_washingtonpost__1000-01-01__timeline:42007-42019	1.000
:Event_0000075	Personnel.EndPosition_Person.actual	:Entity_EDL_0000187	finan_washingtonpost__1000-01-01__timeline:42021-42026	1.000
:Event_0000076	type	Contact.Contact
:Event_0000076	mention.actual	"tells"	finan_washingtonpost__1000-01-01__timeline:49020-49024	1.000
:Event_0000076	canonical_mention.actual	"tells"	finan_washingtonpost__1000-01-01__timeline:49020-49024	1.000
:Event_0000076	Contact.Contact_Participant.actual	:Entity_EDL_0000210	finan_washingtonpost__1000-01-01__timeline:48973-48980	1.000
:Event_0000076	Contact.Contact_Participant.actual	:Entity_EDL_0000190	finan_washingtonpost__1000-01-01__timeline:49030-49063	1.000
:Event_0000077	type	ArtifactExistence.Shortage.Shortage
:Event_0000077	mention.actual	"strapped"	finan_washingtonpost__1000-01-01__timeline:3653-3660	1.000
:Event_0000077	canonical_mention.actual	"strapped"	finan_washingtonpost__1000-01-01__timeline:3653-3660	1.000
:Event_0000078	type	Contact.Meet
:Event_0000078	mention.actual	"hearing"	finan_washingtonpost__1000-01-01__timeline:18333-18339	1.000
:Event_0000078	canonical_mention.actual	"hearing"	finan_washingtonpost__1000-01-01__timeline:18333-18339	1.000
:Event_0000078	Contact.Meet_Participant.actual	:Entity_EDL_0000231	finan_washingtonpost__1000-01-01__timeline:18299-18323	1.000
:Event_0000079	type	Personnel.EndPosition
:Event_0000079	mention.actual	"losses"	finan_washingtonpost__1000-01-01__timeline:26857-26862	1.000
:Event_0000079	canonical_mention.actual	"losses"	finan_washingtonpost__1000-01-01__timeline:26857-26862	1.000
:Event_0000079	Personnel.EndPosition_Place.actual	:Entity_EDL_0000250	finan_washingtonpost__1000-01-01__timeline:26716-26719	1.000
:Event_0000080	type	Justice.ArrestJail
:Event_0000080	mention.actual	"arrested"	finan_washingtonpost__1000-01-01__timeline:1306-1313	1.000
:Event_0000080	canonical_mention.actual	"arrested"	finan_washingtonpost__1000-01-01__timeline:1306-1313	1.000
:Event_0000080	Justice.ArrestJail_Person.actual	:Entity_EDL_0000150	finan_washingtonpost__1000-01-01__timeline:1288-1301	1.000
:Event_0000081	type	Contact.Meet
:Event_0000081	mention.actual	"convene"	finan_washingtonpost__1000-01-01__timeline:35830-35836	1.000
:Event_0000081	canonical_mention.actual	"convene"	finan_washingtonpost__1000-01-01__timeline:35830-35836	1.000
:Event_0000081	Contact.Meet_Participant.actual	:Entity_EDL_0000185	finan_washingtonpost__1000-01-01__timeline:35768-35781	1.000
:Event_0000082	type	Personnel.Elect
:Event_0000082	mention.actual	"-elect"	finan_washingtonpost__1000-01-01__timeline:20532-20537	1.000
:Event_0000082	canonical_mention.actual	"-elect"	finan_washingtonpost__1000-01-01__timeline:20532-20537	1.000
:Event_0000082	Personnel.Elect_Elect.actual	:Entity_EDL_0000096	finan_washingtonpost__1000-01-01__timeline:20523-20532	1.000
:Event_0000082	Personnel.Elect_Elect.actual	:Entity_EDL_0000272	finan_washingtonpost__1000-01-01__timeline:20539-20543	1.000
:Event_0000083	type	Transaction.TransferOwnership
:Event_0000083	mention.actual	"seizes"	finan_washingtonpost__1000-01-01__timeline:39039-39044	1.000
:Event_0000083	canonical_mention.actual	"seizes"	finan_washingtonpost__1000-01-01__timeline:39039-39044	1.000
:Event_0000083	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000132	finan_washingtonpost__1000-01-01__timeline:39031-39037	1.000
:Event_0000083	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000111	finan_washingtonpost__1000-01-01__timeline:39046-39059	1.000
:Event_0000084	type	Contact.Meet
:Event_0000084	mention.actual	"meets"	finan_washingtonpost__1000-01-01__timeline:7109-7113	1.000
:Event_0000084	canonical_mention.actual	"meets"	finan_washingtonpost__1000-01-01__timeline:7109-7113	1.000
:Event_0000084	Contact.Meet_Participant.actual	:Entity_EDL_0000140	finan_washingtonpost__1000-01-01__timeline:7096-7107	1.000
:Event_0000084	Contact.Meet_Participant.actual	:Entity_EDL_0000267	finan_washingtonpost__1000-01-01__timeline:7131-7139	1.000
:Event_0000085	type	Personnel.EndPosition
:Event_0000085	mention.actual	"retired"	finan_washingtonpost__1000-01-01__timeline:6349-6355	1.000
:Event_0000085	canonical_mention.actual	"retired"	finan_washingtonpost__1000-01-01__timeline:6349-6355	1.000
:Event_0000085	Personnel.EndPosition_Person.actual	:Entity_EDL_0000230	finan_washingtonpost__1000-01-01__timeline:6357-6363	1.000
:Event_0000086	type	Transaction.TransferMoney
:Event_0000086	mention.actual	"spending"	finan_washingtonpost__1000-01-01__timeline:35564-35571	1.000
:Event_0000086	canonical_mention.actual	"spending"	finan_washingtonpost__1000-01-01__timeline:35564-35571	1.000
:Event_0000086	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000175	finan_washingtonpost__1000-01-01__timeline:35541-35547	1.000
:Event_0000086	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000232	finan_washingtonpost__1000-01-01__timeline:35652-35660	1.000
:Event_0000087	type	Personnel.EndPosition
:Event_0000087	mention.actual	"cuts"	finan_washingtonpost__1000-01-01__timeline:5435-5438	1.000
:Event_0000087	canonical_mention.actual	"cuts"	finan_washingtonpost__1000-01-01__timeline:5435-5438	1.000
:Event_0000087	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000289	finan_washingtonpost__1000-01-01__timeline:5390-5393	1.000
:Event_0000087	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000189	finan_washingtonpost__1000-01-01__timeline:5408-5420	1.000
:Event_0000088	type	Personnel.EndPosition
:Event_0000088	mention.actual	"layoffs"	finan_washingtonpost__1000-01-01__timeline:23207-23213	1.000
:Event_0000088	canonical_mention.actual	"layoffs"	finan_washingtonpost__1000-01-01__timeline:23207-23213	1.000
:Event_0000088	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000273	finan_washingtonpost__1000-01-01__timeline:23169-23171	1.000
:Event_0000089	type	Transaction.TransferMoney
:Event_0000089	mention.actual	"use"	finan_washingtonpost__1000-01-01__timeline:34350-34352	1.000
:Event_0000089	canonical_mention.actual	"use"	finan_washingtonpost__1000-01-01__timeline:34350-34352	1.000
:Event_0000089	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000214	finan_washingtonpost__1000-01-01__timeline:34317-34335	1.000
:Event_0000089	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000221	finan_washingtonpost__1000-01-01__timeline:34342-34343	1.000
:Event_0000089	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000085	finan_washingtonpost__1000-01-01__timeline:34382-34384	1.000
:Event_0000089	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000212	finan_washingtonpost__1000-01-01__timeline:34424-34426	1.000
:Event_0000090	type	Personnel.EndPosition
:Event_0000090	mention.actual	"Former"	finan_washingtonpost__1000-01-01__timeline:30256-30261	1.000
:Event_0000090	canonical_mention.actual	"Former"	finan_washingtonpost__1000-01-01__timeline:30256-30261	1.000
:Event_0000090	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000136	finan_washingtonpost__1000-01-01__timeline:30263-30277	1.000
:Event_0000090	Personnel.EndPosition_Person.actual	:Entity_EDL_0000067	finan_washingtonpost__1000-01-01__timeline:30288-30301	1.000
:Event_0000091	type	Personnel.EndPosition
:Event_0000091	mention.actual	"left"	finan_washingtonpost__1000-01-01__timeline:36901-36904	1.000
:Event_0000091	canonical_mention.actual	"left"	finan_washingtonpost__1000-01-01__timeline:36901-36904	1.000
:Event_0000091	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000237	finan_washingtonpost__1000-01-01__timeline:36858-36871	1.000
:Event_0000091	Personnel.EndPosition_Person.actual	:Entity_EDL_0000037	finan_washingtonpost__1000-01-01__timeline:36879-36887	1.000
:Event_0000091	Personnel.EndPosition_Person.actual	:Entity_EDL_0000078	finan_washingtonpost__1000-01-01__timeline:36889-36897	1.000
:Event_0000092	type	Personnel.Elect
:Event_0000092	mention.actual	"selects"	finan_washingtonpost__1000-01-01__timeline:11802-11808	1.000
:Event_0000092	canonical_mention.actual	"selects"	finan_washingtonpost__1000-01-01__timeline:11802-11808	1.000
:Event_0000092	Personnel.Elect_Elect.actual	:Entity_EDL_0000054	finan_washingtonpost__1000-01-01__timeline:11850-11868	1.000
:Event_0000093	type	Personnel.Elect
:Event_0000093	mention.actual	"elected"	finan_washingtonpost__1000-01-01__timeline:24863-24869	1.000
:Event_0000093	canonical_mention.actual	"elected"	finan_washingtonpost__1000-01-01__timeline:24863-24869	1.000
:Event_0000093	Personnel.Elect_Elect.actual	:Entity_EDL_0000233	finan_washingtonpost__1000-01-01__timeline:24847-24858	1.000
:Event_0000093	Personnel.Elect_Elector.actual	:Entity_EDL_0000016	finan_washingtonpost__1000-01-01__timeline:24897-24909	1.000
:Event_0000094	type	Personnel.StartPosition
:Event_0000094	mention.actual	"confirms"	finan_washingtonpost__1000-01-01__timeline:3777-3784	1.000
:Event_0000094	canonical_mention.actual	"confirms"	finan_washingtonpost__1000-01-01__timeline:3777-3784	1.000
:Event_0000094	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000207	finan_washingtonpost__1000-01-01__timeline:3770-3775	1.000
:Event_0000094	Personnel.StartPosition_Person.actual	:Entity_EDL_0000130	finan_washingtonpost__1000-01-01__timeline:3786-3801	1.000
:Event_0000095	type	Business.End
:Event_0000095	mention.actual	"fail"	finan_washingtonpost__1000-01-01__timeline:24442-24445	1.000
:Event_0000095	canonical_mention.actual	"fail"	finan_washingtonpost__1000-01-01__timeline:24442-24445	1.000
:Event_0000095	Business.End_Place.actual	:Entity_EDL_0000177	finan_washingtonpost__1000-01-01__timeline:24400-24406	1.000
:Event_0000095	Business.End_Organization.actual	:Entity_EDL_0000013	finan_washingtonpost__1000-01-01__timeline:24408-24417	1.000
:Event_0000095	Business.End_Organization.actual	:Entity_EDL_0000102	finan_washingtonpost__1000-01-01__timeline:24419-24420	1.000
:Event_0000096	type	Business.DeclareBankruptcy
:Event_0000096	mention.actual	"foreclosure"	finan_washingtonpost__1000-01-01__timeline:4913-4923	1.000
:Event_0000096	canonical_mention.actual	"foreclosure"	finan_washingtonpost__1000-01-01__timeline:4913-4923	1.000
:Event_0000097	type	Transaction.TransferMoney
:Event_0000097	mention.actual	"paid"	finan_washingtonpost__1000-01-01__timeline:39586-39589	1.000
:Event_0000097	canonical_mention.actual	"paid"	finan_washingtonpost__1000-01-01__timeline:39586-39589	1.000
:Event_0000097	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000025	finan_washingtonpost__1000-01-01__timeline:39574-39580	1.000
:Event_0000098	type	Personnel.Nominate
:Event_0000098	mention.actual	"nominee"	finan_washingtonpost__1000-01-01__timeline:14422-14428	1.000
:Event_0000098	canonical_mention.actual	"nominee"	finan_washingtonpost__1000-01-01__timeline:14422-14428	1.000
:Event_0000098	Personnel.Nominate_Nominee.actual	:Entity_EDL_0000224	finan_washingtonpost__1000-01-01__timeline:14422-14428	1.000
:Event_0000099	type	Contact.Contact
:Event_0000099	mention.actual	"asks"	finan_washingtonpost__1000-01-01__timeline:33997-34000	1.000
:Event_0000099	canonical_mention.actual	"asks"	finan_washingtonpost__1000-01-01__timeline:33997-34000	1.000
:Event_0000099	Contact.Contact_Participant.actual	:Entity_EDL_0000011	finan_washingtonpost__1000-01-01__timeline:33989-33995	1.000
:Event_0000099	Contact.Contact_Participant.actual	:Entity_EDL_0000216	finan_washingtonpost__1000-01-01__timeline:34006-34008	1.000
:Event_0000100	type	Personnel.EndPosition
:Event_0000100	mention.actual	"lost"	finan_washingtonpost__1000-01-01__timeline:24502-24505	1.000
:Event_0000100	canonical_mention.actual	"lost"	finan_washingtonpost__1000-01-01__timeline:24502-24505	1.000
:Event_0000100	Personnel.EndPosition_Place.actual	:Entity_EDL_0000177	finan_washingtonpost__1000-01-01__timeline:24400-24406	1.000
:Event_0000100	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000137	finan_washingtonpost__1000-01-01__timeline:24487-24492	1.000
:Event_0000101	type	Personnel.EndPosition
:Event_0000101	mention.actual	"lay off"	finan_washingtonpost__1000-01-01__timeline:25436-25442	1.000
:Event_0000101	canonical_mention.actual	"lay off"	finan_washingtonpost__1000-01-01__timeline:25436-25442	1.000
:Event_0000101	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000119	finan_washingtonpost__1000-01-01__timeline:25407-25408	1.000
:Event_0000101	Personnel.EndPosition_Person.actual	:Entity_EDL_0000045	finan_washingtonpost__1000-01-01__timeline:25447-25453	1.000
:Event_0000101	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000080	finan_washingtonpost__1000-01-01__timeline:25458-25460	1.000
:Event_0000101	Personnel.EndPosition_Person.actual	:Entity_EDL_0000112	finan_washingtonpost__1000-01-01__timeline:25467-25471	1.000
:Event_0000102	type	Contact.Contact
:Event_0000102	mention.actual	"asks"	finan_washingtonpost__1000-01-01__timeline:44806-44809	1.000
:Event_0000102	canonical_mention.actual	"asks"	finan_washingtonpost__1000-01-01__timeline:44806-44809	1.000
:Event_0000102	Contact.Contact_Participant.actual	:Entity_EDL_0000203	finan_washingtonpost__1000-01-01__timeline:44774-44804	1.000
:Event_0000102	Contact.Contact_Participant.actual	:Entity_EDL_0000295	finan_washingtonpost__1000-01-01__timeline:44811-44818	1.000
:Event_0000103	type	Contact.Meet
:Event_0000103	mention.actual	"conference"	finan_washingtonpost__1000-01-01__timeline:47381-47390	1.000
:Event_0000103	canonical_mention.actual	"conference"	finan_washingtonpost__1000-01-01__timeline:47381-47390	1.000
:Event_0000103	Contact.Meet_Participant.actual	:Entity_EDL_0000149	finan_washingtonpost__1000-01-01__timeline:47338-47347	1.000
:Event_0000103	Contact.Meet_Place.actual	:Entity_EDL_0000243	finan_washingtonpost__1000-01-01__timeline:47395-47406	1.000
:Event_0000104	type	Transaction.TransferMoney
:Event_0000104	mention.actual	"benefits"	finan_washingtonpost__1000-01-01__timeline:23488-23495	1.000
:Event_0000104	canonical_mention.actual	"benefits"	finan_washingtonpost__1000-01-01__timeline:23488-23495	1.000
:Event_0000104	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000160	finan_washingtonpost__1000-01-01__timeline:23447-23455	1.000
:Event_0000105	type	Transaction.TransferMoney
:Event_0000105	mention.actual	"pay"	finan_washingtonpost__1000-01-01__timeline:27218-27220	1.000
:Event_0000105	canonical_mention.actual	"pay"	finan_washingtonpost__1000-01-01__timeline:27218-27220	1.000
:Event_0000105	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000024	finan_washingtonpost__1000-01-01__timeline:27130-27134	1.000
:Event_0000105	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000055	finan_washingtonpost__1000-01-01__timeline:27258-27269	1.000
:Event_0000105	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000270	finan_washingtonpost__1000-01-01__timeline:27278-27287	1.000
:Event_0000106	type	Personnel.EndPosition
:Event_0000106	mention.actual	"defunct"	finan_washingtonpost__1000-01-01__timeline:41559-41565	1.000
:Event_0000106	canonical_mention.actual	"defunct"	finan_washingtonpost__1000-01-01__timeline:41559-41565	1.000
:Event_0000106	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000040	finan_washingtonpost__1000-01-01__timeline:41576-41581	1.000
:Event_0000107	type	Contact.Meet
:Event_0000107	mention.actual	"meet"	finan_washingtonpost__1000-01-01__timeline:12610-12613	1.000
:Event_0000107	canonical_mention.actual	"meet"	finan_washingtonpost__1000-01-01__timeline:12610-12613	1.000
:Event_0000107	Contact.Meet_Participant.actual	:Entity_EDL_0000260	finan_washingtonpost__1000-01-01__timeline:12521-12525	1.000
:Event_0000107	Contact.Meet_Participant.actual	:Entity_EDL_0000156	finan_washingtonpost__1000-01-01__timeline:12594-12603	1.000
:Event_0000108	type	Transaction.TransferMoney
:Event_0000108	mention.actual	"loans"	finan_washingtonpost__1000-01-01__timeline:27074-27078	1.000
:Event_0000108	canonical_mention.actual	"loans"	finan_washingtonpost__1000-01-01__timeline:27074-27078	1.000
:Event_0000108	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000251	finan_washingtonpost__1000-01-01__timeline:26896-26900	1.000
:Event_0000108	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000120	finan_washingtonpost__1000-01-01__timeline:27089-27098	1.000
:Event_0000109	type	Personnel.Elect
:Event_0000109	mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:7090-7094	1.000
:Event_0000109	canonical_mention.actual	"elect"	finan_washingtonpost__1000-01-01__timeline:7090-7094	1.000
:Event_0000109	Personnel.Elect_Elect.actual	:Entity_EDL_0000140	finan_washingtonpost__1000-01-01__timeline:7096-7107	1.000
:Event_0000110	type	Contact.Correspondence
:Event_0000110	mention.actual	"letter"	finan_washingtonpost__1000-01-01__timeline:42885-42890	1.000
:Event_0000110	canonical_mention.actual	"letter"	finan_washingtonpost__1000-01-01__timeline:42885-42890	1.000
:Event_0000110	Contact.Correspondence_Participant.actual	:Entity_EDL_0000294	finan_washingtonpost__1000-01-01__timeline:42855-42875	1.000
:Event_0000110	Contact.Correspondence_Participant.actual	:Entity_EDL_0000114	finan_washingtonpost__1000-01-01__timeline:42895-42899	1.000
:Event_0000111	type	Transaction.TransferMoney
:Event_0000111	mention.actual	"bail out"	finan_washingtonpost__1000-01-01__timeline:20883-20890	1.000
:Event_0000111	canonical_mention.actual	"bail out"	finan_washingtonpost__1000-01-01__timeline:20883-20890	1.000
:Event_0000112	type	Transaction.TransferMoney
:Event_0000112	mention.actual	"lend"	finan_washingtonpost__1000-01-01__timeline:27755-27758	1.000
:Event_0000112	canonical_mention.actual	"lend"	finan_washingtonpost__1000-01-01__timeline:27755-27758	1.000
:Event_0000112	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000206	finan_washingtonpost__1000-01-01__timeline:27726-27740	1.000
:Event_0000112	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000126	finan_washingtonpost__1000-01-01__timeline:27747-27748	1.000
:Event_0000112	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000291	finan_washingtonpost__1000-01-01__timeline:27796-27800	1.000
:Event_0000113	type	Contact.Meet
:Event_0000113	mention.actual	"testify"	finan_washingtonpost__1000-01-01__timeline:14711-14717	1.000
:Event_0000113	canonical_mention.actual	"testify"	finan_washingtonpost__1000-01-01__timeline:14711-14717	1.000
:Event_0000113	Contact.Meet_Participant.actual	:Entity_EDL_0000122	finan_washingtonpost__1000-01-01__timeline:14581-14593	1.000
:Event_0000113	Contact.Meet_Participant.actual	:Entity_EDL_0000068	finan_washingtonpost__1000-01-01__timeline:14622-14633	1.000
:Event_0000113	Contact.Meet_Participant.actual	:Entity_EDL_0000228	finan_washingtonpost__1000-01-01__timeline:14699-14709	1.000
:Event_0000113	Contact.Meet_Place.actual	:Entity_EDL_0000194	finan_washingtonpost__1000-01-01__timeline:14722-14733	1.000
:Event_0000114	type	Personnel.StartPosition
:Event_0000114	mention.actual	"confirmation"	finan_washingtonpost__1000-01-01__timeline:14362-14373	1.000
:Event_0000114	canonical_mention.actual	"confirmation"	finan_washingtonpost__1000-01-01__timeline:14362-14373	1.000
:Event_0000114	Personnel.StartPosition_Person.actual	:Entity_EDL_0000064	finan_washingtonpost__1000-01-01__timeline:14387-14402	1.000
:Event_0000115	type	Transaction.TransferOwnership
:Event_0000115	mention.actual	"seize"	finan_washingtonpost__1000-01-01__timeline:48548-48552	1.000
:Event_0000115	canonical_mention.actual	"seize"	finan_washingtonpost__1000-01-01__timeline:48548-48552	1.000
:Event_0000115	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000012	finan_washingtonpost__1000-01-01__timeline:48537-48546	1.000
:Event_0000115	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000152	finan_washingtonpost__1000-01-01__timeline:48572-48577	1.000
:Event_0000115	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000263	finan_washingtonpost__1000-01-01__timeline:48579-48595	1.000
:Event_0000115	Transaction.TransferOwnership_Place.actual	:Entity_EDL_0000128	finan_washingtonpost__1000-01-01__timeline:48628-48631	1.000
:Event_0000116	type	Contact.Contact
:Event_0000116	mention.actual	"says"	finan_washingtonpost__1000-01-01__timeline:26332-26335	1.000
:Event_0000116	canonical_mention.actual	"says"	finan_washingtonpost__1000-01-01__timeline:26332-26335	1.000
:Event_0000116	Contact.Contact_Participant.actual	:Entity_EDL_0000138	finan_washingtonpost__1000-01-01__timeline:26276-26283	1.000
:Event_0000117	type	Transaction.TransferMoney
:Event_0000117	mention.actual	"pay"	finan_washingtonpost__1000-01-01__timeline:33933-33935	1.000
:Event_0000117	canonical_mention.actual	"pay"	finan_washingtonpost__1000-01-01__timeline:33933-33935	1.000
:Event_0000117	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000044	finan_washingtonpost__1000-01-01__timeline:33941-33950	1.000
:Event_0000118	type	Contact.Meet
:Event_0000118	mention.actual	"summit"	finan_washingtonpost__1000-01-01__timeline:35840-35845	1.000
:Event_0000118	canonical_mention.actual	"summit"	finan_washingtonpost__1000-01-01__timeline:35840-35845	1.000
:Event_0000118	Contact.Meet_Participant.actual	:Entity_EDL_0000185	finan_washingtonpost__1000-01-01__timeline:35768-35781	1.000
:Event_0000119	type	Transaction.TransferOwnership
:Event_0000119	mention.actual	"seizes"	finan_washingtonpost__1000-01-01__timeline:11946-11951	1.000
:Event_0000119	canonical_mention.actual	"seizes"	finan_washingtonpost__1000-01-01__timeline:11946-11951	1.000
:Event_0000119	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000047	finan_washingtonpost__1000-01-01__timeline:11941-11944	1.000
:Event_0000119	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000000	finan_washingtonpost__1000-01-01__timeline:11959-11963	1.000
:Event_0000119	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000041	finan_washingtonpost__1000-01-01__timeline:11977-12011	1.000
:Event_0000120	type	ArtifactExistence.Shortage.Shortage
:Event_0000120	mention.actual	"scarce"	finan_washingtonpost__1000-01-01__timeline:54031-54036	1.000
:Event_0000120	canonical_mention.actual	"scarce"	finan_washingtonpost__1000-01-01__timeline:54031-54036	1.000
:Event_0000120	ArtifactExistence.Shortage.Shortage_Supply.actual	:Entity_EDL_0000027	finan_washingtonpost__1000-01-01__timeline:54018-54021	1.000
:Event_0000121	type	Transaction.TransferOwnership
:Event_0000121	mention.actual	"bought"	finan_washingtonpost__1000-01-01__timeline:2487-2492	1.000
:Event_0000121	canonical_mention.actual	"bought"	finan_washingtonpost__1000-01-01__timeline:2487-2492	1.000
:Event_0000121	Transaction.TransferOwnership_Giver.actual	:Entity_EDL_0000017	finan_washingtonpost__1000-01-01__timeline:2476-2477	1.000
:Event_0000122	type	Business.End
:Event_0000122	mention.actual	"layoffs"	finan_washingtonpost__1000-01-01__timeline:2174-2180	1.000
:Event_0000122	canonical_mention.actual	"layoffs"	finan_washingtonpost__1000-01-01__timeline:2174-2180	1.000
:Event_0000122	Business.End_Organization.actual	:Entity_EDL_0000285	finan_washingtonpost__1000-01-01__timeline:2133-2137	1.000
:Event_0000122	Business.End_Organization.actual	:Entity_EDL_0000266	finan_washingtonpost__1000-01-01__timeline:2143-2163	1.000
:Event_0000123	type	Contact.Contact
:Event_0000123	mention.actual	"tells"	finan_washingtonpost__1000-01-01__timeline:49969-49973	1.000
:Event_0000123	canonical_mention.actual	"tells"	finan_washingtonpost__1000-01-01__timeline:49969-49973	1.000
:Event_0000123	Contact.Contact_Participant.actual	:Entity_EDL_0000223	finan_washingtonpost__1000-01-01__timeline:49925-49932	1.000
:Event_0000123	Contact.Contact_Participant.actual	:Entity_EDL_0000087	finan_washingtonpost__1000-01-01__timeline:49979-50000	1.000
:Event_0000124	type	Contact.Meet
:Event_0000124	mention.actual	"met"	finan_washingtonpost__1000-01-01__timeline:5790-5792	1.000
:Event_0000124	canonical_mention.actual	"met"	finan_washingtonpost__1000-01-01__timeline:5790-5792	1.000
:Event_0000124	Contact.Meet_Participant.actual	:Entity_EDL_0000006	finan_washingtonpost__1000-01-01__timeline:5777-5788	1.000
:Event_0000124	Contact.Meet_Participant.actual	:Entity_EDL_0000246	finan_washingtonpost__1000-01-01__timeline:5804-5810	1.000
:Event_0000124	Contact.Meet_Participant.actual	:Entity_EDL_0000274	finan_washingtonpost__1000-01-01__timeline:5816-5824	1.000
:Event_0000125	type	Contact.Meet
:Event_0000125	mention.actual	"convene"	finan_washingtonpost__1000-01-01__timeline:20255-20261	1.000
:Event_0000125	canonical_mention.actual	"convene"	finan_washingtonpost__1000-01-01__timeline:20255-20261	1.000
:Event_0000125	Contact.Meet_Participant.actual	:Entity_EDL_0000298	finan_washingtonpost__1000-01-01__timeline:20244-20248	1.000
:Event_0000126	type	Contact.Meet
:Event_0000126	mention.actual	"meeting"	finan_washingtonpost__1000-01-01__timeline:20578-20584	1.000
:Event_0000126	canonical_mention.actual	"meeting"	finan_washingtonpost__1000-01-01__timeline:20578-20584	1.000
:Event_0000126	Contact.Meet_Participant.actual	:Entity_EDL_0000118	finan_washingtonpost__1000-01-01__timeline:20510-20513	1.000
:Event_0000126	Contact.Meet_Participant.actual	:Entity_EDL_0000096	finan_washingtonpost__1000-01-01__timeline:20523-20532	1.000
:Event_0000126	Contact.Meet_Participant.actual	:Entity_EDL_0000272	finan_washingtonpost__1000-01-01__timeline:20539-20543	1.000
:Event_0000126	Contact.Meet_Place.actual	:Entity_EDL_0000151	finan_washingtonpost__1000-01-01__timeline:20552-20562	1.000
:Event_0000127	type	Conflict.Demonstrate
:Event_0000127	mention.actual	"rally"	finan_washingtonpost__1000-01-01__timeline:24772-24776	1.000
:Event_0000127	canonical_mention.actual	"rally"	finan_washingtonpost__1000-01-01__timeline:24772-24776	1.000
:Event_0000127	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000192	finan_washingtonpost__1000-01-01__timeline:24640-24651	1.000
:Event_0000127	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000286	finan_washingtonpost__1000-01-01__timeline:24704-24712	1.000
:Event_0000127	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000238	finan_washingtonpost__1000-01-01__timeline:24781-24787	1.000
:Event_0000128	type	Contact.Contact
:Event_0000128	mention.actual	"request"	finan_washingtonpost__1000-01-01__timeline:22083-22089	1.000
:Event_0000128	canonical_mention.actual	"request"	finan_washingtonpost__1000-01-01__timeline:22083-22089	1.000
:Event_0000128	Contact.Contact_Participant.actual	:Entity_EDL_0000101	finan_washingtonpost__1000-01-01__timeline:22108-22117	1.000
:Event_0000129	type	Transaction.TransferOwnership
:Event_0000129	mention.actual	"rescue"	finan_washingtonpost__1000-01-01__timeline:45674-45679	1.000
:Event_0000129	canonical_mention.actual	"rescue"	finan_washingtonpost__1000-01-01__timeline:45674-45679	1.000
:Event_0000129	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000154	finan_washingtonpost__1000-01-01__timeline:45681-45685	1.000
