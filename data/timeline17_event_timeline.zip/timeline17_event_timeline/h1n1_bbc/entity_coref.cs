:Entity_EDL_0000000	type	GeopoliticalEntity
:Entity_EDL_0000000	canonical_mention	"Mexico"	h1n1_bbc__1000-01-01__timeline:802-807	1.0
:Entity_EDL_0000000	mention	"Mexico"	h1n1_bbc__1000-01-01__timeline:802-807	1.0
:Entity_EDL_0000000	link	3996063
:Entity_EDL_0000001	type	Person
:Entity_EDL_0000001	nominal_mention	"people"	h1n1_bbc__1000-01-01__timeline:4660-4665	1.0
:Entity_EDL_0000001	link	NIL000000001
:Entity_EDL_0000002	type	Facility
:Entity_EDL_0000002	canonical_mention	"Monklands Hospital"	h1n1_bbc__1000-01-01__timeline:5048-5065	1.0
:Entity_EDL_0000002	mention	"Monklands Hospital"	h1n1_bbc__1000-01-01__timeline:5048-5065	1.0
:Entity_EDL_0000002	link	NIL000000002
:Entity_EDL_0000003	type	GeopoliticalEntity
:Entity_EDL_0000003	mention	"Mexico"	h1n1_bbc__1000-01-01__timeline:4988-4993	1.0
:Entity_EDL_0000003	link	3996063
:Entity_EDL_0000004	type	Person
:Entity_EDL_0000004	mention	"Dawn Askham"	h1n1_bbc__1000-01-01__timeline:4924-4934	1.0
:Entity_EDL_0000004	link	NIL000000003
:Entity_EDL_0000005	type	Person
:Entity_EDL_0000005	canonical_mention	"Askhams"	h1n1_bbc__1000-01-01__timeline:3472-3478	1.0
:Entity_EDL_0000005	mention	"Askhams"	h1n1_bbc__1000-01-01__timeline:3472-3478	1.0
:Entity_EDL_0000005	link	NIL000000004
:Entity_EDL_0000006	type	Person
:Entity_EDL_0000006	canonical_mention	"who"	h1n1_bbc__1000-01-01__timeline:1583-1585	1.0
:Entity_EDL_0000006	pronominal_mention	"who"	h1n1_bbc__1000-01-01__timeline:1583-1585	1.0
:Entity_EDL_0000006	link	NIL000000005
:Entity_EDL_0000007	type	Person
:Entity_EDL_0000007	canonical_mention	"Mrs Askham"	h1n1_bbc__1000-01-01__timeline:4584-4593	1.0
:Entity_EDL_0000007	mention	"Mrs Askham"	h1n1_bbc__1000-01-01__timeline:4584-4593	1.0
:Entity_EDL_0000007	link	NIL000000006
:Entity_EDL_0000008	type	Person
:Entity_EDL_0000008	nominal_mention	"people"	h1n1_bbc__1000-01-01__timeline:3776-3781	1.0
:Entity_EDL_0000008	link	NIL000000007
:Entity_EDL_0000009	type	GeopoliticalEntity
:Entity_EDL_0000009	canonical_mention	"Edinburgh"	h1n1_bbc__1000-01-01__timeline:766-774	1.0
:Entity_EDL_0000009	mention	"Edinburgh"	h1n1_bbc__1000-01-01__timeline:766-774	1.0
:Entity_EDL_0000009	link	2650225
:Entity_EDL_0000010	type	Person
:Entity_EDL_0000010	nominal_mention	"people"	h1n1_bbc__1000-01-01__timeline:4543-4548	1.0
:Entity_EDL_0000010	link	NIL000000008
:Entity_EDL_0000011	type	Person
:Entity_EDL_0000011	nominal_mention	"couple"	h1n1_bbc__1000-01-01__timeline:1576-1581	1.0
:Entity_EDL_0000011	link	NIL000000009
:Entity_EDL_0000012	type	Person
:Entity_EDL_0000012	nominal_mention	"people"	h1n1_bbc__1000-01-01__timeline:3417-3422	1.0
:Entity_EDL_0000012	link	NIL000000010
:Entity_EDL_0000013	type	Person
:Entity_EDL_0000013	canonical_mention	"Askham"	h1n1_bbc__1000-01-01__timeline:3819-3824	1.0
:Entity_EDL_0000013	mention	"Askham"	h1n1_bbc__1000-01-01__timeline:3819-3824	1.0
:Entity_EDL_0000013	link	NIL000000011
:Entity_EDL_0000014	type	Person
:Entity_EDL_0000014	mention	"Iain"	h1n1_bbc__1000-01-01__timeline:4915-4918	1.0
:Entity_EDL_0000014	link	30005066
:Entity_EDL_0000015	type	Person
:Entity_EDL_0000015	pronominal_mention	"who"	h1n1_bbc__1000-01-01__timeline:3447-3449	1.0
:Entity_EDL_0000015	link	NIL000000012
:Entity_EDL_0000016	type	GeopoliticalEntity
:Entity_EDL_0000016	mention	"Scotland"	h1n1_bbc__1000-01-01__timeline:227-234	1.0
:Entity_EDL_0000016	link	2638360
:Entity_EDL_0000017	type	Facility
:Entity_EDL_0000017	canonical_mention	"hospital"	h1n1_bbc__1000-01-01__timeline:2556-2563	1.0
:Entity_EDL_0000017	nominal_mention	"hospital"	h1n1_bbc__1000-01-01__timeline:2556-2563	1.0
:Entity_EDL_0000017	link	NIL000000013
:Entity_EDL_0000018	type	GeopoliticalEntity
:Entity_EDL_0000018	canonical_mention	"England"	h1n1_bbc__1000-01-01__timeline:284-290	1.0
:Entity_EDL_0000018	mention	"England"	h1n1_bbc__1000-01-01__timeline:284-290	1.0
:Entity_EDL_0000018	link	6269131
:Entity_EDL_0000019	type	Person
:Entity_EDL_0000019	canonical_mention	"Iain Askham"	h1n1_bbc__1000-01-01__timeline:726-736	1.0
:Entity_EDL_0000019	mention	"Iain Askham"	h1n1_bbc__1000-01-01__timeline:726-736	1.0
:Entity_EDL_0000019	link	NIL000000014
:Entity_EDL_0000020	type	Location
:Entity_EDL_0000020	canonical_mention	"areas"	h1n1_bbc__1000-01-01__timeline:4736-4740	1.0
:Entity_EDL_0000020	nominal_mention	"areas"	h1n1_bbc__1000-01-01__timeline:4736-4740	1.0
:Entity_EDL_0000020	link	NIL000000015
:Entity_EDL_0000021	type	Person
:Entity_EDL_0000021	nominal_mention	"Mrs Askham"	h1n1_bbc__1000-01-01__timeline:2521-2530	1.0
:Entity_EDL_0000021	link	NIL000000016
