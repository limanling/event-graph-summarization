:Event_0000000	type	ArtifactExistence.DamageDestroy.Destroy
:Event_0000000	mention.actual	"collapsed"	haiti_bbc__1000-01-01__timeline:10760-10768	1.000
:Event_0000000	canonical_mention.actual	"collapsed"	haiti_bbc__1000-01-01__timeline:10760-10768	1.000
:Event_0000000	ArtifactExistence.DamageDestroy.Destroy_Artifact.actual	:Entity_EDL_0000006	haiti_bbc__1000-01-01__timeline:10703-10714	1.000
:Event_0000000	ArtifactExistence.DamageDestroy.Destroy_Artifact.actual	:Entity_EDL_0000066	haiti_bbc__1000-01-01__timeline:10732-10740	1.000
:Event_0000000	ArtifactExistence.DamageDestroy.Destroy_Place.actual	:Entity_EDL_0000031	haiti_bbc__1000-01-01__timeline:10745-10758	1.000
:Event_0000000	type	ArtifactExistence.DamageDestroy.Destroy
:Event_0000000	mention.actual	"collapsed"	haiti_bbc__1000-01-01__timeline:8235-8243	1.000
:Event_0000000	canonical_mention.actual	"collapsed"	haiti_bbc__1000-01-01__timeline:8235-8243	1.000
:Event_0000000	type	ArtifactExistence.DamageDestroy.Destroy
:Event_0000000	mention.actual	"collapsed"	haiti_bbc__1000-01-01__timeline:8369-8377	1.000
:Event_0000000	canonical_mention.actual	"collapsed"	haiti_bbc__1000-01-01__timeline:8369-8377	1.000
:Event_0000000	ArtifactExistence.DamageDestroy.Destroy_Artifact.actual	:Entity_EDL_0000019	haiti_bbc__1000-01-01__timeline:8379-8390	1.000
:Event_0000000	ArtifactExistence.DamageDestroy.Destroy_Place.actual	:Entity_EDL_0000004	haiti_bbc__1000-01-01__timeline:8395-8408	1.000
:Event_0000001	type	Life.Die
:Event_0000001	mention.actual	"dead"	haiti_bbc__1000-01-01__timeline:7186-7189	1.000
:Event_0000001	canonical_mention.actual	"dead"	haiti_bbc__1000-01-01__timeline:7186-7189	1.000
:Event_0000001	Life.Die_Victim.actual	:Entity_EDL_0000058	haiti_bbc__1000-01-01__timeline:7186-7189	1.000
:Event_0000001	type	Life.Die
:Event_0000001	mention.actual	"dead"	haiti_bbc__1000-01-01__timeline:8005-8008	1.000
:Event_0000001	canonical_mention.actual	"dead"	haiti_bbc__1000-01-01__timeline:8005-8008	1.000
:Event_0000002	type	Life.Die
:Event_0000002	mention.actual	"death"	haiti_bbc__1000-01-01__timeline:5982-5986	1.000
:Event_0000002	canonical_mention.actual	"death"	haiti_bbc__1000-01-01__timeline:5982-5986	1.000
:Event_0000002	type	Life.Die
:Event_0000002	mention.actual	"death"	haiti_bbc__1000-01-01__timeline:2490-2494	1.000
:Event_0000002	canonical_mention.actual	"death"	haiti_bbc__1000-01-01__timeline:2490-2494	1.000
:Event_0000003	type	Transaction.TransferMoney
:Event_0000003	mention.actual	"raised"	haiti_bbc__1000-01-01__timeline:451-456	1.000
:Event_0000003	canonical_mention.actual	"raised"	haiti_bbc__1000-01-01__timeline:451-456	1.000
:Event_0000003	Transaction.TransferMoney_Place.actual	:Entity_EDL_0000050	haiti_bbc__1000-01-01__timeline:436-437	1.000
:Event_0000004	type	Business.End
:Event_0000004	mention.actual	"collapsed"	haiti_bbc__1000-01-01__timeline:10358-10366	1.000
:Event_0000004	canonical_mention.actual	"collapsed"	haiti_bbc__1000-01-01__timeline:10358-10366	1.000
:Event_0000004	Business.End_Organization.actual	:Entity_EDL_0000033	haiti_bbc__1000-01-01__timeline:10343-10352	1.000
:Event_0000005	type	Movement.TransportPerson
:Event_0000005	mention.actual	"disperse"	haiti_bbc__1000-01-01__timeline:4452-4459	1.000
:Event_0000005	canonical_mention.actual	"disperse"	haiti_bbc__1000-01-01__timeline:4452-4459	1.000
:Event_0000005	Movement.TransportPerson_Agent.actual	:Entity_EDL_0000042	haiti_bbc__1000-01-01__timeline:4430-4435	1.000
:Event_0000005	Movement.TransportPerson_Person.actual	:Entity_EDL_0000025	haiti_bbc__1000-01-01__timeline:4461-4467	1.000
:Event_0000005	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000026	haiti_bbc__1000-01-01__timeline:4472-4476	1.000
:Event_0000006	type	Movement.TransportArtifact
:Event_0000006	mention.actual	"bring"	haiti_bbc__1000-01-01__timeline:358-362	1.000
:Event_0000006	canonical_mention.actual	"bring"	haiti_bbc__1000-01-01__timeline:358-362	1.000
:Event_0000006	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000003	haiti_bbc__1000-01-01__timeline:298-302	1.000
:Event_0000006	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000032	haiti_bbc__1000-01-01__timeline:364-366	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"preying"	haiti_bbc__1000-01-01__timeline:6530-6536	1.000
:Event_0000007	canonical_mention.actual	"preying"	haiti_bbc__1000-01-01__timeline:6530-6536	1.000
:Event_0000007	Conflict.Attack_Attacker.actual	:Entity_EDL_0000041	haiti_bbc__1000-01-01__timeline:6524-6528	1.000
:Event_0000007	Conflict.Attack_Target.actual	:Entity_EDL_0000047	haiti_bbc__1000-01-01__timeline:6541-6549	1.000
:Event_0000008	type	Life.Die
:Event_0000008	mention.actual	"casualties"	haiti_bbc__1000-01-01__timeline:9913-9922	1.000
:Event_0000008	canonical_mention.actual	"casualties"	haiti_bbc__1000-01-01__timeline:9913-9922	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000017	haiti_bbc__1000-01-01__timeline:9913-9922	1.000
:Event_0000009	type	ArtifactExistence.Shortage.Shortage
:Event_0000009	mention.actual	"low"	haiti_bbc__1000-01-01__timeline:3889-3891	1.000
:Event_0000009	canonical_mention.actual	"low"	haiti_bbc__1000-01-01__timeline:3889-3891	1.000
:Event_0000010	type	Movement.TransportArtifact
:Event_0000010	mention.actual	"landed"	haiti_bbc__1000-01-01__timeline:8802-8807	1.000
:Event_0000010	canonical_mention.actual	"landed"	haiti_bbc__1000-01-01__timeline:8802-8807	1.000
:Event_0000010	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000039	haiti_bbc__1000-01-01__timeline:8788-8789	1.000
:Event_0000010	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000018	haiti_bbc__1000-01-01__timeline:8795-8800	1.000
:Event_0000010	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000052	haiti_bbc__1000-01-01__timeline:8816-8822	1.000
:Event_0000011	type	Life.Die
:Event_0000011	mention.actual	"died"	haiti_bbc__1000-01-01__timeline:4103-4106	1.000
:Event_0000011	canonical_mention.actual	"died"	haiti_bbc__1000-01-01__timeline:4103-4106	1.000
:Event_0000011	Life.Die_Victim.actual	:Entity_EDL_0000046	haiti_bbc__1000-01-01__timeline:4085-4090	1.000
:Event_0000012	type	Conflict.Attack
:Event_0000012	mention.actual	"destroyed"	haiti_bbc__1000-01-01__timeline:5052-5060	1.000
:Event_0000012	canonical_mention.actual	"destroyed"	haiti_bbc__1000-01-01__timeline:5052-5060	1.000
:Event_0000012	Conflict.Attack_Place.actual	:Entity_EDL_0000043	haiti_bbc__1000-01-01__timeline:4986-4990	1.000
:Event_0000012	Conflict.Attack_Target.actual	:Entity_EDL_0000013	haiti_bbc__1000-01-01__timeline:5046-5050	1.000
:Event_0000013	type	Life.Injure
:Event_0000013	mention.actual	"injuries"	haiti_bbc__1000-01-01__timeline:3358-3365	1.000
:Event_0000013	canonical_mention.actual	"injuries"	haiti_bbc__1000-01-01__timeline:3358-3365	1.000
:Event_0000013	Life.Injure_Victim.actual	:Entity_EDL_0000005	haiti_bbc__1000-01-01__timeline:3319-3324	1.000
:Event_0000014	type	Justice.Appeal
:Event_0000014	mention.actual	"appeal"	haiti_bbc__1000-01-01__timeline:7256-7261	1.000
:Event_0000014	canonical_mention.actual	"appeal"	haiti_bbc__1000-01-01__timeline:7256-7261	1.000
:Event_0000015	type	Conflict.Attack
:Event_0000015	mention.actual	"destroyed"	haiti_bbc__1000-01-01__timeline:5577-5585	1.000
:Event_0000015	canonical_mention.actual	"destroyed"	haiti_bbc__1000-01-01__timeline:5577-5585	1.000
:Event_0000015	Conflict.Attack_Target.actual	:Entity_EDL_0000020	haiti_bbc__1000-01-01__timeline:5488-5496	1.000
:Event_0000015	Conflict.Attack_Place.actual	:Entity_EDL_0000048	haiti_bbc__1000-01-01__timeline:5501-5507	1.000
:Event_0000016	type	Life.Die
:Event_0000016	mention.actual	"dying"	haiti_bbc__1000-01-01__timeline:7532-7536	1.000
:Event_0000016	canonical_mention.actual	"dying"	haiti_bbc__1000-01-01__timeline:7532-7536	1.000
:Event_0000016	Life.Die_Place.actual	:Entity_EDL_0000036	haiti_bbc__1000-01-01__timeline:7497-7510	1.000
:Event_0000016	Life.Die_Victim.actual	:Entity_EDL_0000014	haiti_bbc__1000-01-01__timeline:7517-7525	1.000
:Event_0000017	type	Movement.TransportArtifact
:Event_0000017	mention.actual	"sending"	haiti_bbc__1000-01-01__timeline:2103-2109	1.000
:Event_0000017	canonical_mention.actual	"sending"	haiti_bbc__1000-01-01__timeline:2103-2109	1.000
:Event_0000017	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000063	haiti_bbc__1000-01-01__timeline:2083-2084	1.000
:Event_0000017	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000010	haiti_bbc__1000-01-01__timeline:2096-2097	1.000
:Event_0000017	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000059	haiti_bbc__1000-01-01__timeline:2125-2131	1.000
:Event_0000017	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000068	haiti_bbc__1000-01-01__timeline:2137-2143	1.000
:Event_0000017	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000022	haiti_bbc__1000-01-01__timeline:2148-2152	1.000
:Event_0000018	type	Conflict.Attack
:Event_0000018	mention.actual	"destroyed"	haiti_bbc__1000-01-01__timeline:6654-6662	1.000
:Event_0000018	canonical_mention.actual	"destroyed"	haiti_bbc__1000-01-01__timeline:6654-6662	1.000
:Event_0000018	Conflict.Attack_Target.actual	:Entity_EDL_0000016	haiti_bbc__1000-01-01__timeline:6643-6648	1.000
:Event_0000019	type	Movement.TransportArtifact
:Event_0000019	mention.actual	"dropped"	haiti_bbc__1000-01-01__timeline:2780-2786	1.000
:Event_0000019	canonical_mention.actual	"dropped"	haiti_bbc__1000-01-01__timeline:2780-2786	1.000
:Event_0000019	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000012	haiti_bbc__1000-01-01__timeline:2717-2718	1.000
:Event_0000019	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000000	haiti_bbc__1000-01-01__timeline:2736-2742	1.000
:Event_0000019	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000038	haiti_bbc__1000-01-01__timeline:2757-2766	1.000
:Event_0000019	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000049	haiti_bbc__1000-01-01__timeline:2768-2778	1.000
:Event_0000019	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000055	haiti_bbc__1000-01-01__timeline:2798-2803	1.000
:Event_0000019	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000061	haiti_bbc__1000-01-01__timeline:2814-2820	1.000
:Event_0000020	type	Life.Die
:Event_0000020	mention.actual	"died"	haiti_bbc__1000-01-01__timeline:10100-10103	1.000
:Event_0000020	canonical_mention.actual	"died"	haiti_bbc__1000-01-01__timeline:10100-10103	1.000
:Event_0000020	Life.Die_Victim.actual	:Entity_EDL_0000030	haiti_bbc__1000-01-01__timeline:10089-10094	1.000
:Event_0000021	type	Movement.TransportArtifact
:Event_0000021	mention.actual	"crossed"	haiti_bbc__1000-01-01__timeline:2301-2307	1.000
:Event_0000021	canonical_mention.actual	"crossed"	haiti_bbc__1000-01-01__timeline:2301-2307	1.000
:Event_0000021	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000035	haiti_bbc__1000-01-01__timeline:2252-2258	1.000
:Event_0000021	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000045	haiti_bbc__1000-01-01__timeline:2329-2346	1.000
:Event_0000022	type	Movement.TransportArtifact
:Event_0000022	mention.actual	"fleeing"	haiti_bbc__1000-01-01__timeline:4794-4800	1.000
:Event_0000022	canonical_mention.actual	"fleeing"	haiti_bbc__1000-01-01__timeline:4794-4800	1.000
:Event_0000022	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000054	haiti_bbc__1000-01-01__timeline:4769-4777	1.000
:Event_0000022	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000011	haiti_bbc__1000-01-01__timeline:4782-4787	1.000
:Event_0000022	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000053	haiti_bbc__1000-01-01__timeline:4806-4812	1.000
:Event_0000023	type	Movement.TransportArtifact
:Event_0000023	mention.actual	"sent"	haiti_bbc__1000-01-01__timeline:771-774	1.000
:Event_0000023	canonical_mention.actual	"sent"	haiti_bbc__1000-01-01__timeline:771-774	1.000
:Event_0000023	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000051	haiti_bbc__1000-01-01__timeline:748-753	1.000
:Event_0000023	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000064	haiti_bbc__1000-01-01__timeline:782-792	1.000
:Event_0000024	type	ArtifactExistence.Shortage.Shortage
:Event_0000024	mention.actual	"lack"	haiti_bbc__1000-01-01__timeline:9310-9313	1.000
:Event_0000024	canonical_mention.actual	"lack"	haiti_bbc__1000-01-01__timeline:9310-9313	1.000
:Event_0000024	ArtifactExistence.Shortage.Shortage_Supply.actual	:Entity_EDL_0000044	haiti_bbc__1000-01-01__timeline:9332-9340	1.000
:Event_0000025	type	Movement.TransportArtifact
:Event_0000025	mention.actual	"moved"	haiti_bbc__1000-01-01__timeline:671-675	1.000
:Event_0000025	canonical_mention.actual	"moved"	haiti_bbc__1000-01-01__timeline:671-675	1.000
:Event_0000025	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000009	haiti_bbc__1000-01-01__timeline:653-661	1.000
:Event_0000025	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000037	haiti_bbc__1000-01-01__timeline:687-694	1.000
:Event_0000026	type	Personnel.EndPosition
:Event_0000026	mention.actual	"former"	haiti_bbc__1000-01-01__timeline:4584-4589	1.000
:Event_0000026	canonical_mention.actual	"former"	haiti_bbc__1000-01-01__timeline:4584-4589	1.000
:Event_0000026	Personnel.EndPosition_Person.actual	:Entity_EDL_0000069	haiti_bbc__1000-01-01__timeline:4610-4621	1.000
:Event_0000027	type	Conflict.Attack
:Event_0000027	mention.actual	"fired shots"	haiti_bbc__1000-01-01__timeline:4437-4447	1.000
:Event_0000027	canonical_mention.actual	"fired shots"	haiti_bbc__1000-01-01__timeline:4437-4447	1.000
:Event_0000027	Conflict.Attack_Attacker.actual	:Entity_EDL_0000042	haiti_bbc__1000-01-01__timeline:4430-4435	1.000
:Event_0000027	Conflict.Attack_Target.actual	:Entity_EDL_0000025	haiti_bbc__1000-01-01__timeline:4461-4467	1.000
:Event_0000027	Conflict.Attack_Place.actual	:Entity_EDL_0000026	haiti_bbc__1000-01-01__timeline:4472-4476	1.000
:Event_0000028	type	Movement.TransportArtifact
:Event_0000028	mention.actual	"pulled"	haiti_bbc__1000-01-01__timeline:1881-1886	1.000
:Event_0000028	canonical_mention.actual	"pulled"	haiti_bbc__1000-01-01__timeline:1881-1886	1.000
:Event_0000028	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000008	haiti_bbc__1000-01-01__timeline:1866-1868	1.000
:Event_0000028	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000027	haiti_bbc__1000-01-01__timeline:1910-1913	1.000
:Event_0000028	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000065	haiti_bbc__1000-01-01__timeline:1922-1926	1.000
:Event_0000029	type	Movement.TransportArtifact
:Event_0000029	mention.actual	"arrive"	haiti_bbc__1000-01-01__timeline:6177-6182	1.000
:Event_0000029	canonical_mention.actual	"arrive"	haiti_bbc__1000-01-01__timeline:6177-6182	1.000
:Event_0000029	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000024	haiti_bbc__1000-01-01__timeline:6163-6172	1.000
:Event_0000029	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000034	haiti_bbc__1000-01-01__timeline:6187-6191	1.000
:Event_0000030	type	Conflict.Attack
:Event_0000030	mention.actual	"fired"	haiti_bbc__1000-01-01__timeline:4506-4510	1.000
:Event_0000030	canonical_mention.actual	"fired"	haiti_bbc__1000-01-01__timeline:4506-4510	1.000
:Event_0000030	Conflict.Attack_Attacker.actual	:Entity_EDL_0000001	haiti_bbc__1000-01-01__timeline:4499-4504	1.000
:Event_0000030	Conflict.Attack_Instrument.actual	:Entity_EDL_0000023	haiti_bbc__1000-01-01__timeline:4518-4523	1.000
:Event_0000030	Conflict.Attack_Target.actual	:Entity_EDL_0000067	haiti_bbc__1000-01-01__timeline:4536-4540	1.000
:Event_0000030	Conflict.Attack_Place.actual	:Entity_EDL_0000015	haiti_bbc__1000-01-01__timeline:4569-4575	1.000
:Event_0000031	type	ArtifactExistence.DamageDestroy.Destroy
:Event_0000031	mention.actual	"collapsed"	haiti_bbc__1000-01-01__timeline:1626-1634	1.000
:Event_0000031	canonical_mention.actual	"collapsed"	haiti_bbc__1000-01-01__timeline:1626-1634	1.000
:Event_0000031	ArtifactExistence.DamageDestroy.Destroy_Artifact.actual	:Entity_EDL_0000029	haiti_bbc__1000-01-01__timeline:1577-1585	1.000
:Event_0000032	type	Movement.TransportPerson
:Event_0000032	mention.actual	"send"	haiti_bbc__1000-01-01__timeline:2909-2912	1.000
:Event_0000032	canonical_mention.actual	"send"	haiti_bbc__1000-01-01__timeline:2909-2912	1.000
:Event_0000032	Movement.TransportPerson_Person.actual	:Entity_EDL_0000021	haiti_bbc__1000-01-01__timeline:2933-2938	1.000
:Event_0000032	Movement.TransportPerson_Person.actual	:Entity_EDL_0000062	haiti_bbc__1000-01-01__timeline:2944-2949	1.000
:Event_0000032	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000040	haiti_bbc__1000-01-01__timeline:2954-2958	1.000
:Event_0000033	type	Life.Die
:Event_0000033	mention.actual	"died"	haiti_bbc__1000-01-01__timeline:10671-10674	1.000
:Event_0000033	canonical_mention.actual	"died"	haiti_bbc__1000-01-01__timeline:10671-10674	1.000
:Event_0000033	Life.Die_Victim.actual	:Entity_EDL_0000056	haiti_bbc__1000-01-01__timeline:10660-10665	1.000
:Event_0000034	type	Conflict.Attack
:Event_0000034	mention.actual	"destroyed"	haiti_bbc__1000-01-01__timeline:5446-5454	1.000
:Event_0000034	canonical_mention.actual	"destroyed"	haiti_bbc__1000-01-01__timeline:5446-5454	1.000
:Event_0000034	Conflict.Attack_Place.actual	:Entity_EDL_0000002	haiti_bbc__1000-01-01__timeline:5359-5365	1.000
:Event_0000034	Conflict.Attack_Target.actual	:Entity_EDL_0000057	haiti_bbc__1000-01-01__timeline:5437-5444	1.000
:Event_0000035	type	Life.Die
:Event_0000035	mention.actual	"dead"	haiti_bbc__1000-01-01__timeline:9735-9738	1.000
:Event_0000035	canonical_mention.actual	"dead"	haiti_bbc__1000-01-01__timeline:9735-9738	1.000
:Event_0000035	Life.Die_Victim.actual	:Entity_EDL_0000007	haiti_bbc__1000-01-01__timeline:9740-9745	1.000
:Event_0000036	type	Movement.TransportArtifact
:Event_0000036	mention.actual	"leaving"	haiti_bbc__1000-01-01__timeline:4843-4849	1.000
:Event_0000036	canonical_mention.actual	"leaving"	haiti_bbc__1000-01-01__timeline:4843-4849	1.000
:Event_0000036	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000060	haiti_bbc__1000-01-01__timeline:4838-4841	1.000
:Event_0000036	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000028	haiti_bbc__1000-01-01__timeline:4859-4869	1.000
