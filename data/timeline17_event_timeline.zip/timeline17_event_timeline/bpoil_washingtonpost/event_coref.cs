:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killing"	bpoil_washingtonpost__1000-01-01__timeline:82-88	1.000
:Event_0000000	canonical_mention.actual	"killing"	bpoil_washingtonpost__1000-01-01__timeline:82-88	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000002	bpoil_washingtonpost__1000-01-01__timeline:70-78	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000005	bpoil_washingtonpost__1000-01-01__timeline:93-95	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"steps down"	bpoil_washingtonpost__1000-01-01__timeline:1821-1830	1.000
:Event_0000001	canonical_mention.actual	"steps down"	bpoil_washingtonpost__1000-01-01__timeline:1821-1830	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000004	bpoil_washingtonpost__1000-01-01__timeline:1761-1772	1.000
:Event_0000001	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000003	bpoil_washingtonpost__1000-01-01__timeline:1776-1777	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000001	bpoil_washingtonpost__1000-01-01__timeline:1788-1796	1.000
:Event_0000002	type	Disaster.FireExplosion.FireExplosion
:Event_0000002	mention.actual	"burned"	bpoil_washingtonpost__1000-01-01__timeline:161-166	1.000
:Event_0000002	canonical_mention.actual	"burned"	bpoil_washingtonpost__1000-01-01__timeline:161-166	1.000
:Event_0000002	mention.actual	"burned"	bpoil_washingtonpost__1000-01-01__timeline:161-166	1.000
:Event_0000002	canonical_mention.actual	"burned"	bpoil_washingtonpost__1000-01-01__timeline:161-166	1.000
:Event_0000002	Disaster.FireExplosion.FireExplosion_FireExplosionObject.actual	:Entity_EDL_0000000	bpoil_washingtonpost__1000-01-01__timeline:148-150	1.000
