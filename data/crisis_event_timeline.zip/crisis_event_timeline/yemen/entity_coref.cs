:Entity_EDL_0000000	type	Person
:Entity_EDL_0000000	mention	"Saleh"	yemen_telegraphs__1000-01-01__timeline:2275-2279	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_voa__1000-01-01__timeline:1762-1766	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_telegraphs__1000-01-01__timeline:7067-7071	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_washingtonpost__1000-01-01__timeline:2104-2108	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_afp__1000-01-01__timeline:1264-1268	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_telegraphs__1000-01-01__timeline:2571-2575	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_dailystar__1000-01-01__timeline:1846-1850	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_telegraphs__1000-01-01__timeline:5911-5915	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_washingtonpost__1000-01-01__timeline:1590-1594	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_voa__1000-01-01__timeline:2183-2187	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_afp__1000-01-01__timeline:2043-2047	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_telegraphs__1000-01-01__timeline:4666-4670	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_telegraphs__1000-01-01__timeline:5662-5666	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_dailystar__1000-01-01__timeline:1762-1766	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_telegraphs__1000-01-01__timeline:1306-1310	1.0
:Entity_EDL_0000000	canonical_mention	"Saleh"	yemen_dailystar__1000-01-01__timeline:373-377	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_dailystar__1000-01-01__timeline:373-377	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_dailystar__1000-01-01__timeline:2412-2416	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_dailystar__1000-01-01__timeline:2183-2187	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_telegraphs__1000-01-01__timeline:2832-2836	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_telegraphs__1000-01-01__timeline:1697-1701	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_telegraphs__1000-01-01__timeline:6254-6258	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_telegraphs__1000-01-01__timeline:6888-6892	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_voa__1000-01-01__timeline:2412-2416	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_telegraphs__1000-01-01__timeline:3258-3262	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_washingtonpost__1000-01-01__timeline:1654-1658	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_afp__1000-01-01__timeline:1583-1587	1.0
:Entity_EDL_0000000	canonical_mention	"Saleh"	yemen_voa__1000-01-01__timeline:373-377	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_voa__1000-01-01__timeline:373-377	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_voa__1000-01-01__timeline:1846-1850	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_afp__1000-01-01__timeline:4919-4923	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_washingtonpost__1000-01-01__timeline:1896-1900	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_washingtonpost__1000-01-01__timeline:2303-2307	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_telegraphs__1000-01-01__timeline:7224-7228	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_afp__1000-01-01__timeline:3575-3579	1.0
:Entity_EDL_0000000	mention	"Saleh"	yemen_afp__1000-01-01__timeline:3492-3496	1.0
:Entity_EDL_0000000	link	30002798
:Entity_EDL_0000001	type	GeopoliticalEntity
:Entity_EDL_0000001	mention	"Sana'a"	yemen_voa__1000-01-01__timeline:850-855	1.0
:Entity_EDL_0000001	canonical_mention	"Sana'a"	yemen_voa__1000-01-01__timeline:597-602	1.0
:Entity_EDL_0000001	mention	"Sana'a"	yemen_voa__1000-01-01__timeline:597-602	1.0
:Entity_EDL_0000001	mention	"Sanaa"	yemen_telegraphs__1000-01-01__timeline:5578-5582	1.0
:Entity_EDL_0000001	mention	"Sanaa"	yemen_afp__1000-01-01__timeline:2543-2547	1.0
:Entity_EDL_0000001	mention	"Sanaa"	yemen_afp__1000-01-01__timeline:4187-4191	1.0
:Entity_EDL_0000001	canonical_mention	"Sana'a"	yemen_dailystar__1000-01-01__timeline:597-602	1.0
:Entity_EDL_0000001	mention	"Sana'a"	yemen_dailystar__1000-01-01__timeline:597-602	1.0
:Entity_EDL_0000001	mention	"Sana'a"	yemen_voa__1000-01-01__timeline:1947-1952	1.0
:Entity_EDL_0000001	mention	"Sanaa"	yemen_telegraphs__1000-01-01__timeline:4353-4357	1.0
:Entity_EDL_0000001	mention	"Sanaa"	yemen_telegraphs__1000-01-01__timeline:4124-4128	1.0
:Entity_EDL_0000001	mention	"Sanaa"	yemen_telegraphs__1000-01-01__timeline:5345-5349	1.0
:Entity_EDL_0000001	mention	"Sanaa"	yemen_telegraphs__1000-01-01__timeline:3496-3500	1.0
:Entity_EDL_0000001	mention	"Sana'a"	yemen_dailystar__1000-01-01__timeline:850-855	1.0
:Entity_EDL_0000001	mention	"Sanaa"	yemen_afp__1000-01-01__timeline:2324-2328	1.0
:Entity_EDL_0000001	mention	"Sana'a"	yemen_dailystar__1000-01-01__timeline:1947-1952	1.0
:Entity_EDL_0000001	mention	"Sanaa"	yemen_afp__1000-01-01__timeline:1857-1861	1.0
:Entity_EDL_0000001	link	71137
:Entity_EDL_0000002	type	Person
:Entity_EDL_0000002	mention	"Ali Abdullah Saleh"	yemen_latimes__1000-01-01__timeline:2374-2391	1.0
:Entity_EDL_0000002	mention	"Ali Abdullah Saleh"	yemen_latimes__1000-01-01__timeline:2005-2022	1.0
:Entity_EDL_0000002	mention	"Ali Abdullah Saleh"	yemen_latimes__1000-01-01__timeline:4271-4288	1.0
:Entity_EDL_0000002	mention	"Ali Abdullah Saleh"	yemen_latimes__1000-01-01__timeline:3059-3076	1.0
:Entity_EDL_0000002	mention	"Ali Abdullah Saleh"	yemen_latimes__1000-01-01__timeline:3584-3601	1.0
:Entity_EDL_0000002	canonical_mention	"Ali Abdullah Saleh"	yemen_latimes__1000-01-01__timeline:121-138	1.0
:Entity_EDL_0000002	mention	"Ali Abdullah Saleh"	yemen_latimes__1000-01-01__timeline:121-138	1.0
:Entity_EDL_0000002	mention	"Ali Abdullah Saleh"	yemen_latimes__1000-01-01__timeline:4049-4066	1.0
:Entity_EDL_0000002	mention	"Ali Abdullah Saleh"	yemen_latimes__1000-01-01__timeline:260-277	1.0
:Entity_EDL_0000002	link	NIL000000001
:Entity_EDL_0000003	type	GeopoliticalEntity
:Entity_EDL_0000003	mention	"Yemen"	yemen_telegraphs__1000-01-01__timeline:1578-1582	1.0
:Entity_EDL_0000003	mention	"Yemen"	yemen_telegraphs__1000-01-01__timeline:3245-3249	1.0
:Entity_EDL_0000003	mention	"Yemen"	yemen_telegraphs__1000-01-01__timeline:5008-5012	1.0
:Entity_EDL_0000003	mention	"Yemeni"	yemen_telegraphs__1000-01-01__timeline:6464-6469	1.0
:Entity_EDL_0000003	mention	"Yemen"	yemen_telegraphs__1000-01-01__timeline:3173-3177	1.0
:Entity_EDL_0000003	mention	"Yemen"	yemen_dailystar__1000-01-01__timeline:1085-1089	1.0
:Entity_EDL_0000003	link	69543
:Entity_EDL_0000004	type	GeopoliticalEntity
:Entity_EDL_0000004	mention	"Yemen"	yemen_latimes__1000-01-01__timeline:3085-3089	1.0
:Entity_EDL_0000004	mention	"Yemen"	yemen_latimes__1000-01-01__timeline:718-722	1.0
:Entity_EDL_0000004	mention	"Yemen"	yemen_latimes__1000-01-01__timeline:4095-4099	1.0
:Entity_EDL_0000004	mention	"Yemen"	yemen_washingtonpost__1000-01-01__timeline:2463-2467	1.0
:Entity_EDL_0000004	mention	"Yemen"	yemen_washingtonpost__1000-01-01__timeline:1913-1917	1.0
:Entity_EDL_0000004	link	69543
:Entity_EDL_0000005	type	GeopoliticalEntity
:Entity_EDL_0000005	canonical_mention	"Saudi Arabia"	yemen_dailystar__1000-01-01__timeline:2198-2209	1.0
:Entity_EDL_0000005	mention	"Saudi Arabia"	yemen_dailystar__1000-01-01__timeline:2198-2209	1.0
:Entity_EDL_0000005	canonical_mention	"Saudi Arabia"	yemen_washingtonpost__1000-01-01__timeline:1672-1683	1.0
:Entity_EDL_0000005	mention	"Saudi Arabia"	yemen_washingtonpost__1000-01-01__timeline:1672-1683	1.0
:Entity_EDL_0000005	link	102358
:Entity_EDL_0000006	type	GeopoliticalEntity
:Entity_EDL_0000006	canonical_mention	"Taez"	yemen_afp__1000-01-01__timeline:2791-2794	1.0
:Entity_EDL_0000006	mention	"Taez"	yemen_afp__1000-01-01__timeline:2791-2794	1.0
:Entity_EDL_0000006	mention	"Taez"	yemen_afp__1000-01-01__timeline:3380-3383	1.0
:Entity_EDL_0000006	link	70221
:Entity_EDL_0000007	type	Person
:Entity_EDL_0000007	canonical_mention	"Yemenis"	yemen_telegraphs__1000-01-01__timeline:153-159	1.0
:Entity_EDL_0000007	nominal_mention	"Yemenis"	yemen_telegraphs__1000-01-01__timeline:153-159	1.0
:Entity_EDL_0000007	canonical_mention	"Yemenis"	yemen_afp__1000-01-01__timeline:54-60	1.0
:Entity_EDL_0000007	nominal_mention	"Yemenis"	yemen_afp__1000-01-01__timeline:54-60	1.0
:Entity_EDL_0000007	link	NIL000000002
:Entity_EDL_0000008	type	Person
:Entity_EDL_0000008	canonical_mention	"police"	yemen_afp__1000-01-01__timeline:2721-2726	1.0
:Entity_EDL_0000008	nominal_mention	"police"	yemen_afp__1000-01-01__timeline:2721-2726	1.0
:Entity_EDL_0000008	canonical_mention	"police"	yemen_voa__1000-01-01__timeline:623-628	1.0
:Entity_EDL_0000008	nominal_mention	"police"	yemen_voa__1000-01-01__timeline:623-628	1.0
:Entity_EDL_0000008	link	NIL000000003
:Entity_EDL_0000009	type	Facility
:Entity_EDL_0000009	canonical_mention	"compound"	yemen_afp__1000-01-01__timeline:3542-3549	1.0
:Entity_EDL_0000009	nominal_mention	"compound"	yemen_afp__1000-01-01__timeline:3542-3549	1.0
:Entity_EDL_0000009	canonical_mention	"compound"	yemen_voa__1000-01-01__timeline:1935-1942	1.0
:Entity_EDL_0000009	nominal_mention	"compound"	yemen_voa__1000-01-01__timeline:1935-1942	1.0
:Entity_EDL_0000009	link	NIL000000004
:Entity_EDL_0000010	type	Person
:Entity_EDL_0000010	mention	"Hadi"	yemen_afp__1000-01-01__timeline:4813-4816	1.0
:Entity_EDL_0000010	mention	"Hadi"	yemen_afp__1000-01-01__timeline:5023-5026	1.0
:Entity_EDL_0000010	link	NIL000000005
:Entity_EDL_0000011	type	Weapon
:Entity_EDL_0000011	canonical_mention	"rocket"	yemen_dailystar__1000-01-01__timeline:1901-1906	1.0
:Entity_EDL_0000011	nominal_mention	"rocket"	yemen_dailystar__1000-01-01__timeline:1901-1906	1.0
:Entity_EDL_0000011	canonical_mention	"rocket"	yemen_washingtonpost__1000-01-01__timeline:1538-1543	1.0
:Entity_EDL_0000011	nominal_mention	"rocket"	yemen_washingtonpost__1000-01-01__timeline:1538-1543	1.0
:Entity_EDL_0000011	link	NIL000000006
:Entity_EDL_0000012	type	GeopoliticalEntity
:Entity_EDL_0000012	canonical_mention	"Tunisia"	yemen_voa__1000-01-01__timeline:242-248	1.0
:Entity_EDL_0000012	mention	"Tunisia"	yemen_voa__1000-01-01__timeline:242-248	1.0
:Entity_EDL_0000012	canonical_mention	"Tunisia"	yemen_afp__1000-01-01__timeline:34-40	1.0
:Entity_EDL_0000012	mention	"Tunisia"	yemen_afp__1000-01-01__timeline:34-40	1.0
:Entity_EDL_0000012	link	2464461
:Entity_EDL_0000013	type	GeopoliticalEntity
:Entity_EDL_0000013	mention	"United States"	yemen_washingtonpost__1000-01-01__timeline:2338-2350	1.0
:Entity_EDL_0000013	canonical_mention	"United States"	yemen_latimes__1000-01-01__timeline:4925-4937	1.0
:Entity_EDL_0000013	mention	"United States"	yemen_latimes__1000-01-01__timeline:4925-4937	1.0
:Entity_EDL_0000013	link	6252001
:Entity_EDL_0000014	type	GeopoliticalEntity
:Entity_EDL_0000014	canonical_mention	"Saudi Arabia"	yemen_voa__1000-01-01__timeline:2198-2209	1.0
:Entity_EDL_0000014	mention	"Saudi Arabia"	yemen_voa__1000-01-01__timeline:2198-2209	1.0
:Entity_EDL_0000014	canonical_mention	"Saudi Arabia"	yemen_afp__1000-01-01__timeline:3602-3613	1.0
:Entity_EDL_0000014	mention	"Saudi Arabia"	yemen_afp__1000-01-01__timeline:3602-3613	1.0
:Entity_EDL_0000014	link	102358
:Entity_EDL_0000015	type	Person
:Entity_EDL_0000015	nominal_mention	"five"	yemen_dailystar__1000-01-01__timeline:404-407	1.0
:Entity_EDL_0000015	link	NIL000000007
:Entity_EDL_0000016	type	Person
:Entity_EDL_0000016	canonical_mention	"Protesters"	yemen_latimes__1000-01-01__timeline:309-318	1.0
:Entity_EDL_0000016	nominal_mention	"Protesters"	yemen_latimes__1000-01-01__timeline:309-318	1.0
:Entity_EDL_0000016	link	NIL000000008
:Entity_EDL_0000017	type	Person
:Entity_EDL_0000017	canonical_mention	"tribesmen"	yemen_telegraphs__1000-01-01__timeline:4757-4765	1.0
:Entity_EDL_0000017	nominal_mention	"tribesmen"	yemen_telegraphs__1000-01-01__timeline:4757-4765	1.0
:Entity_EDL_0000017	link	NIL000000009
:Entity_EDL_0000018	type	Person
:Entity_EDL_0000018	nominal_mention	"protesters"	yemen_latimes__1000-01-01__timeline:4628-4637	1.0
:Entity_EDL_0000018	link	NIL000000010
:Entity_EDL_0000019	type	GeopoliticalEntity
:Entity_EDL_0000019	canonical_mention	"cities"	yemen_telegraphs__1000-01-01__timeline:6499-6504	1.0
:Entity_EDL_0000019	nominal_mention	"cities"	yemen_telegraphs__1000-01-01__timeline:6499-6504	1.0
:Entity_EDL_0000019	link	NIL000000011
:Entity_EDL_0000020	type	Person
:Entity_EDL_0000020	canonical_mention	"crowd"	yemen_telegraphs__1000-01-01__timeline:8320-8324	1.0
:Entity_EDL_0000020	nominal_mention	"crowd"	yemen_telegraphs__1000-01-01__timeline:8320-8324	1.0
:Entity_EDL_0000020	link	NIL000000012
:Entity_EDL_0000021	type	Weapon
:Entity_EDL_0000021	canonical_mention	"rocket"	yemen_latimes__1000-01-01__timeline:3131-3136	1.0
:Entity_EDL_0000021	nominal_mention	"rocket"	yemen_latimes__1000-01-01__timeline:3131-3136	1.0
:Entity_EDL_0000021	link	NIL000000013
:Entity_EDL_0000022	type	Facility
:Entity_EDL_0000022	canonical_mention	"compound"	yemen_washingtonpost__1000-01-01__timeline:1579-1586	1.0
:Entity_EDL_0000022	nominal_mention	"compound"	yemen_washingtonpost__1000-01-01__timeline:1579-1586	1.0
:Entity_EDL_0000022	link	NIL000000014
:Entity_EDL_0000023	type	Person
:Entity_EDL_0000023	nominal_mention	"people"	yemen_telegraphs__1000-01-01__timeline:4973-4978	1.0
:Entity_EDL_0000023	link	NIL000000015
:Entity_EDL_0000024	type	Person
:Entity_EDL_0000024	nominal_mention	"demonstrator"	yemen_afp__1000-01-01__timeline:2753-2764	1.0
:Entity_EDL_0000024	link	NIL000000016
:Entity_EDL_0000025	type	Person
:Entity_EDL_0000025	nominal_mention	"president"	yemen_telegraphs__1000-01-01__timeline:5599-5607	0.000
:Entity_EDL_0000025	link	NIL000000017
:Entity_EDL_0000026	type	Person
:Entity_EDL_0000026	nominal_mention	"forces"	yemen_dailystar__1000-01-01__timeline:1681-1686	0.000
:Entity_EDL_0000026	link	NIL000000018
:Entity_EDL_0000027	type	Person
:Entity_EDL_0000027	canonical_mention	"100"	yemen_voa__1000-01-01__timeline:909-911	1.0
:Entity_EDL_0000027	pronominal_mention	"100"	yemen_voa__1000-01-01__timeline:909-911	1.0
:Entity_EDL_0000027	link	NIL000000019
:Entity_EDL_0000028	type	Person
:Entity_EDL_0000028	canonical_mention	"Hamid alAhmar"	yemen_telegraphs__1000-01-01__timeline:7185-7197	1.0
:Entity_EDL_0000028	mention	"Hamid alAhmar"	yemen_telegraphs__1000-01-01__timeline:7185-7197	1.0
:Entity_EDL_0000028	link	NIL000000020
:Entity_EDL_0000029	type	Person
:Entity_EDL_0000029	nominal_mention	"police"	yemen_afp__1000-01-01__timeline:4130-4135	1.0
:Entity_EDL_0000029	link	NIL000000021
:Entity_EDL_0000030	type	Facility
:Entity_EDL_0000030	canonical_mention	"compound"	yemen_dailystar__1000-01-01__timeline:1935-1942	1.0
:Entity_EDL_0000030	nominal_mention	"compound"	yemen_dailystar__1000-01-01__timeline:1935-1942	1.0
:Entity_EDL_0000030	link	NIL000000022
:Entity_EDL_0000031	type	Person
:Entity_EDL_0000031	nominal_mention	"tribes"	yemen_afp__1000-01-01__timeline:4171-4176	1.0
:Entity_EDL_0000031	link	NIL000000023
:Entity_EDL_0000032	type	Person
:Entity_EDL_0000032	nominal_mention	"forces"	yemen_telegraphs__1000-01-01__timeline:8245-8250	1.0
:Entity_EDL_0000032	link	NIL000000024
:Entity_EDL_0000033	type	Person
:Entity_EDL_0000033	canonical_mention	"Abd al-Rab Mansur Hadi"	yemen_dailystar__1000-01-01__timeline:2243-2264	1.0
:Entity_EDL_0000033	mention	"Abd al-Rab Mansur Hadi"	yemen_dailystar__1000-01-01__timeline:2243-2264	1.0
:Entity_EDL_0000033	link	NIL000000025
:Entity_EDL_0000034	type	Person
:Entity_EDL_0000034	canonical_mention	"others"	yemen_dailystar__1000-01-01__timeline:732-737	1.0
:Entity_EDL_0000034	pronominal_mention	"others"	yemen_dailystar__1000-01-01__timeline:732-737	1.0
:Entity_EDL_0000034	link	NIL000000026
:Entity_EDL_0000035	type	Person
:Entity_EDL_0000035	canonical_mention	"cabinet"	yemen_latimes__1000-01-01__timeline:1050-1056	1.0
:Entity_EDL_0000035	nominal_mention	"cabinet"	yemen_latimes__1000-01-01__timeline:1050-1056	1.0
:Entity_EDL_0000035	link	NIL000000027
:Entity_EDL_0000036	type	GeopoliticalEntity
:Entity_EDL_0000036	canonical_mention	"capital"	yemen_washingtonpost__1000-01-01__timeline:1394-1400	1.0
:Entity_EDL_0000036	nominal_mention	"capital"	yemen_washingtonpost__1000-01-01__timeline:1394-1400	1.0
:Entity_EDL_0000036	link	NIL000000028
:Entity_EDL_0000037	type	Person
:Entity_EDL_0000037	canonical_mention	"Mohammed alYadoumi"	yemen_telegraphs__1000-01-01__timeline:1720-1737	1.0
:Entity_EDL_0000037	mention	"Mohammed alYadoumi"	yemen_telegraphs__1000-01-01__timeline:1720-1737	1.0
:Entity_EDL_0000037	link	NIL000000029
:Entity_EDL_0000038	type	Vehicle
:Entity_EDL_0000038	canonical_mention	"helicopter"	yemen_telegraphs__1000-01-01__timeline:4025-4034	1.0
:Entity_EDL_0000038	nominal_mention	"helicopter"	yemen_telegraphs__1000-01-01__timeline:4025-4034	1.0
:Entity_EDL_0000038	link	NIL000000030
:Entity_EDL_0000039	type	Organization
:Entity_EDL_0000039	nominal_mention	"army"	yemen_telegraphs__1000-01-01__timeline:6599-6602	1.0
:Entity_EDL_0000039	link	NIL000000031
:Entity_EDL_0000040	type	Person
:Entity_EDL_0000040	canonical_mention	"fighters"	yemen_latimes__1000-01-01__timeline:2701-2708	1.0
:Entity_EDL_0000040	nominal_mention	"fighters"	yemen_latimes__1000-01-01__timeline:2701-2708	1.0
:Entity_EDL_0000040	link	NIL000000032
:Entity_EDL_0000041	type	Person
:Entity_EDL_0000041	nominal_mention	"president"	yemen_telegraphs__1000-01-01__timeline:7491-7499	1.0
:Entity_EDL_0000041	link	NIL000000033
:Entity_EDL_0000042	type	GeopoliticalEntity
:Entity_EDL_0000042	canonical_mention	"United States"	yemen_afp__1000-01-01__timeline:4940-4952	1.0
:Entity_EDL_0000042	mention	"United States"	yemen_afp__1000-01-01__timeline:4940-4952	1.0
:Entity_EDL_0000042	link	6252001
:Entity_EDL_0000043	type	Organization
:Entity_EDL_0000043	nominal_mention	"party"	yemen_washingtonpost__1000-01-01__timeline:116-120	1.0
:Entity_EDL_0000043	link	NIL000000034
:Entity_EDL_0000044	type	Person
:Entity_EDL_0000044	nominal_mention	"protesters"	yemen_afp__1000-01-01__timeline:2981-2990	0.000
:Entity_EDL_0000044	link	NIL000000035
:Entity_EDL_0000045	type	Person
:Entity_EDL_0000045	pronominal_mention	"him"	yemen_telegraphs__1000-01-01__timeline:7691-7693	1.0
:Entity_EDL_0000045	link	NIL000000036
:Entity_EDL_0000046	type	GeopoliticalEntity
:Entity_EDL_0000046	canonical_mention	"cities"	yemen_washingtonpost__1000-01-01__timeline:1415-1420	1.0
:Entity_EDL_0000046	nominal_mention	"cities"	yemen_washingtonpost__1000-01-01__timeline:1415-1420	1.0
:Entity_EDL_0000046	link	NIL000000037
:Entity_EDL_0000047	type	Person
:Entity_EDL_0000047	canonical_mention	"protesters"	yemen_dailystar__1000-01-01__timeline:42-51	1.0
:Entity_EDL_0000047	nominal_mention	"protesters"	yemen_dailystar__1000-01-01__timeline:42-51	1.0
:Entity_EDL_0000047	link	NIL000000038
:Entity_EDL_0000048	type	Person
:Entity_EDL_0000048	nominal_mention	"people"	yemen_telegraphs__1000-01-01__timeline:5368-5373	1.0
:Entity_EDL_0000048	link	NIL000000039
:Entity_EDL_0000049	type	Person
:Entity_EDL_0000049	canonical_mention	"civilians"	yemen_telegraphs__1000-01-01__timeline:6553-6561	1.0
:Entity_EDL_0000049	nominal_mention	"civilians"	yemen_telegraphs__1000-01-01__timeline:6553-6561	1.0
:Entity_EDL_0000049	link	NIL000000040
:Entity_EDL_0000050	type	Person
:Entity_EDL_0000050	canonical_mention	"he"	yemen_latimes__1000-01-01__timeline:3985-3986	1.0
:Entity_EDL_0000050	pronominal_mention	"he"	yemen_latimes__1000-01-01__timeline:3985-3986	1.0
:Entity_EDL_0000050	link	NIL000000041
:Entity_EDL_0000051	type	Person
:Entity_EDL_0000051	nominal_mention	"forces"	yemen_dailystar__1000-01-01__timeline:821-826	0.000
:Entity_EDL_0000051	link	NIL000000042
:Entity_EDL_0000052	type	Person
:Entity_EDL_0000052	pronominal_mention	"he"	yemen_washingtonpost__1000-01-01__timeline:1977-1978	1.0
:Entity_EDL_0000052	link	NIL000000043
:Entity_EDL_0000053	type	GeopoliticalEntity
:Entity_EDL_0000053	mention	"Yemen"	yemen_voa__1000-01-01__timeline:1085-1089	1.0
:Entity_EDL_0000053	link	69543
:Entity_EDL_0000054	type	Facility
:Entity_EDL_0000054	canonical_mention	"street"	yemen_telegraphs__1000-01-01__timeline:4335-4340	1.0
:Entity_EDL_0000054	nominal_mention	"street"	yemen_telegraphs__1000-01-01__timeline:4335-4340	1.0
:Entity_EDL_0000054	link	NIL000000044
:Entity_EDL_0000055	type	Person
:Entity_EDL_0000055	nominal_mention	"forces"	yemen_latimes__1000-01-01__timeline:358-363	0.000
:Entity_EDL_0000055	link	NIL000000045
:Entity_EDL_0000056	type	Person
:Entity_EDL_0000056	canonical_mention	"17"	yemen_afp__1000-01-01__timeline:5126-5127	1.0
:Entity_EDL_0000056	pronominal_mention	"17"	yemen_afp__1000-01-01__timeline:5126-5127	1.0
:Entity_EDL_0000056	link	NIL000000046
:Entity_EDL_0000057	type	Facility
:Entity_EDL_0000057	canonical_mention	"Sana'a University"	yemen_voa__1000-01-01__timeline:63-79	1.0
:Entity_EDL_0000057	mention	"Sana'a University"	yemen_voa__1000-01-01__timeline:63-79	1.0
:Entity_EDL_0000057	link	NIL000000047
:Entity_EDL_0000058	type	Person
:Entity_EDL_0000058	canonical_mention	"demonstrators"	yemen_washingtonpost__1000-01-01__timeline:1351-1363	1.0
:Entity_EDL_0000058	nominal_mention	"demonstrators"	yemen_washingtonpost__1000-01-01__timeline:1351-1363	1.0
:Entity_EDL_0000058	link	NIL000000048
:Entity_EDL_0000059	type	Person
:Entity_EDL_0000059	canonical_mention	"loyalists"	yemen_afp__1000-01-01__timeline:830-838	1.0
:Entity_EDL_0000059	nominal_mention	"loyalists"	yemen_afp__1000-01-01__timeline:830-838	1.0
:Entity_EDL_0000059	link	NIL000000049
:Entity_EDL_0000060	type	Person
:Entity_EDL_0000060	nominal_mention	"supporters"	yemen_telegraphs__1000-01-01__timeline:122-131	1.0
:Entity_EDL_0000060	link	NIL000000050
:Entity_EDL_0000061	type	Person
:Entity_EDL_0000061	nominal_mention	"demonstrators"	yemen_latimes__1000-01-01__timeline:3743-3755	1.0
:Entity_EDL_0000061	link	NIL000000051
:Entity_EDL_0000062	type	Person
:Entity_EDL_0000062	nominal_mention	"speaker"	yemen_telegraphs__1000-01-01__timeline:5651-5657	1.0
:Entity_EDL_0000062	link	NIL000000052
:Entity_EDL_0000063	type	Organization
:Entity_EDL_0000063	nominal_mention	"station"	yemen_afp__1000-01-01__timeline:1846-1852	1.0
:Entity_EDL_0000063	link	NIL000000053
:Entity_EDL_0000064	type	Person
:Entity_EDL_0000064	nominal_mention	"Protesters"	yemen_latimes__1000-01-01__timeline:3518-3527	1.0
:Entity_EDL_0000064	link	NIL000000054
:Entity_EDL_0000065	type	Person
:Entity_EDL_0000065	canonical_mention	"ministers"	yemen_telegraphs__1000-01-01__timeline:2454-2462	1.0
:Entity_EDL_0000065	nominal_mention	"ministers"	yemen_telegraphs__1000-01-01__timeline:2454-2462	1.0
:Entity_EDL_0000065	link	NIL000000055
:Entity_EDL_0000066	type	Person
:Entity_EDL_0000066	canonical_mention	"Abd al-Rab Mansur Hadi"	yemen_voa__1000-01-01__timeline:2243-2264	1.0
:Entity_EDL_0000066	mention	"Abd al-Rab Mansur Hadi"	yemen_voa__1000-01-01__timeline:2243-2264	1.0
:Entity_EDL_0000066	link	NIL000000056
:Entity_EDL_0000067	type	Person
:Entity_EDL_0000067	nominal_mention	"forces"	yemen_voa__1000-01-01__timeline:1681-1686	0.000
:Entity_EDL_0000067	link	NIL000000057
:Entity_EDL_0000068	type	Person
:Entity_EDL_0000068	nominal_mention	"protesters"	yemen_dailystar__1000-01-01__timeline:643-652	1.0
:Entity_EDL_0000068	link	NIL000000058
:Entity_EDL_0000069	type	Organization
:Entity_EDL_0000069	canonical_mention	"U.N. Security Council"	yemen_voa__1000-01-01__timeline:1054-1074	1.0
:Entity_EDL_0000069	mention	"U.N. Security Council"	yemen_voa__1000-01-01__timeline:1054-1074	1.0
:Entity_EDL_0000069	link	20000223
:Entity_EDL_0000070	type	Person
:Entity_EDL_0000070	canonical_mention	"100"	yemen_dailystar__1000-01-01__timeline:909-911	1.0
:Entity_EDL_0000070	pronominal_mention	"100"	yemen_dailystar__1000-01-01__timeline:909-911	1.0
:Entity_EDL_0000070	link	NIL000000059
:Entity_EDL_0000071	type	Person
:Entity_EDL_0000071	canonical_mention	"separatists"	yemen_afp__1000-01-01__timeline:5348-5358	1.0
:Entity_EDL_0000071	nominal_mention	"separatists"	yemen_afp__1000-01-01__timeline:5348-5358	1.0
:Entity_EDL_0000071	link	NIL000000060
:Entity_EDL_0000072	type	Person
:Entity_EDL_0000072	canonical_mention	"155"	yemen_telegraphs__1000-01-01__timeline:5466-5468	1.0
:Entity_EDL_0000072	pronominal_mention	"155"	yemen_telegraphs__1000-01-01__timeline:5466-5468	1.0
:Entity_EDL_0000072	link	NIL000000061
:Entity_EDL_0000073	type	Person
:Entity_EDL_0000073	nominal_mention	"protesters"	yemen_latimes__1000-01-01__timeline:610-619	1.0
:Entity_EDL_0000073	link	NIL000000062
:Entity_EDL_0000074	type	Person
:Entity_EDL_0000074	nominal_mention	"forces"	yemen_latimes__1000-01-01__timeline:2230-2235	0.000
:Entity_EDL_0000074	link	NIL000000063
:Entity_EDL_0000075	type	Person
:Entity_EDL_0000075	nominal_mention	"legislators"	yemen_washingtonpost__1000-01-01__timeline:173-183	1.0
:Entity_EDL_0000075	link	NIL000000064
:Entity_EDL_0000076	type	Person
:Entity_EDL_0000076	nominal_mention	"mediators"	yemen_telegraphs__1000-01-01__timeline:3949-3957	1.0
:Entity_EDL_0000076	link	NIL000000065
:Entity_EDL_0000077	type	GeopoliticalEntity
:Entity_EDL_0000077	nominal_mention	"capital"	yemen_latimes__1000-01-01__timeline:487-493	1.0
:Entity_EDL_0000077	link	NIL000000066
:Entity_EDL_0000078	type	GeopoliticalEntity
:Entity_EDL_0000078	nominal_mention	"capital"	yemen_latimes__1000-01-01__timeline:3770-3776	1.0
:Entity_EDL_0000078	link	NIL000000067
:Entity_EDL_0000079	type	Person
:Entity_EDL_0000079	nominal_mention	"protesters"	yemen_latimes__1000-01-01__timeline:3807-3816	1.0
:Entity_EDL_0000079	link	NIL000000068
:Entity_EDL_0000080	type	Person
:Entity_EDL_0000080	nominal_mention	"loyalists"	yemen_afp__1000-01-01__timeline:365-373	1.0
:Entity_EDL_0000080	link	NIL000000069
:Entity_EDL_0000081	type	Person
:Entity_EDL_0000081	canonical_mention	"Thousands"	yemen_telegraphs__1000-01-01__timeline:1587-1595	1.0
:Entity_EDL_0000081	pronominal_mention	"Thousands"	yemen_telegraphs__1000-01-01__timeline:1587-1595	1.0
:Entity_EDL_0000081	link	NIL000000070
:Entity_EDL_0000082	type	Person
:Entity_EDL_0000082	nominal_mention	"protesters"	yemen_telegraphs__1000-01-01__timeline:3155-3164	1.0
:Entity_EDL_0000082	link	NIL000000071
:Entity_EDL_0000083	type	Person
:Entity_EDL_0000083	nominal_mention	"protesters"	yemen_afp__1000-01-01__timeline:4150-4159	1.0
:Entity_EDL_0000083	link	NIL000000072
:Entity_EDL_0000084	type	Organization
:Entity_EDL_0000084	canonical_mention	"party"	yemen_washingtonpost__1000-01-01__timeline:199-203	1.0
:Entity_EDL_0000084	nominal_mention	"party"	yemen_washingtonpost__1000-01-01__timeline:199-203	1.0
:Entity_EDL_0000084	link	NIL000000073
:Entity_EDL_0000085	type	Person
:Entity_EDL_0000085	canonical_mention	"students"	yemen_voa__1000-01-01__timeline:23-30	1.0
:Entity_EDL_0000085	nominal_mention	"students"	yemen_voa__1000-01-01__timeline:23-30	1.0
:Entity_EDL_0000085	link	NIL000000074
:Entity_EDL_0000086	type	Person
:Entity_EDL_0000086	canonical_mention	"John Brennan"	yemen_telegraphs__1000-01-01__timeline:6869-6880	1.0
:Entity_EDL_0000086	mention	"John Brennan"	yemen_telegraphs__1000-01-01__timeline:6869-6880	1.0
:Entity_EDL_0000086	link	NIL000000075
:Entity_EDL_0000087	type	Person
:Entity_EDL_0000087	nominal_mention	"opponents"	yemen_afp__1000-01-01__timeline:2498-2506	1.0
:Entity_EDL_0000087	link	NIL000000076
:Entity_EDL_0000088	type	Person
:Entity_EDL_0000088	canonical_mention	"115"	yemen_telegraphs__1000-01-01__timeline:4821-4823	1.0
:Entity_EDL_0000088	pronominal_mention	"115"	yemen_telegraphs__1000-01-01__timeline:4821-4823	1.0
:Entity_EDL_0000088	link	NIL000000077
:Entity_EDL_0000089	type	Person
:Entity_EDL_0000089	nominal_mention	"protesters"	yemen_latimes__1000-01-01__timeline:1902-1911	1.0
:Entity_EDL_0000089	link	NIL000000078
:Entity_EDL_0000090	type	Location
:Entity_EDL_0000090	nominal_mention	"Yemen"	yemen_afp__1000-01-01__timeline:1962-1966	1.0
:Entity_EDL_0000090	link	NIL000000079
:Entity_EDL_0000091	type	Person
:Entity_EDL_0000091	canonical_mention	"dozens"	yemen_afp__1000-01-01__timeline:3284-3289	1.0
:Entity_EDL_0000091	pronominal_mention	"dozens"	yemen_afp__1000-01-01__timeline:3284-3289	1.0
:Entity_EDL_0000091	link	NIL000000080
:Entity_EDL_0000092	type	Person
:Entity_EDL_0000092	canonical_mention	"police"	yemen_latimes__1000-01-01__timeline:1744-1749	1.0
:Entity_EDL_0000092	nominal_mention	"police"	yemen_latimes__1000-01-01__timeline:1744-1749	1.0
:Entity_EDL_0000092	link	NIL000000081
:Entity_EDL_0000093	type	Person
:Entity_EDL_0000093	canonical_mention	"forces"	yemen_telegraphs__1000-01-01__timeline:3140-3145	1.0
:Entity_EDL_0000093	nominal_mention	"forces"	yemen_telegraphs__1000-01-01__timeline:3140-3145	1.0
:Entity_EDL_0000093	link	NIL000000082
:Entity_EDL_0000094	type	Facility
:Entity_EDL_0000094	canonical_mention	"premises"	yemen_afp__1000-01-01__timeline:1811-1818	1.0
:Entity_EDL_0000094	nominal_mention	"premises"	yemen_afp__1000-01-01__timeline:1811-1818	1.0
:Entity_EDL_0000094	link	NIL000000083
:Entity_EDL_0000095	type	Organization
:Entity_EDL_0000095	canonical_mention	"Republican Guard"	yemen_afp__1000-01-01__timeline:2004-2019	1.0
:Entity_EDL_0000095	mention	"Republican Guard"	yemen_afp__1000-01-01__timeline:2004-2019	1.0
:Entity_EDL_0000095	link	NIL000000084
:Entity_EDL_0000096	type	Person
:Entity_EDL_0000096	nominal_mention	"people"	yemen_telegraphs__1000-01-01__timeline:8269-8274	1.0
:Entity_EDL_0000096	link	NIL000000085
:Entity_EDL_0000097	type	Person
:Entity_EDL_0000097	nominal_mention	"forces"	yemen_afp__1000-01-01__timeline:3265-3270	0.000
:Entity_EDL_0000097	link	NIL000000086
:Entity_EDL_0000098	type	Person
:Entity_EDL_0000098	pronominal_mention	"him"	yemen_latimes__1000-01-01__timeline:4583-4585	1.0
:Entity_EDL_0000098	link	NIL000000087
:Entity_EDL_0000099	type	Facility
:Entity_EDL_0000099	canonical_mention	"palace"	yemen_telegraphs__1000-01-01__timeline:3990-3995	1.0
:Entity_EDL_0000099	nominal_mention	"palace"	yemen_telegraphs__1000-01-01__timeline:3990-3995	1.0
:Entity_EDL_0000099	link	NIL000000088
:Entity_EDL_0000100	type	Person
:Entity_EDL_0000100	canonical_mention	"them"	yemen_latimes__1000-01-01__timeline:836-839	1.0
:Entity_EDL_0000100	pronominal_mention	"them"	yemen_latimes__1000-01-01__timeline:836-839	1.0
:Entity_EDL_0000100	link	NIL000000089
:Entity_EDL_0000101	type	Facility
:Entity_EDL_0000101	canonical_mention	"Sanaa University"	yemen_afp__1000-01-01__timeline:592-607	1.0
:Entity_EDL_0000101	mention	"Sanaa University"	yemen_afp__1000-01-01__timeline:592-607	1.0
:Entity_EDL_0000101	link	NIL000000090
:Entity_EDL_0000102	type	Person
:Entity_EDL_0000102	canonical_mention	"29"	yemen_afp__1000-01-01__timeline:4117-4118	1.0
:Entity_EDL_0000102	pronominal_mention	"29"	yemen_afp__1000-01-01__timeline:4117-4118	1.0
:Entity_EDL_0000102	link	NIL000000091
:Entity_EDL_0000103	type	Person
:Entity_EDL_0000103	canonical_mention	"figures"	yemen_telegraphs__1000-01-01__timeline:7296-7302	1.0
:Entity_EDL_0000103	nominal_mention	"figures"	yemen_telegraphs__1000-01-01__timeline:7296-7302	1.0
:Entity_EDL_0000103	link	NIL000000092
:Entity_EDL_0000104	type	Person
:Entity_EDL_0000104	canonical_mention	"fighters"	yemen_telegraphs__1000-01-01__timeline:5262-5269	1.0
:Entity_EDL_0000104	nominal_mention	"fighters"	yemen_telegraphs__1000-01-01__timeline:5262-5269	1.0
:Entity_EDL_0000104	link	NIL000000093
:Entity_EDL_0000105	type	Person
:Entity_EDL_0000105	canonical_mention	"him"	yemen_afp__1000-01-01__timeline:4478-4480	1.0
:Entity_EDL_0000105	pronominal_mention	"him"	yemen_afp__1000-01-01__timeline:4478-4480	1.0
:Entity_EDL_0000105	link	NIL000000094
:Entity_EDL_0000106	type	GeopoliticalEntity
:Entity_EDL_0000106	mention	"Riyadh"	yemen_telegraphs__1000-01-01__timeline:6897-6902	1.0
:Entity_EDL_0000106	link	108410
:Entity_EDL_0000107	type	Person
:Entity_EDL_0000107	canonical_mention	"15"	yemen_telegraphs__1000-01-01__timeline:5176-5177	1.0
:Entity_EDL_0000107	pronominal_mention	"15"	yemen_telegraphs__1000-01-01__timeline:5176-5177	1.0
:Entity_EDL_0000107	link	NIL000000095
:Entity_EDL_0000108	type	GeopoliticalEntity
:Entity_EDL_0000108	nominal_mention	"city"	yemen_telegraphs__1000-01-01__timeline:5144-5147	1.0
:Entity_EDL_0000108	link	NIL000000096
:Entity_EDL_0000109	type	GeopoliticalEntity
:Entity_EDL_0000109	nominal_mention	"country"	yemen_dailystar__1000-01-01__timeline:2427-2433	1.0
:Entity_EDL_0000109	link	NIL000000097
:Entity_EDL_0000110	type	Person
:Entity_EDL_0000110	canonical_mention	"authorities"	yemen_washingtonpost__1000-01-01__timeline:872-882	1.0
:Entity_EDL_0000110	nominal_mention	"authorities"	yemen_washingtonpost__1000-01-01__timeline:872-882	1.0
:Entity_EDL_0000110	link	NIL000000098
:Entity_EDL_0000111	type	Person
:Entity_EDL_0000111	canonical_mention	"Eleven"	yemen_afp__1000-01-01__timeline:3554-3559	1.0
:Entity_EDL_0000111	pronominal_mention	"Eleven"	yemen_afp__1000-01-01__timeline:3554-3559	1.0
:Entity_EDL_0000111	link	NIL000000099
:Entity_EDL_0000112	type	Organization
:Entity_EDL_0000112	canonical_mention	"National Council"	yemen_telegraphs__1000-01-01__timeline:7322-7337	1.0
:Entity_EDL_0000112	mention	"National Council"	yemen_telegraphs__1000-01-01__timeline:7322-7337	1.0
:Entity_EDL_0000112	link	NIL000000100
:Entity_EDL_0000113	type	Person
:Entity_EDL_0000113	pronominal_mention	"Thousands"	yemen_afp__1000-01-01__timeline:2375-2383	1.0
:Entity_EDL_0000113	link	NIL000000101
:Entity_EDL_0000114	type	Organization
:Entity_EDL_0000114	nominal_mention	"group"	yemen_telegraphs__1000-01-01__timeline:4409-4413	1.0
:Entity_EDL_0000114	link	NIL000000102
:Entity_EDL_0000115	type	Vehicle
:Entity_EDL_0000115	canonical_mention	"warplanes"	yemen_telegraphs__1000-01-01__timeline:6471-6479	1.0
:Entity_EDL_0000115	nominal_mention	"warplanes"	yemen_telegraphs__1000-01-01__timeline:6471-6479	1.0
:Entity_EDL_0000115	link	NIL000000103
:Entity_EDL_0000116	type	Person
:Entity_EDL_0000116	nominal_mention	"protesters"	yemen_dailystar__1000-01-01__timeline:836-845	1.0
:Entity_EDL_0000116	link	NIL000000104
:Entity_EDL_0000117	type	Person
:Entity_EDL_0000117	canonical_mention	"he"	yemen_washingtonpost__1000-01-01__timeline:496-497	1.0
:Entity_EDL_0000117	pronominal_mention	"he"	yemen_washingtonpost__1000-01-01__timeline:496-497	1.0
:Entity_EDL_0000117	link	NIL000000105
:Entity_EDL_0000118	type	Weapon
:Entity_EDL_0000118	canonical_mention	"weapons"	yemen_latimes__1000-01-01__timeline:855-861	1.0
:Entity_EDL_0000118	nominal_mention	"weapons"	yemen_latimes__1000-01-01__timeline:855-861	1.0
:Entity_EDL_0000118	link	NIL000000106
:Entity_EDL_0000119	type	Person
:Entity_EDL_0000119	nominal_mention	"forces"	yemen_telegraphs__1000-01-01__timeline:5420-5425	1.0
:Entity_EDL_0000119	link	NIL000000107
:Entity_EDL_0000120	type	Person
:Entity_EDL_0000120	nominal_mention	"demonstrators"	yemen_voa__1000-01-01__timeline:161-173	1.0
:Entity_EDL_0000120	link	NIL000000108
:Entity_EDL_0000121	type	Person
:Entity_EDL_0000121	canonical_mention	"protesters"	yemen_washingtonpost__1000-01-01__timeline:473-482	1.0
:Entity_EDL_0000121	nominal_mention	"protesters"	yemen_washingtonpost__1000-01-01__timeline:473-482	1.0
:Entity_EDL_0000121	link	NIL000000109
:Entity_EDL_0000122	type	Person
:Entity_EDL_0000122	canonical_mention	"dozens"	yemen_washingtonpost__1000-01-01__timeline:856-861	1.0
:Entity_EDL_0000122	pronominal_mention	"dozens"	yemen_washingtonpost__1000-01-01__timeline:856-861	1.0
:Entity_EDL_0000122	link	NIL000000110
:Entity_EDL_0000123	type	Person
:Entity_EDL_0000123	nominal_mention	"Forces"	yemen_telegraphs__1000-01-01__timeline:5226-5231	1.0
:Entity_EDL_0000123	link	NIL000000111
:Entity_EDL_0000124	type	Person
:Entity_EDL_0000124	nominal_mention	"minister"	yemen_telegraphs__1000-01-01__timeline:5621-5628	1.0
:Entity_EDL_0000124	link	NIL000000112
:Entity_EDL_0000125	type	Person
:Entity_EDL_0000125	nominal_mention	"protesters"	yemen_latimes__1000-01-01__timeline:2257-2266	1.0
:Entity_EDL_0000125	link	NIL000000113
:Entity_EDL_0000126	type	Person
:Entity_EDL_0000126	nominal_mention	"people"	yemen_telegraphs__1000-01-01__timeline:5504-5509	1.0
:Entity_EDL_0000126	link	NIL000000114
:Entity_EDL_0000127	type	Person
:Entity_EDL_0000127	nominal_mention	"leader"	yemen_afp__1000-01-01__timeline:5199-5204	1.0
:Entity_EDL_0000127	link	NIL000000115
:Entity_EDL_0000128	type	Person
:Entity_EDL_0000128	nominal_mention	"opponents"	yemen_telegraphs__1000-01-01__timeline:4111-4119	1.0
:Entity_EDL_0000128	link	NIL000000116
:Entity_EDL_0000129	type	Person
:Entity_EDL_0000129	nominal_mention	"protesters"	yemen_latimes__1000-01-01__timeline:1767-1776	0.000
:Entity_EDL_0000129	link	NIL000000117
:Entity_EDL_0000130	type	Person
:Entity_EDL_0000130	canonical_mention	"Hadi"	yemen_washingtonpost__1000-01-01__timeline:2443-2446	1.0
:Entity_EDL_0000130	mention	"Hadi"	yemen_washingtonpost__1000-01-01__timeline:2443-2446	1.0
:Entity_EDL_0000130	link	NIL000000118
:Entity_EDL_0000131	type	Person
:Entity_EDL_0000131	canonical_mention	"100,000"	yemen_latimes__1000-01-01__timeline:458-464	1.0
:Entity_EDL_0000131	pronominal_mention	"100,000"	yemen_latimes__1000-01-01__timeline:458-464	1.0
:Entity_EDL_0000131	link	NIL000000119
:Entity_EDL_0000132	type	Person
:Entity_EDL_0000132	canonical_mention	"people"	yemen_voa__1000-01-01__timeline:879-884	1.0
:Entity_EDL_0000132	nominal_mention	"people"	yemen_voa__1000-01-01__timeline:879-884	1.0
:Entity_EDL_0000132	link	NIL000000120
:Entity_EDL_0000133	type	Person
:Entity_EDL_0000133	canonical_mention	"Ali Mohsen al-Ahmar"	yemen_afp__1000-01-01__timeline:2099-2117	1.0
:Entity_EDL_0000133	mention	"Ali Mohsen al-Ahmar"	yemen_afp__1000-01-01__timeline:2099-2117	1.0
:Entity_EDL_0000133	link	NIL000000121
:Entity_EDL_0000134	type	Person
:Entity_EDL_0000134	nominal_mention	"forces"	yemen_voa__1000-01-01__timeline:821-826	0.000
:Entity_EDL_0000134	link	NIL000000122
:Entity_EDL_0000135	type	Person
:Entity_EDL_0000135	canonical_mention	"demonstrators"	yemen_latimes__1000-01-01__timeline:991-1003	1.0
:Entity_EDL_0000135	nominal_mention	"demonstrators"	yemen_latimes__1000-01-01__timeline:991-1003	1.0
:Entity_EDL_0000135	link	NIL000000123
:Entity_EDL_0000136	type	Organization
:Entity_EDL_0000136	nominal_mention	"government"	yemen_latimes__1000-01-01__timeline:4694-4703	1.0
:Entity_EDL_0000136	link	NIL000000124
:Entity_EDL_0000137	type	Person
:Entity_EDL_0000137	nominal_mention	"diplomats"	yemen_telegraphs__1000-01-01__timeline:4603-4611	1.0
:Entity_EDL_0000137	link	NIL000000125
:Entity_EDL_0000138	type	Person
:Entity_EDL_0000138	canonical_mention	"brother"	yemen_afp__1000-01-01__timeline:5218-5224	1.0
:Entity_EDL_0000138	nominal_mention	"brother"	yemen_afp__1000-01-01__timeline:5218-5224	1.0
:Entity_EDL_0000138	link	NIL000000126
:Entity_EDL_0000139	type	Location
:Entity_EDL_0000139	canonical_mention	"district"	yemen_latimes__1000-01-01__timeline:2784-2791	1.0
:Entity_EDL_0000139	nominal_mention	"district"	yemen_latimes__1000-01-01__timeline:2784-2791	1.0
:Entity_EDL_0000139	link	NIL000000127
:Entity_EDL_0000140	type	Organization
:Entity_EDL_0000140	canonical_mention	"Justice and Development Bloc"	yemen_telegraphs__1000-01-01__timeline:2471-2498	1.0
:Entity_EDL_0000140	mention	"Justice and Development Bloc"	yemen_telegraphs__1000-01-01__timeline:2471-2498	1.0
:Entity_EDL_0000140	link	NIL000000128
:Entity_EDL_0000141	type	Person
:Entity_EDL_0000141	canonical_mention	"Gunmen"	yemen_afp__1000-01-01__timeline:3129-3134	1.0
:Entity_EDL_0000141	nominal_mention	"Gunmen"	yemen_afp__1000-01-01__timeline:3129-3134	1.0
:Entity_EDL_0000141	link	NIL000000129
:Entity_EDL_0000142	type	Facility
:Entity_EDL_0000142	nominal_mention	"streets"	yemen_telegraphs__1000-01-01__timeline:464-470	0.000
:Entity_EDL_0000142	link	NIL000000130
:Entity_EDL_0000143	type	Person
:Entity_EDL_0000143	canonical_mention	"police"	yemen_dailystar__1000-01-01__timeline:623-628	1.0
:Entity_EDL_0000143	nominal_mention	"police"	yemen_dailystar__1000-01-01__timeline:623-628	1.0
:Entity_EDL_0000143	link	NIL000000131
:Entity_EDL_0000144	type	Person
:Entity_EDL_0000144	nominal_mention	"leaders"	yemen_latimes__1000-01-01__timeline:298-304	0.000
:Entity_EDL_0000144	link	NIL000000132
:Entity_EDL_0000145	type	Person
:Entity_EDL_0000145	nominal_mention	"protesters"	yemen_latimes__1000-01-01__timeline:1264-1273	1.0
:Entity_EDL_0000145	link	NIL000000133
:Entity_EDL_0000146	type	Person
:Entity_EDL_0000146	canonical_mention	"officials"	yemen_voa__1000-01-01__timeline:1874-1882	1.0
:Entity_EDL_0000146	nominal_mention	"officials"	yemen_voa__1000-01-01__timeline:1874-1882	1.0
:Entity_EDL_0000146	link	NIL000000134
:Entity_EDL_0000147	type	GeopoliticalEntity
:Entity_EDL_0000147	nominal_mention	"country"	yemen_voa__1000-01-01__timeline:2427-2433	1.0
:Entity_EDL_0000147	link	NIL000000135
:Entity_EDL_0000148	type	Person
:Entity_EDL_0000148	nominal_mention	"demonstrators"	yemen_telegraphs__1000-01-01__timeline:8142-8154	1.0
:Entity_EDL_0000148	link	NIL000000136
:Entity_EDL_0000149	type	Person
:Entity_EDL_0000149	nominal_mention	"loyalists"	yemen_afp__1000-01-01__timeline:1104-1112	1.0
:Entity_EDL_0000149	link	NIL000000137
:Entity_EDL_0000150	type	GeopoliticalEntity
:Entity_EDL_0000150	canonical_mention	"capital"	yemen_afp__1000-01-01__timeline:874-880	1.0
:Entity_EDL_0000150	nominal_mention	"capital"	yemen_afp__1000-01-01__timeline:874-880	1.0
:Entity_EDL_0000150	link	NIL000000138
:Entity_EDL_0000151	type	GeopoliticalEntity
:Entity_EDL_0000151	canonical_mention	"country"	yemen_latimes__1000-01-01__timeline:4157-4163	1.0
:Entity_EDL_0000151	nominal_mention	"country"	yemen_latimes__1000-01-01__timeline:4157-4163	1.0
:Entity_EDL_0000151	link	NIL000000139
:Entity_EDL_0000152	type	Person
:Entity_EDL_0000152	canonical_mention	"members"	yemen_telegraphs__1000-01-01__timeline:2421-2427	1.0
:Entity_EDL_0000152	nominal_mention	"members"	yemen_telegraphs__1000-01-01__timeline:2421-2427	1.0
:Entity_EDL_0000152	link	NIL000000140
:Entity_EDL_0000153	type	Facility
:Entity_EDL_0000153	canonical_mention	"port"	yemen_afp__1000-01-01__timeline:2432-2435	1.0
:Entity_EDL_0000153	nominal_mention	"port"	yemen_afp__1000-01-01__timeline:2432-2435	1.0
:Entity_EDL_0000153	link	NIL000000141
:Entity_EDL_0000154	type	Weapon
:Entity_EDL_0000154	canonical_mention	"rocket"	yemen_voa__1000-01-01__timeline:1901-1906	1.0
:Entity_EDL_0000154	nominal_mention	"rocket"	yemen_voa__1000-01-01__timeline:1901-1906	1.0
:Entity_EDL_0000154	link	NIL000000142
:Entity_EDL_0000155	type	Facility
:Entity_EDL_0000155	canonical_mention	"Sana'a University"	yemen_dailystar__1000-01-01__timeline:63-79	1.0
:Entity_EDL_0000155	mention	"Sana'a University"	yemen_dailystar__1000-01-01__timeline:63-79	1.0
:Entity_EDL_0000155	link	NIL000000143
:Entity_EDL_0000156	type	GeopoliticalEntity
:Entity_EDL_0000156	canonical_mention	"Tunisia"	yemen_dailystar__1000-01-01__timeline:242-248	1.0
:Entity_EDL_0000156	mention	"Tunisia"	yemen_dailystar__1000-01-01__timeline:242-248	1.0
:Entity_EDL_0000156	link	2464461
:Entity_EDL_0000157	type	Person
:Entity_EDL_0000157	canonical_mention	"President"	yemen_voa__1000-01-01__timeline:253-261	1.0
:Entity_EDL_0000157	nominal_mention	"President"	yemen_voa__1000-01-01__timeline:253-261	1.0
:Entity_EDL_0000157	link	NIL000000144
:Entity_EDL_0000158	type	Person
:Entity_EDL_0000158	nominal_mention	"five"	yemen_voa__1000-01-01__timeline:404-407	1.0
:Entity_EDL_0000158	link	NIL000000145
:Entity_EDL_0000159	type	Person
:Entity_EDL_0000159	canonical_mention	"troops"	yemen_afp__1000-01-01__timeline:1989-1994	1.0
:Entity_EDL_0000159	nominal_mention	"troops"	yemen_afp__1000-01-01__timeline:1989-1994	1.0
:Entity_EDL_0000159	link	NIL000000146
:Entity_EDL_0000160	type	Location
:Entity_EDL_0000160	nominal_mention	"Yemen"	yemen_afp__1000-01-01__timeline:5334-5338	1.0
:Entity_EDL_0000160	link	NIL000000147
:Entity_EDL_0000161	type	Person
:Entity_EDL_0000161	canonical_mention	"students"	yemen_dailystar__1000-01-01__timeline:23-30	1.0
:Entity_EDL_0000161	nominal_mention	"students"	yemen_dailystar__1000-01-01__timeline:23-30	1.0
:Entity_EDL_0000161	link	NIL000000148
:Entity_EDL_0000162	type	Person
:Entity_EDL_0000162	nominal_mention	"people"	yemen_telegraphs__1000-01-01__timeline:448-453	1.0
:Entity_EDL_0000162	link	NIL000000149
:Entity_EDL_0000163	type	Person
:Entity_EDL_0000163	canonical_mention	"Ali Abdullah Saleh"	yemen_afp__1000-01-01__timeline:102-119	1.0
:Entity_EDL_0000163	mention	"Ali Abdullah Saleh"	yemen_afp__1000-01-01__timeline:102-119	1.0
:Entity_EDL_0000163	link	NIL000000150
:Entity_EDL_0000164	type	Person
:Entity_EDL_0000164	nominal_mention	"forces"	yemen_telegraphs__1000-01-01__timeline:8127-8132	0.000
:Entity_EDL_0000164	link	NIL000000151
:Entity_EDL_0000165	type	Person
:Entity_EDL_0000165	canonical_mention	"Abdullatif alZayani"	yemen_telegraphs__1000-01-01__timeline:3465-3483	1.0
:Entity_EDL_0000165	mention	"Abdullatif alZayani"	yemen_telegraphs__1000-01-01__timeline:3465-3483	1.0
:Entity_EDL_0000165	link	NIL000000152
:Entity_EDL_0000166	type	Person
:Entity_EDL_0000166	canonical_mention	"person"	yemen_voa__1000-01-01__timeline:709-714	1.0
:Entity_EDL_0000166	nominal_mention	"person"	yemen_voa__1000-01-01__timeline:709-714	1.0
:Entity_EDL_0000166	link	NIL000000153
:Entity_EDL_0000167	type	Person
:Entity_EDL_0000167	nominal_mention	"Diplomats"	yemen_telegraphs__1000-01-01__timeline:4000-4008	1.0
:Entity_EDL_0000167	link	NIL000000154
:Entity_EDL_0000168	type	Person
:Entity_EDL_0000168	canonical_mention	"people"	yemen_dailystar__1000-01-01__timeline:879-884	1.0
:Entity_EDL_0000168	nominal_mention	"people"	yemen_dailystar__1000-01-01__timeline:879-884	1.0
:Entity_EDL_0000168	link	NIL000000155
:Entity_EDL_0000169	type	Person
:Entity_EDL_0000169	canonical_mention	"Snipers"	yemen_telegraphs__1000-01-01__timeline:825-831	1.0
:Entity_EDL_0000169	nominal_mention	"Snipers"	yemen_telegraphs__1000-01-01__timeline:825-831	1.0
:Entity_EDL_0000169	link	NIL000000156
:Entity_EDL_0000170	type	Person
:Entity_EDL_0000170	canonical_mention	"replacement"	yemen_latimes__1000-01-01__timeline:4978-4988	1.0
:Entity_EDL_0000170	nominal_mention	"replacement"	yemen_latimes__1000-01-01__timeline:4978-4988	1.0
:Entity_EDL_0000170	link	NIL000000157
:Entity_EDL_0000171	type	Person
:Entity_EDL_0000171	canonical_mention	"officials"	yemen_dailystar__1000-01-01__timeline:1874-1882	1.0
:Entity_EDL_0000171	nominal_mention	"officials"	yemen_dailystar__1000-01-01__timeline:1874-1882	1.0
:Entity_EDL_0000171	link	NIL000000158
:Entity_EDL_0000172	type	Person
:Entity_EDL_0000172	nominal_mention	"forces"	yemen_telegraphs__1000-01-01__timeline:5097-5102	1.0
:Entity_EDL_0000172	link	NIL000000159
:Entity_EDL_0000173	type	Person
:Entity_EDL_0000173	nominal_mention	"forces"	yemen_afp__1000-01-01__timeline:2952-2957	0.000
:Entity_EDL_0000173	link	NIL000000160
:Entity_EDL_0000174	type	Person
:Entity_EDL_0000174	nominal_mention	"people"	yemen_telegraphs__1000-01-01__timeline:4482-4487	1.0
:Entity_EDL_0000174	link	NIL000000161
:Entity_EDL_0000175	type	Person
:Entity_EDL_0000175	nominal_mention	"protesters"	yemen_telegraphs__1000-01-01__timeline:5117-5126	1.0
:Entity_EDL_0000175	link	NIL000000162
:Entity_EDL_0000176	type	Person
:Entity_EDL_0000176	canonical_mention	"leaders"	yemen_telegraphs__1000-01-01__timeline:4628-4634	1.0
:Entity_EDL_0000176	nominal_mention	"leaders"	yemen_telegraphs__1000-01-01__timeline:4628-4634	1.0
:Entity_EDL_0000176	link	NIL000000163
:Entity_EDL_0000177	type	Person
:Entity_EDL_0000177	nominal_mention	"protesters"	yemen_voa__1000-01-01__timeline:643-652	1.0
:Entity_EDL_0000177	link	NIL000000164
:Entity_EDL_0000178	type	Person
:Entity_EDL_0000178	canonical_mention	"21"	yemen_telegraphs__1000-01-01__timeline:8166-8167	1.0
:Entity_EDL_0000178	pronominal_mention	"21"	yemen_telegraphs__1000-01-01__timeline:8166-8167	1.0
:Entity_EDL_0000178	link	NIL000000165
:Entity_EDL_0000179	type	Organization
:Entity_EDL_0000179	canonical_mention	"U.N. Security Council"	yemen_dailystar__1000-01-01__timeline:1054-1074	1.0
:Entity_EDL_0000179	mention	"U.N. Security Council"	yemen_dailystar__1000-01-01__timeline:1054-1074	1.0
:Entity_EDL_0000179	link	20000223
:Entity_EDL_0000180	type	Person
:Entity_EDL_0000180	nominal_mention	"protesters"	yemen_voa__1000-01-01__timeline:836-845	1.0
:Entity_EDL_0000180	link	NIL000000166
:Entity_EDL_0000181	type	Person
:Entity_EDL_0000181	nominal_mention	"protesters"	yemen_afp__1000-01-01__timeline:2399-2408	1.0
:Entity_EDL_0000181	link	NIL000000167
:Entity_EDL_0000182	type	Person
:Entity_EDL_0000182	canonical_mention	"supports"	yemen_afp__1000-01-01__timeline:2512-2519	1.0
:Entity_EDL_0000182	nominal_mention	"supports"	yemen_afp__1000-01-01__timeline:2512-2519	1.0
:Entity_EDL_0000182	link	NIL000000168
:Entity_EDL_0000183	type	Person
:Entity_EDL_0000183	canonical_mention	"militants"	yemen_telegraphs__1000-01-01__timeline:6608-6616	1.0
:Entity_EDL_0000183	nominal_mention	"militants"	yemen_telegraphs__1000-01-01__timeline:6608-6616	1.0
:Entity_EDL_0000183	link	NIL000000169
:Entity_EDL_0000184	type	Person
:Entity_EDL_0000184	canonical_mention	"Suspects"	yemen_telegraphs__1000-01-01__timeline:6221-6228	1.0
:Entity_EDL_0000184	nominal_mention	"Suspects"	yemen_telegraphs__1000-01-01__timeline:6221-6228	1.0
:Entity_EDL_0000184	link	NIL000000170
:Entity_EDL_0000185	type	Person
:Entity_EDL_0000185	canonical_mention	"others"	yemen_voa__1000-01-01__timeline:732-737	1.0
:Entity_EDL_0000185	pronominal_mention	"others"	yemen_voa__1000-01-01__timeline:732-737	1.0
:Entity_EDL_0000185	link	NIL000000171
:Entity_EDL_0000186	type	GeopoliticalEntity
:Entity_EDL_0000186	canonical_mention	"France"	yemen_telegraphs__1000-01-01__timeline:4651-4656	1.0
:Entity_EDL_0000186	mention	"France"	yemen_telegraphs__1000-01-01__timeline:4651-4656	1.0
:Entity_EDL_0000186	link	3017382
:Entity_EDL_0000187	type	Person
:Entity_EDL_0000187	nominal_mention	"snipers"	yemen_telegraphs__1000-01-01__timeline:8291-8297	1.0
:Entity_EDL_0000187	link	NIL000000172
:Entity_EDL_0000188	type	Person
:Entity_EDL_0000188	nominal_mention	"demonstrators"	yemen_dailystar__1000-01-01__timeline:161-173	1.0
:Entity_EDL_0000188	link	NIL000000173
:Entity_EDL_0000189	type	Person
:Entity_EDL_0000189	canonical_mention	"person"	yemen_dailystar__1000-01-01__timeline:709-714	1.0
:Entity_EDL_0000189	nominal_mention	"person"	yemen_dailystar__1000-01-01__timeline:709-714	1.0
:Entity_EDL_0000189	link	NIL000000174
:Entity_EDL_0000190	type	Person
:Entity_EDL_0000190	pronominal_mention	"52"	yemen_afp__1000-01-01__timeline:892-893	1.0
:Entity_EDL_0000190	link	NIL000000175
:Entity_EDL_0000191	type	Person
:Entity_EDL_0000191	canonical_mention	"demonstrators"	yemen_afp__1000-01-01__timeline:853-865	1.0
:Entity_EDL_0000191	nominal_mention	"demonstrators"	yemen_afp__1000-01-01__timeline:853-865	1.0
:Entity_EDL_0000191	link	NIL000000176
:Entity_EDL_0000192	type	Person
:Entity_EDL_0000192	pronominal_mention	"he"	yemen_afp__1000-01-01__timeline:1754-1755	1.0
:Entity_EDL_0000192	link	NIL000000177
:Entity_EDL_0000193	type	Person
:Entity_EDL_0000193	canonical_mention	"family"	yemen_afp__1000-01-01__timeline:4490-4495	1.0
:Entity_EDL_0000193	nominal_mention	"family"	yemen_afp__1000-01-01__timeline:4490-4495	1.0
:Entity_EDL_0000193	link	NIL000000178
:Entity_EDL_0000194	type	Person
:Entity_EDL_0000194	canonical_mention	"protesters"	yemen_voa__1000-01-01__timeline:42-51	1.0
:Entity_EDL_0000194	nominal_mention	"protesters"	yemen_voa__1000-01-01__timeline:42-51	1.0
:Entity_EDL_0000194	link	NIL000000179
:Entity_EDL_0000195	type	Facility
:Entity_EDL_0000195	nominal_mention	"palace"	yemen_telegraphs__1000-01-01__timeline:5568-5573	1.0
:Entity_EDL_0000195	link	NIL000000180
:Entity_EDL_0000196	type	Person
:Entity_EDL_0000196	nominal_mention	"forces"	yemen_telegraphs__1000-01-01__timeline:4380-4385	0.000
:Entity_EDL_0000196	link	NIL000000181
:Entity_EDL_0000197	type	Person
:Entity_EDL_0000197	canonical_mention	"legislators"	yemen_washingtonpost__1000-01-01__timeline:17-27	1.0
:Entity_EDL_0000197	nominal_mention	"legislators"	yemen_washingtonpost__1000-01-01__timeline:17-27	1.0
:Entity_EDL_0000197	link	NIL000000182
:Entity_EDL_0000198	type	Person
:Entity_EDL_0000198	canonical_mention	"dozens"	yemen_telegraphs__1000-01-01__timeline:8182-8187	1.0
:Entity_EDL_0000198	pronominal_mention	"dozens"	yemen_telegraphs__1000-01-01__timeline:8182-8187	1.0
:Entity_EDL_0000198	link	NIL000000183
:Entity_EDL_0000199	type	Person
:Entity_EDL_0000199	nominal_mention	"protesters"	yemen_washingtonpost__1000-01-01__timeline:834-843	1.0
:Entity_EDL_0000199	link	NIL000000184
:Entity_EDL_0000200	type	Person
:Entity_EDL_0000200	canonical_mention	"his"	yemen_washingtonpost__1000-01-01__timeline:1084-1086	1.0
:Entity_EDL_0000200	pronominal_mention	"his"	yemen_washingtonpost__1000-01-01__timeline:1084-1086	1.0
:Entity_EDL_0000200	link	NIL000000185
:Entity_EDL_0000201	type	Person
:Entity_EDL_0000201	nominal_mention	"forces"	yemen_latimes__1000-01-01__timeline:2689-2694	0.000
:Entity_EDL_0000201	link	NIL000000186
:Entity_EDL_0000202	type	Facility
:Entity_EDL_0000202	canonical_mention	"hospital"	yemen_telegraphs__1000-01-01__timeline:5699-5706	1.0
:Entity_EDL_0000202	nominal_mention	"hospital"	yemen_telegraphs__1000-01-01__timeline:5699-5706	1.0
:Entity_EDL_0000202	link	NIL000000187
:Entity_EDL_0000203	type	Person
:Entity_EDL_0000203	canonical_mention	"ministers"	yemen_latimes__1000-01-01__timeline:918-926	1.0
:Entity_EDL_0000203	nominal_mention	"ministers"	yemen_latimes__1000-01-01__timeline:918-926	1.0
:Entity_EDL_0000203	link	NIL000000188
:Entity_EDL_0000204	type	Facility
:Entity_EDL_0000204	nominal_mention	"Street"	yemen_telegraphs__1000-01-01__timeline:5430-5435	1.0
:Entity_EDL_0000204	link	NIL000000189
:Entity_EDL_0000205	type	Person
:Entity_EDL_0000205	canonical_mention	"people"	yemen_afp__1000-01-01__timeline:1078-1083	1.0
:Entity_EDL_0000205	nominal_mention	"people"	yemen_afp__1000-01-01__timeline:1078-1083	1.0
:Entity_EDL_0000205	link	NIL000000190
:Entity_EDL_0000206	type	Person
:Entity_EDL_0000206	canonical_mention	"President"	yemen_dailystar__1000-01-01__timeline:253-261	1.0
:Entity_EDL_0000206	nominal_mention	"President"	yemen_dailystar__1000-01-01__timeline:253-261	1.0
:Entity_EDL_0000206	link	NIL000000191
:Entity_EDL_0000207	type	Person
:Entity_EDL_0000207	nominal_mention	"forces"	yemen_latimes__1000-01-01__timeline:3702-3707	1.0
:Entity_EDL_0000207	link	NIL000000192
:Entity_EDL_0000208	type	Person
:Entity_EDL_0000208	pronominal_mention	"he"	yemen_latimes__1000-01-01__timeline:4898-4899	1.0
:Entity_EDL_0000208	link	NIL000000193
:Entity_EDL_0000209	type	Person
:Entity_EDL_0000209	nominal_mention	"protesters"	yemen_telegraphs__1000-01-01__timeline:841-850	1.0
:Entity_EDL_0000209	link	NIL000000194
:Entity_EDL_0000210	type	GeopoliticalEntity
:Entity_EDL_0000210	canonical_mention	"Egypt"	yemen_afp__1000-01-01__timeline:46-50	1.0
:Entity_EDL_0000210	mention	"Egypt"	yemen_afp__1000-01-01__timeline:46-50	1.0
:Entity_EDL_0000210	link	357994
:Entity_EDL_0000211	type	Person
:Entity_EDL_0000211	nominal_mention	"people"	yemen_afp__1000-01-01__timeline:5296-5301	1.0
:Entity_EDL_0000211	link	NIL000000195
:Entity_EDL_0000212	type	Person
:Entity_EDL_0000212	canonical_mention	"many"	yemen_afp__1000-01-01__timeline:1063-1066	1.0
:Entity_EDL_0000212	pronominal_mention	"many"	yemen_afp__1000-01-01__timeline:1063-1066	1.0
:Entity_EDL_0000212	link	NIL000000196
:Entity_EDL_0000213	type	Person
:Entity_EDL_0000213	nominal_mention	"forces"	yemen_afp__1000-01-01__timeline:3352-3357	1.0
:Entity_EDL_0000213	link	NIL000000197
:Entity_EDL_0000214	type	Person
:Entity_EDL_0000214	nominal_mention	"forces"	yemen_telegraphs__1000-01-01__timeline:4092-4097	1.0
:Entity_EDL_0000214	link	NIL000000198
:Entity_EDL_0000215	type	Person
:Entity_EDL_0000215	nominal_mention	"people"	yemen_afp__1000-01-01__timeline:3438-3443	1.0
:Entity_EDL_0000215	link	NIL000000199
:Entity_EDL_0000216	type	GeopoliticalEntity
:Entity_EDL_0000216	canonical_mention	"Bayda province"	yemen_afp__1000-01-01__timeline:5229-5242	1.0
:Entity_EDL_0000216	mention	"Bayda province"	yemen_afp__1000-01-01__timeline:5229-5242	1.0
:Entity_EDL_0000216	link	NIL000000200
:Entity_EDL_0000217	type	Person
:Entity_EDL_0000217	nominal_mention	"protester"	yemen_afp__1000-01-01__timeline:2868-2876	1.0
:Entity_EDL_0000217	link	NIL000000201
:Entity_EDL_0000218	type	Weapon
:Entity_EDL_0000218	canonical_mention	"bomb"	yemen_telegraphs__1000-01-01__timeline:5542-5545	1.0
:Entity_EDL_0000218	nominal_mention	"bomb"	yemen_telegraphs__1000-01-01__timeline:5542-5545	1.0
:Entity_EDL_0000218	link	NIL000000202
:Entity_EDL_0000219	type	GeopoliticalEntity
:Entity_EDL_0000219	nominal_mention	"country"	yemen_latimes__1000-01-01__timeline:4415-4421	1.0
:Entity_EDL_0000219	link	NIL000000203
