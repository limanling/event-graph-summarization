:Entity_EDL_0000000	type	Organization
:Entity_EDL_0000000	nominal_mention	"banks"	finan_washingtonpost__1000-01-01__timeline:11959-11963	1.0
:Entity_EDL_0000000	link	NIL000000001
:Entity_EDL_0000001	type	Person
:Entity_EDL_0000001	mention	"Bush"	finan_washingtonpost__1000-01-01__timeline:48190-48193	1.0
:Entity_EDL_0000001	link	NIL000000002
:Entity_EDL_0000002	type	Organization
:Entity_EDL_0000002	canonical_mention	"exporters"	finan_washingtonpost__1000-01-01__timeline:33411-33419	1.0
:Entity_EDL_0000002	nominal_mention	"exporters"	finan_washingtonpost__1000-01-01__timeline:33411-33419	1.0
:Entity_EDL_0000002	link	NIL000000003
:Entity_EDL_0000003	type	Organization
:Entity_EDL_0000003	nominal_mention	"firm"	finan_washingtonpost__1000-01-01__timeline:34953-34956	1.0
:Entity_EDL_0000003	link	NIL000000004
:Entity_EDL_0000004	type	Person
:Entity_EDL_0000004	mention	"Barack Obama"	finan_washingtonpost__1000-01-01__timeline:22191-22202	1.0
:Entity_EDL_0000004	link	NIL000000005
:Entity_EDL_0000005	type	Person
:Entity_EDL_0000005	canonical_mention	"officials"	finan_washingtonpost__1000-01-01__timeline:4648-4656	1.0
:Entity_EDL_0000005	nominal_mention	"officials"	finan_washingtonpost__1000-01-01__timeline:4648-4656	1.0
:Entity_EDL_0000005	link	NIL000000006
:Entity_EDL_0000006	type	Person
:Entity_EDL_0000006	canonical_mention	"Alan Mulally"	finan_washingtonpost__1000-01-01__timeline:5777-5788	1.0
:Entity_EDL_0000006	mention	"Alan Mulally"	finan_washingtonpost__1000-01-01__timeline:5777-5788	1.0
:Entity_EDL_0000006	link	NIL000000007
:Entity_EDL_0000007	type	Organization
:Entity_EDL_0000007	nominal_mention	"banks"	finan_washingtonpost__1000-01-01__timeline:38577-38581	1.0
:Entity_EDL_0000007	link	NIL000000008
:Entity_EDL_0000008	type	Organization
:Entity_EDL_0000008	nominal_mention	"government"	finan_washingtonpost__1000-01-01__timeline:40029-40038	1.0
:Entity_EDL_0000008	link	NIL000000009
:Entity_EDL_0000009	type	Organization
:Entity_EDL_0000009	mention	"Treasury Department"	finan_washingtonpost__1000-01-01__timeline:27177-27195	1.0
:Entity_EDL_0000009	link	NIL000000010
:Entity_EDL_0000010	type	Organization
:Entity_EDL_0000010	canonical_mention	"Capital One"	finan_washingtonpost__1000-01-01__timeline:6014-6024	1.0
:Entity_EDL_0000010	mention	"Capital One"	finan_washingtonpost__1000-01-01__timeline:6014-6024	1.0
:Entity_EDL_0000010	link	NIL000000011
:Entity_EDL_0000011	type	GeopoliticalEntity
:Entity_EDL_0000011	canonical_mention	"Ukraine"	finan_washingtonpost__1000-01-01__timeline:33989-33995	1.0
:Entity_EDL_0000011	mention	"Ukraine"	finan_washingtonpost__1000-01-01__timeline:33989-33995	1.0
:Entity_EDL_0000011	link	690791
:Entity_EDL_0000012	type	Person
:Entity_EDL_0000012	nominal_mention	"regulators"	finan_washingtonpost__1000-01-01__timeline:48537-48546	1.0
:Entity_EDL_0000012	link	NIL000000012
:Entity_EDL_0000013	type	Organization
:Entity_EDL_0000013	nominal_mention	"automakers"	finan_washingtonpost__1000-01-01__timeline:24408-24417	1.0
:Entity_EDL_0000013	link	NIL000000013
:Entity_EDL_0000014	type	Organization
:Entity_EDL_0000014	pronominal_mention	"its"	finan_washingtonpost__1000-01-01__timeline:34727-34729	1.0
:Entity_EDL_0000014	link	NIL000000014
:Entity_EDL_0000015	type	Organization
:Entity_EDL_0000015	mention	"Treasury"	finan_washingtonpost__1000-01-01__timeline:32364-32371	1.0
:Entity_EDL_0000015	link	NIL000000015
:Entity_EDL_0000016	type	GeopoliticalEntity
:Entity_EDL_0000016	mention	"United States"	finan_washingtonpost__1000-01-01__timeline:24897-24909	1.0
:Entity_EDL_0000016	link	6252001
:Entity_EDL_0000017	type	GeopoliticalEntity
:Entity_EDL_0000017	pronominal_mention	"we"	finan_washingtonpost__1000-01-01__timeline:2476-2477	1.0
:Entity_EDL_0000017	link	NIL000000016
:Entity_EDL_0000018	type	Organization
:Entity_EDL_0000018	mention	"House"	finan_washingtonpost__1000-01-01__timeline:2323-2327	1.0
:Entity_EDL_0000018	link	NIL000000017
:Entity_EDL_0000019	type	Person
:Entity_EDL_0000019	mention	"Barack Obama"	finan_washingtonpost__1000-01-01__timeline:12069-12080	1.0
:Entity_EDL_0000019	link	NIL000000018
:Entity_EDL_0000020	type	Organization
:Entity_EDL_0000020	mention	"Treasury"	finan_washingtonpost__1000-01-01__timeline:10214-10221	1.0
:Entity_EDL_0000020	link	NIL000000019
:Entity_EDL_0000021	type	Person
:Entity_EDL_0000021	canonical_mention	"nominees"	finan_washingtonpost__1000-01-01__timeline:48240-48247	1.0
:Entity_EDL_0000021	nominal_mention	"nominees"	finan_washingtonpost__1000-01-01__timeline:48240-48247	1.0
:Entity_EDL_0000021	link	NIL000000020
:Entity_EDL_0000022	type	Organization
:Entity_EDL_0000022	pronominal_mention	"its"	finan_washingtonpost__1000-01-01__timeline:38781-38783	1.0
:Entity_EDL_0000022	link	NIL000000021
:Entity_EDL_0000023	type	Person
:Entity_EDL_0000023	canonical_mention	"Paul Volcker"	finan_washingtonpost__1000-01-01__timeline:9169-9180	1.0
:Entity_EDL_0000023	mention	"Paul Volcker"	finan_washingtonpost__1000-01-01__timeline:9169-9180	1.0
:Entity_EDL_0000023	link	NIL000000022
:Entity_EDL_0000024	type	Organization
:Entity_EDL_0000024	nominal_mention	"banks"	finan_washingtonpost__1000-01-01__timeline:27130-27134	1.0
:Entity_EDL_0000024	link	NIL000000023
:Entity_EDL_0000025	type	Organization
:Entity_EDL_0000025	nominal_mention	"company"	finan_washingtonpost__1000-01-01__timeline:39574-39580	1.0
:Entity_EDL_0000025	link	NIL000000024
:Entity_EDL_0000026	type	Organization
:Entity_EDL_0000026	mention	"Fannie Mae"	finan_washingtonpost__1000-01-01__timeline:50852-50861	1.0
:Entity_EDL_0000026	link	NIL000000025
:Entity_EDL_0000027	type	MON
:Entity_EDL_0000027	nominal_mention	"cash"	finan_washingtonpost__1000-01-01__timeline:54018-54021	1.0
:Entity_EDL_0000027	link	NIL000000026
:Entity_EDL_0000029	type	Organization
:Entity_EDL_0000029	canonical_mention	"Senate Banking Committee"	finan_washingtonpost__1000-01-01__timeline:14329-14352	1.0
:Entity_EDL_0000029	mention	"Senate Banking Committee"	finan_washingtonpost__1000-01-01__timeline:14329-14352	1.0
:Entity_EDL_0000029	link	NIL000000028
:Entity_EDL_0000030	type	Location
:Entity_EDL_0000030	mention	"Capitol Hill"	finan_washingtonpost__1000-01-01__timeline:13923-13934	1.0
:Entity_EDL_0000030	link	5772445
:Entity_EDL_0000031	type	Person
:Entity_EDL_0000031	nominal_mention	"workforce"	finan_washingtonpost__1000-01-01__timeline:29950-29958	1.0
:Entity_EDL_0000031	link	NIL000000029
:Entity_EDL_0000032	type	Person
:Entity_EDL_0000032	nominal_mention	"executives"	finan_washingtonpost__1000-01-01__timeline:13868-13877	1.0
:Entity_EDL_0000032	link	NIL000000030
:Entity_EDL_0000033	type	Person
:Entity_EDL_0000033	mention	"Ben Bernanke"	finan_washingtonpost__1000-01-01__timeline:40679-40690	1.0
:Entity_EDL_0000033	link	NIL000000031
:Entity_EDL_0000034	type	Person
:Entity_EDL_0000034	canonical_mention	"James H. Lambright"	finan_washingtonpost__1000-01-01__timeline:31448-31465	1.0
:Entity_EDL_0000034	mention	"James H. Lambright"	finan_washingtonpost__1000-01-01__timeline:31448-31465	1.0
:Entity_EDL_0000034	link	NIL000000032
:Entity_EDL_0000035	type	Organization
:Entity_EDL_0000035	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:43565-43566	1.0
:Entity_EDL_0000035	link	NIL000000033
:Entity_EDL_0000036	type	Organization
:Entity_EDL_0000036	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:43796-43797	1.0
:Entity_EDL_0000036	link	NIL000000034
:Entity_EDL_0000037	type	Person
:Entity_EDL_0000037	nominal_mention	"executive"	finan_washingtonpost__1000-01-01__timeline:36879-36887	1.0
:Entity_EDL_0000037	link	NIL000000035
:Entity_EDL_0000038	type	Person
:Entity_EDL_0000038	nominal_mention	"bankers"	finan_washingtonpost__1000-01-01__timeline:43626-43632	1.0
:Entity_EDL_0000038	link	NIL000000036
:Entity_EDL_0000039	type	Organization
:Entity_EDL_0000039	nominal_mention	"company"	finan_washingtonpost__1000-01-01__timeline:16625-16631	1.0
:Entity_EDL_0000039	link	NIL000000037
:Entity_EDL_0000040	type	Organization
:Entity_EDL_0000040	nominal_mention	"lender"	finan_washingtonpost__1000-01-01__timeline:41576-41581	1.0
:Entity_EDL_0000040	link	NIL000000038
:Entity_EDL_0000041	type	Organization
:Entity_EDL_0000041	canonical_mention	"Downey Savings and Loan Association"	finan_washingtonpost__1000-01-01__timeline:11977-12011	1.0
:Entity_EDL_0000041	mention	"Downey Savings and Loan Association"	finan_washingtonpost__1000-01-01__timeline:11977-12011	1.0
:Entity_EDL_0000041	link	NIL000000039
:Entity_EDL_0000042	type	Organization
:Entity_EDL_0000042	mention	"National Association for Business Economics"	finan_washingtonpost__1000-01-01__timeline:26041-26083	1.0
:Entity_EDL_0000042	link	NIL000000040
:Entity_EDL_0000043	type	GeopoliticalEntity
:Entity_EDL_0000043	nominal_mention	"government"	finan_washingtonpost__1000-01-01__timeline:38549-38558	0.000
:Entity_EDL_0000043	link	NIL000000041
:Entity_EDL_0000044	type	Person
:Entity_EDL_0000044	nominal_mention	"executives"	finan_washingtonpost__1000-01-01__timeline:33941-33950	1.0
:Entity_EDL_0000044	link	NIL000000042
:Entity_EDL_0000045	type	Person
:Entity_EDL_0000045	pronominal_mention	"percent"	finan_washingtonpost__1000-01-01__timeline:25447-25453	1.0
:Entity_EDL_0000045	link	NIL000000043
:Entity_EDL_0000046	type	Person
:Entity_EDL_0000046	canonical_mention	"leaders"	finan_washingtonpost__1000-01-01__timeline:4684-4690	1.0
:Entity_EDL_0000046	nominal_mention	"leaders"	finan_washingtonpost__1000-01-01__timeline:4684-4690	1.0
:Entity_EDL_0000046	link	NIL000000044
:Entity_EDL_0000047	type	Organization
:Entity_EDL_0000047	mention	"FDIC"	finan_washingtonpost__1000-01-01__timeline:11941-11944	1.0
:Entity_EDL_0000047	link	NIL000000045
:Entity_EDL_0000048	type	Person
:Entity_EDL_0000048	mention	"Bush"	finan_washingtonpost__1000-01-01__timeline:17942-17945	1.0
:Entity_EDL_0000048	link	NIL000000046
:Entity_EDL_0000049	type	Organization
:Entity_EDL_0000049	nominal_mention	"companies"	finan_washingtonpost__1000-01-01__timeline:38969-38977	1.0
:Entity_EDL_0000049	link	NIL000000047
:Entity_EDL_0000050	type	Person
:Entity_EDL_0000050	mention	"Neel Kashkari"	finan_washingtonpost__1000-01-01__timeline:41930-41942	1.0
:Entity_EDL_0000050	link	NIL000000048
:Entity_EDL_0000051	type	Organization
:Entity_EDL_0000051	mention	"Fannie Mae"	finan_washingtonpost__1000-01-01__timeline:49088-49097	1.0
:Entity_EDL_0000051	link	NIL000000049
:Entity_EDL_0000052	type	Organization
:Entity_EDL_0000052	canonical_mention	"Metro"	finan_washingtonpost__1000-01-01__timeline:17116-17120	1.0
:Entity_EDL_0000052	mention	"Metro"	finan_washingtonpost__1000-01-01__timeline:17116-17120	1.0
:Entity_EDL_0000052	link	NIL000000050
:Entity_EDL_0000053	type	Organization
:Entity_EDL_0000053	canonical_mention	"Fortune 500"	finan_washingtonpost__1000-01-01__timeline:7464-7474	1.0
:Entity_EDL_0000053	mention	"Fortune 500"	finan_washingtonpost__1000-01-01__timeline:7464-7474	1.0
:Entity_EDL_0000053	link	NIL000000051
:Entity_EDL_0000054	type	Person
:Entity_EDL_0000054	canonical_mention	"Timothy F. Geithner"	finan_washingtonpost__1000-01-01__timeline:11850-11868	1.0
:Entity_EDL_0000054	mention	"Timothy F. Geithner"	finan_washingtonpost__1000-01-01__timeline:11850-11868	1.0
:Entity_EDL_0000054	link	NIL000000052
:Entity_EDL_0000055	type	Person
:Entity_EDL_0000055	nominal_mention	"shareholders"	finan_washingtonpost__1000-01-01__timeline:27258-27269	1.0
:Entity_EDL_0000055	link	NIL000000053
:Entity_EDL_0000056	type	Organization
:Entity_EDL_0000056	nominal_mention	"banks"	finan_washingtonpost__1000-01-01__timeline:32326-32330	1.0
:Entity_EDL_0000056	link	NIL000000054
:Entity_EDL_0000057	type	GeopoliticalEntity
:Entity_EDL_0000057	canonical_mention	"country"	finan_washingtonpost__1000-01-01__timeline:20692-20698	1.0
:Entity_EDL_0000057	nominal_mention	"country"	finan_washingtonpost__1000-01-01__timeline:20692-20698	1.0
:Entity_EDL_0000057	link	NIL000000055
:Entity_EDL_0000058	type	MON
:Entity_EDL_0000058	canonical_mention	"cash"	finan_washingtonpost__1000-01-01__timeline:42978-42981	1.0
:Entity_EDL_0000058	nominal_mention	"cash"	finan_washingtonpost__1000-01-01__timeline:42978-42981	1.0
:Entity_EDL_0000058	link	NIL000000056
:Entity_EDL_0000059	type	GeopoliticalEntity
:Entity_EDL_0000059	mention	"Belgium"	finan_washingtonpost__1000-01-01__timeline:46769-46775	1.0
:Entity_EDL_0000059	link	2802361
:Entity_EDL_0000060	type	GeopoliticalEntity
:Entity_EDL_0000060	canonical_mention	"Luxembourg"	finan_washingtonpost__1000-01-01__timeline:46799-46808	1.0
:Entity_EDL_0000060	mention	"Luxembourg"	finan_washingtonpost__1000-01-01__timeline:46799-46808	1.0
:Entity_EDL_0000060	link	2960313
:Entity_EDL_0000061	type	GeopoliticalEntity
:Entity_EDL_0000061	nominal_mention	"nation"	finan_washingtonpost__1000-01-01__timeline:36156-36161	1.0
:Entity_EDL_0000061	link	NIL000000057
:Entity_EDL_0000062	type	Person
:Entity_EDL_0000062	canonical_mention	"chiefs"	finan_washingtonpost__1000-01-01__timeline:49078-49083	1.0
:Entity_EDL_0000062	nominal_mention	"chiefs"	finan_washingtonpost__1000-01-01__timeline:49078-49083	1.0
:Entity_EDL_0000062	link	NIL000000058
:Entity_EDL_0000064	type	Person
:Entity_EDL_0000064	mention	"Neil M. Barofsky"	finan_washingtonpost__1000-01-01__timeline:14387-14402	1.0
:Entity_EDL_0000064	link	NIL000000060
:Entity_EDL_0000065	type	Organization
:Entity_EDL_0000065	nominal_mention	"banks"	finan_washingtonpost__1000-01-01__timeline:33401-33405	1.0
:Entity_EDL_0000065	link	NIL000000061
:Entity_EDL_0000066	type	GeopoliticalEntity
:Entity_EDL_0000066	canonical_mention	"Netherlands"	finan_washingtonpost__1000-01-01__timeline:46783-46793	1.0
:Entity_EDL_0000066	mention	"Netherlands"	finan_washingtonpost__1000-01-01__timeline:46783-46793	1.0
:Entity_EDL_0000066	link	2750405
:Entity_EDL_0000067	type	Person
:Entity_EDL_0000067	canonical_mention	"Alan Greenspan"	finan_washingtonpost__1000-01-01__timeline:30288-30301	1.0
:Entity_EDL_0000067	mention	"Alan Greenspan"	finan_washingtonpost__1000-01-01__timeline:30288-30301	1.0
:Entity_EDL_0000067	link	NIL000000062
:Entity_EDL_0000068	type	Person
:Entity_EDL_0000068	mention	"Ben Bernanke"	finan_washingtonpost__1000-01-01__timeline:14622-14633	1.0
:Entity_EDL_0000068	link	NIL000000063
:Entity_EDL_0000069	type	Organization
:Entity_EDL_0000069	mention	"Citigroup"	finan_washingtonpost__1000-01-01__timeline:46017-46025	1.0
:Entity_EDL_0000069	link	NIL000000064
:Entity_EDL_0000070	type	Organization
:Entity_EDL_0000070	mention	"AIG"	finan_washingtonpost__1000-01-01__timeline:50899-50901	1.0
:Entity_EDL_0000070	link	NIL000000065
:Entity_EDL_0000071	type	Organization
:Entity_EDL_0000071	nominal_mention	"government"	finan_washingtonpost__1000-01-01__timeline:18790-18799	1.0
:Entity_EDL_0000071	link	NIL000000066
:Entity_EDL_0000072	type	Organization
:Entity_EDL_0000072	nominal_mention	"industry"	finan_washingtonpost__1000-01-01__timeline:20354-20361	1.0
:Entity_EDL_0000072	link	NIL000000067
:Entity_EDL_0000073	type	Organization
:Entity_EDL_0000073	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:38903-38904	1.0
:Entity_EDL_0000073	link	NIL000000068
:Entity_EDL_0000074	type	Organization
:Entity_EDL_0000074	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:22960-22961	1.0
:Entity_EDL_0000074	link	NIL000000069
:Entity_EDL_0000075	type	Organization
:Entity_EDL_0000075	pronominal_mention	"its"	finan_washingtonpost__1000-01-01__timeline:2824-2826	1.0
:Entity_EDL_0000075	link	NIL000000070
:Entity_EDL_0000076	type	Person
:Entity_EDL_0000076	canonical_mention	"team"	finan_washingtonpost__1000-01-01__timeline:4603-4606	1.0
:Entity_EDL_0000076	nominal_mention	"team"	finan_washingtonpost__1000-01-01__timeline:4603-4606	1.0
:Entity_EDL_0000076	link	NIL000000071
:Entity_EDL_0000077	type	Person
:Entity_EDL_0000077	canonical_mention	"Neil Barofsky"	finan_washingtonpost__1000-01-01__timeline:16991-17003	1.0
:Entity_EDL_0000077	mention	"Neil Barofsky"	finan_washingtonpost__1000-01-01__timeline:16991-17003	1.0
:Entity_EDL_0000077	link	NIL000000072
:Entity_EDL_0000078	type	Person
:Entity_EDL_0000078	canonical_mention	"John Mack"	finan_washingtonpost__1000-01-01__timeline:36889-36897	1.0
:Entity_EDL_0000078	mention	"John Mack"	finan_washingtonpost__1000-01-01__timeline:36889-36897	1.0
:Entity_EDL_0000078	link	NIL000000073
:Entity_EDL_0000079	type	Person
:Entity_EDL_0000079	mention	"Henry Paulson"	finan_washingtonpost__1000-01-01__timeline:14963-14975	1.0
:Entity_EDL_0000079	link	NIL000000074
:Entity_EDL_0000080	type	Organization
:Entity_EDL_0000080	pronominal_mention	"its"	finan_washingtonpost__1000-01-01__timeline:25458-25460	1.0
:Entity_EDL_0000080	link	NIL000000075
:Entity_EDL_0000081	type	Organization
:Entity_EDL_0000081	mention	"Wachovia"	finan_washingtonpost__1000-01-01__timeline:46067-46074	1.0
:Entity_EDL_0000081	link	NIL000000076
:Entity_EDL_0000082	type	Organization
:Entity_EDL_0000082	nominal_mention	"banks"	finan_washingtonpost__1000-01-01__timeline:53974-53978	1.0
:Entity_EDL_0000082	link	NIL000000077
:Entity_EDL_0000083	type	Organization
:Entity_EDL_0000083	mention	"Wachovia"	finan_washingtonpost__1000-01-01__timeline:54217-54224	1.0
:Entity_EDL_0000083	link	NIL000000078
:Entity_EDL_0000084	type	Organization
:Entity_EDL_0000084	canonical_mention	"Countrywide Financial"	finan_washingtonpost__1000-01-01__timeline:41531-41551	1.0
:Entity_EDL_0000084	mention	"Countrywide Financial"	finan_washingtonpost__1000-01-01__timeline:41531-41551	1.0
:Entity_EDL_0000084	link	NIL000000079
:Entity_EDL_0000085	type	Organization
:Entity_EDL_0000085	mention	"Fed"	finan_washingtonpost__1000-01-01__timeline:34382-34384	1.0
:Entity_EDL_0000085	link	NIL000000080
:Entity_EDL_0000086	type	Organization
:Entity_EDL_0000086	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:6031-6032	1.0
:Entity_EDL_0000086	link	NIL000000081
:Entity_EDL_0000087	type	Organization
:Entity_EDL_0000087	mention	"House Budget Committee"	finan_washingtonpost__1000-01-01__timeline:49979-50000	1.0
:Entity_EDL_0000087	link	NIL000000082
:Entity_EDL_0000088	type	Facility
:Entity_EDL_0000088	canonical_mention	"airports"	finan_washingtonpost__1000-01-01__timeline:20839-20846	1.0
:Entity_EDL_0000088	nominal_mention	"airports"	finan_washingtonpost__1000-01-01__timeline:20839-20846	1.0
:Entity_EDL_0000088	link	NIL000000083
:Entity_EDL_0000089	type	Organization
:Entity_EDL_0000089	canonical_mention	"PricewaterhouseCoopers"	finan_washingtonpost__1000-01-01__timeline:32401-32422	1.0
:Entity_EDL_0000089	mention	"PricewaterhouseCoopers"	finan_washingtonpost__1000-01-01__timeline:32401-32422	1.0
:Entity_EDL_0000089	link	NIL000000084
:Entity_EDL_0000090	type	Organization
:Entity_EDL_0000090	mention	"White House"	finan_washingtonpost__1000-01-01__timeline:3595-3605	1.0
:Entity_EDL_0000090	link	NIL000000085
:Entity_EDL_0000091	type	Organization
:Entity_EDL_0000091	nominal_mention	"giants"	finan_washingtonpost__1000-01-01__timeline:50845-50850	1.0
:Entity_EDL_0000091	link	NIL000000086
:Entity_EDL_0000092	type	GeopoliticalEntity
:Entity_EDL_0000092	canonical_mention	"Frankfurt"	finan_washingtonpost__1000-01-01__timeline:16332-16340	1.0
:Entity_EDL_0000092	mention	"Frankfurt"	finan_washingtonpost__1000-01-01__timeline:16332-16340	1.0
:Entity_EDL_0000092	link	2925533
:Entity_EDL_0000093	type	Organization
:Entity_EDL_0000093	nominal_mention	"business"	finan_washingtonpost__1000-01-01__timeline:42683-42690	1.0
:Entity_EDL_0000093	link	NIL000000087
:Entity_EDL_0000095	type	Organization
:Entity_EDL_0000095	mention	"Congress"	finan_washingtonpost__1000-01-01__timeline:15735-15742	1.0
:Entity_EDL_0000095	link	20000051
:Entity_EDL_0000096	type	Person
:Entity_EDL_0000096	canonical_mention	"President-"	finan_washingtonpost__1000-01-01__timeline:20523-20532	1.0
:Entity_EDL_0000096	nominal_mention	"President-"	finan_washingtonpost__1000-01-01__timeline:20523-20532	1.0
:Entity_EDL_0000096	link	NIL000000089
:Entity_EDL_0000098	type	Organization
:Entity_EDL_0000098	canonical_mention	"Tribune Co."	finan_washingtonpost__1000-01-01__timeline:4024-4034	1.0
:Entity_EDL_0000098	mention	"Tribune Co."	finan_washingtonpost__1000-01-01__timeline:4024-4034	1.0
:Entity_EDL_0000098	link	NIL000000091
:Entity_EDL_0000099	type	Organization
:Entity_EDL_0000099	mention	"Freddie Mac"	finan_washingtonpost__1000-01-01__timeline:50865-50875	1.0
:Entity_EDL_0000099	link	NIL000000092
:Entity_EDL_0000100	type	Person
:Entity_EDL_0000100	canonical_mention	"employers"	finan_washingtonpost__1000-01-01__timeline:4460-4468	1.0
:Entity_EDL_0000100	nominal_mention	"employers"	finan_washingtonpost__1000-01-01__timeline:4460-4468	1.0
:Entity_EDL_0000100	link	NIL000000093
:Entity_EDL_0000101	type	Organization
:Entity_EDL_0000101	nominal_mention	"automakers"	finan_washingtonpost__1000-01-01__timeline:22108-22117	1.0
:Entity_EDL_0000101	link	NIL000000094
:Entity_EDL_0000102	type	Organization
:Entity_EDL_0000102	mention	"GM"	finan_washingtonpost__1000-01-01__timeline:24419-24420	1.0
:Entity_EDL_0000102	link	NIL000000095
:Entity_EDL_0000103	type	Organization
:Entity_EDL_0000103	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:41583-41584	1.0
:Entity_EDL_0000103	link	NIL000000096
:Entity_EDL_0000104	type	Person
:Entity_EDL_0000104	mention	"Obama"	finan_washingtonpost__1000-01-01__timeline:21789-21793	1.0
:Entity_EDL_0000104	link	30001628
:Entity_EDL_0000105	type	Person
:Entity_EDL_0000105	mention	"Ben Bernanke"	finan_washingtonpost__1000-01-01__timeline:16252-16263	1.0
:Entity_EDL_0000105	link	NIL000000097
:Entity_EDL_0000106	type	GeopoliticalEntity
:Entity_EDL_0000106	mention	"Washington"	finan_washingtonpost__1000-01-01__timeline:26088-26097	1.0
:Entity_EDL_0000106	link	5815135
:Entity_EDL_0000108	type	Organization
:Entity_EDL_0000108	nominal_mention	"automakers"	finan_washingtonpost__1000-01-01__timeline:3670-3679	1.0
:Entity_EDL_0000108	link	NIL000000099
:Entity_EDL_0000109	type	GeopoliticalEntity
:Entity_EDL_0000109	mention	"U.S."	finan_washingtonpost__1000-01-01__timeline:4455-4458	1.0
:Entity_EDL_0000109	link	6252001
:Entity_EDL_0000110	type	Person
:Entity_EDL_0000110	canonical_mention	"Richard Shelby"	finan_washingtonpost__1000-01-01__timeline:48070-48083	1.0
:Entity_EDL_0000110	mention	"Richard Shelby"	finan_washingtonpost__1000-01-01__timeline:48070-48083	1.0
:Entity_EDL_0000110	link	NIL000000100
:Entity_EDL_0000111	type	Organization
:Entity_EDL_0000111	canonical_mention	"Kaupthing Bank"	finan_washingtonpost__1000-01-01__timeline:39046-39059	1.0
:Entity_EDL_0000111	mention	"Kaupthing Bank"	finan_washingtonpost__1000-01-01__timeline:39046-39059	1.0
:Entity_EDL_0000111	link	NIL000000101
:Entity_EDL_0000112	type	Person
:Entity_EDL_0000112	nominal_mention	"force"	finan_washingtonpost__1000-01-01__timeline:25467-25471	1.0
:Entity_EDL_0000112	link	NIL000000102
:Entity_EDL_0000113	type	Organization
:Entity_EDL_0000113	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:29907-29908	1.0
:Entity_EDL_0000113	link	NIL000000103
:Entity_EDL_0000114	type	Person
:Entity_EDL_0000114	canonical_mention	"Treas"	finan_washingtonpost__1000-01-01__timeline:42895-42899	1.0
:Entity_EDL_0000114	mention	"Treas"	finan_washingtonpost__1000-01-01__timeline:42895-42899	1.0
:Entity_EDL_0000114	link	NIL000000104
:Entity_EDL_0000115	type	GeopoliticalEntity
:Entity_EDL_0000115	mention	"U.S."	finan_washingtonpost__1000-01-01__timeline:25622-25625	1.0
:Entity_EDL_0000115	link	6252001
:Entity_EDL_0000116	type	Organization
:Entity_EDL_0000116	mention	"Freddie Mac"	finan_washingtonpost__1000-01-01__timeline:49103-49113	1.0
:Entity_EDL_0000116	link	NIL000000105
:Entity_EDL_0000117	type	Organization
:Entity_EDL_0000117	mention	"Citigroup"	finan_washingtonpost__1000-01-01__timeline:41218-41226	1.0
:Entity_EDL_0000117	link	NIL000000106
:Entity_EDL_0000118	type	Person
:Entity_EDL_0000118	mention	"Bush"	finan_washingtonpost__1000-01-01__timeline:20510-20513	1.0
:Entity_EDL_0000118	link	NIL000000107
:Entity_EDL_0000119	type	Organization
:Entity_EDL_0000119	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:25407-25408	1.0
:Entity_EDL_0000119	link	NIL000000108
:Entity_EDL_0000120	type	Organization
:Entity_EDL_0000120	nominal_mention	"businesses"	finan_washingtonpost__1000-01-01__timeline:27089-27098	1.0
:Entity_EDL_0000120	link	NIL000000109
:Entity_EDL_0000121	type	Person
:Entity_EDL_0000121	mention	"Barack Obama"	finan_washingtonpost__1000-01-01__timeline:11104-11115	1.0
:Entity_EDL_0000121	link	NIL000000110
:Entity_EDL_0000122	type	Person
:Entity_EDL_0000122	mention	"Henry Paulson"	finan_washingtonpost__1000-01-01__timeline:14581-14593	1.0
:Entity_EDL_0000122	link	NIL000000111
:Entity_EDL_0000123	type	Organization
:Entity_EDL_0000123	pronominal_mention	"them"	finan_washingtonpost__1000-01-01__timeline:17568-17571	1.0
:Entity_EDL_0000123	link	NIL000000112
:Entity_EDL_0000124	type	Organization
:Entity_EDL_0000124	nominal_mention	"automakers"	finan_washingtonpost__1000-01-01__timeline:6532-6541	1.0
:Entity_EDL_0000124	link	NIL000000113
:Entity_EDL_0000125	type	Organization
:Entity_EDL_0000125	mention	"Morgan Stanley"	finan_washingtonpost__1000-01-01__timeline:54198-54211	1.0
:Entity_EDL_0000125	link	NIL000000114
:Entity_EDL_0000126	type	Organization
:Entity_EDL_0000126	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:27747-27748	1.0
:Entity_EDL_0000126	link	NIL000000115
:Entity_EDL_0000127	type	Person
:Entity_EDL_0000127	canonical_mention	"Henry Paulson"	finan_washingtonpost__1000-01-01__timeline:7389-7401	1.0
:Entity_EDL_0000127	mention	"Henry Paulson"	finan_washingtonpost__1000-01-01__timeline:7389-7401	1.0
:Entity_EDL_0000127	link	NIL000000116
:Entity_EDL_0000128	type	GeopoliticalEntity
:Entity_EDL_0000128	mention	"U.S."	finan_washingtonpost__1000-01-01__timeline:48628-48631	1.0
:Entity_EDL_0000128	link	6252001
:Entity_EDL_0000129	type	Organization
:Entity_EDL_0000129	nominal_mention	"automakers"	finan_washingtonpost__1000-01-01__timeline:6752-6761	1.0
:Entity_EDL_0000129	link	NIL000000117
:Entity_EDL_0000130	type	Person
:Entity_EDL_0000130	canonical_mention	"Neil M. Barofsky"	finan_washingtonpost__1000-01-01__timeline:3786-3801	1.0
:Entity_EDL_0000130	mention	"Neil M. Barofsky"	finan_washingtonpost__1000-01-01__timeline:3786-3801	1.0
:Entity_EDL_0000130	link	NIL000000118
:Entity_EDL_0000131	type	Organization
:Entity_EDL_0000131	mention	"Chevy Chase Bank"	finan_washingtonpost__1000-01-01__timeline:18468-18483	1.0
:Entity_EDL_0000131	link	NIL000000119
:Entity_EDL_0000132	type	GeopoliticalEntity
:Entity_EDL_0000132	mention	"Iceland"	finan_washingtonpost__1000-01-01__timeline:39031-39037	1.0
:Entity_EDL_0000132	link	2629691
:Entity_EDL_0000133	type	Organization
:Entity_EDL_0000133	canonical_mention	"National City"	finan_washingtonpost__1000-01-01__timeline:29778-29790	1.0
:Entity_EDL_0000133	mention	"National City"	finan_washingtonpost__1000-01-01__timeline:29778-29790	1.0
:Entity_EDL_0000133	link	NIL000000120
:Entity_EDL_0000134	type	Person
:Entity_EDL_0000134	nominal_mention	"leaders"	finan_washingtonpost__1000-01-01__timeline:48211-48217	1.0
:Entity_EDL_0000134	link	NIL000000121
:Entity_EDL_0000135	type	Organization
:Entity_EDL_0000135	mention	"Fed"	finan_washingtonpost__1000-01-01__timeline:40741-40743	1.0
:Entity_EDL_0000135	link	NIL000000122
:Entity_EDL_0000136	type	Organization
:Entity_EDL_0000136	mention	"Federal Reserve"	finan_washingtonpost__1000-01-01__timeline:30263-30277	1.0
:Entity_EDL_0000136	link	NIL000000123
:Entity_EDL_0000137	type	Organization
:Entity_EDL_0000137	nominal_mention	"sector"	finan_washingtonpost__1000-01-01__timeline:24487-24492	1.0
:Entity_EDL_0000137	link	NIL000000124
:Entity_EDL_0000138	type	Person
:Entity_EDL_0000138	canonical_mention	"operator"	finan_washingtonpost__1000-01-01__timeline:26276-26283	1.0
:Entity_EDL_0000138	nominal_mention	"operator"	finan_washingtonpost__1000-01-01__timeline:26276-26283	1.0
:Entity_EDL_0000138	link	NIL000000125
:Entity_EDL_0000139	type	Organization
:Entity_EDL_0000139	nominal_mention	"banks"	finan_washingtonpost__1000-01-01__timeline:40108-40112	1.0
:Entity_EDL_0000139	link	NIL000000126
:Entity_EDL_0000140	type	Person
:Entity_EDL_0000140	mention	"Barack Obama"	finan_washingtonpost__1000-01-01__timeline:7096-7107	1.0
:Entity_EDL_0000140	link	NIL000000127
:Entity_EDL_0000141	type	Organization
:Entity_EDL_0000141	canonical_mention	"agency"	finan_washingtonpost__1000-01-01__timeline:17201-17206	1.0
:Entity_EDL_0000141	nominal_mention	"agency"	finan_washingtonpost__1000-01-01__timeline:17201-17206	1.0
:Entity_EDL_0000141	link	NIL000000128
:Entity_EDL_0000142	type	Organization
:Entity_EDL_0000142	canonical_mention	"Goldman Sachs"	finan_washingtonpost__1000-01-01__timeline:42007-42019	1.0
:Entity_EDL_0000142	mention	"Goldman Sachs"	finan_washingtonpost__1000-01-01__timeline:42007-42019	1.0
:Entity_EDL_0000142	link	NIL000000129
:Entity_EDL_0000143	type	GeopoliticalEntity
:Entity_EDL_0000143	canonical_mention	"Mississippi"	finan_washingtonpost__1000-01-01__timeline:47823-47833	1.0
:Entity_EDL_0000143	mention	"Mississippi"	finan_washingtonpost__1000-01-01__timeline:47823-47833	1.0
:Entity_EDL_0000143	link	4436296
:Entity_EDL_0000144	type	GeopoliticalEntity
:Entity_EDL_0000144	nominal_mention	"government"	finan_washingtonpost__1000-01-01__timeline:36195-36204	0.000
:Entity_EDL_0000144	link	NIL000000130
:Entity_EDL_0000145	type	Organization
:Entity_EDL_0000145	nominal_mention	"media"	finan_washingtonpost__1000-01-01__timeline:48152-48156	1.0
:Entity_EDL_0000145	link	NIL000000131
:Entity_EDL_0000146	type	Organization
:Entity_EDL_0000146	pronominal_mention	"its"	finan_washingtonpost__1000-01-01__timeline:23007-23009	1.0
:Entity_EDL_0000146	link	NIL000000132
:Entity_EDL_0000147	type	Organization
:Entity_EDL_0000147	nominal_mention	"companies"	finan_washingtonpost__1000-01-01__timeline:4285-4293	1.0
:Entity_EDL_0000147	link	NIL000000133
:Entity_EDL_0000148	type	Organization
:Entity_EDL_0000148	mention	"Wells Fargo"	finan_washingtonpost__1000-01-01__timeline:42586-42596	1.0
:Entity_EDL_0000148	link	NIL000000134
:Entity_EDL_0000149	type	Person
:Entity_EDL_0000149	canonical_mention	"Gregg Judd"	finan_washingtonpost__1000-01-01__timeline:47338-47347	1.0
:Entity_EDL_0000149	mention	"Gregg Judd"	finan_washingtonpost__1000-01-01__timeline:47338-47347	1.0
:Entity_EDL_0000149	link	NIL000000135
:Entity_EDL_0000150	type	Person
:Entity_EDL_0000150	canonical_mention	"Bernard Madoff"	finan_washingtonpost__1000-01-01__timeline:1288-1301	1.0
:Entity_EDL_0000150	mention	"Bernard Madoff"	finan_washingtonpost__1000-01-01__timeline:1288-1301	1.0
:Entity_EDL_0000150	link	NIL000000136
:Entity_EDL_0000151	type	Facility
:Entity_EDL_0000151	mention	"White House"	finan_washingtonpost__1000-01-01__timeline:20552-20562	1.0
:Entity_EDL_0000151	link	NIL000000137
:Entity_EDL_0000152	type	Organization
:Entity_EDL_0000152	nominal_mention	"lender"	finan_washingtonpost__1000-01-01__timeline:48572-48577	1.0
:Entity_EDL_0000152	link	NIL000000138
:Entity_EDL_0000153	type	Organization
:Entity_EDL_0000153	mention	"Lehman Brothers"	finan_washingtonpost__1000-01-01__timeline:54775-54789	1.0
:Entity_EDL_0000153	link	NIL000000139
:Entity_EDL_0000154	type	Organization
:Entity_EDL_0000154	canonical_mention	"Dexia"	finan_washingtonpost__1000-01-01__timeline:45681-45685	1.0
:Entity_EDL_0000154	mention	"Dexia"	finan_washingtonpost__1000-01-01__timeline:45681-45685	1.0
:Entity_EDL_0000154	link	NIL000000140
:Entity_EDL_0000155	type	Person
:Entity_EDL_0000155	mention	"Barack Obama"	finan_washingtonpost__1000-01-01__timeline:9764-9775	1.0
:Entity_EDL_0000155	link	NIL000000141
:Entity_EDL_0000156	type	Organization
:Entity_EDL_0000156	nominal_mention	"automakers"	finan_washingtonpost__1000-01-01__timeline:12594-12603	1.0
:Entity_EDL_0000156	link	NIL000000142
:Entity_EDL_0000157	type	Organization
:Entity_EDL_0000157	nominal_mention	"government"	finan_washingtonpost__1000-01-01__timeline:16570-16579	1.0
:Entity_EDL_0000157	link	NIL000000143
:Entity_EDL_0000158	type	GeopoliticalEntity
:Entity_EDL_0000158	mention	"China"	finan_washingtonpost__1000-01-01__timeline:20622-20626	1.0
:Entity_EDL_0000158	link	1814991
:Entity_EDL_0000159	type	Organization
:Entity_EDL_0000159	canonical_mention	"Circuit City"	finan_washingtonpost__1000-01-01__timeline:21098-21109	1.0
:Entity_EDL_0000159	mention	"Circuit City"	finan_washingtonpost__1000-01-01__timeline:21098-21109	1.0
:Entity_EDL_0000159	link	NIL000000144
:Entity_EDL_0000160	type	Person
:Entity_EDL_0000160	nominal_mention	"Americans"	finan_washingtonpost__1000-01-01__timeline:23447-23455	1.0
:Entity_EDL_0000160	link	NIL000000145
:Entity_EDL_0000161	type	Person
:Entity_EDL_0000161	mention	"Barack Obama"	finan_washingtonpost__1000-01-01__timeline:11789-11800	1.0
:Entity_EDL_0000161	link	NIL000000146
:Entity_EDL_0000162	type	Organization
:Entity_EDL_0000162	nominal_mention	"government"	finan_washingtonpost__1000-01-01__timeline:18958-18967	1.0
:Entity_EDL_0000162	link	NIL000000147
:Entity_EDL_0000163	type	Organization
:Entity_EDL_0000163	nominal_mention	"automakers"	finan_washingtonpost__1000-01-01__timeline:7992-8001	1.0
:Entity_EDL_0000163	link	NIL000000148
:Entity_EDL_0000164	type	Organization
:Entity_EDL_0000164	mention	"Federal Reserve"	finan_washingtonpost__1000-01-01__timeline:9144-9158	1.0
:Entity_EDL_0000164	link	NIL000000149
:Entity_EDL_0000165	type	Organization
:Entity_EDL_0000165	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:29765-29766	1.0
:Entity_EDL_0000165	link	NIL000000150
:Entity_EDL_0000166	type	Person
:Entity_EDL_0000166	canonical_mention	"brokers"	finan_washingtonpost__1000-01-01__timeline:43614-43620	1.0
:Entity_EDL_0000166	nominal_mention	"brokers"	finan_washingtonpost__1000-01-01__timeline:43614-43620	1.0
:Entity_EDL_0000166	link	NIL000000151
:Entity_EDL_0000167	type	Person
:Entity_EDL_0000167	mention	"Bush"	finan_washingtonpost__1000-01-01__timeline:16952-16955	1.0
:Entity_EDL_0000167	link	NIL000000152
:Entity_EDL_0000168	type	Organization
:Entity_EDL_0000168	canonical_mention	"Chevy Chase Bank"	finan_washingtonpost__1000-01-01__timeline:6047-6062	1.0
:Entity_EDL_0000168	mention	"Chevy Chase Bank"	finan_washingtonpost__1000-01-01__timeline:6047-6062	1.0
:Entity_EDL_0000168	link	NIL000000153
:Entity_EDL_0000169	type	MON
:Entity_EDL_0000169	canonical_mention	"dollars"	finan_washingtonpost__1000-01-01__timeline:27873-27879	1.0
:Entity_EDL_0000169	nominal_mention	"dollars"	finan_washingtonpost__1000-01-01__timeline:27873-27879	1.0
:Entity_EDL_0000169	link	NIL000000154
:Entity_EDL_0000170	type	Person
:Entity_EDL_0000170	canonical_mention	"Vikram Pandit"	finan_washingtonpost__1000-01-01__timeline:36938-36950	1.0
:Entity_EDL_0000170	mention	"Vikram Pandit"	finan_washingtonpost__1000-01-01__timeline:36938-36950	1.0
:Entity_EDL_0000170	link	NIL000000155
:Entity_EDL_0000171	type	Organization
:Entity_EDL_0000171	nominal_mention	"bank"	finan_washingtonpost__1000-01-01__timeline:38870-38873	1.0
:Entity_EDL_0000171	link	NIL000000156
:Entity_EDL_0000172	type	Organization
:Entity_EDL_0000172	mention	"Fed"	finan_washingtonpost__1000-01-01__timeline:54554-54556	1.0
:Entity_EDL_0000172	link	NIL000000157
:Entity_EDL_0000173	type	Person
:Entity_EDL_0000173	mention	"Bush"	finan_washingtonpost__1000-01-01__timeline:52658-52661	1.0
:Entity_EDL_0000173	link	NIL000000158
:Entity_EDL_0000174	type	Organization
:Entity_EDL_0000174	canonical_mention	"People 's Bank of China"	finan_washingtonpost__1000-01-01__timeline:9277-9299	1.0
:Entity_EDL_0000174	mention	"People 's Bank of China"	finan_washingtonpost__1000-01-01__timeline:9277-9299	1.0
:Entity_EDL_0000174	link	NIL000000159
:Entity_EDL_0000175	type	Organization
:Entity_EDL_0000175	nominal_mention	"company"	finan_washingtonpost__1000-01-01__timeline:35541-35547	1.0
:Entity_EDL_0000175	link	NIL000000160
:Entity_EDL_0000176	type	Organization
:Entity_EDL_0000176	mention	"Wachovia"	finan_washingtonpost__1000-01-01__timeline:34746-34753	1.0
:Entity_EDL_0000176	link	NIL000000161
:Entity_EDL_0000177	type	GeopoliticalEntity
:Entity_EDL_0000177	mention	"Detroit"	finan_washingtonpost__1000-01-01__timeline:24400-24406	1.0
:Entity_EDL_0000177	link	4990729
:Entity_EDL_0000178	type	Organization
:Entity_EDL_0000178	canonical_mention	"Dow Chemical"	finan_washingtonpost__1000-01-01__timeline:3705-3716	1.0
:Entity_EDL_0000178	mention	"Dow Chemical"	finan_washingtonpost__1000-01-01__timeline:3705-3716	1.0
:Entity_EDL_0000178	link	NIL000000162
:Entity_EDL_0000179	type	Organization
:Entity_EDL_0000179	mention	"Treasury"	finan_washingtonpost__1000-01-01__timeline:31433-31440	1.0
:Entity_EDL_0000179	link	NIL000000163
:Entity_EDL_0000180	type	Organization
:Entity_EDL_0000180	canonical_mention	"Fannie Mae"	finan_washingtonpost__1000-01-01__timeline:2562-2571	1.0
:Entity_EDL_0000180	mention	"Fannie Mae"	finan_washingtonpost__1000-01-01__timeline:2562-2571	1.0
:Entity_EDL_0000180	link	NIL000000164
:Entity_EDL_0000181	type	Facility
:Entity_EDL_0000181	canonical_mention	"railways"	finan_washingtonpost__1000-01-01__timeline:20818-20825	1.0
:Entity_EDL_0000181	nominal_mention	"railways"	finan_washingtonpost__1000-01-01__timeline:20818-20825	1.0
:Entity_EDL_0000181	link	NIL000000165
:Entity_EDL_0000182	type	Organization
:Entity_EDL_0000182	mention	"Wachovia"	finan_washingtonpost__1000-01-01__timeline:42534-42541	1.0
:Entity_EDL_0000182	link	NIL000000166
:Entity_EDL_0000183	type	Organization
:Entity_EDL_0000183	mention	"Citigroup"	finan_washingtonpost__1000-01-01__timeline:18446-18454	1.0
:Entity_EDL_0000183	link	NIL000000167
:Entity_EDL_0000184	type	Organization
:Entity_EDL_0000184	mention	"Federal Reserve"	finan_washingtonpost__1000-01-01__timeline:9790-9804	1.0
:Entity_EDL_0000184	link	NIL000000168
:Entity_EDL_0000185	type	Organization
:Entity_EDL_0000185	canonical_mention	"Group of Eight"	finan_washingtonpost__1000-01-01__timeline:35768-35781	1.0
:Entity_EDL_0000185	mention	"Group of Eight"	finan_washingtonpost__1000-01-01__timeline:35768-35781	1.0
:Entity_EDL_0000185	link	20000099
:Entity_EDL_0000186	type	Person
:Entity_EDL_0000186	mention	"Paul Volcker"	finan_washingtonpost__1000-01-01__timeline:9815-9826	1.0
:Entity_EDL_0000186	link	NIL000000169
:Entity_EDL_0000187	type	Person
:Entity_EDL_0000187	canonical_mention	"banker"	finan_washingtonpost__1000-01-01__timeline:42021-42026	1.0
:Entity_EDL_0000187	nominal_mention	"banker"	finan_washingtonpost__1000-01-01__timeline:42021-42026	1.0
:Entity_EDL_0000187	link	NIL000000170
:Entity_EDL_0000188	type	Person
:Entity_EDL_0000188	pronominal_mention	"their"	finan_washingtonpost__1000-01-01__timeline:47807-47811	1.0
:Entity_EDL_0000188	link	NIL000000171
:Entity_EDL_0000189	type	Organization
:Entity_EDL_0000189	canonical_mention	"Credit Suisse"	finan_washingtonpost__1000-01-01__timeline:5408-5420	1.0
:Entity_EDL_0000189	mention	"Credit Suisse"	finan_washingtonpost__1000-01-01__timeline:5408-5420	1.0
:Entity_EDL_0000189	link	NIL000000172
:Entity_EDL_0000190	type	Organization
:Entity_EDL_0000190	mention	"House Financial Services Committee"	finan_washingtonpost__1000-01-01__timeline:49030-49063	1.0
:Entity_EDL_0000190	link	NIL000000173
:Entity_EDL_0000191	type	Organization
:Entity_EDL_0000191	canonical_mention	"Fortis"	finan_washingtonpost__1000-01-01__timeline:46856-46861	1.0
:Entity_EDL_0000191	mention	"Fortis"	finan_washingtonpost__1000-01-01__timeline:46856-46861	1.0
:Entity_EDL_0000191	link	NIL000000174
:Entity_EDL_0000192	type	Person
:Entity_EDL_0000192	mention	"Barack Obama"	finan_washingtonpost__1000-01-01__timeline:24640-24651	1.0
:Entity_EDL_0000192	link	NIL000000175
:Entity_EDL_0000193	type	Organization
:Entity_EDL_0000193	canonical_mention	"Ernst & Young"	finan_washingtonpost__1000-01-01__timeline:32428-32440	1.0
:Entity_EDL_0000193	mention	"Ernst & Young"	finan_washingtonpost__1000-01-01__timeline:32428-32440	1.0
:Entity_EDL_0000193	link	NIL000000176
:Entity_EDL_0000194	type	Location
:Entity_EDL_0000194	mention	"Capitol Hill"	finan_washingtonpost__1000-01-01__timeline:14722-14733	1.0
:Entity_EDL_0000194	link	5772445
:Entity_EDL_0000195	type	GeopoliticalEntity
:Entity_EDL_0000195	canonical_mention	"South Korea"	finan_washingtonpost__1000-01-01__timeline:33308-33318	1.0
:Entity_EDL_0000195	mention	"South Korea"	finan_washingtonpost__1000-01-01__timeline:33308-33318	1.0
:Entity_EDL_0000195	link	1835841
:Entity_EDL_0000196	type	Organization
:Entity_EDL_0000196	nominal_mention	"two"	finan_washingtonpost__1000-01-01__timeline:44360-44362	1.0
:Entity_EDL_0000196	link	NIL000000177
:Entity_EDL_0000197	type	Organization
:Entity_EDL_0000197	nominal_mention	"banks"	finan_washingtonpost__1000-01-01__timeline:36228-36232	1.0
:Entity_EDL_0000197	link	NIL000000178
:Entity_EDL_0000198	type	Organization
:Entity_EDL_0000198	canonical_mention	"Freddie Mac"	finan_washingtonpost__1000-01-01__timeline:2275-2285	1.0
:Entity_EDL_0000198	mention	"Freddie Mac"	finan_washingtonpost__1000-01-01__timeline:2275-2285	1.0
:Entity_EDL_0000198	link	NIL000000179
:Entity_EDL_0000199	type	Organization
:Entity_EDL_0000199	mention	"Senate Banking Committee"	finan_washingtonpost__1000-01-01__timeline:18213-18236	1.0
:Entity_EDL_0000199	link	NIL000000180
:Entity_EDL_0000200	type	Organization
:Entity_EDL_0000200	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:30819-30820	1.0
:Entity_EDL_0000200	link	NIL000000181
:Entity_EDL_0000201	type	Organization
:Entity_EDL_0000201	canonical_mention	"American International Group"	finan_washingtonpost__1000-01-01__timeline:54580-54607	1.0
:Entity_EDL_0000201	mention	"American International Group"	finan_washingtonpost__1000-01-01__timeline:54580-54607	1.0
:Entity_EDL_0000201	link	NIL000000182
:Entity_EDL_0000202	type	Person
:Entity_EDL_0000202	pronominal_mention	"he"	finan_washingtonpost__1000-01-01__timeline:47777-47778	1.0
:Entity_EDL_0000202	link	NIL000000183
:Entity_EDL_0000203	type	Organization
:Entity_EDL_0000203	canonical_mention	"Federal Deposit Insurance Corp."	finan_washingtonpost__1000-01-01__timeline:44774-44804	1.0
:Entity_EDL_0000203	mention	"Federal Deposit Insurance Corp."	finan_washingtonpost__1000-01-01__timeline:44774-44804	1.0
:Entity_EDL_0000203	link	NIL000000184
:Entity_EDL_0000204	type	Organization
:Entity_EDL_0000204	mention	"AIG"	finan_washingtonpost__1000-01-01__timeline:54327-54329	1.0
:Entity_EDL_0000204	link	NIL000000185
:Entity_EDL_0000205	type	Person
:Entity_EDL_0000205	nominal_mention	"President-"	finan_washingtonpost__1000-01-01__timeline:24624-24633	1.0
:Entity_EDL_0000205	link	NIL000000186
:Entity_EDL_0000206	type	Organization
:Entity_EDL_0000206	mention	"Federal Reserve"	finan_washingtonpost__1000-01-01__timeline:27726-27740	1.0
:Entity_EDL_0000206	link	NIL000000187
:Entity_EDL_0000207	type	Organization
:Entity_EDL_0000207	mention	"Senate"	finan_washingtonpost__1000-01-01__timeline:3770-3775	1.0
:Entity_EDL_0000207	link	NIL000000188
:Entity_EDL_0000209	type	Person
:Entity_EDL_0000209	mention	"Ben Bernanke"	finan_washingtonpost__1000-01-01__timeline:26014-26025	1.0
:Entity_EDL_0000209	link	NIL000000190
:Entity_EDL_0000210	type	Person
:Entity_EDL_0000210	nominal_mention	"chairman"	finan_washingtonpost__1000-01-01__timeline:48973-48980	1.0
:Entity_EDL_0000210	link	NIL000000191
:Entity_EDL_0000211	type	Person
:Entity_EDL_0000211	canonical_mention	"executives"	finan_washingtonpost__1000-01-01__timeline:2589-2598	1.0
:Entity_EDL_0000211	nominal_mention	"executives"	finan_washingtonpost__1000-01-01__timeline:2589-2598	1.0
:Entity_EDL_0000211	link	NIL000000192
:Entity_EDL_0000212	type	Organization
:Entity_EDL_0000212	canonical_mention	"UBS"	finan_washingtonpost__1000-01-01__timeline:34424-34426	1.0
:Entity_EDL_0000212	mention	"UBS"	finan_washingtonpost__1000-01-01__timeline:34424-34426	1.0
:Entity_EDL_0000212	link	NIL000000193
:Entity_EDL_0000213	type	Organization
:Entity_EDL_0000213	canonical_mention	"Lehman Brothers"	finan_washingtonpost__1000-01-01__timeline:50879-50893	1.0
:Entity_EDL_0000213	mention	"Lehman Brothers"	finan_washingtonpost__1000-01-01__timeline:50879-50893	1.0
:Entity_EDL_0000213	link	NIL000000194
:Entity_EDL_0000214	type	Organization
:Entity_EDL_0000214	mention	"Swiss National Bank"	finan_washingtonpost__1000-01-01__timeline:34317-34335	1.0
:Entity_EDL_0000214	link	NIL000000195
:Entity_EDL_0000215	type	Organization
:Entity_EDL_0000215	mention	"Federal Reserve"	finan_washingtonpost__1000-01-01__timeline:10194-10208	1.0
:Entity_EDL_0000215	link	NIL000000196
:Entity_EDL_0000216	type	Organization
:Entity_EDL_0000216	mention	"IMF"	finan_washingtonpost__1000-01-01__timeline:34006-34008	1.0
:Entity_EDL_0000216	link	20000126
:Entity_EDL_0000217	type	Facility
:Entity_EDL_0000217	mention	"Treasury Department"	finan_washingtonpost__1000-01-01__timeline:36975-36993	1.0
:Entity_EDL_0000217	link	NIL000000197
:Entity_EDL_0000218	type	Organization
:Entity_EDL_0000218	nominal_mention	"giant"	finan_washingtonpost__1000-01-01__timeline:54574-54578	1.0
:Entity_EDL_0000218	link	NIL000000198
:Entity_EDL_0000219	type	Person
:Entity_EDL_0000219	mention	"Bush"	finan_washingtonpost__1000-01-01__timeline:49247-49250	1.0
:Entity_EDL_0000219	link	NIL000000199
:Entity_EDL_0000221	type	Organization
:Entity_EDL_0000221	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:34342-34343	1.0
:Entity_EDL_0000221	link	NIL000000201
:Entity_EDL_0000222	type	Person
:Entity_EDL_0000222	mention	"Barack Obama"	finan_washingtonpost__1000-01-01__timeline:11501-11512	1.0
:Entity_EDL_0000222	link	NIL000000202
:Entity_EDL_0000223	type	Person
:Entity_EDL_0000223	nominal_mention	"director"	finan_washingtonpost__1000-01-01__timeline:49925-49932	1.0
:Entity_EDL_0000223	link	NIL000000203
:Entity_EDL_0000224	type	Person
:Entity_EDL_0000224	canonical_mention	"nominee"	finan_washingtonpost__1000-01-01__timeline:14422-14428	1.0
:Entity_EDL_0000224	nominal_mention	"nominee"	finan_washingtonpost__1000-01-01__timeline:14422-14428	1.0
:Entity_EDL_0000224	link	NIL000000204
:Entity_EDL_0000225	type	Organization
:Entity_EDL_0000225	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:34692-34693	1.0
:Entity_EDL_0000225	link	NIL000000205
:Entity_EDL_0000226	type	Person
:Entity_EDL_0000226	nominal_mention	"borrowers"	finan_washingtonpost__1000-01-01__timeline:41486-41494	1.0
:Entity_EDL_0000226	link	NIL000000206
:Entity_EDL_0000227	type	GeopoliticalEntity
:Entity_EDL_0000227	mention	"U.S."	finan_washingtonpost__1000-01-01__timeline:42713-42716	1.0
:Entity_EDL_0000227	link	6252001
:Entity_EDL_0000228	type	Person
:Entity_EDL_0000228	mention	"Sheila Bair"	finan_washingtonpost__1000-01-01__timeline:14699-14709	1.0
:Entity_EDL_0000228	link	NIL000000207
:Entity_EDL_0000229	type	Organization
:Entity_EDL_0000229	nominal_mention	"automakers"	finan_washingtonpost__1000-01-01__timeline:379-388	1.0
:Entity_EDL_0000229	link	NIL000000208
:Entity_EDL_0000230	type	Person
:Entity_EDL_0000230	nominal_mention	"workers"	finan_washingtonpost__1000-01-01__timeline:6357-6363	1.0
:Entity_EDL_0000230	link	NIL000000209
:Entity_EDL_0000231	type	Organization
:Entity_EDL_0000231	canonical_mention	"House Oversight Committee"	finan_washingtonpost__1000-01-01__timeline:18299-18323	1.0
:Entity_EDL_0000231	mention	"House Oversight Committee"	finan_washingtonpost__1000-01-01__timeline:18299-18323	1.0
:Entity_EDL_0000231	link	NIL000000210
:Entity_EDL_0000232	type	Person
:Entity_EDL_0000232	nominal_mention	"taxpayers"	finan_washingtonpost__1000-01-01__timeline:35652-35660	1.0
:Entity_EDL_0000232	link	NIL000000211
:Entity_EDL_0000233	type	Person
:Entity_EDL_0000233	mention	"Barack Obama"	finan_washingtonpost__1000-01-01__timeline:24847-24858	1.0
:Entity_EDL_0000233	link	NIL000000212
:Entity_EDL_0000234	type	Organization
:Entity_EDL_0000234	mention	"Citigroup"	finan_washingtonpost__1000-01-01__timeline:42629-42637	1.0
:Entity_EDL_0000234	link	NIL000000213
:Entity_EDL_0000235	type	Organization
:Entity_EDL_0000235	canonical_mention	"Economic Recovery Advisory Board"	finan_washingtonpost__1000-01-01__timeline:9198-9229	1.0
:Entity_EDL_0000235	mention	"Economic Recovery Advisory Board"	finan_washingtonpost__1000-01-01__timeline:9198-9229	1.0
:Entity_EDL_0000235	link	NIL000000214
:Entity_EDL_0000236	type	Organization
:Entity_EDL_0000236	mention	"Wachovia"	finan_washingtonpost__1000-01-01__timeline:41265-41272	1.0
:Entity_EDL_0000236	link	NIL000000215
:Entity_EDL_0000237	type	Organization
:Entity_EDL_0000237	mention	"Morgan Stanley"	finan_washingtonpost__1000-01-01__timeline:36858-36871	1.0
:Entity_EDL_0000237	link	NIL000000216
:Entity_EDL_0000238	type	GeopoliticalEntity
:Entity_EDL_0000238	canonical_mention	"Chicago"	finan_washingtonpost__1000-01-01__timeline:24781-24787	1.0
:Entity_EDL_0000238	mention	"Chicago"	finan_washingtonpost__1000-01-01__timeline:24781-24787	1.0
:Entity_EDL_0000238	link	4887398
:Entity_EDL_0000239	type	Person
:Entity_EDL_0000239	mention	"Barack Obama"	finan_washingtonpost__1000-01-01__timeline:47790-47801	1.0
:Entity_EDL_0000239	link	NIL000000217
:Entity_EDL_0000240	type	Organization
:Entity_EDL_0000240	pronominal_mention	"its"	finan_washingtonpost__1000-01-01__timeline:29933-29935	1.0
:Entity_EDL_0000240	link	NIL000000218
:Entity_EDL_0000241	type	Organization
:Entity_EDL_0000241	nominal_mention	"they"	finan_washingtonpost__1000-01-01__timeline:32258-32261	1.0
:Entity_EDL_0000241	link	NIL000000219
:Entity_EDL_0000243	type	Location
:Entity_EDL_0000243	mention	"Capitol Hill"	finan_washingtonpost__1000-01-01__timeline:47395-47406	1.0
:Entity_EDL_0000243	link	5772445
:Entity_EDL_0000244	type	Person
:Entity_EDL_0000244	pronominal_mention	"percent"	finan_washingtonpost__1000-01-01__timeline:19547-19553	1.0
:Entity_EDL_0000244	link	NIL000000221
:Entity_EDL_0000245	type	Organization
:Entity_EDL_0000245	canonical_mention	"3M"	finan_washingtonpost__1000-01-01__timeline:3722-3723	1.0
:Entity_EDL_0000245	mention	"3M"	finan_washingtonpost__1000-01-01__timeline:3722-3723	1.0
:Entity_EDL_0000245	link	NIL000000222
:Entity_EDL_0000246	type	Person
:Entity_EDL_0000246	canonical_mention	"editors"	finan_washingtonpost__1000-01-01__timeline:5804-5810	1.0
:Entity_EDL_0000246	nominal_mention	"editors"	finan_washingtonpost__1000-01-01__timeline:5804-5810	1.0
:Entity_EDL_0000246	link	NIL000000223
:Entity_EDL_0000247	type	Person
:Entity_EDL_0000247	nominal_mention	"borrowers"	finan_washingtonpost__1000-01-01__timeline:9535-9543	1.0
:Entity_EDL_0000247	link	NIL000000224
:Entity_EDL_0000248	type	Organization
:Entity_EDL_0000248	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:21357-21358	1.0
:Entity_EDL_0000248	link	NIL000000225
:Entity_EDL_0000249	type	Location
:Entity_EDL_0000249	mention	"Capitol Hill"	finan_washingtonpost__1000-01-01__timeline:49801-49812	1.0
:Entity_EDL_0000249	link	5772445
:Entity_EDL_0000250	type	GeopoliticalEntity
:Entity_EDL_0000250	mention	"U.S."	finan_washingtonpost__1000-01-01__timeline:26716-26719	1.0
:Entity_EDL_0000250	link	6252001
:Entity_EDL_0000251	type	GeopoliticalEntity
:Entity_EDL_0000251	mention	"Japan"	finan_washingtonpost__1000-01-01__timeline:26896-26900	1.0
:Entity_EDL_0000251	link	1861060
:Entity_EDL_0000252	type	Organization
:Entity_EDL_0000252	nominal_mention	"firms"	finan_washingtonpost__1000-01-01__timeline:52718-52722	1.0
:Entity_EDL_0000252	link	NIL000000226
:Entity_EDL_0000253	type	Organization
:Entity_EDL_0000253	mention	"House Financial Services Committee"	finan_washingtonpost__1000-01-01__timeline:14907-14940	1.0
:Entity_EDL_0000253	link	NIL000000227
:Entity_EDL_0000254	type	Organization
:Entity_EDL_0000254	mention	"National Association of Business Economists"	finan_washingtonpost__1000-01-01__timeline:25797-25839	1.0
:Entity_EDL_0000254	link	NIL000000228
:Entity_EDL_0000255	type	Organization
:Entity_EDL_0000255	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:35618-35619	1.0
:Entity_EDL_0000255	link	NIL000000229
:Entity_EDL_0000256	type	GeopoliticalEntity
:Entity_EDL_0000256	nominal_mention	"government"	finan_washingtonpost__1000-01-01__timeline:39492-39501	1.0
:Entity_EDL_0000256	link	NIL000000230
:Entity_EDL_0000257	type	Person
:Entity_EDL_0000257	nominal_mention	"workers"	finan_washingtonpost__1000-01-01__timeline:6406-6412	1.0
:Entity_EDL_0000257	link	NIL000000231
:Entity_EDL_0000258	type	Organization
:Entity_EDL_0000258	nominal_mention	"bank"	finan_washingtonpost__1000-01-01__timeline:34716-34719	1.0
:Entity_EDL_0000258	link	NIL000000232
:Entity_EDL_0000259	type	GeopoliticalEntity
:Entity_EDL_0000259	nominal_mention	"government"	finan_washingtonpost__1000-01-01__timeline:39686-39695	0.000
:Entity_EDL_0000259	link	NIL000000233
:Entity_EDL_0000260	type	Person
:Entity_EDL_0000260	canonical_mention	"heads"	finan_washingtonpost__1000-01-01__timeline:12521-12525	1.0
:Entity_EDL_0000260	nominal_mention	"heads"	finan_washingtonpost__1000-01-01__timeline:12521-12525	1.0
:Entity_EDL_0000260	link	NIL000000234
:Entity_EDL_0000261	type	Person
:Entity_EDL_0000261	canonical_mention	"Richard Syron"	finan_washingtonpost__1000-01-01__timeline:2291-2303	1.0
:Entity_EDL_0000261	mention	"Richard Syron"	finan_washingtonpost__1000-01-01__timeline:2291-2303	1.0
:Entity_EDL_0000261	link	NIL000000235
:Entity_EDL_0000262	type	GeopoliticalEntity
:Entity_EDL_0000262	canonical_mention	"Washington"	finan_washingtonpost__1000-01-01__timeline:7485-7494	1.0
:Entity_EDL_0000262	mention	"Washington"	finan_washingtonpost__1000-01-01__timeline:7485-7494	1.0
:Entity_EDL_0000262	link	5815135
:Entity_EDL_0000263	type	Organization
:Entity_EDL_0000263	mention	"Washington Mutual"	finan_washingtonpost__1000-01-01__timeline:48579-48595	1.0
:Entity_EDL_0000263	link	NIL000000236
:Entity_EDL_0000264	type	Person
:Entity_EDL_0000264	canonical_mention	"Timothy Geithner"	finan_washingtonpost__1000-01-01__timeline:12130-12145	1.0
:Entity_EDL_0000264	mention	"Timothy Geithner"	finan_washingtonpost__1000-01-01__timeline:12130-12145	1.0
:Entity_EDL_0000264	link	NIL000000237
:Entity_EDL_0000265	type	Organization
:Entity_EDL_0000265	canonical_mention	"Wells Fargo"	finan_washingtonpost__1000-01-01__timeline:38822-38832	1.0
:Entity_EDL_0000265	mention	"Wells Fargo"	finan_washingtonpost__1000-01-01__timeline:38822-38832	1.0
:Entity_EDL_0000265	link	NIL000000238
:Entity_EDL_0000266	type	Organization
:Entity_EDL_0000266	canonical_mention	"National Public Radio"	finan_washingtonpost__1000-01-01__timeline:2143-2163	1.0
:Entity_EDL_0000266	mention	"National Public Radio"	finan_washingtonpost__1000-01-01__timeline:2143-2163	1.0
:Entity_EDL_0000266	link	NIL000000239
:Entity_EDL_0000267	type	Person
:Entity_EDL_0000267	canonical_mention	"governors"	finan_washingtonpost__1000-01-01__timeline:7131-7139	1.0
:Entity_EDL_0000267	nominal_mention	"governors"	finan_washingtonpost__1000-01-01__timeline:7131-7139	1.0
:Entity_EDL_0000267	link	NIL000000240
:Entity_EDL_0000268	type	Organization
:Entity_EDL_0000268	mention	"Wachovia"	finan_washingtonpost__1000-01-01__timeline:42663-42670	1.0
:Entity_EDL_0000268	link	NIL000000241
:Entity_EDL_0000269	type	Person
:Entity_EDL_0000269	mention	"Barack Obama"	finan_washingtonpost__1000-01-01__timeline:9118-9129	1.0
:Entity_EDL_0000269	link	NIL000000242
:Entity_EDL_0000270	type	Organization
:Entity_EDL_0000270	nominal_mention	"government"	finan_washingtonpost__1000-01-01__timeline:27278-27287	1.0
:Entity_EDL_0000270	link	NIL000000243
:Entity_EDL_0000271	type	Person
:Entity_EDL_0000271	canonical_mention	"taxpayers"	finan_washingtonpost__1000-01-01__timeline:4307-4315	1.0
:Entity_EDL_0000271	nominal_mention	"taxpayers"	finan_washingtonpost__1000-01-01__timeline:4307-4315	1.0
:Entity_EDL_0000271	link	NIL000000244
:Entity_EDL_0000272	type	Person
:Entity_EDL_0000272	canonical_mention	"Obama"	finan_washingtonpost__1000-01-01__timeline:20539-20543	1.0
:Entity_EDL_0000272	mention	"Obama"	finan_washingtonpost__1000-01-01__timeline:20539-20543	1.0
:Entity_EDL_0000272	link	30001628
:Entity_EDL_0000273	type	Organization
:Entity_EDL_0000273	pronominal_mention	"its"	finan_washingtonpost__1000-01-01__timeline:23169-23171	1.0
:Entity_EDL_0000273	link	NIL000000245
:Entity_EDL_0000274	type	Person
:Entity_EDL_0000274	canonical_mention	"reporters"	finan_washingtonpost__1000-01-01__timeline:5816-5824	1.0
:Entity_EDL_0000274	nominal_mention	"reporters"	finan_washingtonpost__1000-01-01__timeline:5816-5824	1.0
:Entity_EDL_0000274	link	NIL000000246
:Entity_EDL_0000275	type	Person
:Entity_EDL_0000275	canonical_mention	"workforce"	finan_washingtonpost__1000-01-01__timeline:2828-2836	1.0
:Entity_EDL_0000275	nominal_mention	"workforce"	finan_washingtonpost__1000-01-01__timeline:2828-2836	1.0
:Entity_EDL_0000275	link	NIL000000247
:Entity_EDL_0000276	type	Organization
:Entity_EDL_0000276	pronominal_mention	"it"	finan_washingtonpost__1000-01-01__timeline:32388-32389	1.0
:Entity_EDL_0000276	link	NIL000000248
:Entity_EDL_0000277	type	Organization
:Entity_EDL_0000277	mention	"Wachovia"	finan_washingtonpost__1000-01-01__timeline:38802-38809	1.0
:Entity_EDL_0000277	link	NIL000000249
:Entity_EDL_0000278	type	Organization
:Entity_EDL_0000278	mention	"AIG"	finan_washingtonpost__1000-01-01__timeline:39509-39511	1.0
:Entity_EDL_0000278	link	NIL000000250
:Entity_EDL_0000279	type	Organization
:Entity_EDL_0000279	mention	"Wells Fargo"	finan_washingtonpost__1000-01-01__timeline:41278-41288	1.0
:Entity_EDL_0000279	link	NIL000000251
:Entity_EDL_0000280	type	Person
:Entity_EDL_0000280	pronominal_mention	"percent"	finan_washingtonpost__1000-01-01__timeline:29922-29928	1.0
:Entity_EDL_0000280	link	NIL000000252
:Entity_EDL_0000281	type	GeopoliticalEntity
:Entity_EDL_0000281	mention	"United States"	finan_washingtonpost__1000-01-01__timeline:6145-6157	1.0
:Entity_EDL_0000281	link	6252001
:Entity_EDL_0000282	type	Organization
:Entity_EDL_0000282	nominal_mention	"employers"	finan_washingtonpost__1000-01-01__timeline:6170-6178	1.0
:Entity_EDL_0000282	link	NIL000000253
:Entity_EDL_0000283	type	Organization
:Entity_EDL_0000283	mention	"GM"	finan_washingtonpost__1000-01-01__timeline:38700-38701	1.0
:Entity_EDL_0000283	link	NIL000000254
:Entity_EDL_0000284	type	Organization
:Entity_EDL_0000284	canonical_mention	"each other"	finan_washingtonpost__1000-01-01__timeline:54005-54014	1.0
:Entity_EDL_0000284	pronominal_mention	"each other"	finan_washingtonpost__1000-01-01__timeline:54005-54014	1.0
:Entity_EDL_0000284	link	NIL000000255
:Entity_EDL_0000285	type	Organization
:Entity_EDL_0000285	canonical_mention	"Yahoo"	finan_washingtonpost__1000-01-01__timeline:2133-2137	1.0
:Entity_EDL_0000285	mention	"Yahoo"	finan_washingtonpost__1000-01-01__timeline:2133-2137	1.0
:Entity_EDL_0000285	link	NIL000000256
:Entity_EDL_0000286	type	Person
:Entity_EDL_0000286	nominal_mention	"daughters"	finan_washingtonpost__1000-01-01__timeline:24704-24712	1.0
:Entity_EDL_0000286	link	NIL000000257
:Entity_EDL_0000287	type	Organization
:Entity_EDL_0000287	mention	"Freddie Mac"	finan_washingtonpost__1000-01-01__timeline:2577-2587	1.0
:Entity_EDL_0000287	link	NIL000000258
:Entity_EDL_0000288	type	Organization
:Entity_EDL_0000288	nominal_mention	"industry"	finan_washingtonpost__1000-01-01__timeline:1794-1801	1.0
:Entity_EDL_0000288	link	NIL000000259
:Entity_EDL_0000289	type	Organization
:Entity_EDL_0000289	canonical_mention	"AT&T"	finan_washingtonpost__1000-01-01__timeline:5390-5393	1.0
:Entity_EDL_0000289	mention	"AT&T"	finan_washingtonpost__1000-01-01__timeline:5390-5393	1.0
:Entity_EDL_0000289	link	NIL000000260
:Entity_EDL_0000290	type	Person
:Entity_EDL_0000290	nominal_mention	"households"	finan_washingtonpost__1000-01-01__timeline:10341-10350	1.0
:Entity_EDL_0000290	link	NIL000000261
:Entity_EDL_0000291	type	Organization
:Entity_EDL_0000291	nominal_mention	"banks"	finan_washingtonpost__1000-01-01__timeline:27796-27800	1.0
:Entity_EDL_0000291	link	NIL000000262
:Entity_EDL_0000292	type	Person
:Entity_EDL_0000292	nominal_mention	"economists"	finan_washingtonpost__1000-01-01__timeline:25857-25866	1.0
:Entity_EDL_0000292	link	NIL000000263
:Entity_EDL_0000294	type	Person
:Entity_EDL_0000294	canonical_mention	"Arnold Schwarzenegger"	finan_washingtonpost__1000-01-01__timeline:42855-42875	1.0
:Entity_EDL_0000294	mention	"Arnold Schwarzenegger"	finan_washingtonpost__1000-01-01__timeline:42855-42875	1.0
:Entity_EDL_0000294	link	NIL000000265
:Entity_EDL_0000295	type	Organization
:Entity_EDL_0000295	mention	"Congress"	finan_washingtonpost__1000-01-01__timeline:44811-44818	1.0
:Entity_EDL_0000295	link	20000051
:Entity_EDL_0000296	type	Person
:Entity_EDL_0000296	nominal_mention	"employers"	finan_washingtonpost__1000-01-01__timeline:42718-42726	1.0
:Entity_EDL_0000296	link	NIL000000266
:Entity_EDL_0000297	type	Organization
:Entity_EDL_0000297	mention	"J.P. Morgan Chase"	finan_washingtonpost__1000-01-01__timeline:48688-48704	1.0
:Entity_EDL_0000297	link	NIL000000267
:Entity_EDL_0000298	type	Organization
:Entity_EDL_0000298	mention	"House"	finan_washingtonpost__1000-01-01__timeline:20244-20248	1.0
:Entity_EDL_0000298	link	NIL000000268
