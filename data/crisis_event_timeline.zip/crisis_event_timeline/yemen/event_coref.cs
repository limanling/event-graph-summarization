:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_afp__1000-01-01__timeline:578-585	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_afp__1000-01-01__timeline:578-585	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000101	yemen_afp__1000-01-01__timeline:592-607	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_telegraphs__1000-01-01__timeline:104-111	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_telegraphs__1000-01-01__timeline:104-111	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	yemen_latimes__1000-01-01__timeline:4628-4637	1.000
:Event_0000000	canonical_mention.actual	"protesters"	yemen_latimes__1000-01-01__timeline:4628-4637	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000018	yemen_latimes__1000-01-01__timeline:4628-4637	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_dailystar__1000-01-01__timeline:207-214	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_dailystar__1000-01-01__timeline:207-214	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000188	yemen_dailystar__1000-01-01__timeline:161-173	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	yemen_telegraphs__1000-01-01__timeline:8329-8338	1.000
:Event_0000000	canonical_mention.actual	"protesters"	yemen_telegraphs__1000-01-01__timeline:8329-8338	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000020	yemen_telegraphs__1000-01-01__timeline:8320-8324	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_latimes__1000-01-01__timeline:1510-1517	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_latimes__1000-01-01__timeline:1510-1517	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_telegraphs__1000-01-01__timeline:1641-1648	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_telegraphs__1000-01-01__timeline:1641-1648	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000081	yemen_telegraphs__1000-01-01__timeline:1587-1595	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	yemen_dailystar__1000-01-01__timeline:643-652	1.000
:Event_0000000	canonical_mention.actual	"protesters"	yemen_dailystar__1000-01-01__timeline:643-652	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000001	yemen_dailystar__1000-01-01__timeline:597-602	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000068	yemen_dailystar__1000-01-01__timeline:643-652	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	yemen_telegraphs__1000-01-01__timeline:5117-5126	1.000
:Event_0000000	canonical_mention.actual	"protesters"	yemen_telegraphs__1000-01-01__timeline:5117-5126	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000175	yemen_telegraphs__1000-01-01__timeline:5117-5126	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000108	yemen_telegraphs__1000-01-01__timeline:5144-5147	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_voa__1000-01-01__timeline:480-487	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_voa__1000-01-01__timeline:480-487	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"demonstrators"	yemen_voa__1000-01-01__timeline:161-173	1.000
:Event_0000000	canonical_mention.actual	"demonstrators"	yemen_voa__1000-01-01__timeline:161-173	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000120	yemen_voa__1000-01-01__timeline:161-173	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	yemen_washingtonpost__1000-01-01__timeline:473-482	1.000
:Event_0000000	canonical_mention.actual	"protesters"	yemen_washingtonpost__1000-01-01__timeline:473-482	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000121	yemen_washingtonpost__1000-01-01__timeline:473-482	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_telegraphs__1000-01-01__timeline:2515-2522	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_telegraphs__1000-01-01__timeline:2515-2522	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_dailystar__1000-01-01__timeline:1120-1127	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_dailystar__1000-01-01__timeline:1120-1127	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	yemen_dailystar__1000-01-01__timeline:1085-1089	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	yemen_latimes__1000-01-01__timeline:610-619	1.000
:Event_0000000	canonical_mention.actual	"protesters"	yemen_latimes__1000-01-01__timeline:610-619	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000073	yemen_latimes__1000-01-01__timeline:610-619	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	yemen_voa__1000-01-01__timeline:643-652	1.000
:Event_0000000	canonical_mention.actual	"protesters"	yemen_voa__1000-01-01__timeline:643-652	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000001	yemen_voa__1000-01-01__timeline:597-602	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000177	yemen_voa__1000-01-01__timeline:643-652	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_washingtonpost__1000-01-01__timeline:211-218	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_washingtonpost__1000-01-01__timeline:211-218	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"demonstrators"	yemen_dailystar__1000-01-01__timeline:161-173	1.000
:Event_0000000	canonical_mention.actual	"demonstrators"	yemen_dailystar__1000-01-01__timeline:161-173	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000188	yemen_dailystar__1000-01-01__timeline:161-173	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	yemen_telegraphs__1000-01-01__timeline:3155-3164	1.000
:Event_0000000	canonical_mention.actual	"protesters"	yemen_telegraphs__1000-01-01__timeline:3155-3164	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000082	yemen_telegraphs__1000-01-01__timeline:3155-3164	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	yemen_telegraphs__1000-01-01__timeline:3173-3177	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	yemen_latimes__1000-01-01__timeline:3807-3816	1.000
:Event_0000000	canonical_mention.actual	"protesters"	yemen_latimes__1000-01-01__timeline:3807-3816	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000078	yemen_latimes__1000-01-01__timeline:3770-3776	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000079	yemen_latimes__1000-01-01__timeline:3807-3816	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_dailystar__1000-01-01__timeline:480-487	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_dailystar__1000-01-01__timeline:480-487	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	yemen_latimes__1000-01-01__timeline:1767-1776	1.000
:Event_0000000	canonical_mention.actual	"protesters"	yemen_latimes__1000-01-01__timeline:1767-1776	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000129	yemen_latimes__1000-01-01__timeline:1767-1776	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	yemen_latimes__1000-01-01__timeline:1902-1911	1.000
:Event_0000000	canonical_mention.actual	"protesters"	yemen_latimes__1000-01-01__timeline:1902-1911	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000089	yemen_latimes__1000-01-01__timeline:1902-1911	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	yemen_washingtonpost__1000-01-01__timeline:834-843	1.000
:Event_0000000	canonical_mention.actual	"protesters"	yemen_washingtonpost__1000-01-01__timeline:834-843	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000199	yemen_washingtonpost__1000-01-01__timeline:834-843	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_telegraphs__1000-01-01__timeline:415-422	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_telegraphs__1000-01-01__timeline:415-422	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000162	yemen_telegraphs__1000-01-01__timeline:448-453	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000142	yemen_telegraphs__1000-01-01__timeline:464-470	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"demonstrations"	yemen_telegraphs__1000-01-01__timeline:5020-5033	1.000
:Event_0000000	canonical_mention.actual	"demonstrations"	yemen_telegraphs__1000-01-01__timeline:5020-5033	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	yemen_telegraphs__1000-01-01__timeline:5008-5012	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_voa__1000-01-01__timeline:207-214	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_voa__1000-01-01__timeline:207-214	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000120	yemen_voa__1000-01-01__timeline:161-173	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	yemen_latimes__1000-01-01__timeline:1264-1273	1.000
:Event_0000000	canonical_mention.actual	"protesters"	yemen_latimes__1000-01-01__timeline:1264-1273	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000145	yemen_latimes__1000-01-01__timeline:1264-1273	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"Protests"	yemen_telegraphs__1000-01-01__timeline:8097-8104	1.000
:Event_0000000	canonical_mention.actual	"Protests"	yemen_telegraphs__1000-01-01__timeline:8097-8104	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_latimes__1000-01-01__timeline:2158-2165	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_latimes__1000-01-01__timeline:2158-2165	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_voa__1000-01-01__timeline:1120-1127	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_voa__1000-01-01__timeline:1120-1127	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000053	yemen_voa__1000-01-01__timeline:1085-1089	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protest"	yemen_latimes__1000-01-01__timeline:466-472	1.000
:Event_0000000	canonical_mention.actual	"protest"	yemen_latimes__1000-01-01__timeline:466-472	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000131	yemen_latimes__1000-01-01__timeline:458-464	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000077	yemen_latimes__1000-01-01__timeline:487-493	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	yemen_afp__1000-01-01__timeline:2829-2836	1.000
:Event_0000000	canonical_mention.actual	"protests"	yemen_afp__1000-01-01__timeline:2829-2836	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000006	yemen_afp__1000-01-01__timeline:2791-2794	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"uprising"	yemen_washingtonpost__1000-01-01__timeline:1065-1072	1.000
:Event_0000000	canonical_mention.actual	"uprising"	yemen_washingtonpost__1000-01-01__timeline:1065-1072	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"demonstration"	yemen_afp__1000-01-01__timeline:390-402	1.000
:Event_0000000	canonical_mention.actual	"demonstration"	yemen_afp__1000-01-01__timeline:390-402	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000080	yemen_afp__1000-01-01__timeline:365-373	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"ouster"	yemen_voa__1000-01-01__timeline:363-368	1.000
:Event_0000001	canonical_mention.actual	"ouster"	yemen_voa__1000-01-01__timeline:363-368	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	yemen_voa__1000-01-01__timeline:373-377	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"ouster"	yemen_afp__1000-01-01__timeline:82-87	1.000
:Event_0000001	canonical_mention.actual	"ouster"	yemen_afp__1000-01-01__timeline:82-87	1.000
:Event_0000001	Personnel.EndPosition_Place.actual	:Entity_EDL_0000012	yemen_afp__1000-01-01__timeline:34-40	1.000
:Event_0000001	Personnel.EndPosition_Place.actual	:Entity_EDL_0000210	yemen_afp__1000-01-01__timeline:46-50	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000163	yemen_afp__1000-01-01__timeline:102-119	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"leave office"	yemen_latimes__1000-01-01__timeline:2396-2407	1.000
:Event_0000001	canonical_mention.actual	"leave office"	yemen_latimes__1000-01-01__timeline:2396-2407	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	yemen_latimes__1000-01-01__timeline:2374-2391	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	yemen_washingtonpost__1000-01-01__timeline:1989-1997	1.000
:Event_0000001	canonical_mention.actual	"step down"	yemen_washingtonpost__1000-01-01__timeline:1989-1997	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000052	yemen_washingtonpost__1000-01-01__timeline:1977-1978	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	yemen_telegraphs__1000-01-01__timeline:7720-7728	1.000
:Event_0000001	canonical_mention.actual	"step down"	yemen_telegraphs__1000-01-01__timeline:7720-7728	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000045	yemen_telegraphs__1000-01-01__timeline:7691-7693	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"leave"	yemen_dailystar__1000-01-01__timeline:1771-1775	1.000
:Event_0000001	canonical_mention.actual	"leave"	yemen_dailystar__1000-01-01__timeline:1771-1775	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	yemen_dailystar__1000-01-01__timeline:1762-1766	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	yemen_latimes__1000-01-01__timeline:2072-2080	1.000
:Event_0000001	canonical_mention.actual	"step down"	yemen_latimes__1000-01-01__timeline:2072-2080	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	yemen_latimes__1000-01-01__timeline:2005-2022	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	yemen_latimes__1000-01-01__timeline:4308-4316	1.000
:Event_0000001	canonical_mention.actual	"step down"	yemen_latimes__1000-01-01__timeline:4308-4316	1.000
:Event_0000001	Personnel.EndPosition_Place.actual	:Entity_EDL_0000151	yemen_latimes__1000-01-01__timeline:4157-4163	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	yemen_latimes__1000-01-01__timeline:4271-4288	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	yemen_afp__1000-01-01__timeline:1771-1779	1.000
:Event_0000001	canonical_mention.actual	"step down"	yemen_afp__1000-01-01__timeline:1771-1779	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000192	yemen_afp__1000-01-01__timeline:1754-1755	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step aside"	yemen_telegraphs__1000-01-01__timeline:2841-2850	1.000
:Event_0000001	canonical_mention.actual	"step aside"	yemen_telegraphs__1000-01-01__timeline:2841-2850	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:2832-2836	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"exit"	yemen_afp__1000-01-01__timeline:1273-1276	1.000
:Event_0000001	canonical_mention.actual	"exit"	yemen_afp__1000-01-01__timeline:1273-1276	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	yemen_afp__1000-01-01__timeline:1264-1268	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	yemen_washingtonpost__1000-01-01__timeline:499-507	1.000
:Event_0000001	canonical_mention.actual	"step down"	yemen_washingtonpost__1000-01-01__timeline:499-507	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000117	yemen_washingtonpost__1000-01-01__timeline:496-497	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	yemen_telegraphs__1000-01-01__timeline:1322-1330	1.000
:Event_0000001	canonical_mention.actual	"step down"	yemen_telegraphs__1000-01-01__timeline:1322-1330	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:1306-1310	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"ouster"	yemen_washingtonpost__1000-01-01__timeline:1088-1093	1.000
:Event_0000001	canonical_mention.actual	"ouster"	yemen_washingtonpost__1000-01-01__timeline:1088-1093	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000200	yemen_washingtonpost__1000-01-01__timeline:1084-1086	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"leave"	yemen_voa__1000-01-01__timeline:1771-1775	1.000
:Event_0000001	canonical_mention.actual	"leave"	yemen_voa__1000-01-01__timeline:1771-1775	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	yemen_voa__1000-01-01__timeline:1762-1766	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"ouster"	yemen_voa__1000-01-01__timeline:232-237	1.000
:Event_0000001	canonical_mention.actual	"ouster"	yemen_voa__1000-01-01__timeline:232-237	1.000
:Event_0000001	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000012	yemen_voa__1000-01-01__timeline:242-248	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000157	yemen_voa__1000-01-01__timeline:253-261	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	yemen_washingtonpost__1000-01-01__timeline:2165-2173	1.000
:Event_0000001	canonical_mention.actual	"step down"	yemen_washingtonpost__1000-01-01__timeline:2165-2173	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	yemen_washingtonpost__1000-01-01__timeline:2104-2108	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"ouster"	yemen_dailystar__1000-01-01__timeline:363-368	1.000
:Event_0000001	canonical_mention.actual	"ouster"	yemen_dailystar__1000-01-01__timeline:363-368	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	yemen_dailystar__1000-01-01__timeline:373-377	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	yemen_latimes__1000-01-01__timeline:145-153	1.000
:Event_0000001	canonical_mention.actual	"step down"	yemen_latimes__1000-01-01__timeline:145-153	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	yemen_latimes__1000-01-01__timeline:121-138	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	yemen_latimes__1000-01-01__timeline:2537-2545	1.000
:Event_0000001	canonical_mention.actual	"step down"	yemen_latimes__1000-01-01__timeline:2537-2545	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	yemen_telegraphs__1000-01-01__timeline:2587-2595	1.000
:Event_0000001	canonical_mention.actual	"step down"	yemen_telegraphs__1000-01-01__timeline:2587-2595	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:2571-2575	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step aside"	yemen_latimes__1000-01-01__timeline:1418-1427	1.000
:Event_0000001	canonical_mention.actual	"step aside"	yemen_latimes__1000-01-01__timeline:1418-1427	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"ouster"	yemen_dailystar__1000-01-01__timeline:232-237	1.000
:Event_0000001	canonical_mention.actual	"ouster"	yemen_dailystar__1000-01-01__timeline:232-237	1.000
:Event_0000001	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000156	yemen_dailystar__1000-01-01__timeline:242-248	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000206	yemen_dailystar__1000-01-01__timeline:253-261	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"attack"	yemen_latimes__1000-01-01__timeline:3138-3143	1.000
:Event_0000002	canonical_mention.actual	"attack"	yemen_latimes__1000-01-01__timeline:3138-3143	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000004	yemen_latimes__1000-01-01__timeline:3085-3089	1.000
:Event_0000002	Conflict.Attack_Instrument.actual	:Entity_EDL_0000021	yemen_latimes__1000-01-01__timeline:3131-3136	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"attack"	yemen_telegraphs__1000-01-01__timeline:6244-6249	1.000
:Event_0000002	canonical_mention.actual	"attack"	yemen_telegraphs__1000-01-01__timeline:6244-6249	1.000
:Event_0000002	Conflict.Attack_Target.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:6254-6258	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"attack"	yemen_washingtonpost__1000-01-01__timeline:824-829	1.000
:Event_0000002	canonical_mention.actual	"attack"	yemen_washingtonpost__1000-01-01__timeline:824-829	1.000
:Event_0000002	Conflict.Attack_Target.actual	:Entity_EDL_0000199	yemen_washingtonpost__1000-01-01__timeline:834-843	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"attack"	yemen_voa__1000-01-01__timeline:1908-1913	1.000
:Event_0000002	canonical_mention.actual	"attack"	yemen_voa__1000-01-01__timeline:1908-1913	1.000
:Event_0000002	Conflict.Attack_Target.actual	:Entity_EDL_0000146	yemen_voa__1000-01-01__timeline:1874-1882	1.000
:Event_0000002	Conflict.Attack_Instrument.actual	:Entity_EDL_0000154	yemen_voa__1000-01-01__timeline:1901-1906	1.000
:Event_0000002	Conflict.Attack_Target.actual	:Entity_EDL_0000009	yemen_voa__1000-01-01__timeline:1935-1942	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000001	yemen_voa__1000-01-01__timeline:1947-1952	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"attack"	yemen_dailystar__1000-01-01__timeline:1908-1913	1.000
:Event_0000002	canonical_mention.actual	"attack"	yemen_dailystar__1000-01-01__timeline:1908-1913	1.000
:Event_0000002	Conflict.Attack_Target.actual	:Entity_EDL_0000171	yemen_dailystar__1000-01-01__timeline:1874-1882	1.000
:Event_0000002	Conflict.Attack_Instrument.actual	:Entity_EDL_0000011	yemen_dailystar__1000-01-01__timeline:1901-1906	1.000
:Event_0000002	Conflict.Attack_Target.actual	:Entity_EDL_0000030	yemen_dailystar__1000-01-01__timeline:1935-1942	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000001	yemen_dailystar__1000-01-01__timeline:1947-1952	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"attack"	yemen_telegraphs__1000-01-01__timeline:7203-7208	1.000
:Event_0000002	canonical_mention.actual	"attack"	yemen_telegraphs__1000-01-01__timeline:7203-7208	1.000
:Event_0000002	Conflict.Attack_Attacker.actual	:Entity_EDL_0000028	yemen_telegraphs__1000-01-01__timeline:7185-7197	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"attack"	yemen_telegraphs__1000-01-01__timeline:6729-6734	1.000
:Event_0000002	canonical_mention.actual	"attack"	yemen_telegraphs__1000-01-01__timeline:6729-6734	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"attack"	yemen_washingtonpost__1000-01-01__timeline:1545-1550	1.000
:Event_0000002	canonical_mention.actual	"attack"	yemen_washingtonpost__1000-01-01__timeline:1545-1550	1.000
:Event_0000002	Conflict.Attack_Instrument.actual	:Entity_EDL_0000011	yemen_washingtonpost__1000-01-01__timeline:1538-1543	1.000
:Event_0000002	Conflict.Attack_Target.actual	:Entity_EDL_0000022	yemen_washingtonpost__1000-01-01__timeline:1579-1586	1.000
:Event_0000003	type	Movement.TransportArtifact
:Event_0000003	mention.actual	"leave"	yemen_telegraphs__1000-01-01__timeline:2284-2288	1.000
:Event_0000003	canonical_mention.actual	"leave"	yemen_telegraphs__1000-01-01__timeline:2284-2288	1.000
:Event_0000003	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:2275-2279	1.000
:Event_0000003	type	Movement.TransportArtifact
:Event_0000003	mention.actual	"left"	yemen_dailystar__1000-01-01__timeline:2418-2421	1.000
:Event_0000003	canonical_mention.actual	"left"	yemen_dailystar__1000-01-01__timeline:2418-2421	1.000
:Event_0000003	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000000	yemen_dailystar__1000-01-01__timeline:2412-2416	1.000
:Event_0000003	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000109	yemen_dailystar__1000-01-01__timeline:2427-2433	1.000
:Event_0000003	type	Movement.TransportArtifact
:Event_0000003	mention.actual	"left"	yemen_voa__1000-01-01__timeline:2418-2421	1.000
:Event_0000003	canonical_mention.actual	"left"	yemen_voa__1000-01-01__timeline:2418-2421	1.000
:Event_0000003	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000000	yemen_voa__1000-01-01__timeline:2412-2416	1.000
:Event_0000003	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000147	yemen_voa__1000-01-01__timeline:2427-2433	1.000
:Event_0000003	type	Movement.TransportArtifact
:Event_0000003	mention.actual	"leaves"	yemen_latimes__1000-01-01__timeline:3078-3083	1.000
:Event_0000003	canonical_mention.actual	"leaves"	yemen_latimes__1000-01-01__timeline:3078-3083	1.000
:Event_0000003	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000002	yemen_latimes__1000-01-01__timeline:3059-3076	1.000
:Event_0000003	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000004	yemen_latimes__1000-01-01__timeline:3085-3089	1.000
:Event_0000003	type	Movement.TransportArtifact
:Event_0000003	mention.actual	"flies"	yemen_dailystar__1000-01-01__timeline:2189-2193	1.000
:Event_0000003	canonical_mention.actual	"flies"	yemen_dailystar__1000-01-01__timeline:2189-2193	1.000
:Event_0000003	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000000	yemen_dailystar__1000-01-01__timeline:2183-2187	1.000
:Event_0000003	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000005	yemen_dailystar__1000-01-01__timeline:2198-2209	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"killing"	yemen_voa__1000-01-01__timeline:688-694	1.000
:Event_0000004	canonical_mention.actual	"killing"	yemen_voa__1000-01-01__timeline:688-694	1.000
:Event_0000004	Life.Die_Place.actual	:Entity_EDL_0000001	yemen_voa__1000-01-01__timeline:597-602	1.000
:Event_0000004	Life.Die_Agent.actual	:Entity_EDL_0000008	yemen_voa__1000-01-01__timeline:623-628	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000166	yemen_voa__1000-01-01__timeline:709-714	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"killing"	yemen_voa__1000-01-01__timeline:859-865	1.000
:Event_0000004	canonical_mention.actual	"killing"	yemen_voa__1000-01-01__timeline:859-865	1.000
:Event_0000004	Life.Die_Agent.actual	:Entity_EDL_0000134	yemen_voa__1000-01-01__timeline:821-826	1.000
:Event_0000004	Life.Die_Place.actual	:Entity_EDL_0000001	yemen_voa__1000-01-01__timeline:850-855	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000132	yemen_voa__1000-01-01__timeline:879-884	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"killing"	yemen_latimes__1000-01-01__timeline:3787-3793	1.000
:Event_0000004	canonical_mention.actual	"killing"	yemen_latimes__1000-01-01__timeline:3787-3793	1.000
:Event_0000004	Life.Die_Agent.actual	:Entity_EDL_0000207	yemen_latimes__1000-01-01__timeline:3702-3707	1.000
:Event_0000004	Life.Die_Place.actual	:Entity_EDL_0000078	yemen_latimes__1000-01-01__timeline:3770-3776	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000079	yemen_latimes__1000-01-01__timeline:3807-3816	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"killing"	yemen_telegraphs__1000-01-01__timeline:8158-8164	1.000
:Event_0000004	canonical_mention.actual	"killing"	yemen_telegraphs__1000-01-01__timeline:8158-8164	1.000
:Event_0000004	Life.Die_Agent.actual	:Entity_EDL_0000164	yemen_telegraphs__1000-01-01__timeline:8127-8132	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000148	yemen_telegraphs__1000-01-01__timeline:8142-8154	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000178	yemen_telegraphs__1000-01-01__timeline:8166-8167	1.000
:Event_0000005	type	Life.Die
:Event_0000005	mention.actual	"killing"	yemen_dailystar__1000-01-01__timeline:688-694	1.000
:Event_0000005	canonical_mention.actual	"killing"	yemen_dailystar__1000-01-01__timeline:688-694	1.000
:Event_0000005	Life.Die_Place.actual	:Entity_EDL_0000001	yemen_dailystar__1000-01-01__timeline:597-602	1.000
:Event_0000005	Life.Die_Agent.actual	:Entity_EDL_0000143	yemen_dailystar__1000-01-01__timeline:623-628	1.000
:Event_0000005	Life.Die_Victim.actual	:Entity_EDL_0000189	yemen_dailystar__1000-01-01__timeline:709-714	1.000
:Event_0000005	type	Life.Die
:Event_0000005	mention.actual	"killing"	yemen_afp__1000-01-01__timeline:884-890	1.000
:Event_0000005	canonical_mention.actual	"killing"	yemen_afp__1000-01-01__timeline:884-890	1.000
:Event_0000005	Life.Die_Agent.actual	:Entity_EDL_0000059	yemen_afp__1000-01-01__timeline:830-838	1.000
:Event_0000005	Life.Die_Victim.actual	:Entity_EDL_0000191	yemen_afp__1000-01-01__timeline:853-865	1.000
:Event_0000005	Life.Die_Place.actual	:Entity_EDL_0000150	yemen_afp__1000-01-01__timeline:874-880	1.000
:Event_0000005	Life.Die_Victim.actual	:Entity_EDL_0000190	yemen_afp__1000-01-01__timeline:892-893	1.000
:Event_0000005	type	Life.Die
:Event_0000005	mention.actual	"killing"	yemen_dailystar__1000-01-01__timeline:859-865	1.000
:Event_0000005	canonical_mention.actual	"killing"	yemen_dailystar__1000-01-01__timeline:859-865	1.000
:Event_0000005	Life.Die_Agent.actual	:Entity_EDL_0000051	yemen_dailystar__1000-01-01__timeline:821-826	1.000
:Event_0000005	Life.Die_Place.actual	:Entity_EDL_0000001	yemen_dailystar__1000-01-01__timeline:850-855	1.000
:Event_0000005	Life.Die_Victim.actual	:Entity_EDL_0000168	yemen_dailystar__1000-01-01__timeline:879-884	1.000
:Event_0000006	type	Personnel.Elect
:Event_0000006	mention.actual	"election"	yemen_afp__1000-01-01__timeline:5432-5439	1.000
:Event_0000006	canonical_mention.actual	"election"	yemen_afp__1000-01-01__timeline:5432-5439	1.000
:Event_0000006	type	Personnel.Elect
:Event_0000006	mention.actual	"election"	yemen_afp__1000-01-01__timeline:4848-4855	1.000
:Event_0000006	canonical_mention.actual	"election"	yemen_afp__1000-01-01__timeline:4848-4855	1.000
:Event_0000006	Personnel.Elect_Elect.actual	:Entity_EDL_0000010	yemen_afp__1000-01-01__timeline:4813-4816	1.000
:Event_0000006	type	Personnel.Elect
:Event_0000006	mention.actual	"election"	yemen_afp__1000-01-01__timeline:5070-5077	1.000
:Event_0000006	canonical_mention.actual	"election"	yemen_afp__1000-01-01__timeline:5070-5077	1.000
:Event_0000006	Personnel.Elect_Elect.actual	:Entity_EDL_0000010	yemen_afp__1000-01-01__timeline:5023-5026	1.000
:Event_0000007	type	Contact.Meet
:Event_0000007	mention.actual	"talks"	yemen_telegraphs__1000-01-01__timeline:2390-2394	1.000
:Event_0000007	canonical_mention.actual	"talks"	yemen_telegraphs__1000-01-01__timeline:2390-2394	1.000
:Event_0000007	type	Contact.Meet
:Event_0000007	mention.actual	"talks"	yemen_telegraphs__1000-01-01__timeline:1709-1713	1.000
:Event_0000007	canonical_mention.actual	"talks"	yemen_telegraphs__1000-01-01__timeline:1709-1713	1.000
:Event_0000007	Contact.Meet_Participant.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:1697-1701	1.000
:Event_0000007	Contact.Meet_Participant.actual	:Entity_EDL_0000037	yemen_telegraphs__1000-01-01__timeline:1720-1737	1.000
:Event_0000007	type	Contact.Meet
:Event_0000007	mention.actual	"Talks"	yemen_latimes__1000-01-01__timeline:225-229	1.000
:Event_0000007	canonical_mention.actual	"Talks"	yemen_latimes__1000-01-01__timeline:225-229	1.000
:Event_0000007	Contact.Meet_Participant.actual	:Entity_EDL_0000002	yemen_latimes__1000-01-01__timeline:260-277	1.000
:Event_0000007	Contact.Meet_Participant.actual	:Entity_EDL_0000144	yemen_latimes__1000-01-01__timeline:298-304	1.000
:Event_0000008	type	Life.Die
:Event_0000008	mention.actual	"deaths"	yemen_latimes__1000-01-01__timeline:4618-4623	1.000
:Event_0000008	canonical_mention.actual	"deaths"	yemen_latimes__1000-01-01__timeline:4618-4623	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000018	yemen_latimes__1000-01-01__timeline:4628-4637	1.000
:Event_0000008	type	Life.Die
:Event_0000008	mention.actual	"deaths"	yemen_latimes__1000-01-01__timeline:973-978	1.000
:Event_0000008	canonical_mention.actual	"deaths"	yemen_latimes__1000-01-01__timeline:973-978	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000135	yemen_latimes__1000-01-01__timeline:991-1003	1.000
:Event_0000008	type	Life.Die
:Event_0000008	mention.actual	"killed"	yemen_latimes__1000-01-01__timeline:625-630	1.000
:Event_0000008	canonical_mention.actual	"killed"	yemen_latimes__1000-01-01__timeline:625-630	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000073	yemen_latimes__1000-01-01__timeline:610-619	1.000
:Event_0000008	Life.Die_Place.actual	:Entity_EDL_0000004	yemen_latimes__1000-01-01__timeline:718-722	1.000
:Event_0000009	type	Personnel.Elect
:Event_0000009	mention.actual	"vote"	yemen_afp__1000-01-01__timeline:1630-1633	1.000
:Event_0000009	canonical_mention.actual	"vote"	yemen_afp__1000-01-01__timeline:1630-1633	1.000
:Event_0000009	Personnel.Elect_Elect.actual	:Entity_EDL_0000000	yemen_afp__1000-01-01__timeline:1583-1587	1.000
:Event_0000009	type	Personnel.Elect
:Event_0000009	mention.actual	"vote"	yemen_afp__1000-01-01__timeline:1718-1721	1.000
:Event_0000009	canonical_mention.actual	"vote"	yemen_afp__1000-01-01__timeline:1718-1721	1.000
:Event_0000010	type	Movement.TransportPerson
:Event_0000010	mention.actual	"leave"	yemen_telegraphs__1000-01-01__timeline:4675-4679	1.000
:Event_0000010	canonical_mention.actual	"leave"	yemen_telegraphs__1000-01-01__timeline:4675-4679	1.000
:Event_0000010	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000186	yemen_telegraphs__1000-01-01__timeline:4651-4656	1.000
:Event_0000010	Movement.TransportPerson_Person.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:4666-4670	1.000
:Event_0000010	type	Movement.TransportPerson
:Event_0000010	mention.actual	"leave"	yemen_telegraphs__1000-01-01__timeline:3264-3268	1.000
:Event_0000010	canonical_mention.actual	"leave"	yemen_telegraphs__1000-01-01__timeline:3264-3268	1.000
:Event_0000010	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000003	yemen_telegraphs__1000-01-01__timeline:3245-3249	1.000
:Event_0000010	Movement.TransportPerson_Person.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:3258-3262	1.000
:Event_0000011	type	Personnel.Elect
:Event_0000011	mention.actual	"elections"	yemen_telegraphs__1000-01-01__timeline:1851-1859	1.000
:Event_0000011	canonical_mention.actual	"elections"	yemen_telegraphs__1000-01-01__timeline:1851-1859	1.000
:Event_0000011	type	Personnel.Elect
:Event_0000011	mention.actual	"elections"	yemen_latimes__1000-01-01__timeline:4960-4968	1.000
:Event_0000011	canonical_mention.actual	"elections"	yemen_latimes__1000-01-01__timeline:4960-4968	1.000
:Event_0000011	Personnel.Elect_Elect.actual	:Entity_EDL_0000170	yemen_latimes__1000-01-01__timeline:4978-4988	1.000
:Event_0000012	type	Conflict.Attack
:Event_0000012	mention.actual	"war"	yemen_latimes__1000-01-01__timeline:4444-4446	1.000
:Event_0000012	canonical_mention.actual	"war"	yemen_latimes__1000-01-01__timeline:4444-4446	1.000
:Event_0000012	Conflict.Attack_Place.actual	:Entity_EDL_0000219	yemen_latimes__1000-01-01__timeline:4415-4421	1.000
:Event_0000012	type	Conflict.Attack
:Event_0000012	mention.actual	"war"	yemen_latimes__1000-01-01__timeline:4186-4188	1.000
:Event_0000012	canonical_mention.actual	"war"	yemen_latimes__1000-01-01__timeline:4186-4188	1.000
:Event_0000012	Conflict.Attack_Place.actual	:Entity_EDL_0000151	yemen_latimes__1000-01-01__timeline:4157-4163	1.000
:Event_0000013	type	Justice.ChargeIndict
:Event_0000013	mention.actual	"prosecution"	yemen_telegraphs__1000-01-01__timeline:2634-2644	1.000
:Event_0000013	canonical_mention.actual	"prosecution"	yemen_telegraphs__1000-01-01__timeline:2634-2644	1.000
:Event_0000013	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:2571-2575	1.000
:Event_0000013	type	Justice.ChargeIndict
:Event_0000013	mention.actual	"prosecution"	yemen_latimes__1000-01-01__timeline:4599-4609	1.000
:Event_0000013	canonical_mention.actual	"prosecution"	yemen_latimes__1000-01-01__timeline:4599-4609	1.000
:Event_0000013	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000098	yemen_latimes__1000-01-01__timeline:4583-4585	1.000
:Event_0000014	type	Personnel.EndPosition
:Event_0000014	mention.actual	"fires"	yemen_dailystar__1000-01-01__timeline:398-402	1.000
:Event_0000014	canonical_mention.actual	"fires"	yemen_dailystar__1000-01-01__timeline:398-402	1.000
:Event_0000014	Personnel.EndPosition_Person.actual	:Entity_EDL_0000015	yemen_dailystar__1000-01-01__timeline:404-407	1.000
:Event_0000015	type	Conflict.Attack
:Event_0000015	mention.actual	"fire"	yemen_dailystar__1000-01-01__timeline:828-831	1.000
:Event_0000015	canonical_mention.actual	"fire"	yemen_dailystar__1000-01-01__timeline:828-831	1.000
:Event_0000015	Conflict.Attack_Attacker.actual	:Entity_EDL_0000051	yemen_dailystar__1000-01-01__timeline:821-826	1.000
:Event_0000015	Conflict.Attack_Target.actual	:Entity_EDL_0000116	yemen_dailystar__1000-01-01__timeline:836-845	1.000
:Event_0000015	Conflict.Attack_Place.actual	:Entity_EDL_0000001	yemen_dailystar__1000-01-01__timeline:850-855	1.000
:Event_0000016	type	Contact.Meet
:Event_0000016	mention.actual	"meets"	yemen_telegraphs__1000-01-01__timeline:6882-6886	1.000
:Event_0000016	canonical_mention.actual	"meets"	yemen_telegraphs__1000-01-01__timeline:6882-6886	1.000
:Event_0000016	Contact.Meet_Participant.actual	:Entity_EDL_0000086	yemen_telegraphs__1000-01-01__timeline:6869-6880	1.000
:Event_0000016	Contact.Meet_Participant.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:6888-6892	1.000
:Event_0000016	Contact.Meet_Place.actual	:Entity_EDL_0000106	yemen_telegraphs__1000-01-01__timeline:6897-6902	1.000
:Event_0000017	type	Contact.Meet
:Event_0000017	mention.actual	"gather"	yemen_voa__1000-01-01__timeline:53-58	1.000
:Event_0000017	canonical_mention.actual	"gather"	yemen_voa__1000-01-01__timeline:53-58	1.000
:Event_0000017	Contact.Meet_Participant.actual	:Entity_EDL_0000085	yemen_voa__1000-01-01__timeline:23-30	1.000
:Event_0000017	Contact.Meet_Participant.actual	:Entity_EDL_0000194	yemen_voa__1000-01-01__timeline:42-51	1.000
:Event_0000017	Contact.Meet_Place.actual	:Entity_EDL_0000057	yemen_voa__1000-01-01__timeline:63-79	1.000
:Event_0000018	type	Life.Die
:Event_0000018	mention.actual	"kill"	yemen_afp__1000-01-01__timeline:2728-2731	1.000
:Event_0000018	canonical_mention.actual	"kill"	yemen_afp__1000-01-01__timeline:2728-2731	1.000
:Event_0000018	Life.Die_Agent.actual	:Entity_EDL_0000008	yemen_afp__1000-01-01__timeline:2721-2726	1.000
:Event_0000018	Life.Die_Victim.actual	:Entity_EDL_0000024	yemen_afp__1000-01-01__timeline:2753-2764	1.000
:Event_0000018	Life.Die_Place.actual	:Entity_EDL_0000006	yemen_afp__1000-01-01__timeline:2791-2794	1.000
:Event_0000019	type	Life.Die
:Event_0000019	mention.actual	"killed"	yemen_afp__1000-01-01__timeline:5303-5308	1.000
:Event_0000019	canonical_mention.actual	"killed"	yemen_afp__1000-01-01__timeline:5303-5308	1.000
:Event_0000019	Life.Die_Victim.actual	:Entity_EDL_0000211	yemen_afp__1000-01-01__timeline:5296-5301	1.000
:Event_0000019	Life.Die_Place.actual	:Entity_EDL_0000160	yemen_afp__1000-01-01__timeline:5334-5338	1.000
:Event_0000020	type	Life.Die
:Event_0000020	mention.actual	"killed"	yemen_afp__1000-01-01__timeline:4120-4125	1.000
:Event_0000020	canonical_mention.actual	"killed"	yemen_afp__1000-01-01__timeline:4120-4125	1.000
:Event_0000020	Life.Die_Victim.actual	:Entity_EDL_0000102	yemen_afp__1000-01-01__timeline:4117-4118	1.000
:Event_0000020	Life.Die_Agent.actual	:Entity_EDL_0000029	yemen_afp__1000-01-01__timeline:4130-4135	1.000
:Event_0000020	Life.Die_Victim.actual	:Entity_EDL_0000083	yemen_afp__1000-01-01__timeline:4150-4159	1.000
:Event_0000020	Life.Die_Place.actual	:Entity_EDL_0000001	yemen_afp__1000-01-01__timeline:4187-4191	1.000
:Event_0000021	type	Conflict.Attack
:Event_0000021	mention.actual	"clash"	yemen_afp__1000-01-01__timeline:4178-4182	1.000
:Event_0000021	canonical_mention.actual	"clash"	yemen_afp__1000-01-01__timeline:4178-4182	1.000
:Event_0000021	Conflict.Attack_Attacker.actual	:Entity_EDL_0000031	yemen_afp__1000-01-01__timeline:4171-4176	1.000
:Event_0000021	Conflict.Attack_Place.actual	:Entity_EDL_0000001	yemen_afp__1000-01-01__timeline:4187-4191	1.000
:Event_0000022	type	Conflict.Attack
:Event_0000022	mention.actual	"fighting"	yemen_latimes__1000-01-01__timeline:3188-3195	1.000
:Event_0000022	canonical_mention.actual	"fighting"	yemen_latimes__1000-01-01__timeline:3188-3195	1.000
:Event_0000023	type	Contact.Meet
:Event_0000023	mention.actual	"meets"	yemen_voa__1000-01-01__timeline:1076-1080	1.000
:Event_0000023	canonical_mention.actual	"meets"	yemen_voa__1000-01-01__timeline:1076-1080	1.000
:Event_0000023	Contact.Meet_Participant.actual	:Entity_EDL_0000069	yemen_voa__1000-01-01__timeline:1054-1074	1.000
:Event_0000023	Contact.Meet_Place.actual	:Entity_EDL_0000053	yemen_voa__1000-01-01__timeline:1085-1089	1.000
:Event_0000024	type	Movement.TransportArtifact
:Event_0000024	mention.actual	"arrives"	yemen_telegraphs__1000-01-01__timeline:3485-3491	1.000
:Event_0000024	canonical_mention.actual	"arrives"	yemen_telegraphs__1000-01-01__timeline:3485-3491	1.000
:Event_0000024	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000165	yemen_telegraphs__1000-01-01__timeline:3465-3483	1.000
:Event_0000024	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000001	yemen_telegraphs__1000-01-01__timeline:3496-3500	1.000
:Event_0000025	type	Conflict.Attack
:Event_0000025	mention.actual	"fire"	yemen_afp__1000-01-01__timeline:4142-4145	1.000
:Event_0000025	canonical_mention.actual	"fire"	yemen_afp__1000-01-01__timeline:4142-4145	1.000
:Event_0000025	Conflict.Attack_Target.actual	:Entity_EDL_0000102	yemen_afp__1000-01-01__timeline:4117-4118	1.000
:Event_0000025	Conflict.Attack_Attacker.actual	:Entity_EDL_0000029	yemen_afp__1000-01-01__timeline:4130-4135	1.000
:Event_0000025	Conflict.Attack_Target.actual	:Entity_EDL_0000083	yemen_afp__1000-01-01__timeline:4150-4159	1.000
:Event_0000026	type	Personnel.EndPosition
:Event_0000026	mention.actual	"former"	yemen_telegraphs__1000-01-01__timeline:2447-2452	1.000
:Event_0000026	canonical_mention.actual	"former"	yemen_telegraphs__1000-01-01__timeline:2447-2452	1.000
:Event_0000026	Personnel.EndPosition_Person.actual	:Entity_EDL_0000065	yemen_telegraphs__1000-01-01__timeline:2454-2462	1.000
:Event_0000027	type	Life.Die
:Event_0000027	mention.actual	"killed"	yemen_telegraphs__1000-01-01__timeline:4493-4498	1.000
:Event_0000027	canonical_mention.actual	"killed"	yemen_telegraphs__1000-01-01__timeline:4493-4498	1.000
:Event_0000027	Life.Die_Victim.actual	:Entity_EDL_0000174	yemen_telegraphs__1000-01-01__timeline:4482-4487	1.000
:Event_0000028	type	Personnel.StartPosition
:Event_0000028	mention.actual	"sworn in"	yemen_washingtonpost__1000-01-01__timeline:2451-2458	1.000
:Event_0000028	canonical_mention.actual	"sworn in"	yemen_washingtonpost__1000-01-01__timeline:2451-2458	1.000
:Event_0000028	Personnel.StartPosition_Person.actual	:Entity_EDL_0000130	yemen_washingtonpost__1000-01-01__timeline:2443-2446	1.000
:Event_0000028	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000004	yemen_washingtonpost__1000-01-01__timeline:2463-2467	1.000
:Event_0000029	type	Life.Die
:Event_0000029	mention.actual	"kill"	yemen_telegraphs__1000-01-01__timeline:833-836	1.000
:Event_0000029	canonical_mention.actual	"kill"	yemen_telegraphs__1000-01-01__timeline:833-836	1.000
:Event_0000029	Life.Die_Agent.actual	:Entity_EDL_0000169	yemen_telegraphs__1000-01-01__timeline:825-831	1.000
:Event_0000029	Life.Die_Victim.actual	:Entity_EDL_0000209	yemen_telegraphs__1000-01-01__timeline:841-850	1.000
:Event_0000030	type	Life.Die
:Event_0000030	mention.actual	"kills"	yemen_washingtonpost__1000-01-01__timeline:850-854	1.000
:Event_0000030	canonical_mention.actual	"kills"	yemen_washingtonpost__1000-01-01__timeline:850-854	1.000
:Event_0000030	Life.Die_Victim.actual	:Entity_EDL_0000199	yemen_washingtonpost__1000-01-01__timeline:834-843	1.000
:Event_0000030	Life.Die_Victim.actual	:Entity_EDL_0000122	yemen_washingtonpost__1000-01-01__timeline:856-861	1.000
:Event_0000031	type	Movement.TransportArtifact
:Event_0000031	mention.actual	"carrying"	yemen_latimes__1000-01-01__timeline:846-853	1.000
:Event_0000031	canonical_mention.actual	"carrying"	yemen_latimes__1000-01-01__timeline:846-853	1.000
:Event_0000031	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000004	yemen_latimes__1000-01-01__timeline:718-722	1.000
:Event_0000031	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000100	yemen_latimes__1000-01-01__timeline:836-839	1.000
:Event_0000031	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000118	yemen_latimes__1000-01-01__timeline:855-861	1.000
:Event_0000032	type	Conflict.Attack
:Event_0000032	mention.actual	"battles"	yemen_telegraphs__1000-01-01__timeline:5437-5443	1.000
:Event_0000032	canonical_mention.actual	"battles"	yemen_telegraphs__1000-01-01__timeline:5437-5443	1.000
:Event_0000032	Conflict.Attack_Place.actual	:Entity_EDL_0000204	yemen_telegraphs__1000-01-01__timeline:5430-5435	1.000
:Event_0000033	type	Life.Die
:Event_0000033	mention.actual	"killed"	yemen_telegraphs__1000-01-01__timeline:5450-5455	1.000
:Event_0000033	canonical_mention.actual	"killed"	yemen_telegraphs__1000-01-01__timeline:5450-5455	1.000
:Event_0000033	Life.Die_Place.actual	:Entity_EDL_0000204	yemen_telegraphs__1000-01-01__timeline:5430-5435	1.000
:Event_0000033	Life.Die_Victim.actual	:Entity_EDL_0000072	yemen_telegraphs__1000-01-01__timeline:5466-5468	1.000
:Event_0000034	type	Business.Start
:Event_0000034	mention.actual	"formed"	yemen_telegraphs__1000-01-01__timeline:7315-7320	1.000
:Event_0000034	canonical_mention.actual	"formed"	yemen_telegraphs__1000-01-01__timeline:7315-7320	1.000
:Event_0000034	Business.Start_Agent.actual	:Entity_EDL_0000103	yemen_telegraphs__1000-01-01__timeline:7296-7302	1.000
:Event_0000034	Business.Start_Organization.actual	:Entity_EDL_0000112	yemen_telegraphs__1000-01-01__timeline:7322-7337	1.000
:Event_0000035	type	Conflict.Demonstrate
:Event_0000035	mention.actual	"protesters"	yemen_afp__1000-01-01__timeline:2981-2990	1.000
:Event_0000035	canonical_mention.actual	"protesters"	yemen_afp__1000-01-01__timeline:2981-2990	1.000
:Event_0000035	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000044	yemen_afp__1000-01-01__timeline:2981-2990	1.000
:Event_0000036	type	Movement.TransportPerson
:Event_0000036	mention.actual	"leave"	yemen_telegraphs__1000-01-01__timeline:4616-4620	1.000
:Event_0000036	canonical_mention.actual	"leave"	yemen_telegraphs__1000-01-01__timeline:4616-4620	1.000
:Event_0000036	Movement.TransportPerson_Person.actual	:Entity_EDL_0000137	yemen_telegraphs__1000-01-01__timeline:4603-4611	1.000
:Event_0000037	type	Life.Die
:Event_0000037	mention.actual	"kill"	yemen_telegraphs__1000-01-01__timeline:4807-4810	1.000
:Event_0000037	canonical_mention.actual	"kill"	yemen_telegraphs__1000-01-01__timeline:4807-4810	1.000
:Event_0000037	Life.Die_Agent.actual	:Entity_EDL_0000017	yemen_telegraphs__1000-01-01__timeline:4757-4765	1.000
:Event_0000037	Life.Die_Victim.actual	:Entity_EDL_0000088	yemen_telegraphs__1000-01-01__timeline:4821-4823	1.000
:Event_0000038	type	Conflict.Attack
:Event_0000038	mention.actual	"coup"	yemen_afp__1000-01-01__timeline:1433-1436	1.000
:Event_0000038	canonical_mention.actual	"coup"	yemen_afp__1000-01-01__timeline:1433-1436	1.000
:Event_0000039	type	Contact.Broadcast
:Event_0000039	mention.actual	"declare"	yemen_washingtonpost__1000-01-01__timeline:884-890	1.000
:Event_0000039	canonical_mention.actual	"declare"	yemen_washingtonpost__1000-01-01__timeline:884-890	1.000
:Event_0000039	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000110	yemen_washingtonpost__1000-01-01__timeline:872-882	1.000
:Event_0000040	type	Conflict.Attack
:Event_0000040	mention.actual	"fighting"	yemen_telegraphs__1000-01-01__timeline:4798-4805	1.000
:Event_0000040	canonical_mention.actual	"fighting"	yemen_telegraphs__1000-01-01__timeline:4798-4805	1.000
:Event_0000040	Conflict.Attack_Attacker.actual	:Entity_EDL_0000017	yemen_telegraphs__1000-01-01__timeline:4757-4765	1.000
:Event_0000041	type	Conflict.Demonstrate
:Event_0000041	mention.actual	"marches"	yemen_afp__1000-01-01__timeline:2313-2319	1.000
:Event_0000041	canonical_mention.actual	"marches"	yemen_afp__1000-01-01__timeline:2313-2319	1.000
:Event_0000041	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000001	yemen_afp__1000-01-01__timeline:2324-2328	1.000
:Event_0000042	type	Conflict.Attack
:Event_0000042	mention.actual	"fight"	yemen_telegraphs__1000-01-01__timeline:4099-4103	1.000
:Event_0000042	canonical_mention.actual	"fight"	yemen_telegraphs__1000-01-01__timeline:4099-4103	1.000
:Event_0000042	Conflict.Attack_Attacker.actual	:Entity_EDL_0000214	yemen_telegraphs__1000-01-01__timeline:4092-4097	1.000
:Event_0000042	Conflict.Attack_Target.actual	:Entity_EDL_0000128	yemen_telegraphs__1000-01-01__timeline:4111-4119	1.000
:Event_0000042	Conflict.Attack_Place.actual	:Entity_EDL_0000001	yemen_telegraphs__1000-01-01__timeline:4124-4128	1.000
:Event_0000043	type	Life.Injure
:Event_0000043	mention.actual	"wounded"	yemen_voa__1000-01-01__timeline:1888-1894	1.000
:Event_0000043	canonical_mention.actual	"wounded"	yemen_voa__1000-01-01__timeline:1888-1894	1.000
:Event_0000043	Life.Injure_Victim.actual	:Entity_EDL_0000000	yemen_voa__1000-01-01__timeline:1846-1850	1.000
:Event_0000043	Life.Injure_Victim.actual	:Entity_EDL_0000146	yemen_voa__1000-01-01__timeline:1874-1882	1.000
:Event_0000043	Life.Injure_Instrument.actual	:Entity_EDL_0000154	yemen_voa__1000-01-01__timeline:1901-1906	1.000
:Event_0000043	Life.Injure_Place.actual	:Entity_EDL_0000009	yemen_voa__1000-01-01__timeline:1935-1942	1.000
:Event_0000044	type	Conflict.Demonstrate
:Event_0000044	mention.actual	"protest"	yemen_afp__1000-01-01__timeline:5399-5405	1.000
:Event_0000044	canonical_mention.actual	"protest"	yemen_afp__1000-01-01__timeline:5399-5405	1.000
:Event_0000044	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000071	yemen_afp__1000-01-01__timeline:5348-5358	1.000
:Event_0000045	type	Conflict.Attack
:Event_0000045	mention.actual	"fired upon"	yemen_latimes__1000-01-01__timeline:335-344	1.000
:Event_0000045	canonical_mention.actual	"fired upon"	yemen_latimes__1000-01-01__timeline:335-344	1.000
:Event_0000045	Conflict.Attack_Target.actual	:Entity_EDL_0000016	yemen_latimes__1000-01-01__timeline:309-318	1.000
:Event_0000045	Conflict.Attack_Attacker.actual	:Entity_EDL_0000055	yemen_latimes__1000-01-01__timeline:358-363	1.000
:Event_0000046	type	Conflict.Attack
:Event_0000046	mention.actual	"clash"	yemen_latimes__1000-01-01__timeline:2268-2272	1.000
:Event_0000046	canonical_mention.actual	"clash"	yemen_latimes__1000-01-01__timeline:2268-2272	1.000
:Event_0000046	Conflict.Attack_Attacker.actual	:Entity_EDL_0000074	yemen_latimes__1000-01-01__timeline:2230-2235	1.000
:Event_0000046	Conflict.Attack_Target.actual	:Entity_EDL_0000125	yemen_latimes__1000-01-01__timeline:2257-2266	1.000
:Event_0000047	type	Conflict.Attack
:Event_0000047	mention.actual	"bloodshed"	yemen_telegraphs__1000-01-01__timeline:1565-1573	1.000
:Event_0000047	canonical_mention.actual	"bloodshed"	yemen_telegraphs__1000-01-01__timeline:1565-1573	1.000
:Event_0000047	Conflict.Attack_Place.actual	:Entity_EDL_0000003	yemen_telegraphs__1000-01-01__timeline:1578-1582	1.000
:Event_0000048	type	Personnel.EndPosition
:Event_0000048	mention.actual	"resign"	yemen_washingtonpost__1000-01-01__timeline:29-34	1.000
:Event_0000048	canonical_mention.actual	"resign"	yemen_washingtonpost__1000-01-01__timeline:29-34	1.000
:Event_0000048	Personnel.EndPosition_Person.actual	:Entity_EDL_0000197	yemen_washingtonpost__1000-01-01__timeline:17-27	1.000
:Event_0000048	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000043	yemen_washingtonpost__1000-01-01__timeline:116-120	1.000
:Event_0000049	type	Life.Injure
:Event_0000049	mention.actual	"wounding"	yemen_dailystar__1000-01-01__timeline:890-897	1.000
:Event_0000049	canonical_mention.actual	"wounding"	yemen_dailystar__1000-01-01__timeline:890-897	1.000
:Event_0000049	Life.Injure_Agent.actual	:Entity_EDL_0000051	yemen_dailystar__1000-01-01__timeline:821-826	1.000
:Event_0000049	Life.Injure_Place.actual	:Entity_EDL_0000001	yemen_dailystar__1000-01-01__timeline:850-855	1.000
:Event_0000049	Life.Injure_Victim.actual	:Entity_EDL_0000070	yemen_dailystar__1000-01-01__timeline:909-911	1.000
:Event_0000050	type	Contact.Meet
:Event_0000050	mention.actual	"summit"	yemen_telegraphs__1000-01-01__timeline:4641-4646	1.000
:Event_0000050	canonical_mention.actual	"summit"	yemen_telegraphs__1000-01-01__timeline:4641-4646	1.000
:Event_0000050	Contact.Meet_Participant.actual	:Entity_EDL_0000176	yemen_telegraphs__1000-01-01__timeline:4628-4634	1.000
:Event_0000050	Contact.Meet_Place.actual	:Entity_EDL_0000186	yemen_telegraphs__1000-01-01__timeline:4651-4656	1.000
:Event_0000051	type	Movement.TransportArtifact
:Event_0000051	mention.actual	"arrives"	yemen_afp__1000-01-01__timeline:4925-4931	1.000
:Event_0000051	canonical_mention.actual	"arrives"	yemen_afp__1000-01-01__timeline:4925-4931	1.000
:Event_0000051	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000000	yemen_afp__1000-01-01__timeline:4919-4923	1.000
:Event_0000051	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000042	yemen_afp__1000-01-01__timeline:4940-4952	1.000
:Event_0000052	type	Conflict.Attack
:Event_0000052	mention.actual	"fighting"	yemen_voa__1000-01-01__timeline:1658-1665	1.000
:Event_0000052	canonical_mention.actual	"fighting"	yemen_voa__1000-01-01__timeline:1658-1665	1.000
:Event_0000052	Conflict.Attack_Attacker.actual	:Entity_EDL_0000067	yemen_voa__1000-01-01__timeline:1681-1686	1.000
:Event_0000053	type	Life.Die
:Event_0000053	mention.actual	"dead"	yemen_afp__1000-01-01__timeline:3291-3294	1.000
:Event_0000053	canonical_mention.actual	"dead"	yemen_afp__1000-01-01__timeline:3291-3294	1.000
:Event_0000053	Life.Die_Agent.actual	:Entity_EDL_0000097	yemen_afp__1000-01-01__timeline:3265-3270	1.000
:Event_0000053	Life.Die_Victim.actual	:Entity_EDL_0000091	yemen_afp__1000-01-01__timeline:3284-3289	1.000
:Event_0000054	type	Conflict.Attack
:Event_0000054	mention.actual	"fire"	yemen_telegraphs__1000-01-01__timeline:8134-8137	1.000
:Event_0000054	canonical_mention.actual	"fire"	yemen_telegraphs__1000-01-01__timeline:8134-8137	1.000
:Event_0000054	Conflict.Attack_Attacker.actual	:Entity_EDL_0000164	yemen_telegraphs__1000-01-01__timeline:8127-8132	1.000
:Event_0000054	Conflict.Attack_Target.actual	:Entity_EDL_0000148	yemen_telegraphs__1000-01-01__timeline:8142-8154	1.000
:Event_0000055	type	Personnel.EndPosition
:Event_0000055	mention.actual	"resign"	yemen_latimes__1000-01-01__timeline:939-944	1.000
:Event_0000055	canonical_mention.actual	"resign"	yemen_latimes__1000-01-01__timeline:939-944	1.000
:Event_0000055	Personnel.EndPosition_Person.actual	:Entity_EDL_0000203	yemen_latimes__1000-01-01__timeline:918-926	1.000
:Event_0000056	type	Life.Die
:Event_0000056	mention.actual	"kill"	yemen_telegraphs__1000-01-01__timeline:8252-8255	1.000
:Event_0000056	canonical_mention.actual	"kill"	yemen_telegraphs__1000-01-01__timeline:8252-8255	1.000
:Event_0000056	Life.Die_Agent.actual	:Entity_EDL_0000032	yemen_telegraphs__1000-01-01__timeline:8245-8250	1.000
:Event_0000056	Life.Die_Victim.actual	:Entity_EDL_0000096	yemen_telegraphs__1000-01-01__timeline:8269-8274	1.000
:Event_0000056	Life.Die_Agent.actual	:Entity_EDL_0000187	yemen_telegraphs__1000-01-01__timeline:8291-8297	1.000
:Event_0000057	type	Conflict.Attack
:Event_0000057	mention.actual	"fire"	yemen_latimes__1000-01-01__timeline:1751-1754	1.000
:Event_0000057	canonical_mention.actual	"fire"	yemen_latimes__1000-01-01__timeline:1751-1754	1.000
:Event_0000057	Conflict.Attack_Attacker.actual	:Entity_EDL_0000092	yemen_latimes__1000-01-01__timeline:1744-1749	1.000
:Event_0000057	Conflict.Attack_Target.actual	:Entity_EDL_0000129	yemen_latimes__1000-01-01__timeline:1767-1776	1.000
:Event_0000058	type	Conflict.Attack
:Event_0000058	mention.actual	"war"	yemen_afp__1000-01-01__timeline:1468-1470	1.000
:Event_0000058	canonical_mention.actual	"war"	yemen_afp__1000-01-01__timeline:1468-1470	1.000
:Event_0000059	type	Life.Die
:Event_0000059	mention.actual	"killing"	yemen_afp__1000-01-01__timeline:3418-3424	1.000
:Event_0000059	canonical_mention.actual	"killing"	yemen_afp__1000-01-01__timeline:3418-3424	1.000
:Event_0000059	Life.Die_Agent.actual	:Entity_EDL_0000213	yemen_afp__1000-01-01__timeline:3352-3357	1.000
:Event_0000059	Life.Die_Place.actual	:Entity_EDL_0000006	yemen_afp__1000-01-01__timeline:3380-3383	1.000
:Event_0000059	Life.Die_Victim.actual	:Entity_EDL_0000215	yemen_afp__1000-01-01__timeline:3438-3443	1.000
:Event_0000060	type	Movement.TransportArtifact
:Event_0000060	mention.actual	"going"	yemen_telegraphs__1000-01-01__timeline:3964-3968	1.000
:Event_0000060	canonical_mention.actual	"going"	yemen_telegraphs__1000-01-01__timeline:3964-3968	1.000
:Event_0000060	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000076	yemen_telegraphs__1000-01-01__timeline:3949-3957	1.000
:Event_0000060	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000099	yemen_telegraphs__1000-01-01__timeline:3990-3995	1.000
:Event_0000061	type	Conflict.Demonstrate
:Event_0000061	mention.actual	"march"	yemen_afp__1000-01-01__timeline:2410-2414	1.000
:Event_0000061	canonical_mention.actual	"march"	yemen_afp__1000-01-01__timeline:2410-2414	1.000
:Event_0000061	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000113	yemen_afp__1000-01-01__timeline:2375-2383	1.000
:Event_0000061	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000181	yemen_afp__1000-01-01__timeline:2399-2408	1.000
:Event_0000061	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000153	yemen_afp__1000-01-01__timeline:2432-2435	1.000
:Event_0000062	type	Movement.TransportArtifact
:Event_0000062	mention.actual	"leave"	yemen_latimes__1000-01-01__timeline:4911-4915	1.000
:Event_0000062	canonical_mention.actual	"leave"	yemen_latimes__1000-01-01__timeline:4911-4915	1.000
:Event_0000062	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000208	yemen_latimes__1000-01-01__timeline:4898-4899	1.000
:Event_0000062	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000013	yemen_latimes__1000-01-01__timeline:4925-4937	1.000
:Event_0000063	type	Life.Injure
:Event_0000063	mention.actual	"wounding"	yemen_voa__1000-01-01__timeline:890-897	1.000
:Event_0000063	canonical_mention.actual	"wounding"	yemen_voa__1000-01-01__timeline:890-897	1.000
:Event_0000063	Life.Injure_Agent.actual	:Entity_EDL_0000134	yemen_voa__1000-01-01__timeline:821-826	1.000
:Event_0000063	Life.Injure_Place.actual	:Entity_EDL_0000001	yemen_voa__1000-01-01__timeline:850-855	1.000
:Event_0000063	Life.Injure_Victim.actual	:Entity_EDL_0000027	yemen_voa__1000-01-01__timeline:909-911	1.000
:Event_0000064	type	Conflict.Attack
:Event_0000064	mention.actual	"fire"	yemen_afp__1000-01-01__timeline:845-848	1.000
:Event_0000064	canonical_mention.actual	"fire"	yemen_afp__1000-01-01__timeline:845-848	1.000
:Event_0000064	Conflict.Attack_Attacker.actual	:Entity_EDL_0000059	yemen_afp__1000-01-01__timeline:830-838	1.000
:Event_0000064	Conflict.Attack_Target.actual	:Entity_EDL_0000191	yemen_afp__1000-01-01__timeline:853-865	1.000
:Event_0000064	Conflict.Attack_Place.actual	:Entity_EDL_0000150	yemen_afp__1000-01-01__timeline:874-880	1.000
:Event_0000065	type	Life.Die
:Event_0000065	mention.actual	"assassination"	yemen_latimes__1000-01-01__timeline:4015-4027	1.000
:Event_0000065	canonical_mention.actual	"assassination"	yemen_latimes__1000-01-01__timeline:4015-4027	1.000
:Event_0000065	Life.Die_Victim.actual	:Entity_EDL_0000050	yemen_latimes__1000-01-01__timeline:3985-3986	1.000
:Event_0000066	type	Life.Injure
:Event_0000066	mention.actual	"wounding"	yemen_voa__1000-01-01__timeline:720-727	1.000
:Event_0000066	canonical_mention.actual	"wounding"	yemen_voa__1000-01-01__timeline:720-727	1.000
:Event_0000066	Life.Injure_Place.actual	:Entity_EDL_0000001	yemen_voa__1000-01-01__timeline:597-602	1.000
:Event_0000066	Life.Injure_Agent.actual	:Entity_EDL_0000008	yemen_voa__1000-01-01__timeline:623-628	1.000
:Event_0000066	Life.Injure_Victim.actual	:Entity_EDL_0000177	yemen_voa__1000-01-01__timeline:643-652	1.000
:Event_0000066	Life.Injure_Victim.actual	:Entity_EDL_0000185	yemen_voa__1000-01-01__timeline:732-737	1.000
:Event_0000067	type	Life.Injure
:Event_0000067	mention.actual	"wounded"	yemen_washingtonpost__1000-01-01__timeline:1599-1605	1.000
:Event_0000067	canonical_mention.actual	"wounded"	yemen_washingtonpost__1000-01-01__timeline:1599-1605	1.000
:Event_0000067	Life.Injure_Instrument.actual	:Entity_EDL_0000011	yemen_washingtonpost__1000-01-01__timeline:1538-1543	1.000
:Event_0000067	Life.Injure_Place.actual	:Entity_EDL_0000022	yemen_washingtonpost__1000-01-01__timeline:1579-1586	1.000
:Event_0000067	Life.Injure_Victim.actual	:Entity_EDL_0000000	yemen_washingtonpost__1000-01-01__timeline:1590-1594	1.000
:Event_0000068	type	Conflict.Attack
:Event_0000068	mention.actual	"revolts"	yemen_afp__1000-01-01__timeline:23-29	1.000
:Event_0000068	canonical_mention.actual	"revolts"	yemen_afp__1000-01-01__timeline:23-29	1.000
:Event_0000068	Conflict.Attack_Place.actual	:Entity_EDL_0000012	yemen_afp__1000-01-01__timeline:34-40	1.000
:Event_0000068	Conflict.Attack_Place.actual	:Entity_EDL_0000210	yemen_afp__1000-01-01__timeline:46-50	1.000
:Event_0000069	type	Business.Start
:Event_0000069	mention.actual	"sworn in to office"	yemen_latimes__1000-01-01__timeline:4798-4815	1.000
:Event_0000069	canonical_mention.actual	"sworn in to office"	yemen_latimes__1000-01-01__timeline:4798-4815	1.000
:Event_0000069	Business.Start_Organization.actual	:Entity_EDL_0000136	yemen_latimes__1000-01-01__timeline:4694-4703	1.000
:Event_0000070	type	Life.Die
:Event_0000070	mention.actual	"killed"	yemen_telegraphs__1000-01-01__timeline:4994-4999	1.000
:Event_0000070	canonical_mention.actual	"killed"	yemen_telegraphs__1000-01-01__timeline:4994-4999	1.000
:Event_0000070	Life.Die_Victim.actual	:Entity_EDL_0000023	yemen_telegraphs__1000-01-01__timeline:4973-4978	1.000
:Event_0000070	Life.Die_Place.actual	:Entity_EDL_0000003	yemen_telegraphs__1000-01-01__timeline:5008-5012	1.000
:Event_0000071	type	Conflict.Attack
:Event_0000071	mention.actual	"fire"	yemen_voa__1000-01-01__timeline:828-831	1.000
:Event_0000071	canonical_mention.actual	"fire"	yemen_voa__1000-01-01__timeline:828-831	1.000
:Event_0000071	Conflict.Attack_Attacker.actual	:Entity_EDL_0000134	yemen_voa__1000-01-01__timeline:821-826	1.000
:Event_0000071	Conflict.Attack_Target.actual	:Entity_EDL_0000180	yemen_voa__1000-01-01__timeline:836-845	1.000
:Event_0000071	Conflict.Attack_Place.actual	:Entity_EDL_0000001	yemen_voa__1000-01-01__timeline:850-855	1.000
:Event_0000072	type	Conflict.Attack
:Event_0000072	mention.actual	"ransacked"	yemen_afp__1000-01-01__timeline:1867-1875	1.000
:Event_0000072	canonical_mention.actual	"ransacked"	yemen_afp__1000-01-01__timeline:1867-1875	1.000
:Event_0000072	Conflict.Attack_Target.actual	:Entity_EDL_0000094	yemen_afp__1000-01-01__timeline:1811-1818	1.000
:Event_0000072	Conflict.Attack_Target.actual	:Entity_EDL_0000063	yemen_afp__1000-01-01__timeline:1846-1852	1.000
:Event_0000072	Conflict.Attack_Place.actual	:Entity_EDL_0000001	yemen_afp__1000-01-01__timeline:1857-1861	1.000
:Event_0000073	type	Contact.Meet
:Event_0000073	mention.actual	"talks"	yemen_afp__1000-01-01__timeline:2066-2070	1.000
:Event_0000073	canonical_mention.actual	"talks"	yemen_afp__1000-01-01__timeline:2066-2070	1.000
:Event_0000073	Contact.Meet_Participant.actual	:Entity_EDL_0000000	yemen_afp__1000-01-01__timeline:2043-2047	1.000
:Event_0000073	Contact.Meet_Participant.actual	:Entity_EDL_0000133	yemen_afp__1000-01-01__timeline:2099-2117	1.000
:Event_0000074	type	Justice.ChargeIndict
:Event_0000074	mention.actual	"prosecution"	yemen_afp__1000-01-01__timeline:4457-4467	1.000
:Event_0000074	canonical_mention.actual	"prosecution"	yemen_afp__1000-01-01__timeline:4457-4467	1.000
:Event_0000074	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000105	yemen_afp__1000-01-01__timeline:4478-4480	1.000
:Event_0000074	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000193	yemen_afp__1000-01-01__timeline:4490-4495	1.000
:Event_0000075	type	Conflict.Attack
:Event_0000075	mention.actual	"gunned down"	yemen_afp__1000-01-01__timeline:1085-1095	1.000
:Event_0000075	canonical_mention.actual	"gunned down"	yemen_afp__1000-01-01__timeline:1085-1095	1.000
:Event_0000075	Conflict.Attack_Target.actual	:Entity_EDL_0000212	yemen_afp__1000-01-01__timeline:1063-1066	1.000
:Event_0000075	Conflict.Attack_Target.actual	:Entity_EDL_0000205	yemen_afp__1000-01-01__timeline:1078-1083	1.000
:Event_0000075	Conflict.Attack_Attacker.actual	:Entity_EDL_0000149	yemen_afp__1000-01-01__timeline:1104-1112	1.000
:Event_0000076	type	Conflict.Attack
:Event_0000076	mention.actual	"battles"	yemen_telegraphs__1000-01-01__timeline:4342-4348	1.000
:Event_0000076	canonical_mention.actual	"battles"	yemen_telegraphs__1000-01-01__timeline:4342-4348	1.000
:Event_0000076	Conflict.Attack_Place.actual	:Entity_EDL_0000054	yemen_telegraphs__1000-01-01__timeline:4335-4340	1.000
:Event_0000076	Conflict.Attack_Place.actual	:Entity_EDL_0000001	yemen_telegraphs__1000-01-01__timeline:4353-4357	1.000
:Event_0000076	Conflict.Attack_Attacker.actual	:Entity_EDL_0000196	yemen_telegraphs__1000-01-01__timeline:4380-4385	1.000
:Event_0000076	Conflict.Attack_Attacker.actual	:Entity_EDL_0000114	yemen_telegraphs__1000-01-01__timeline:4409-4413	1.000
:Event_0000077	type	Movement.TransportArtifact
:Event_0000077	mention.actual	"leave"	yemen_telegraphs__1000-01-01__timeline:4016-4020	1.000
:Event_0000077	canonical_mention.actual	"leave"	yemen_telegraphs__1000-01-01__timeline:4016-4020	1.000
:Event_0000077	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000167	yemen_telegraphs__1000-01-01__timeline:4000-4008	1.000
:Event_0000077	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000038	yemen_telegraphs__1000-01-01__timeline:4025-4034	1.000
:Event_0000078	type	Conflict.Attack
:Event_0000078	mention.actual	"attack"	yemen_telegraphs__1000-01-01__timeline:133-138	1.000
:Event_0000078	canonical_mention.actual	"attack"	yemen_telegraphs__1000-01-01__timeline:133-138	1.000
:Event_0000078	Conflict.Attack_Attacker.actual	:Entity_EDL_0000060	yemen_telegraphs__1000-01-01__timeline:122-131	1.000
:Event_0000078	Conflict.Attack_Target.actual	:Entity_EDL_0000007	yemen_telegraphs__1000-01-01__timeline:153-159	1.000
:Event_0000079	type	Movement.TransportArtifact
:Event_0000079	mention.actual	"push"	yemen_latimes__1000-01-01__timeline:2696-2699	1.000
:Event_0000079	canonical_mention.actual	"push"	yemen_latimes__1000-01-01__timeline:2696-2699	1.000
:Event_0000079	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000201	yemen_latimes__1000-01-01__timeline:2689-2694	1.000
:Event_0000079	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000040	yemen_latimes__1000-01-01__timeline:2701-2708	1.000
:Event_0000079	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000139	yemen_latimes__1000-01-01__timeline:2784-2791	1.000
:Event_0000080	type	Movement.TransportPerson
:Event_0000080	mention.actual	"travel"	yemen_washingtonpost__1000-01-01__timeline:2324-2329	1.000
:Event_0000080	canonical_mention.actual	"travel"	yemen_washingtonpost__1000-01-01__timeline:2324-2329	1.000
:Event_0000080	Movement.TransportPerson_Agent.actual	:Entity_EDL_0000000	yemen_washingtonpost__1000-01-01__timeline:2303-2307	1.000
:Event_0000080	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000013	yemen_washingtonpost__1000-01-01__timeline:2338-2350	1.000
:Event_0000081	type	Conflict.Attack
:Event_0000081	mention.actual	"clashes"	yemen_afp__1000-01-01__timeline:5313-5319	1.000
:Event_0000081	canonical_mention.actual	"clashes"	yemen_afp__1000-01-01__timeline:5313-5319	1.000
:Event_0000081	Conflict.Attack_Target.actual	:Entity_EDL_0000211	yemen_afp__1000-01-01__timeline:5296-5301	1.000
:Event_0000081	Conflict.Attack_Place.actual	:Entity_EDL_0000160	yemen_afp__1000-01-01__timeline:5334-5338	1.000
:Event_0000082	type	Conflict.Attack
:Event_0000082	mention.actual	"fighting"	yemen_afp__1000-01-01__timeline:3242-3249	1.000
:Event_0000082	canonical_mention.actual	"fighting"	yemen_afp__1000-01-01__timeline:3242-3249	1.000
:Event_0000082	Conflict.Attack_Attacker.actual	:Entity_EDL_0000141	yemen_afp__1000-01-01__timeline:3129-3134	1.000
:Event_0000082	Conflict.Attack_Target.actual	:Entity_EDL_0000097	yemen_afp__1000-01-01__timeline:3265-3270	1.000
:Event_0000083	type	Conflict.Attack
:Event_0000083	mention.actual	"explodes"	yemen_telegraphs__1000-01-01__timeline:5547-5554	1.000
:Event_0000083	canonical_mention.actual	"explodes"	yemen_telegraphs__1000-01-01__timeline:5547-5554	1.000
:Event_0000083	Conflict.Attack_Instrument.actual	:Entity_EDL_0000218	yemen_telegraphs__1000-01-01__timeline:5542-5545	1.000
:Event_0000083	Conflict.Attack_Target.actual	:Entity_EDL_0000195	yemen_telegraphs__1000-01-01__timeline:5568-5573	1.000
:Event_0000083	Conflict.Attack_Place.actual	:Entity_EDL_0000001	yemen_telegraphs__1000-01-01__timeline:5578-5582	1.000
:Event_0000084	type	Life.Injure
:Event_0000084	mention.actual	"wound"	yemen_afp__1000-01-01__timeline:2770-2774	1.000
:Event_0000084	canonical_mention.actual	"wound"	yemen_afp__1000-01-01__timeline:2770-2774	1.000
:Event_0000084	Life.Injure_Agent.actual	:Entity_EDL_0000008	yemen_afp__1000-01-01__timeline:2721-2726	1.000
:Event_0000084	Life.Injure_Place.actual	:Entity_EDL_0000006	yemen_afp__1000-01-01__timeline:2791-2794	1.000
:Event_0000085	type	Conflict.Attack
:Event_0000085	mention.actual	"shot"	yemen_afp__1000-01-01__timeline:2959-2962	1.000
:Event_0000085	canonical_mention.actual	"shot"	yemen_afp__1000-01-01__timeline:2959-2962	1.000
:Event_0000085	Conflict.Attack_Attacker.actual	:Entity_EDL_0000173	yemen_afp__1000-01-01__timeline:2952-2957	1.000
:Event_0000085	Conflict.Attack_Target.actual	:Entity_EDL_0000044	yemen_afp__1000-01-01__timeline:2981-2990	1.000
:Event_0000086	type	Justice.ChargeIndict
:Event_0000086	mention.actual	"charges"	yemen_latimes__1000-01-01__timeline:820-826	1.000
:Event_0000086	canonical_mention.actual	"charges"	yemen_latimes__1000-01-01__timeline:820-826	1.000
:Event_0000086	Justice.ChargeIndict_Place.actual	:Entity_EDL_0000004	yemen_latimes__1000-01-01__timeline:718-722	1.000
:Event_0000087	type	Movement.TransportArtifact
:Event_0000087	mention.actual	"flee"	yemen_telegraphs__1000-01-01__timeline:6563-6566	1.000
:Event_0000087	canonical_mention.actual	"flee"	yemen_telegraphs__1000-01-01__timeline:6563-6566	1.000
:Event_0000087	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000049	yemen_telegraphs__1000-01-01__timeline:6553-6561	1.000
:Event_0000088	type	Conflict.Demonstrate
:Event_0000088	mention.actual	"rallies"	yemen_afp__1000-01-01__timeline:2532-2538	1.000
:Event_0000088	canonical_mention.actual	"rallies"	yemen_afp__1000-01-01__timeline:2532-2538	1.000
:Event_0000088	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000087	yemen_afp__1000-01-01__timeline:2498-2506	1.000
:Event_0000088	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000182	yemen_afp__1000-01-01__timeline:2512-2519	1.000
:Event_0000088	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000001	yemen_afp__1000-01-01__timeline:2543-2547	1.000
:Event_0000089	type	Movement.TransportArtifact
:Event_0000089	mention.actual	"flown"	yemen_washingtonpost__1000-01-01__timeline:1663-1667	1.000
:Event_0000089	canonical_mention.actual	"flown"	yemen_washingtonpost__1000-01-01__timeline:1663-1667	1.000
:Event_0000089	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000000	yemen_washingtonpost__1000-01-01__timeline:1654-1658	1.000
:Event_0000089	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000005	yemen_washingtonpost__1000-01-01__timeline:1672-1683	1.000
:Event_0000090	type	Life.Injure
:Event_0000090	mention.actual	"wounded"	yemen_dailystar__1000-01-01__timeline:1888-1894	1.000
:Event_0000090	canonical_mention.actual	"wounded"	yemen_dailystar__1000-01-01__timeline:1888-1894	1.000
:Event_0000090	Life.Injure_Victim.actual	:Entity_EDL_0000000	yemen_dailystar__1000-01-01__timeline:1846-1850	1.000
:Event_0000090	Life.Injure_Victim.actual	:Entity_EDL_0000171	yemen_dailystar__1000-01-01__timeline:1874-1882	1.000
:Event_0000090	Life.Injure_Instrument.actual	:Entity_EDL_0000011	yemen_dailystar__1000-01-01__timeline:1901-1906	1.000
:Event_0000090	Life.Injure_Place.actual	:Entity_EDL_0000030	yemen_dailystar__1000-01-01__timeline:1935-1942	1.000
:Event_0000091	type	Personnel.Elect
:Event_0000091	mention.actual	"election"	yemen_telegraphs__1000-01-01__timeline:1437-1444	1.000
:Event_0000091	canonical_mention.actual	"election"	yemen_telegraphs__1000-01-01__timeline:1437-1444	1.000
:Event_0000092	type	Life.Die
:Event_0000092	mention.actual	"killed"	yemen_telegraphs__1000-01-01__timeline:5388-5393	1.000
:Event_0000092	canonical_mention.actual	"killed"	yemen_telegraphs__1000-01-01__timeline:5388-5393	1.000
:Event_0000092	Life.Die_Place.actual	:Entity_EDL_0000001	yemen_telegraphs__1000-01-01__timeline:5345-5349	1.000
:Event_0000092	Life.Die_Victim.actual	:Entity_EDL_0000048	yemen_telegraphs__1000-01-01__timeline:5368-5373	1.000
:Event_0000092	Life.Die_Agent.actual	:Entity_EDL_0000119	yemen_telegraphs__1000-01-01__timeline:5420-5425	1.000
:Event_0000093	type	Contact.Contact
:Event_0000093	mention.actual	"negotiate"	yemen_telegraphs__1000-01-01__timeline:7051-7059	1.000
:Event_0000093	canonical_mention.actual	"negotiate"	yemen_telegraphs__1000-01-01__timeline:7051-7059	1.000
:Event_0000093	Contact.Contact_Participant.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:7067-7071	1.000
:Event_0000094	type	Movement.TransportArtifact
:Event_0000094	mention.actual	"flies"	yemen_voa__1000-01-01__timeline:2189-2193	1.000
:Event_0000094	canonical_mention.actual	"flies"	yemen_voa__1000-01-01__timeline:2189-2193	1.000
:Event_0000094	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000000	yemen_voa__1000-01-01__timeline:2183-2187	1.000
:Event_0000094	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000014	yemen_voa__1000-01-01__timeline:2198-2209	1.000
:Event_0000095	type	Conflict.Attack
:Event_0000095	mention.actual	"bomb"	yemen_telegraphs__1000-01-01__timeline:6481-6484	1.000
:Event_0000095	canonical_mention.actual	"bomb"	yemen_telegraphs__1000-01-01__timeline:6481-6484	1.000
:Event_0000095	Conflict.Attack_Attacker.actual	:Entity_EDL_0000003	yemen_telegraphs__1000-01-01__timeline:6464-6469	1.000
:Event_0000095	Conflict.Attack_Instrument.actual	:Entity_EDL_0000115	yemen_telegraphs__1000-01-01__timeline:6471-6479	1.000
:Event_0000095	Conflict.Attack_Target.actual	:Entity_EDL_0000019	yemen_telegraphs__1000-01-01__timeline:6499-6504	1.000
:Event_0000096	type	Personnel.EndPosition
:Event_0000096	mention.actual	"Former"	yemen_washingtonpost__1000-01-01__timeline:2421-2426	1.000
:Event_0000096	canonical_mention.actual	"Former"	yemen_washingtonpost__1000-01-01__timeline:2421-2426	1.000
:Event_0000096	Personnel.EndPosition_Person.actual	:Entity_EDL_0000130	yemen_washingtonpost__1000-01-01__timeline:2443-2446	1.000
:Event_0000097	type	Conflict.Demonstrate
:Event_0000097	mention.actual	"rally"	yemen_afp__1000-01-01__timeline:62-66	1.000
:Event_0000097	canonical_mention.actual	"rally"	yemen_afp__1000-01-01__timeline:62-66	1.000
:Event_0000097	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000007	yemen_afp__1000-01-01__timeline:54-60	1.000
:Event_0000098	type	Life.Die
:Event_0000098	mention.actual	"killed"	yemen_afp__1000-01-01__timeline:5129-5134	1.000
:Event_0000098	canonical_mention.actual	"killed"	yemen_afp__1000-01-01__timeline:5129-5134	1.000
:Event_0000098	Life.Die_Victim.actual	:Entity_EDL_0000056	yemen_afp__1000-01-01__timeline:5126-5127	1.000
:Event_0000098	Life.Die_Victim.actual	:Entity_EDL_0000127	yemen_afp__1000-01-01__timeline:5199-5204	1.000
:Event_0000098	Life.Die_Agent.actual	:Entity_EDL_0000138	yemen_afp__1000-01-01__timeline:5218-5224	1.000
:Event_0000098	Life.Die_Place.actual	:Entity_EDL_0000216	yemen_afp__1000-01-01__timeline:5229-5242	1.000
:Event_0000099	type	Personnel.StartPosition
:Event_0000099	mention.actual	"takes over"	yemen_dailystar__1000-01-01__timeline:2266-2275	1.000
:Event_0000099	canonical_mention.actual	"takes over"	yemen_dailystar__1000-01-01__timeline:2266-2275	1.000
:Event_0000099	Personnel.StartPosition_Person.actual	:Entity_EDL_0000033	yemen_dailystar__1000-01-01__timeline:2243-2264	1.000
:Event_0000100	type	Life.Die
:Event_0000100	mention.actual	"killing"	yemen_telegraphs__1000-01-01__timeline:5159-5165	1.000
:Event_0000100	canonical_mention.actual	"killing"	yemen_telegraphs__1000-01-01__timeline:5159-5165	1.000
:Event_0000100	Life.Die_Agent.actual	:Entity_EDL_0000172	yemen_telegraphs__1000-01-01__timeline:5097-5102	1.000
:Event_0000100	Life.Die_Victim.actual	:Entity_EDL_0000175	yemen_telegraphs__1000-01-01__timeline:5117-5126	1.000
:Event_0000100	Life.Die_Place.actual	:Entity_EDL_0000108	yemen_telegraphs__1000-01-01__timeline:5144-5147	1.000
:Event_0000100	Life.Die_Victim.actual	:Entity_EDL_0000107	yemen_telegraphs__1000-01-01__timeline:5176-5177	1.000
:Event_0000101	type	Conflict.Attack
:Event_0000101	mention.actual	"fighting"	yemen_dailystar__1000-01-01__timeline:1658-1665	1.000
:Event_0000101	canonical_mention.actual	"fighting"	yemen_dailystar__1000-01-01__timeline:1658-1665	1.000
:Event_0000101	Conflict.Attack_Attacker.actual	:Entity_EDL_0000026	yemen_dailystar__1000-01-01__timeline:1681-1686	1.000
:Event_0000102	type	Personnel.EndPosition
:Event_0000102	mention.actual	"left"	yemen_washingtonpost__1000-01-01__timeline:190-193	1.000
:Event_0000102	canonical_mention.actual	"left"	yemen_washingtonpost__1000-01-01__timeline:190-193	1.000
:Event_0000102	Personnel.EndPosition_Person.actual	:Entity_EDL_0000075	yemen_washingtonpost__1000-01-01__timeline:173-183	1.000
:Event_0000102	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000084	yemen_washingtonpost__1000-01-01__timeline:199-203	1.000
:Event_0000103	type	Business.Start
:Event_0000103	mention.actual	"form"	yemen_telegraphs__1000-01-01__timeline:2466-2469	1.000
:Event_0000103	canonical_mention.actual	"form"	yemen_telegraphs__1000-01-01__timeline:2466-2469	1.000
:Event_0000103	Business.Start_Agent.actual	:Entity_EDL_0000152	yemen_telegraphs__1000-01-01__timeline:2421-2427	1.000
:Event_0000103	Business.Start_Agent.actual	:Entity_EDL_0000065	yemen_telegraphs__1000-01-01__timeline:2454-2462	1.000
:Event_0000103	Business.Start_Organization.actual	:Entity_EDL_0000140	yemen_telegraphs__1000-01-01__timeline:2471-2498	1.000
:Event_0000104	type	Conflict.Attack
:Event_0000104	mention.actual	"clashes"	yemen_telegraphs__1000-01-01__timeline:5398-5404	1.000
:Event_0000104	canonical_mention.actual	"clashes"	yemen_telegraphs__1000-01-01__timeline:5398-5404	1.000
:Event_0000104	Conflict.Attack_Place.actual	:Entity_EDL_0000001	yemen_telegraphs__1000-01-01__timeline:5345-5349	1.000
:Event_0000104	Conflict.Attack_Target.actual	:Entity_EDL_0000048	yemen_telegraphs__1000-01-01__timeline:5368-5373	1.000
:Event_0000104	Conflict.Attack_Attacker.actual	:Entity_EDL_0000119	yemen_telegraphs__1000-01-01__timeline:5420-5425	1.000
:Event_0000105	type	Conflict.Attack
:Event_0000105	mention.actual	"fire"	yemen_latimes__1000-01-01__timeline:3714-3717	1.000
:Event_0000105	canonical_mention.actual	"fire"	yemen_latimes__1000-01-01__timeline:3714-3717	1.000
:Event_0000105	Conflict.Attack_Attacker.actual	:Entity_EDL_0000207	yemen_latimes__1000-01-01__timeline:3702-3707	1.000
:Event_0000105	Conflict.Attack_Target.actual	:Entity_EDL_0000061	yemen_latimes__1000-01-01__timeline:3743-3755	1.000
:Event_0000105	Conflict.Attack_Place.actual	:Entity_EDL_0000078	yemen_latimes__1000-01-01__timeline:3770-3776	1.000
:Event_0000105	Conflict.Attack_Target.actual	:Entity_EDL_0000079	yemen_latimes__1000-01-01__timeline:3807-3816	1.000
:Event_0000106	type	Personnel.EndPosition
:Event_0000106	mention.actual	"fires"	yemen_voa__1000-01-01__timeline:398-402	1.000
:Event_0000106	canonical_mention.actual	"fires"	yemen_voa__1000-01-01__timeline:398-402	1.000
:Event_0000106	Personnel.EndPosition_Person.actual	:Entity_EDL_0000158	yemen_voa__1000-01-01__timeline:404-407	1.000
:Event_0000107	type	Conflict.Attack
:Event_0000107	mention.actual	"bloodshed"	yemen_latimes__1000-01-01__timeline:1485-1493	1.000
:Event_0000107	canonical_mention.actual	"bloodshed"	yemen_latimes__1000-01-01__timeline:1485-1493	1.000
:Event_0000108	type	Justice.ArrestJail
:Event_0000108	mention.actual	"arrested"	yemen_telegraphs__1000-01-01__timeline:6230-6237	1.000
:Event_0000108	canonical_mention.actual	"arrested"	yemen_telegraphs__1000-01-01__timeline:6230-6237	1.000
:Event_0000108	Justice.ArrestJail_Person.actual	:Entity_EDL_0000184	yemen_telegraphs__1000-01-01__timeline:6221-6228	1.000
:Event_0000109	type	Personnel.EndPosition
:Event_0000109	mention.actual	"quit"	yemen_telegraphs__1000-01-01__timeline:7304-7307	1.000
:Event_0000109	canonical_mention.actual	"quit"	yemen_telegraphs__1000-01-01__timeline:7304-7307	1.000
:Event_0000109	Personnel.EndPosition_Person.actual	:Entity_EDL_0000103	yemen_telegraphs__1000-01-01__timeline:7296-7302	1.000
:Event_0000109	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000112	yemen_telegraphs__1000-01-01__timeline:7322-7337	1.000
:Event_0000110	type	Conflict.Demonstrate
:Event_0000110	mention.actual	"rallies"	yemen_washingtonpost__1000-01-01__timeline:1379-1385	1.000
:Event_0000110	canonical_mention.actual	"rallies"	yemen_washingtonpost__1000-01-01__timeline:1379-1385	1.000
:Event_0000110	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000058	yemen_washingtonpost__1000-01-01__timeline:1351-1363	1.000
:Event_0000110	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000036	yemen_washingtonpost__1000-01-01__timeline:1394-1400	1.000
:Event_0000110	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000046	yemen_washingtonpost__1000-01-01__timeline:1415-1420	1.000
:Event_0000111	type	Life.Injure
:Event_0000111	mention.actual	"wounding"	yemen_telegraphs__1000-01-01__timeline:5586-5593	1.000
:Event_0000111	canonical_mention.actual	"wounding"	yemen_telegraphs__1000-01-01__timeline:5586-5593	1.000
:Event_0000111	Life.Injure_Instrument.actual	:Entity_EDL_0000218	yemen_telegraphs__1000-01-01__timeline:5542-5545	1.000
:Event_0000111	Life.Injure_Place.actual	:Entity_EDL_0000195	yemen_telegraphs__1000-01-01__timeline:5568-5573	1.000
:Event_0000111	Life.Injure_Victim.actual	:Entity_EDL_0000025	yemen_telegraphs__1000-01-01__timeline:5599-5607	1.000
:Event_0000111	Life.Injure_Victim.actual	:Entity_EDL_0000124	yemen_telegraphs__1000-01-01__timeline:5621-5628	1.000
:Event_0000111	Life.Injure_Victim.actual	:Entity_EDL_0000062	yemen_telegraphs__1000-01-01__timeline:5651-5657	1.000
:Event_0000112	type	Life.Die
:Event_0000112	mention.actual	"dead"	yemen_afp__1000-01-01__timeline:2964-2967	1.000
:Event_0000112	canonical_mention.actual	"dead"	yemen_afp__1000-01-01__timeline:2964-2967	1.000
:Event_0000112	Life.Die_Agent.actual	:Entity_EDL_0000173	yemen_afp__1000-01-01__timeline:2952-2957	1.000
:Event_0000112	Life.Die_Victim.actual	:Entity_EDL_0000044	yemen_afp__1000-01-01__timeline:2981-2990	1.000
:Event_0000113	type	Conflict.Attack
:Event_0000113	mention.actual	"fire"	yemen_voa__1000-01-01__timeline:635-638	1.000
:Event_0000113	canonical_mention.actual	"fire"	yemen_voa__1000-01-01__timeline:635-638	1.000
:Event_0000113	Conflict.Attack_Place.actual	:Entity_EDL_0000001	yemen_voa__1000-01-01__timeline:597-602	1.000
:Event_0000113	Conflict.Attack_Attacker.actual	:Entity_EDL_0000008	yemen_voa__1000-01-01__timeline:623-628	1.000
:Event_0000113	Conflict.Attack_Target.actual	:Entity_EDL_0000177	yemen_voa__1000-01-01__timeline:643-652	1.000
:Event_0000114	type	Movement.TransportArtifact
:Event_0000114	mention.actual	"leaves"	yemen_telegraphs__1000-01-01__timeline:5668-5673	1.000
:Event_0000114	canonical_mention.actual	"leaves"	yemen_telegraphs__1000-01-01__timeline:5668-5673	1.000
:Event_0000114	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:5662-5666	1.000
:Event_0000114	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000202	yemen_telegraphs__1000-01-01__timeline:5699-5706	1.000
:Event_0000115	type	Conflict.Attack
:Event_0000115	mention.actual	"Clashes"	yemen_afp__1000-01-01__timeline:1938-1944	1.000
:Event_0000115	canonical_mention.actual	"Clashes"	yemen_afp__1000-01-01__timeline:1938-1944	1.000
:Event_0000115	Conflict.Attack_Place.actual	:Entity_EDL_0000090	yemen_afp__1000-01-01__timeline:1962-1966	1.000
:Event_0000115	Conflict.Attack_Attacker.actual	:Entity_EDL_0000159	yemen_afp__1000-01-01__timeline:1989-1994	1.000
:Event_0000115	Conflict.Attack_Attacker.actual	:Entity_EDL_0000095	yemen_afp__1000-01-01__timeline:2004-2019	1.000
:Event_0000116	type	Conflict.Attack
:Event_0000116	mention.actual	"fire"	yemen_telegraphs__1000-01-01__timeline:5109-5112	1.000
:Event_0000116	canonical_mention.actual	"fire"	yemen_telegraphs__1000-01-01__timeline:5109-5112	1.000
:Event_0000116	Conflict.Attack_Attacker.actual	:Entity_EDL_0000172	yemen_telegraphs__1000-01-01__timeline:5097-5102	1.000
:Event_0000116	Conflict.Attack_Target.actual	:Entity_EDL_0000175	yemen_telegraphs__1000-01-01__timeline:5117-5126	1.000
:Event_0000116	Conflict.Attack_Place.actual	:Entity_EDL_0000108	yemen_telegraphs__1000-01-01__timeline:5144-5147	1.000
:Event_0000117	type	Life.Die
:Event_0000117	mention.actual	"killing"	yemen_afp__1000-01-01__timeline:5171-5177	1.000
:Event_0000117	canonical_mention.actual	"killing"	yemen_afp__1000-01-01__timeline:5171-5177	1.000
:Event_0000117	Life.Die_Victim.actual	:Entity_EDL_0000056	yemen_afp__1000-01-01__timeline:5126-5127	1.000
:Event_0000117	Life.Die_Victim.actual	:Entity_EDL_0000127	yemen_afp__1000-01-01__timeline:5199-5204	1.000
:Event_0000117	Life.Die_Agent.actual	:Entity_EDL_0000138	yemen_afp__1000-01-01__timeline:5218-5224	1.000
:Event_0000117	Life.Die_Place.actual	:Entity_EDL_0000216	yemen_afp__1000-01-01__timeline:5229-5242	1.000
:Event_0000118	type	Contact.Meet
:Event_0000118	mention.actual	"meets"	yemen_dailystar__1000-01-01__timeline:1076-1080	1.000
:Event_0000118	canonical_mention.actual	"meets"	yemen_dailystar__1000-01-01__timeline:1076-1080	1.000
:Event_0000118	Contact.Meet_Participant.actual	:Entity_EDL_0000179	yemen_dailystar__1000-01-01__timeline:1054-1074	1.000
:Event_0000118	Contact.Meet_Place.actual	:Entity_EDL_0000003	yemen_dailystar__1000-01-01__timeline:1085-1089	1.000
:Event_0000119	type	Contact.Meet
:Event_0000119	mention.actual	"gather"	yemen_dailystar__1000-01-01__timeline:53-58	1.000
:Event_0000119	canonical_mention.actual	"gather"	yemen_dailystar__1000-01-01__timeline:53-58	1.000
:Event_0000119	Contact.Meet_Participant.actual	:Entity_EDL_0000161	yemen_dailystar__1000-01-01__timeline:23-30	1.000
:Event_0000119	Contact.Meet_Participant.actual	:Entity_EDL_0000047	yemen_dailystar__1000-01-01__timeline:42-51	1.000
:Event_0000119	Contact.Meet_Place.actual	:Entity_EDL_0000155	yemen_dailystar__1000-01-01__timeline:63-79	1.000
:Event_0000120	type	Life.Injure
:Event_0000120	mention.actual	"wounded"	yemen_latimes__1000-01-01__timeline:4001-4007	1.000
:Event_0000120	canonical_mention.actual	"wounded"	yemen_latimes__1000-01-01__timeline:4001-4007	1.000
:Event_0000120	Life.Injure_Victim.actual	:Entity_EDL_0000050	yemen_latimes__1000-01-01__timeline:3985-3986	1.000
:Event_0000121	type	Conflict.Attack
:Event_0000121	mention.actual	"shot"	yemen_telegraphs__1000-01-01__timeline:8283-8286	1.000
:Event_0000121	canonical_mention.actual	"shot"	yemen_telegraphs__1000-01-01__timeline:8283-8286	1.000
:Event_0000121	Conflict.Attack_Target.actual	:Entity_EDL_0000096	yemen_telegraphs__1000-01-01__timeline:8269-8274	1.000
:Event_0000121	Conflict.Attack_Attacker.actual	:Entity_EDL_0000187	yemen_telegraphs__1000-01-01__timeline:8291-8297	1.000
:Event_0000122	type	Disaster.FireExplosion.FireExplosion
:Event_0000122	mention.actual	"explosion"	yemen_afp__1000-01-01__timeline:3512-3520	1.000
:Event_0000122	canonical_mention.actual	"explosion"	yemen_afp__1000-01-01__timeline:3512-3520	1.000
:Event_0000122	mention.actual	"explosion"	yemen_afp__1000-01-01__timeline:3512-3520	1.000
:Event_0000122	canonical_mention.actual	"explosion"	yemen_afp__1000-01-01__timeline:3512-3520	1.000
:Event_0000122	Disaster.FireExplosion.FireExplosion_Place.actual	:Entity_EDL_0000009	yemen_afp__1000-01-01__timeline:3542-3549	1.000
:Event_0000123	type	Life.Die
:Event_0000123	mention.actual	"kill"	yemen_telegraphs__1000-01-01__timeline:3147-3150	1.000
:Event_0000123	canonical_mention.actual	"kill"	yemen_telegraphs__1000-01-01__timeline:3147-3150	1.000
:Event_0000123	Life.Die_Agent.actual	:Entity_EDL_0000093	yemen_telegraphs__1000-01-01__timeline:3140-3145	1.000
:Event_0000123	Life.Die_Victim.actual	:Entity_EDL_0000082	yemen_telegraphs__1000-01-01__timeline:3155-3164	1.000
:Event_0000123	Life.Die_Place.actual	:Entity_EDL_0000003	yemen_telegraphs__1000-01-01__timeline:3173-3177	1.000
:Event_0000124	type	Life.Injure
:Event_0000124	mention.actual	"injuries"	yemen_latimes__1000-01-01__timeline:3108-3115	1.000
:Event_0000124	canonical_mention.actual	"injuries"	yemen_latimes__1000-01-01__timeline:3108-3115	1.000
:Event_0000124	Life.Injure_Victim.actual	:Entity_EDL_0000002	yemen_latimes__1000-01-01__timeline:3059-3076	1.000
:Event_0000124	Life.Injure_Place.actual	:Entity_EDL_0000004	yemen_latimes__1000-01-01__timeline:3085-3089	1.000
:Event_0000124	Life.Injure_Instrument.actual	:Entity_EDL_0000021	yemen_latimes__1000-01-01__timeline:3131-3136	1.000
:Event_0000125	type	Life.Injure
:Event_0000125	mention.actual	"wounded"	yemen_telegraphs__1000-01-01__timeline:7216-7222	1.000
:Event_0000125	canonical_mention.actual	"wounded"	yemen_telegraphs__1000-01-01__timeline:7216-7222	1.000
:Event_0000125	Life.Injure_Agent.actual	:Entity_EDL_0000028	yemen_telegraphs__1000-01-01__timeline:7185-7197	1.000
:Event_0000125	Life.Injure_Victim.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:7224-7228	1.000
:Event_0000126	type	Movement.TransportArtifact
:Event_0000126	mention.actual	"flown"	yemen_afp__1000-01-01__timeline:3581-3585	1.000
:Event_0000126	canonical_mention.actual	"flown"	yemen_afp__1000-01-01__timeline:3581-3585	1.000
:Event_0000126	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000000	yemen_afp__1000-01-01__timeline:3575-3579	1.000
:Event_0000126	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000014	yemen_afp__1000-01-01__timeline:3602-3613	1.000
:Event_0000127	type	Movement.TransportPerson
:Event_0000127	mention.actual	"return"	yemen_latimes__1000-01-01__timeline:4085-4090	1.000
:Event_0000127	canonical_mention.actual	"return"	yemen_latimes__1000-01-01__timeline:4085-4090	1.000
:Event_0000127	Movement.TransportPerson_Agent.actual	:Entity_EDL_0000002	yemen_latimes__1000-01-01__timeline:4049-4066	1.000
:Event_0000127	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000004	yemen_latimes__1000-01-01__timeline:4095-4099	1.000
:Event_0000128	type	Movement.TransportPerson
:Event_0000128	mention.actual	"disperse"	yemen_telegraphs__1000-01-01__timeline:144-151	1.000
:Event_0000128	canonical_mention.actual	"disperse"	yemen_telegraphs__1000-01-01__timeline:144-151	1.000
:Event_0000128	Movement.TransportPerson_Person.actual	:Entity_EDL_0000007	yemen_telegraphs__1000-01-01__timeline:153-159	1.000
:Event_0000129	type	Conflict.Attack
:Event_0000129	mention.actual	"clashes"	yemen_telegraphs__1000-01-01__timeline:6583-6589	1.000
:Event_0000129	canonical_mention.actual	"clashes"	yemen_telegraphs__1000-01-01__timeline:6583-6589	1.000
:Event_0000129	Conflict.Attack_Target.actual	:Entity_EDL_0000049	yemen_telegraphs__1000-01-01__timeline:6553-6561	1.000
:Event_0000129	Conflict.Attack_Attacker.actual	:Entity_EDL_0000039	yemen_telegraphs__1000-01-01__timeline:6599-6602	1.000
:Event_0000129	Conflict.Attack_Attacker.actual	:Entity_EDL_0000183	yemen_telegraphs__1000-01-01__timeline:6608-6616	1.000
:Event_0000130	type	Life.Die
:Event_0000130	mention.actual	"killed"	yemen_telegraphs__1000-01-01__timeline:5521-5526	1.000
:Event_0000130	canonical_mention.actual	"killed"	yemen_telegraphs__1000-01-01__timeline:5521-5526	1.000
:Event_0000130	Life.Die_Victim.actual	:Entity_EDL_0000126	yemen_telegraphs__1000-01-01__timeline:5504-5509	1.000
:Event_0000131	type	Personnel.Elect
:Event_0000131	mention.actual	"elections"	yemen_telegraphs__1000-01-01__timeline:7471-7479	1.000
:Event_0000131	canonical_mention.actual	"elections"	yemen_telegraphs__1000-01-01__timeline:7471-7479	1.000
:Event_0000131	Personnel.Elect_Elect.actual	:Entity_EDL_0000041	yemen_telegraphs__1000-01-01__timeline:7491-7499	1.000
:Event_0000132	type	Conflict.Demonstrate
:Event_0000132	mention.actual	"march"	yemen_telegraphs__1000-01-01__timeline:172-176	1.000
:Event_0000132	canonical_mention.actual	"march"	yemen_telegraphs__1000-01-01__timeline:172-176	1.000
:Event_0000133	type	Conflict.Attack
:Event_0000133	mention.actual	"fire"	yemen_dailystar__1000-01-01__timeline:635-638	1.000
:Event_0000133	canonical_mention.actual	"fire"	yemen_dailystar__1000-01-01__timeline:635-638	1.000
:Event_0000133	Conflict.Attack_Place.actual	:Entity_EDL_0000001	yemen_dailystar__1000-01-01__timeline:597-602	1.000
:Event_0000133	Conflict.Attack_Attacker.actual	:Entity_EDL_0000143	yemen_dailystar__1000-01-01__timeline:623-628	1.000
:Event_0000133	Conflict.Attack_Target.actual	:Entity_EDL_0000068	yemen_dailystar__1000-01-01__timeline:643-652	1.000
:Event_0000134	type	Conflict.Coup.Coup
:Event_0000134	mention.actual	"overthrow"	yemen_latimes__1000-01-01__timeline:3564-3572	1.000
:Event_0000134	canonical_mention.actual	"overthrow"	yemen_latimes__1000-01-01__timeline:3564-3572	1.000
:Event_0000134	Conflict.Coup.Coup_DeposingEntity.actual	:Entity_EDL_0000064	yemen_latimes__1000-01-01__timeline:3518-3527	1.000
:Event_0000134	Conflict.Coup.Coup_DeposedEntity.actual	:Entity_EDL_0000002	yemen_latimes__1000-01-01__timeline:3584-3601	1.000
:Event_0000135	type	Life.Die
:Event_0000135	mention.actual	"killed"	yemen_afp__1000-01-01__timeline:2882-2887	1.000
:Event_0000135	canonical_mention.actual	"killed"	yemen_afp__1000-01-01__timeline:2882-2887	1.000
:Event_0000135	Life.Die_Victim.actual	:Entity_EDL_0000217	yemen_afp__1000-01-01__timeline:2868-2876	1.000
:Event_0000136	type	Life.Injure
:Event_0000136	mention.actual	"wounded"	yemen_afp__1000-01-01__timeline:3498-3504	1.000
:Event_0000136	canonical_mention.actual	"wounded"	yemen_afp__1000-01-01__timeline:3498-3504	1.000
:Event_0000136	Life.Injure_Victim.actual	:Entity_EDL_0000000	yemen_afp__1000-01-01__timeline:3492-3496	1.000
:Event_0000136	Life.Injure_Place.actual	:Entity_EDL_0000009	yemen_afp__1000-01-01__timeline:3542-3549	1.000
:Event_0000137	type	Contact.Meet
:Event_0000137	mention.actual	"talks"	yemen_telegraphs__1000-01-01__timeline:8015-8019	1.000
:Event_0000137	canonical_mention.actual	"talks"	yemen_telegraphs__1000-01-01__timeline:8015-8019	1.000
:Event_0000138	type	Movement.TransportPerson
:Event_0000138	mention.actual	"returns"	yemen_washingtonpost__1000-01-01__timeline:1902-1908	1.000
:Event_0000138	canonical_mention.actual	"returns"	yemen_washingtonpost__1000-01-01__timeline:1902-1908	1.000
:Event_0000138	Movement.TransportPerson_Person.actual	:Entity_EDL_0000000	yemen_washingtonpost__1000-01-01__timeline:1896-1900	1.000
:Event_0000138	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000004	yemen_washingtonpost__1000-01-01__timeline:1913-1917	1.000
:Event_0000139	type	Medical.Intervention.Intervention
:Event_0000139	mention.actual	"surgery"	yemen_telegraphs__1000-01-01__timeline:5927-5933	1.000
:Event_0000139	canonical_mention.actual	"surgery"	yemen_telegraphs__1000-01-01__timeline:5927-5933	1.000
:Event_0000139	Medical.Intervention.Intervention_Patient.actual	:Entity_EDL_0000000	yemen_telegraphs__1000-01-01__timeline:5911-5915	1.000
:Event_0000140	type	Conflict.Attack
:Event_0000140	mention.actual	"explosion"	yemen_afp__1000-01-01__timeline:3726-3734	1.000
:Event_0000140	canonical_mention.actual	"explosion"	yemen_afp__1000-01-01__timeline:3726-3734	1.000
:Event_0000141	type	Personnel.StartPosition
:Event_0000141	mention.actual	"takes over"	yemen_voa__1000-01-01__timeline:2266-2275	1.000
:Event_0000141	canonical_mention.actual	"takes over"	yemen_voa__1000-01-01__timeline:2266-2275	1.000
:Event_0000141	Personnel.StartPosition_Person.actual	:Entity_EDL_0000066	yemen_voa__1000-01-01__timeline:2243-2264	1.000
:Event_0000142	type	Life.Injure
:Event_0000142	mention.actual	"wounding"	yemen_dailystar__1000-01-01__timeline:720-727	1.000
:Event_0000142	canonical_mention.actual	"wounding"	yemen_dailystar__1000-01-01__timeline:720-727	1.000
:Event_0000142	Life.Injure_Place.actual	:Entity_EDL_0000001	yemen_dailystar__1000-01-01__timeline:597-602	1.000
:Event_0000142	Life.Injure_Agent.actual	:Entity_EDL_0000143	yemen_dailystar__1000-01-01__timeline:623-628	1.000
:Event_0000142	Life.Injure_Victim.actual	:Entity_EDL_0000068	yemen_dailystar__1000-01-01__timeline:643-652	1.000
:Event_0000142	Life.Injure_Victim.actual	:Entity_EDL_0000034	yemen_dailystar__1000-01-01__timeline:732-737	1.000
:Event_0000143	type	Life.Die
:Event_0000143	mention.actual	"killed"	yemen_afp__1000-01-01__timeline:3565-3570	1.000
:Event_0000143	canonical_mention.actual	"killed"	yemen_afp__1000-01-01__timeline:3565-3570	1.000
:Event_0000143	Life.Die_Victim.actual	:Entity_EDL_0000111	yemen_afp__1000-01-01__timeline:3554-3559	1.000
:Event_0000144	type	Life.Injure
:Event_0000144	mention.actual	"wounding"	yemen_telegraphs__1000-01-01__timeline:8173-8180	1.000
:Event_0000144	canonical_mention.actual	"wounding"	yemen_telegraphs__1000-01-01__timeline:8173-8180	1.000
:Event_0000144	Life.Injure_Agent.actual	:Entity_EDL_0000164	yemen_telegraphs__1000-01-01__timeline:8127-8132	1.000
:Event_0000144	Life.Injure_Victim.actual	:Entity_EDL_0000198	yemen_telegraphs__1000-01-01__timeline:8182-8187	1.000
:Event_0000145	type	Personnel.EndPosition
:Event_0000145	mention.actual	"dismisses"	yemen_latimes__1000-01-01__timeline:1036-1044	1.000
:Event_0000145	canonical_mention.actual	"dismisses"	yemen_latimes__1000-01-01__timeline:1036-1044	1.000
:Event_0000145	Personnel.EndPosition_Person.actual	:Entity_EDL_0000035	yemen_latimes__1000-01-01__timeline:1050-1056	1.000
:Event_0000146	type	Conflict.Attack
:Event_0000146	mention.actual	"battle"	yemen_telegraphs__1000-01-01__timeline:5248-5253	1.000
:Event_0000146	canonical_mention.actual	"battle"	yemen_telegraphs__1000-01-01__timeline:5248-5253	1.000
:Event_0000146	Conflict.Attack_Attacker.actual	:Entity_EDL_0000123	yemen_telegraphs__1000-01-01__timeline:5226-5231	1.000
:Event_0000146	Conflict.Attack_Target.actual	:Entity_EDL_0000104	yemen_telegraphs__1000-01-01__timeline:5262-5269	1.000
:Event_0000147	type	Conflict.Demonstrate
:Event_0000147	mention.actual	"rally"	yemen_telegraphs__1000-01-01__timeline:1597-1601	1.000
:Event_0000147	canonical_mention.actual	"rally"	yemen_telegraphs__1000-01-01__timeline:1597-1601	1.000
:Event_0000147	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000081	yemen_telegraphs__1000-01-01__timeline:1587-1595	1.000
