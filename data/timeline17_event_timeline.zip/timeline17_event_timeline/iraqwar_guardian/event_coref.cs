:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:15889-15891	1.000
:Event_0000000	canonical_mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:15889-15891	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000190	iraqwar_guardian__1000-01-01__timeline:15880-15887	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000132	iraqwar_guardian__1000-01-01__timeline:15924-15929	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:45098-45102	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:45098-45102	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000314	iraqwar_guardian__1000-01-01__timeline:45088-45090	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000224	iraqwar_guardian__1000-01-01__timeline:45104-45106	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000644	iraqwar_guardian__1000-01-01__timeline:45111-45114	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:45318-45322	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:45318-45322	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000253	iraqwar_guardian__1000-01-01__timeline:45300-45305	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000572	iraqwar_guardian__1000-01-01__timeline:45333-45338	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:38461-38466	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:38461-38466	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000120	iraqwar_guardian__1000-01-01__timeline:38458-38459	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000490	iraqwar_guardian__1000-01-01__timeline:38471-38477	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:34559-34564	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:34559-34564	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000756	iraqwar_guardian__1000-01-01__timeline:34548-34557	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:36606-36612	1.000
:Event_0000000	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:36606-36612	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000477	iraqwar_guardian__1000-01-01__timeline:36553-36557	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000281	iraqwar_guardian__1000-01-01__timeline:36586-36591	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000525	iraqwar_guardian__1000-01-01__timeline:36626-36631	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:34226-34231	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:34226-34231	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000514	iraqwar_guardian__1000-01-01__timeline:34148-34152	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000010	iraqwar_guardian__1000-01-01__timeline:34242-34247	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:24163-24166	1.000
:Event_0000000	canonical_mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:24163-24166	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000758	iraqwar_guardian__1000-01-01__timeline:24156-24161	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:11435-11437	1.000
:Event_0000000	canonical_mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:11435-11437	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000346	iraqwar_guardian__1000-01-01__timeline:11424-11433	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000052	iraqwar_guardian__1000-01-01__timeline:11464-11467	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:14289-14293	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:14289-14293	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000291	iraqwar_guardian__1000-01-01__timeline:14309-14314	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000300	iraqwar_guardian__1000-01-01__timeline:14356-14361	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000446	iraqwar_guardian__1000-01-01__timeline:14394-14401	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:13592-13597	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:13592-13597	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000631	iraqwar_guardian__1000-01-01__timeline:13550-13551	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000159	iraqwar_guardian__1000-01-01__timeline:13639-13647	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:3737-3741	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:3737-3741	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000056	iraqwar_guardian__1000-01-01__timeline:3732-3735	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000036	iraqwar_guardian__1000-01-01__timeline:3743-3749	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:23-25	1.000
:Event_0000000	canonical_mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:23-25	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000084	iraqwar_guardian__1000-01-01__timeline:16-21	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000410	iraqwar_guardian__1000-01-01__timeline:33-42	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000474	iraqwar_guardian__1000-01-01__timeline:52-54	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000324	iraqwar_guardian__1000-01-01__timeline:114-117	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:3580-3585	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:3580-3585	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000700	iraqwar_guardian__1000-01-01__timeline:3569-3575	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000539	iraqwar_guardian__1000-01-01__timeline:3618-3621	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:1872-1875	1.000
:Event_0000000	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:1872-1875	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000356	iraqwar_guardian__1000-01-01__timeline:1864-1870	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000348	iraqwar_guardian__1000-01-01__timeline:1880-1887	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000529	iraqwar_guardian__1000-01-01__timeline:1893-1898	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:10146-10149	1.000
:Event_0000000	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:10146-10149	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000641	iraqwar_guardian__1000-01-01__timeline:10139-10144	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000004	iraqwar_guardian__1000-01-01__timeline:10176-10183	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000681	iraqwar_guardian__1000-01-01__timeline:10191-10196	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000128	iraqwar_guardian__1000-01-01__timeline:10203-10208	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:30050-30055	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:30050-30055	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000499	iraqwar_guardian__1000-01-01__timeline:29974-29980	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000607	iraqwar_guardian__1000-01-01__timeline:29999-30014	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000565	iraqwar_guardian__1000-01-01__timeline:30094-30097	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:34049-34051	1.000
:Event_0000000	canonical_mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:34049-34051	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000085	iraqwar_guardian__1000-01-01__timeline:34046-34047	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000669	iraqwar_guardian__1000-01-01__timeline:34056-34058	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000393	iraqwar_guardian__1000-01-01__timeline:34077-34082	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:15618-15622	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:15618-15622	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000057	iraqwar_guardian__1000-01-01__timeline:15613-15616	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000671	iraqwar_guardian__1000-01-01__timeline:15636-15643	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000011	iraqwar_guardian__1000-01-01__timeline:15692-15695	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:9147-9150	1.000
:Event_0000000	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:9147-9150	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000468	iraqwar_guardian__1000-01-01__timeline:9063-9066	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000260	iraqwar_guardian__1000-01-01__timeline:9090-9094	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000049	iraqwar_guardian__1000-01-01__timeline:9152-9153	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:9566-9569	1.000
:Event_0000000	canonical_mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:9566-9569	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000021	iraqwar_guardian__1000-01-01__timeline:9436-9453	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000093	iraqwar_guardian__1000-01-01__timeline:9577-9582	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000259	iraqwar_guardian__1000-01-01__timeline:9617-9621	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"deaths"	iraqwar_guardian__1000-01-01__timeline:11092-11097	1.000
:Event_0000000	canonical_mention.actual	"deaths"	iraqwar_guardian__1000-01-01__timeline:11092-11097	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000609	iraqwar_guardian__1000-01-01__timeline:11053-11056	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000708	iraqwar_guardian__1000-01-01__timeline:11110-11115	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:21446-21451	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:21446-21451	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000298	iraqwar_guardian__1000-01-01__timeline:21398-21404	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000247	iraqwar_guardian__1000-01-01__timeline:21467-21470	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000729	iraqwar_guardian__1000-01-01__timeline:21475-21479	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:34832-34836	1.000
:Event_0000000	canonical_mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:34832-34836	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000282	iraqwar_guardian__1000-01-01__timeline:34796-34803	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000610	iraqwar_guardian__1000-01-01__timeline:34828-34830	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:34297-34301	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:34297-34301	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000655	iraqwar_guardian__1000-01-01__timeline:34290-34295	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000095	iraqwar_guardian__1000-01-01__timeline:34303-34304	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000330	iraqwar_guardian__1000-01-01__timeline:34318-34321	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:15796-15801	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:15796-15801	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000472	iraqwar_guardian__1000-01-01__timeline:15787-15794	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000385	iraqwar_guardian__1000-01-01__timeline:15811-15814	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:44059-44063	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:44059-44063	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000559	iraqwar_guardian__1000-01-01__timeline:44052-44057	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000500	iraqwar_guardian__1000-01-01__timeline:44065-44066	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"perish"	iraqwar_guardian__1000-01-01__timeline:16222-16227	1.000
:Event_0000000	canonical_mention.actual	"perish"	iraqwar_guardian__1000-01-01__timeline:16222-16227	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000396	iraqwar_guardian__1000-01-01__timeline:16205-16210	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000191	iraqwar_guardian__1000-01-01__timeline:16218-16220	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000293	iraqwar_guardian__1000-01-01__timeline:16232-16235	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:37337-37342	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:37337-37342	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000046	iraqwar_guardian__1000-01-01__timeline:37334-37335	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000102	iraqwar_guardian__1000-01-01__timeline:37383-37386	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:33612-33614	1.000
:Event_0000000	canonical_mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:33612-33614	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000725	iraqwar_guardian__1000-01-01__timeline:33605-33610	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:37254-37260	1.000
:Event_0000000	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:37254-37260	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000520	iraqwar_guardian__1000-01-01__timeline:37159-37168	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000045	iraqwar_guardian__1000-01-01__timeline:37269-37274	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:31355-31359	1.000
:Event_0000000	canonical_mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:31355-31359	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000112	iraqwar_guardian__1000-01-01__timeline:31338-31339	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000594	iraqwar_guardian__1000-01-01__timeline:31372-31377	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:31252-31256	1.000
:Event_0000000	canonical_mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:31252-31256	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000626	iraqwar_guardian__1000-01-01__timeline:31281-31288	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:34608-34610	1.000
:Event_0000000	canonical_mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:34608-34610	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:18298-18304	1.000
:Event_0000000	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:18298-18304	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000730	iraqwar_guardian__1000-01-01__timeline:18212-18216	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000187	iraqwar_guardian__1000-01-01__timeline:18243-18249	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000149	iraqwar_guardian__1000-01-01__timeline:18318-18323	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:29655-29658	1.000
:Event_0000000	canonical_mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:29655-29658	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000200	iraqwar_guardian__1000-01-01__timeline:29652-29653	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000037	iraqwar_guardian__1000-01-01__timeline:29663-29666	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:3137-3142	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:3137-3142	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000547	iraqwar_guardian__1000-01-01__timeline:3129-3135	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000209	iraqwar_guardian__1000-01-01__timeline:3175-3178	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:44832-44838	1.000
:Event_0000000	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:44832-44838	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000414	iraqwar_guardian__1000-01-01__timeline:44752-44761	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000738	iraqwar_guardian__1000-01-01__timeline:44815-44828	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000485	iraqwar_guardian__1000-01-01__timeline:44853-44858	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000368	iraqwar_guardian__1000-01-01__timeline:44875-44880	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:21332-21336	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:21332-21336	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000301	iraqwar_guardian__1000-01-01__timeline:21327-21330	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000618	iraqwar_guardian__1000-01-01__timeline:21341-21347	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:45270-45276	1.000
:Event_0000000	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:45270-45276	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000540	iraqwar_guardian__1000-01-01__timeline:45175-45180	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000757	iraqwar_guardian__1000-01-01__timeline:45234-45237	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000749	iraqwar_guardian__1000-01-01__timeline:45290-45295	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:30155-30159	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:30155-30159	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000469	iraqwar_guardian__1000-01-01__timeline:30150-30153	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000494	iraqwar_guardian__1000-01-01__timeline:30169-30175	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:36807-36810	1.000
:Event_0000000	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:36807-36810	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000165	iraqwar_guardian__1000-01-01__timeline:36801-36805	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000082	iraqwar_guardian__1000-01-01__timeline:36812-36813	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"slaughter"	iraqwar_guardian__1000-01-01__timeline:33853-33861	1.000
:Event_0000000	canonical_mention.actual	"slaughter"	iraqwar_guardian__1000-01-01__timeline:33853-33861	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000590	iraqwar_guardian__1000-01-01__timeline:33912-33915	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:2977-2979	1.000
:Event_0000000	canonical_mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:2977-2979	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000731	iraqwar_guardian__1000-01-01__timeline:2965-2975	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000244	iraqwar_guardian__1000-01-01__timeline:3019-3025	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:9264-9267	1.000
:Event_0000000	canonical_mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:9264-9267	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000475	iraqwar_guardian__1000-01-01__timeline:9264-9267	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:30883-30885	1.000
:Event_0000000	canonical_mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:30883-30885	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000248	iraqwar_guardian__1000-01-01__timeline:30876-30881	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000370	iraqwar_guardian__1000-01-01__timeline:30965-30971	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:35003-35007	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:35003-35007	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000588	iraqwar_guardian__1000-01-01__timeline:34998-35001	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000443	iraqwar_guardian__1000-01-01__timeline:35017-35023	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:30118-30122	1.000
:Event_0000000	canonical_mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:30118-30122	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:35075-35081	1.000
:Event_0000000	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:35075-35081	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000355	iraqwar_guardian__1000-01-01__timeline:35072-35073	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000453	iraqwar_guardian__1000-01-01__timeline:35086-35090	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:1987-1990	1.000
:Event_0000000	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:1987-1990	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000670	iraqwar_guardian__1000-01-01__timeline:1979-1985	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000660	iraqwar_guardian__1000-01-01__timeline:1992-1993	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000103	iraqwar_guardian__1000-01-01__timeline:2005-2011	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:48276-48280	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:48276-48280	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000661	iraqwar_guardian__1000-01-01__timeline:48258-48264	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000326	iraqwar_guardian__1000-01-01__timeline:48299-48307	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:33710-33715	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:33710-33715	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000526	iraqwar_guardian__1000-01-01__timeline:33699-33704	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000602	iraqwar_guardian__1000-01-01__timeline:33747-33754	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000343	iraqwar_guardian__1000-01-01__timeline:33771-33774	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000680	iraqwar_guardian__1000-01-01__timeline:33793-33798	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:34394-34399	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:34394-34399	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000153	iraqwar_guardian__1000-01-01__timeline:34381-34389	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000557	iraqwar_guardian__1000-01-01__timeline:34435-34438	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000376	iraqwar_guardian__1000-01-01__timeline:34452-34455	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:24542-24548	1.000
:Event_0000000	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:24542-24548	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000531	iraqwar_guardian__1000-01-01__timeline:24509-24514	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000408	iraqwar_guardian__1000-01-01__timeline:24568-24572	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000452	iraqwar_guardian__1000-01-01__timeline:24608-24613	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:10399-10402	1.000
:Event_0000000	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:10399-10402	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000608	iraqwar_guardian__1000-01-01__timeline:10392-10397	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000383	iraqwar_guardian__1000-01-01__timeline:10404-10417	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000518	iraqwar_guardian__1000-01-01__timeline:10422-10425	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:2367-2369	1.000
:Event_0000000	canonical_mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:2367-2369	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000319	iraqwar_guardian__1000-01-01__timeline:2359-2365	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000705	iraqwar_guardian__1000-01-01__timeline:2374-2383	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000634	iraqwar_guardian__1000-01-01__timeline:2408-2411	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000231	iraqwar_guardian__1000-01-01__timeline:2448-2455	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:29388-29391	1.000
:Event_0000000	canonical_mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:29388-29391	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:29194-29199	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:29194-29199	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000439	iraqwar_guardian__1000-01-01__timeline:29183-29188	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:24787-24791	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:24787-24791	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000340	iraqwar_guardian__1000-01-01__timeline:24782-24785	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000702	iraqwar_guardian__1000-01-01__timeline:24802-24806	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:22645-22651	1.000
:Event_0000000	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:22645-22651	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000672	iraqwar_guardian__1000-01-01__timeline:22617-22622	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000633	iraqwar_guardian__1000-01-01__timeline:22635-22641	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000643	iraqwar_guardian__1000-01-01__timeline:22662-22667	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:31619-31623	1.000
:Event_0000000	canonical_mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:31619-31623	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000668	iraqwar_guardian__1000-01-01__timeline:31590-31596	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:24449-24452	1.000
:Event_0000000	canonical_mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:24449-24452	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000760	iraqwar_guardian__1000-01-01__timeline:24433-24437	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000543	iraqwar_guardian__1000-01-01__timeline:24445-24447	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:11399-11403	1.000
:Event_0000000	canonical_mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:11399-11403	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000346	iraqwar_guardian__1000-01-01__timeline:11424-11433	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:13692-13697	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:13692-13697	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000654	iraqwar_guardian__1000-01-01__timeline:13681-13690	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000673	iraqwar_guardian__1000-01-01__timeline:13702-13706	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:25270-25275	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:25270-25275	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000235	iraqwar_guardian__1000-01-01__timeline:25233-25238	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000420	iraqwar_guardian__1000-01-01__timeline:25309-25311	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000242	iraqwar_guardian__1000-01-01__timeline:25325-25334	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000737	iraqwar_guardian__1000-01-01__timeline:25411-25414	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:33429-33434	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:33429-33434	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000032	iraqwar_guardian__1000-01-01__timeline:33418-33423	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000674	iraqwar_guardian__1000-01-01__timeline:33471-33477	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000336	iraqwar_guardian__1000-01-01__timeline:33481-33486	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000502	iraqwar_guardian__1000-01-01__timeline:33492-33497	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"murder"	iraqwar_guardian__1000-01-01__timeline:21120-21125	1.000
:Event_0000000	canonical_mention.actual	"murder"	iraqwar_guardian__1000-01-01__timeline:21120-21125	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000053	iraqwar_guardian__1000-01-01__timeline:21133-21142	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000703	iraqwar_guardian__1000-01-01__timeline:21144-21157	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000091	iraqwar_guardian__1000-01-01__timeline:21162-21166	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:26587-26592	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:26587-26592	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000493	iraqwar_guardian__1000-01-01__timeline:26573-26577	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"hanged"	iraqwar_guardian__1000-01-01__timeline:11523-11528	1.000
:Event_0000000	canonical_mention.actual	"hanged"	iraqwar_guardian__1000-01-01__timeline:11523-11528	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000519	iraqwar_guardian__1000-01-01__timeline:11516-11521	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000236	iraqwar_guardian__1000-01-01__timeline:11530-11536	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:43817-43823	1.000
:Event_0000000	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:43817-43823	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000381	iraqwar_guardian__1000-01-01__timeline:43742-43747	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000020	iraqwar_guardian__1000-01-01__timeline:43799-43804	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000221	iraqwar_guardian__1000-01-01__timeline:43837-43842	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:26281-26285	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:26281-26285	1.000
:Event_0000000	Life.Die_Agent.actual	:Entity_EDL_0000000	iraqwar_guardian__1000-01-01__timeline:26264-26271	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000080	iraqwar_guardian__1000-01-01__timeline:26276-26279	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000426	iraqwar_guardian__1000-01-01__timeline:26308-26312	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:2527-2531	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:2527-2531	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000090	iraqwar_guardian__1000-01-01__timeline:2522-2525	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000347	iraqwar_guardian__1000-01-01__timeline:2536-2542	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000031	iraqwar_guardian__1000-01-01__timeline:2549-2555	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"deaths"	iraqwar_guardian__1000-01-01__timeline:8553-8558	1.000
:Event_0000000	canonical_mention.actual	"deaths"	iraqwar_guardian__1000-01-01__timeline:8553-8558	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000365	iraqwar_guardian__1000-01-01__timeline:8502-8506	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000656	iraqwar_guardian__1000-01-01__timeline:8577-8582	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:21024-21028	1.000
:Event_0000000	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:21024-21028	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000419	iraqwar_guardian__1000-01-01__timeline:21019-21022	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000277	iraqwar_guardian__1000-01-01__timeline:21033-21039	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000058	iraqwar_guardian__1000-01-01__timeline:21057-21066	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:30980-30983	1.000
:Event_0000000	canonical_mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:30980-30983	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000550	iraqwar_guardian__1000-01-01__timeline:31002-31015	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:258-263	1.000
:Event_0000000	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:258-263	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000001	iraqwar_guardian__1000-01-01__timeline:253-256	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000645	iraqwar_guardian__1000-01-01__timeline:276-281	1.000
:Event_0000000	type	Life.Die
:Event_0000000	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:48110-48116	1.000
:Event_0000000	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:48110-48116	1.000
:Event_0000000	Life.Die_Instrument.actual	:Entity_EDL_0000233	iraqwar_guardian__1000-01-01__timeline:48074-48081	1.000
:Event_0000000	Life.Die_Place.actual	:Entity_EDL_0000285	iraqwar_guardian__1000-01-01__timeline:48100-48106	1.000
:Event_0000000	Life.Die_Victim.actual	:Entity_EDL_0000723	iraqwar_guardian__1000-01-01__timeline:48143-48151	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:43882-43887	1.000
:Event_0000001	canonical_mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:43882-43887	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000431	iraqwar_guardian__1000-01-01__timeline:43931-43939	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:9318-9323	1.000
:Event_0000001	canonical_mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:9318-9323	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:36823-36829	1.000
:Event_0000001	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:36823-36829	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000165	iraqwar_guardian__1000-01-01__timeline:36801-36805	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000082	iraqwar_guardian__1000-01-01__timeline:36812-36813	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:48759-48765	1.000
:Event_0000001	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:48759-48765	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000464	iraqwar_guardian__1000-01-01__timeline:48716-48721	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000152	iraqwar_guardian__1000-01-01__timeline:48727-48736	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"explosion"	iraqwar_guardian__1000-01-01__timeline:43709-43717	1.000
:Event_0000001	canonical_mention.actual	"explosion"	iraqwar_guardian__1000-01-01__timeline:43709-43717	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000381	iraqwar_guardian__1000-01-01__timeline:43742-43747	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000020	iraqwar_guardian__1000-01-01__timeline:43799-43804	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"shot down"	iraqwar_guardian__1000-01-01__timeline:37370-37378	1.000
:Event_0000001	canonical_mention.actual	"shot down"	iraqwar_guardian__1000-01-01__timeline:37370-37378	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000046	iraqwar_guardian__1000-01-01__timeline:37334-37335	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000448	iraqwar_guardian__1000-01-01__timeline:37356-37365	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000102	iraqwar_guardian__1000-01-01__timeline:37383-37386	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"explode"	iraqwar_guardian__1000-01-01__timeline:36559-36565	1.000
:Event_0000001	canonical_mention.actual	"explode"	iraqwar_guardian__1000-01-01__timeline:36559-36565	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000477	iraqwar_guardian__1000-01-01__timeline:36553-36557	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000281	iraqwar_guardian__1000-01-01__timeline:36586-36591	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000241	iraqwar_guardian__1000-01-01__timeline:36596-36602	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"explode"	iraqwar_guardian__1000-01-01__timeline:29239-29245	1.000
:Event_0000001	canonical_mention.actual	"explode"	iraqwar_guardian__1000-01-01__timeline:29239-29245	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000696	iraqwar_guardian__1000-01-01__timeline:29233-29237	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000262	iraqwar_guardian__1000-01-01__timeline:29265-29268	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"Bombs"	iraqwar_guardian__1000-01-01__timeline:36801-36805	1.000
:Event_0000001	canonical_mention.actual	"Bombs"	iraqwar_guardian__1000-01-01__timeline:36801-36805	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000165	iraqwar_guardian__1000-01-01__timeline:36801-36805	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"shot"	iraqwar_guardian__1000-01-01__timeline:9561-9564	1.000
:Event_0000001	canonical_mention.actual	"shot"	iraqwar_guardian__1000-01-01__timeline:9561-9564	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000021	iraqwar_guardian__1000-01-01__timeline:9436-9453	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000093	iraqwar_guardian__1000-01-01__timeline:9577-9582	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000259	iraqwar_guardian__1000-01-01__timeline:9617-9621	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"strikes"	iraqwar_guardian__1000-01-01__timeline:22624-22630	1.000
:Event_0000001	canonical_mention.actual	"strikes"	iraqwar_guardian__1000-01-01__timeline:22624-22630	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000573	iraqwar_guardian__1000-01-01__timeline:22611-22615	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000672	iraqwar_guardian__1000-01-01__timeline:22617-22622	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000633	iraqwar_guardian__1000-01-01__timeline:22635-22641	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000643	iraqwar_guardian__1000-01-01__timeline:22662-22667	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:24128-24134	1.000
:Event_0000001	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:24128-24134	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"ambush"	iraqwar_guardian__1000-01-01__timeline:2987-2992	1.000
:Event_0000001	canonical_mention.actual	"ambush"	iraqwar_guardian__1000-01-01__timeline:2987-2992	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000731	iraqwar_guardian__1000-01-01__timeline:2965-2975	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000178	iraqwar_guardian__1000-01-01__timeline:3003-3009	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000244	iraqwar_guardian__1000-01-01__timeline:3019-3025	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"strikes"	iraqwar_guardian__1000-01-01__timeline:18364-18370	1.000
:Event_0000001	canonical_mention.actual	"strikes"	iraqwar_guardian__1000-01-01__timeline:18364-18370	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"blows"	iraqwar_guardian__1000-01-01__timeline:45251-45255	1.000
:Event_0000001	canonical_mention.actual	"blows"	iraqwar_guardian__1000-01-01__timeline:45251-45255	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000540	iraqwar_guardian__1000-01-01__timeline:45175-45180	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000012	iraqwar_guardian__1000-01-01__timeline:45242-45245	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000749	iraqwar_guardian__1000-01-01__timeline:45290-45295	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"explosion"	iraqwar_guardian__1000-01-01__timeline:24580-24588	1.000
:Event_0000001	canonical_mention.actual	"explosion"	iraqwar_guardian__1000-01-01__timeline:24580-24588	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000531	iraqwar_guardian__1000-01-01__timeline:24509-24514	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000452	iraqwar_guardian__1000-01-01__timeline:24608-24613	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:24390-24396	1.000
:Event_0000001	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:24390-24396	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000006	iraqwar_guardian__1000-01-01__timeline:24380-24388	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000164	iraqwar_guardian__1000-01-01__timeline:24401-24406	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"blast"	iraqwar_guardian__1000-01-01__timeline:45011-45015	1.000
:Event_0000001	canonical_mention.actual	"blast"	iraqwar_guardian__1000-01-01__timeline:45011-45015	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000582	iraqwar_guardian__1000-01-01__timeline:45024-45027	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"blast"	iraqwar_guardian__1000-01-01__timeline:45092-45096	1.000
:Event_0000001	canonical_mention.actual	"blast"	iraqwar_guardian__1000-01-01__timeline:45092-45096	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000314	iraqwar_guardian__1000-01-01__timeline:45088-45090	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000644	iraqwar_guardian__1000-01-01__timeline:45111-45114	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"bombed"	iraqwar_guardian__1000-01-01__timeline:53991-53996	1.000
:Event_0000001	canonical_mention.actual	"bombed"	iraqwar_guardian__1000-01-01__timeline:53991-53996	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000463	iraqwar_guardian__1000-01-01__timeline:53985-53989	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:39684-39689	1.000
:Event_0000001	canonical_mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:39684-39689	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000653	iraqwar_guardian__1000-01-01__timeline:39673-39682	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000072	iraqwar_guardian__1000-01-01__timeline:39691-39707	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:4649-4654	1.000
:Event_0000001	canonical_mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:4649-4654	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000246	iraqwar_guardian__1000-01-01__timeline:4646-4647	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"blast"	iraqwar_guardian__1000-01-01__timeline:36721-36725	1.000
:Event_0000001	canonical_mention.actual	"blast"	iraqwar_guardian__1000-01-01__timeline:36721-36725	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"ambushes"	iraqwar_guardian__1000-01-01__timeline:18268-18275	1.000
:Event_0000001	canonical_mention.actual	"ambushes"	iraqwar_guardian__1000-01-01__timeline:18268-18275	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000762	iraqwar_guardian__1000-01-01__timeline:18263-18266	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000411	iraqwar_guardian__1000-01-01__timeline:18287-18294	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000415	iraqwar_guardian__1000-01-01__timeline:18338-18343	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"explosions"	iraqwar_guardian__1000-01-01__timeline:33455-33464	1.000
:Event_0000001	canonical_mention.actual	"explosions"	iraqwar_guardian__1000-01-01__timeline:33455-33464	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000674	iraqwar_guardian__1000-01-01__timeline:33471-33477	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:21530-21536	1.000
:Event_0000001	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:21530-21536	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000579	iraqwar_guardian__1000-01-01__timeline:21503-21509	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000627	iraqwar_guardian__1000-01-01__timeline:21523-21528	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000171	iraqwar_guardian__1000-01-01__timeline:21547-21556	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"bombing"	iraqwar_guardian__1000-01-01__timeline:34213-34219	1.000
:Event_0000001	canonical_mention.actual	"bombing"	iraqwar_guardian__1000-01-01__timeline:34213-34219	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000514	iraqwar_guardian__1000-01-01__timeline:34148-34152	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000010	iraqwar_guardian__1000-01-01__timeline:34242-34247	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:30382-30388	1.000
:Event_0000001	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:30382-30388	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:44790-44795	1.000
:Event_0000001	canonical_mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:44790-44795	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000414	iraqwar_guardian__1000-01-01__timeline:44752-44761	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000485	iraqwar_guardian__1000-01-01__timeline:44853-44858	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000368	iraqwar_guardian__1000-01-01__timeline:44875-44880	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:29154-29160	1.000
:Event_0000001	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:29154-29160	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000439	iraqwar_guardian__1000-01-01__timeline:29183-29188	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"blast"	iraqwar_guardian__1000-01-01__timeline:24644-24648	1.000
:Event_0000001	canonical_mention.actual	"blast"	iraqwar_guardian__1000-01-01__timeline:24644-24648	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"ambush"	iraqwar_guardian__1000-01-01__timeline:3147-3152	1.000
:Event_0000001	canonical_mention.actual	"ambush"	iraqwar_guardian__1000-01-01__timeline:3147-3152	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000547	iraqwar_guardian__1000-01-01__timeline:3129-3135	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"beaten"	iraqwar_guardian__1000-01-01__timeline:31345-31350	1.000
:Event_0000001	canonical_mention.actual	"beaten"	iraqwar_guardian__1000-01-01__timeline:31345-31350	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000112	iraqwar_guardian__1000-01-01__timeline:31338-31339	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000594	iraqwar_guardian__1000-01-01__timeline:31372-31377	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:27551-27556	1.000
:Event_0000001	canonical_mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:27551-27556	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000510	iraqwar_guardian__1000-01-01__timeline:27546-27549	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000438	iraqwar_guardian__1000-01-01__timeline:27561-27564	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"raid"	iraqwar_guardian__1000-01-01__timeline:9589-9592	1.000
:Event_0000001	canonical_mention.actual	"raid"	iraqwar_guardian__1000-01-01__timeline:9589-9592	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000093	iraqwar_guardian__1000-01-01__timeline:9577-9582	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000215	iraqwar_guardian__1000-01-01__timeline:9599-9605	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000259	iraqwar_guardian__1000-01-01__timeline:9617-9621	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"bombing"	iraqwar_guardian__1000-01-01__timeline:53923-53929	1.000
:Event_0000001	canonical_mention.actual	"bombing"	iraqwar_guardian__1000-01-01__timeline:53923-53929	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000063	iraqwar_guardian__1000-01-01__timeline:53904-53909	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000206	iraqwar_guardian__1000-01-01__timeline:53938-53944	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"shooting"	iraqwar_guardian__1000-01-01__timeline:34666-34673	1.000
:Event_0000001	canonical_mention.actual	"shooting"	iraqwar_guardian__1000-01-01__timeline:34666-34673	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000334	iraqwar_guardian__1000-01-01__timeline:34703-34717	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000505	iraqwar_guardian__1000-01-01__timeline:34734-34743	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"blown up"	iraqwar_guardian__1000-01-01__timeline:14334-14341	1.000
:Event_0000001	canonical_mention.actual	"blown up"	iraqwar_guardian__1000-01-01__timeline:14334-14341	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000561	iraqwar_guardian__1000-01-01__timeline:14323-14329	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000300	iraqwar_guardian__1000-01-01__timeline:14356-14361	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000600	iraqwar_guardian__1000-01-01__timeline:14368-14372	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000446	iraqwar_guardian__1000-01-01__timeline:14394-14401	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"shot down"	iraqwar_guardian__1000-01-01__timeline:48223-48231	1.000
:Event_0000001	canonical_mention.actual	"shot down"	iraqwar_guardian__1000-01-01__timeline:48223-48231	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000752	iraqwar_guardian__1000-01-01__timeline:48216-48217	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"blasts"	iraqwar_guardian__1000-01-01__timeline:51332-51337	1.000
:Event_0000001	canonical_mention.actual	"blasts"	iraqwar_guardian__1000-01-01__timeline:51332-51337	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000254	iraqwar_guardian__1000-01-01__timeline:51324-51330	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:41056-41062	1.000
:Event_0000001	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:41056-41062	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000372	iraqwar_guardian__1000-01-01__timeline:40994-41003	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000121	iraqwar_guardian__1000-01-01__timeline:41036-41039	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000257	iraqwar_guardian__1000-01-01__timeline:41083-41091	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:9068-9074	1.000
:Event_0000001	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:9068-9074	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000468	iraqwar_guardian__1000-01-01__timeline:9063-9066	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000260	iraqwar_guardian__1000-01-01__timeline:9090-9094	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"shoot down"	iraqwar_guardian__1000-01-01__timeline:37178-37187	1.000
:Event_0000001	canonical_mention.actual	"shoot down"	iraqwar_guardian__1000-01-01__timeline:37178-37187	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000520	iraqwar_guardian__1000-01-01__timeline:37159-37168	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000204	iraqwar_guardian__1000-01-01__timeline:37173-37176	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000430	iraqwar_guardian__1000-01-01__timeline:37202-37211	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000045	iraqwar_guardian__1000-01-01__timeline:37269-37274	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:50659-50664	1.000
:Event_0000001	canonical_mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:50659-50664	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000480	iraqwar_guardian__1000-01-01__timeline:50654-50657	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000425	iraqwar_guardian__1000-01-01__timeline:50676-50681	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000422	iraqwar_guardian__1000-01-01__timeline:50686-50692	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:22676-22681	1.000
:Event_0000001	canonical_mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:22676-22681	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000412	iraqwar_guardian__1000-01-01__timeline:22707-22713	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000166	iraqwar_guardian__1000-01-01__timeline:22764-22768	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"bombing"	iraqwar_guardian__1000-01-01__timeline:53826-53832	1.000
:Event_0000001	canonical_mention.actual	"bombing"	iraqwar_guardian__1000-01-01__timeline:53826-53832	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000576	iraqwar_guardian__1000-01-01__timeline:53765-53774	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000023	iraqwar_guardian__1000-01-01__timeline:53845-53849	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000071	iraqwar_guardian__1000-01-01__timeline:53873-53876	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"bombing"	iraqwar_guardian__1000-01-01__timeline:34060-34066	1.000
:Event_0000001	canonical_mention.actual	"bombing"	iraqwar_guardian__1000-01-01__timeline:34060-34066	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000085	iraqwar_guardian__1000-01-01__timeline:34046-34047	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000669	iraqwar_guardian__1000-01-01__timeline:34056-34058	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000393	iraqwar_guardian__1000-01-01__timeline:34077-34082	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"Bomber"	iraqwar_guardian__1000-01-01__timeline:45300-45305	1.000
:Event_0000001	canonical_mention.actual	"Bomber"	iraqwar_guardian__1000-01-01__timeline:45300-45305	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000253	iraqwar_guardian__1000-01-01__timeline:45300-45305	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000572	iraqwar_guardian__1000-01-01__timeline:45333-45338	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:4123-4128	1.000
:Event_0000001	canonical_mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:4123-4128	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000024	iraqwar_guardian__1000-01-01__timeline:4096-4097	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000662	iraqwar_guardian__1000-01-01__timeline:4135-4141	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000208	iraqwar_guardian__1000-01-01__timeline:4143-4152	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"blows"	iraqwar_guardian__1000-01-01__timeline:36781-36785	1.000
:Event_0000001	canonical_mention.actual	"blows"	iraqwar_guardian__1000-01-01__timeline:36781-36785	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"explode"	iraqwar_guardian__1000-01-01__timeline:18218-18224	1.000
:Event_0000001	canonical_mention.actual	"explode"	iraqwar_guardian__1000-01-01__timeline:18218-18224	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000730	iraqwar_guardian__1000-01-01__timeline:18212-18216	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000187	iraqwar_guardian__1000-01-01__timeline:18243-18249	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"explodes"	iraqwar_guardian__1000-01-01__timeline:33756-33763	1.000
:Event_0000001	canonical_mention.actual	"explodes"	iraqwar_guardian__1000-01-01__timeline:33756-33763	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000451	iraqwar_guardian__1000-01-01__timeline:33721-33722	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000116	iraqwar_guardian__1000-01-01__timeline:33767-33769	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000343	iraqwar_guardian__1000-01-01__timeline:33771-33774	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000680	iraqwar_guardian__1000-01-01__timeline:33793-33798	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000008	iraqwar_guardian__1000-01-01__timeline:33824-33827	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"bombing"	iraqwar_guardian__1000-01-01__timeline:49959-49965	1.000
:Event_0000001	canonical_mention.actual	"bombing"	iraqwar_guardian__1000-01-01__timeline:49959-49965	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000043	iraqwar_guardian__1000-01-01__timeline:49844-49853	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000679	iraqwar_guardian__1000-01-01__timeline:49872-49883	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000065	iraqwar_guardian__1000-01-01__timeline:49955-49957	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"targets"	iraqwar_guardian__1000-01-01__timeline:25336-25342	1.000
:Event_0000001	canonical_mention.actual	"targets"	iraqwar_guardian__1000-01-01__timeline:25336-25342	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000235	iraqwar_guardian__1000-01-01__timeline:25233-25238	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000597	iraqwar_guardian__1000-01-01__timeline:25289-25290	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000420	iraqwar_guardian__1000-01-01__timeline:25309-25311	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000242	iraqwar_guardian__1000-01-01__timeline:25325-25334	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000454	iraqwar_guardian__1000-01-01__timeline:25359-25366	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000737	iraqwar_guardian__1000-01-01__timeline:25411-25414	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:2480-2485	1.000
:Event_0000001	canonical_mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:2480-2485	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000750	iraqwar_guardian__1000-01-01__timeline:2493-2498	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:30063-30068	1.000
:Event_0000001	canonical_mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:30063-30068	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000499	iraqwar_guardian__1000-01-01__timeline:29974-29980	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000562	iraqwar_guardian__1000-01-01__timeline:30075-30080	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000565	iraqwar_guardian__1000-01-01__timeline:30094-30097	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:23938-23945	1.000
:Event_0000002	canonical_mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:23938-23945	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000125	iraqwar_guardian__1000-01-01__timeline:23933-23936	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:7497-7499	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:7497-7499	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:32528-32530	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:32528-32530	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:23831-23838	1.000
:Event_0000002	canonical_mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:23831-23838	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000357	iraqwar_guardian__1000-01-01__timeline:23847-23853	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:22400-22407	1.000
:Event_0000002	canonical_mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:22400-22407	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000195	iraqwar_guardian__1000-01-01__timeline:22382-22385	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:32995-32997	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:32995-32997	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:1788-1790	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:1788-1790	1.000
:Event_0000002	Conflict.Attack_Attacker.actual	:Entity_EDL_0000302	iraqwar_guardian__1000-01-01__timeline:1782-1783	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:21909-21916	1.000
:Event_0000002	canonical_mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:21909-21916	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000692	iraqwar_guardian__1000-01-01__timeline:21904-21907	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:5181-5183	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:5181-5183	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000523	iraqwar_guardian__1000-01-01__timeline:5176-5179	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:52684-52686	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:52684-52686	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000533	iraqwar_guardian__1000-01-01__timeline:52679-52682	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:48658-48660	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:48658-48660	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000158	iraqwar_guardian__1000-01-01__timeline:48643-48646	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:41503-41510	1.000
:Event_0000002	canonical_mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:41503-41510	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:42738-42740	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:42738-42740	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000299	iraqwar_guardian__1000-01-01__timeline:42733-42736	1.000
:Event_0000002	Conflict.Attack_Attacker.actual	:Entity_EDL_0000304	iraqwar_guardian__1000-01-01__timeline:42775-42776	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:35737-35739	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:35737-35739	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000693	iraqwar_guardian__1000-01-01__timeline:35732-35735	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:15771-15778	1.000
:Event_0000002	canonical_mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:15771-15778	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:20996-20998	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:20996-20998	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:36411-36413	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:36411-36413	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:5562-5569	1.000
:Event_0000002	canonical_mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:5562-5569	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"invading"	iraqwar_guardian__1000-01-01__timeline:5320-5327	1.000
:Event_0000002	canonical_mention.actual	"invading"	iraqwar_guardian__1000-01-01__timeline:5320-5327	1.000
:Event_0000002	Conflict.Attack_Attacker.actual	:Entity_EDL_0000170	iraqwar_guardian__1000-01-01__timeline:5310-5311	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000359	iraqwar_guardian__1000-01-01__timeline:5329-5332	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:41353-41355	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:41353-41355	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:26710-26712	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:26710-26712	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000614	iraqwar_guardian__1000-01-01__timeline:26705-26708	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"wars"	iraqwar_guardian__1000-01-01__timeline:24332-24335	1.000
:Event_0000002	canonical_mention.actual	"wars"	iraqwar_guardian__1000-01-01__timeline:24332-24335	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000435	iraqwar_guardian__1000-01-01__timeline:24340-24343	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000677	iraqwar_guardian__1000-01-01__timeline:24349-24359	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:42936-42938	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:42936-42938	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:36161-36168	1.000
:Event_0000002	canonical_mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:36161-36168	1.000
:Event_0000002	Conflict.Attack_Attacker.actual	:Entity_EDL_0000647	iraqwar_guardian__1000-01-01__timeline:36148-36155	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000371	iraqwar_guardian__1000-01-01__timeline:36173-36176	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"conflict"	iraqwar_guardian__1000-01-01__timeline:1657-1664	1.000
:Event_0000002	canonical_mention.actual	"conflict"	iraqwar_guardian__1000-01-01__timeline:1657-1664	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:5272-5274	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:5272-5274	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:15980-15987	1.000
:Event_0000002	canonical_mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:15980-15987	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:42494-42501	1.000
:Event_0000002	canonical_mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:42494-42501	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000211	iraqwar_guardian__1000-01-01__timeline:42506-42509	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:39857-39859	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:39857-39859	1.000
:Event_0000002	Conflict.Attack_Attacker.actual	:Entity_EDL_0000678	iraqwar_guardian__1000-01-01__timeline:39831-39832	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000015	iraqwar_guardian__1000-01-01__timeline:39864-39867	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:13920-13922	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:13920-13922	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:42999-43006	1.000
:Event_0000002	canonical_mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:42999-43006	1.000
:Event_0000002	Conflict.Attack_Attacker.actual	:Entity_EDL_0000002	iraqwar_guardian__1000-01-01__timeline:42994-42997	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"fight"	iraqwar_guardian__1000-01-01__timeline:26786-26790	1.000
:Event_0000002	canonical_mention.actual	"fight"	iraqwar_guardian__1000-01-01__timeline:26786-26790	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:26946-26948	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:26946-26948	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000177	iraqwar_guardian__1000-01-01__timeline:26941-26944	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:36110-36112	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:36110-36112	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:42782-42789	1.000
:Event_0000002	canonical_mention.actual	"invasion"	iraqwar_guardian__1000-01-01__timeline:42782-42789	1.000
:Event_0000002	Conflict.Attack_Attacker.actual	:Entity_EDL_0000304	iraqwar_guardian__1000-01-01__timeline:42775-42776	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:44326-44328	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:44326-44328	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000386	iraqwar_guardian__1000-01-01__timeline:44321-44324	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"conflict"	iraqwar_guardian__1000-01-01__timeline:30131-30138	1.000
:Event_0000002	canonical_mention.actual	"conflict"	iraqwar_guardian__1000-01-01__timeline:30131-30138	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:26905-26907	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:26905-26907	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:36301-36303	1.000
:Event_0000002	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:36301-36303	1.000
:Event_0000002	Conflict.Attack_Attacker.actual	:Entity_EDL_0000323	iraqwar_guardian__1000-01-01__timeline:36284-36290	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"election"	iraqwar_guardian__1000-01-01__timeline:54228-54235	1.000
:Event_0000003	canonical_mention.actual	"election"	iraqwar_guardian__1000-01-01__timeline:54228-54235	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:48556-48564	1.000
:Event_0000003	canonical_mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:48556-48564	1.000
:Event_0000003	Personnel.Elect_Place.actual	:Entity_EDL_0000076	iraqwar_guardian__1000-01-01__timeline:48550-48554	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"election"	iraqwar_guardian__1000-01-01__timeline:48435-48442	1.000
:Event_0000003	canonical_mention.actual	"election"	iraqwar_guardian__1000-01-01__timeline:48435-48442	1.000
:Event_0000003	Personnel.Elect_Place.actual	:Entity_EDL_0000569	iraqwar_guardian__1000-01-01__timeline:48413-48419	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elected"	iraqwar_guardian__1000-01-01__timeline:35287-35293	1.000
:Event_0000003	canonical_mention.actual	"elected"	iraqwar_guardian__1000-01-01__timeline:35287-35293	1.000
:Event_0000003	Personnel.Elect_Elector.actual	:Entity_EDL_0000373	iraqwar_guardian__1000-01-01__timeline:35295-35304	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elected"	iraqwar_guardian__1000-01-01__timeline:39092-39098	1.000
:Event_0000003	canonical_mention.actual	"elected"	iraqwar_guardian__1000-01-01__timeline:39092-39098	1.000
:Event_0000003	Personnel.Elect_Elector.actual	:Entity_EDL_0000374	iraqwar_guardian__1000-01-01__timeline:39059-39062	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:49415-49423	1.000
:Event_0000003	canonical_mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:49415-49423	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"election"	iraqwar_guardian__1000-01-01__timeline:51737-51744	1.000
:Event_0000003	canonical_mention.actual	"election"	iraqwar_guardian__1000-01-01__timeline:51737-51744	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:50450-50458	1.000
:Event_0000003	canonical_mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:50450-50458	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elected"	iraqwar_guardian__1000-01-01__timeline:44219-44225	1.000
:Event_0000003	canonical_mention.actual	"elected"	iraqwar_guardian__1000-01-01__timeline:44219-44225	1.000
:Event_0000003	Personnel.Elect_Elect.actual	:Entity_EDL_0000389	iraqwar_guardian__1000-01-01__timeline:44233-44243	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elected"	iraqwar_guardian__1000-01-01__timeline:44016-44022	1.000
:Event_0000003	canonical_mention.actual	"elected"	iraqwar_guardian__1000-01-01__timeline:44016-44022	1.000
:Event_0000003	Personnel.Elect_Elector.actual	:Entity_EDL_0000710	iraqwar_guardian__1000-01-01__timeline:44030-44039	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"election"	iraqwar_guardian__1000-01-01__timeline:54120-54127	1.000
:Event_0000003	canonical_mention.actual	"election"	iraqwar_guardian__1000-01-01__timeline:54120-54127	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"election"	iraqwar_guardian__1000-01-01__timeline:54283-54290	1.000
:Event_0000003	canonical_mention.actual	"election"	iraqwar_guardian__1000-01-01__timeline:54283-54290	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:49032-49040	1.000
:Event_0000003	canonical_mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:49032-49040	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elected"	iraqwar_guardian__1000-01-01__timeline:42135-42141	1.000
:Event_0000003	canonical_mention.actual	"elected"	iraqwar_guardian__1000-01-01__timeline:42135-42141	1.000
:Event_0000003	Personnel.Elect_Place.actual	:Entity_EDL_0000161	iraqwar_guardian__1000-01-01__timeline:42114-42117	1.000
:Event_0000003	Personnel.Elect_Elector.actual	:Entity_EDL_0000733	iraqwar_guardian__1000-01-01__timeline:42143-42152	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:52162-52170	1.000
:Event_0000003	canonical_mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:52162-52170	1.000
:Event_0000003	Personnel.Elect_Place.actual	:Entity_EDL_0000534	iraqwar_guardian__1000-01-01__timeline:52133-52136	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:50194-50202	1.000
:Event_0000003	canonical_mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:50194-50202	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:47861-47869	1.000
:Event_0000003	canonical_mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:47861-47869	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elected"	iraqwar_guardian__1000-01-01__timeline:35505-35511	1.000
:Event_0000003	canonical_mention.actual	"elected"	iraqwar_guardian__1000-01-01__timeline:35505-35511	1.000
:Event_0000003	Personnel.Elect_Elector.actual	:Entity_EDL_0000604	iraqwar_guardian__1000-01-01__timeline:35513-35522	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:53514-53522	1.000
:Event_0000003	canonical_mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:53514-53522	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:53350-53358	1.000
:Event_0000003	canonical_mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:53350-53358	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:46330-46338	1.000
:Event_0000003	canonical_mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:46330-46338	1.000
:Event_0000003	Personnel.Elect_Place.actual	:Entity_EDL_0000744	iraqwar_guardian__1000-01-01__timeline:46298-46304	1.000
:Event_0000003	type	Personnel.Elect
:Event_0000003	mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:51928-51936	1.000
:Event_0000003	canonical_mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:51928-51936	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:33625-33631	1.000
:Event_0000004	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:33625-33631	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000725	iraqwar_guardian__1000-01-01__timeline:33605-33610	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"assassination"	iraqwar_guardian__1000-01-01__timeline:37683-37695	1.000
:Event_0000004	canonical_mention.actual	"assassination"	iraqwar_guardian__1000-01-01__timeline:37683-37695	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000470	iraqwar_guardian__1000-01-01__timeline:37666-37673	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:27591-27597	1.000
:Event_0000004	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:27591-27597	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000701	iraqwar_guardian__1000-01-01__timeline:27599-27604	1.000
:Event_0000004	Life.Die_Place.actual	:Entity_EDL_0000528	iraqwar_guardian__1000-01-01__timeline:27609-27612	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:44867-44873	1.000
:Event_0000004	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:44867-44873	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000368	iraqwar_guardian__1000-01-01__timeline:44875-44880	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:34205-34211	1.000
:Event_0000004	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:34205-34211	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:43734-43740	1.000
:Event_0000004	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:43734-43740	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000381	iraqwar_guardian__1000-01-01__timeline:43742-43747	1.000
:Event_0000004	Life.Die_Place.actual	:Entity_EDL_0000020	iraqwar_guardian__1000-01-01__timeline:43799-43804	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:36731-36737	1.000
:Event_0000004	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:36731-36737	1.000
:Event_0000004	Life.Die_Agent.actual	:Entity_EDL_0000339	iraqwar_guardian__1000-01-01__timeline:36739-36744	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"assassination"	iraqwar_guardian__1000-01-01__timeline:37503-37515	1.000
:Event_0000004	canonical_mention.actual	"assassination"	iraqwar_guardian__1000-01-01__timeline:37503-37515	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000014	iraqwar_guardian__1000-01-01__timeline:37455-37462	1.000
:Event_0000004	Life.Die_Instrument.actual	:Entity_EDL_0000275	iraqwar_guardian__1000-01-01__timeline:37498-37501	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:49947-49953	1.000
:Event_0000004	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:49947-49953	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000117	iraqwar_guardian__1000-01-01__timeline:49928-49938	1.000
:Event_0000004	Life.Die_Instrument.actual	:Entity_EDL_0000065	iraqwar_guardian__1000-01-01__timeline:49955-49957	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:50646-50652	1.000
:Event_0000004	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:50646-50652	1.000
:Event_0000004	Life.Die_Instrument.actual	:Entity_EDL_0000480	iraqwar_guardian__1000-01-01__timeline:50654-50657	1.000
:Event_0000004	Life.Die_Place.actual	:Entity_EDL_0000425	iraqwar_guardian__1000-01-01__timeline:50676-50681	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:27538-27544	1.000
:Event_0000004	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:27538-27544	1.000
:Event_0000004	Life.Die_Instrument.actual	:Entity_EDL_0000510	iraqwar_guardian__1000-01-01__timeline:27546-27549	1.000
:Event_0000004	Life.Die_Place.actual	:Entity_EDL_0000438	iraqwar_guardian__1000-01-01__timeline:27561-27564	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:37490-37496	1.000
:Event_0000004	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:37490-37496	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000327	iraqwar_guardian__1000-01-01__timeline:37466-37476	1.000
:Event_0000004	Life.Die_Instrument.actual	:Entity_EDL_0000275	iraqwar_guardian__1000-01-01__timeline:37498-37501	1.000
:Event_0000004	type	Life.Die
:Event_0000004	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:45163-45169	1.000
:Event_0000004	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:45163-45169	1.000
:Event_0000004	Life.Die_Victim.actual	:Entity_EDL_0000540	iraqwar_guardian__1000-01-01__timeline:45175-45180	1.000
:Event_0000004	Life.Die_Place.actual	:Entity_EDL_0000757	iraqwar_guardian__1000-01-01__timeline:45234-45237	1.000
:Event_0000005	type	Movement.TransportArtifact
:Event_0000005	mention.actual	"pull"	iraqwar_guardian__1000-01-01__timeline:26195-26198	1.000
:Event_0000005	canonical_mention.actual	"pull"	iraqwar_guardian__1000-01-01__timeline:26195-26198	1.000
:Event_0000005	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000458	iraqwar_guardian__1000-01-01__timeline:26176-26180	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000162	iraqwar_guardian__1000-01-01__timeline:26200-26205	1.000
:Event_0000005	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000251	iraqwar_guardian__1000-01-01__timeline:26214-26217	1.000
:Event_0000005	type	Movement.TransportArtifact
:Event_0000005	mention.actual	"withdrawn"	iraqwar_guardian__1000-01-01__timeline:419-427	1.000
:Event_0000005	canonical_mention.actual	"withdrawn"	iraqwar_guardian__1000-01-01__timeline:419-427	1.000
:Event_0000005	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000005	iraqwar_guardian__1000-01-01__timeline:363-367	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000280	iraqwar_guardian__1000-01-01__timeline:394-399	1.000
:Event_0000005	type	Movement.TransportArtifact
:Event_0000005	mention.actual	"pulling"	iraqwar_guardian__1000-01-01__timeline:25990-25996	1.000
:Event_0000005	canonical_mention.actual	"pulling"	iraqwar_guardian__1000-01-01__timeline:25990-25996	1.000
:Event_0000005	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000513	iraqwar_guardian__1000-01-01__timeline:25971-25977	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000478	iraqwar_guardian__1000-01-01__timeline:25998-26003	1.000
:Event_0000005	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000155	iraqwar_guardian__1000-01-01__timeline:26012-26015	1.000
:Event_0000005	type	Movement.TransportArtifact
:Event_0000005	mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:22264-22273	1.000
:Event_0000005	canonical_mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:22264-22273	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000428	iraqwar_guardian__1000-01-01__timeline:22248-22253	1.000
:Event_0000005	type	Movement.TransportArtifact
:Event_0000005	mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:11813-11822	1.000
:Event_0000005	canonical_mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:11813-11822	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000217	iraqwar_guardian__1000-01-01__timeline:11835-11840	1.000
:Event_0000005	type	Movement.TransportArtifact
:Event_0000005	mention.actual	"withdraw"	iraqwar_guardian__1000-01-01__timeline:11627-11634	1.000
:Event_0000005	canonical_mention.actual	"withdraw"	iraqwar_guardian__1000-01-01__timeline:11627-11634	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000683	iraqwar_guardian__1000-01-01__timeline:11611-11616	1.000
:Event_0000005	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000511	iraqwar_guardian__1000-01-01__timeline:11641-11644	1.000
:Event_0000005	type	Movement.TransportArtifact
:Event_0000005	mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:10545-10554	1.000
:Event_0000005	canonical_mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:10545-10554	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000179	iraqwar_guardian__1000-01-01__timeline:10519-10524	1.000
:Event_0000005	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000492	iraqwar_guardian__1000-01-01__timeline:10561-10564	1.000
:Event_0000005	type	Movement.TransportArtifact
:Event_0000005	mention.actual	"pull"	iraqwar_guardian__1000-01-01__timeline:31437-31440	1.000
:Event_0000005	canonical_mention.actual	"pull"	iraqwar_guardian__1000-01-01__timeline:31437-31440	1.000
:Event_0000005	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000707	iraqwar_guardian__1000-01-01__timeline:31410-31419	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000180	iraqwar_guardian__1000-01-01__timeline:31453-31458	1.000
:Event_0000005	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000751	iraqwar_guardian__1000-01-01__timeline:31473-31477	1.000
:Event_0000005	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000587	iraqwar_guardian__1000-01-01__timeline:31483-31488	1.000
:Event_0000005	type	Movement.TransportArtifact
:Event_0000005	mention.actual	"withdraw"	iraqwar_guardian__1000-01-01__timeline:25565-25572	1.000
:Event_0000005	canonical_mention.actual	"withdraw"	iraqwar_guardian__1000-01-01__timeline:25565-25572	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000593	iraqwar_guardian__1000-01-01__timeline:25574-25577	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000226	iraqwar_guardian__1000-01-01__timeline:25588-25593	1.000
:Event_0000005	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000629	iraqwar_guardian__1000-01-01__timeline:25600-25603	1.000
:Event_0000005	type	Movement.TransportArtifact
:Event_0000005	mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:31576-31585	1.000
:Event_0000005	canonical_mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:31576-31585	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000105	iraqwar_guardian__1000-01-01__timeline:31503-31506	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:51314-51319	1.000
:Event_0000006	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:51314-51319	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000747	iraqwar_guardian__1000-01-01__timeline:51311-51312	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000254	iraqwar_guardian__1000-01-01__timeline:51324-51330	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:53366-53371	1.000
:Event_0000006	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:53366-53371	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000245	iraqwar_guardian__1000-01-01__timeline:53363-53364	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000612	iraqwar_guardian__1000-01-01__timeline:53376-53379	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:51117-51122	1.000
:Event_0000006	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:51117-51122	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000721	iraqwar_guardian__1000-01-01__timeline:51106-51111	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000512	iraqwar_guardian__1000-01-01__timeline:51127-51133	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:53137-53142	1.000
:Event_0000006	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:53137-53142	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000442	iraqwar_guardian__1000-01-01__timeline:53130-53135	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:53210-53215	1.000
:Event_0000006	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:53210-53215	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000295	iraqwar_guardian__1000-01-01__timeline:53199-53204	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000479	iraqwar_guardian__1000-01-01__timeline:53246-53249	1.000
:Event_0000006	Life.Die_Agent.actual	:Entity_EDL_0000066	iraqwar_guardian__1000-01-01__timeline:53254-53263	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:49679-49684	1.000
:Event_0000006	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:49679-49684	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000697	iraqwar_guardian__1000-01-01__timeline:49669-49677	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000740	iraqwar_guardian__1000-01-01__timeline:49689-49695	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:49250-49255	1.000
:Event_0000006	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:49250-49255	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000497	iraqwar_guardian__1000-01-01__timeline:49236-49244	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000113	iraqwar_guardian__1000-01-01__timeline:49290-49297	1.000
:Event_0000006	Life.Die_Agent.actual	:Entity_EDL_0000038	iraqwar_guardian__1000-01-01__timeline:49329-49334	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:38374-38381	1.000
:Event_0000007	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:38374-38381	1.000
:Event_0000007	Conflict.Attack_Instrument.actual	:Entity_EDL_0000307	iraqwar_guardian__1000-01-01__timeline:38370-38372	1.000
:Event_0000007	Conflict.Attack_Place.actual	:Entity_EDL_0000205	iraqwar_guardian__1000-01-01__timeline:38447-38453	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:38487-38494	1.000
:Event_0000007	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:38487-38494	1.000
:Event_0000007	Conflict.Attack_Target.actual	:Entity_EDL_0000120	iraqwar_guardian__1000-01-01__timeline:38458-38459	1.000
:Event_0000007	Conflict.Attack_Place.actual	:Entity_EDL_0000490	iraqwar_guardian__1000-01-01__timeline:38471-38477	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:29505-29512	1.000
:Event_0000007	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:29505-29512	1.000
:Event_0000007	Conflict.Attack_Instrument.actual	:Entity_EDL_0000636	iraqwar_guardian__1000-01-01__timeline:29501-29503	1.000
:Event_0000007	Conflict.Attack_Target.actual	:Entity_EDL_0000099	iraqwar_guardian__1000-01-01__timeline:29522-29527	1.000
:Event_0000007	Conflict.Attack_Place.actual	:Entity_EDL_0000761	iraqwar_guardian__1000-01-01__timeline:29541-29544	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:31094-31101	1.000
:Event_0000007	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:31094-31101	1.000
:Event_0000007	Conflict.Attack_Place.actual	:Entity_EDL_0000297	iraqwar_guardian__1000-01-01__timeline:31108-31111	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:30923-30929	1.000
:Event_0000007	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:30923-30929	1.000
:Event_0000007	Conflict.Attack_Place.actual	:Entity_EDL_0000370	iraqwar_guardian__1000-01-01__timeline:30965-30971	1.000
:Event_0000008	type	Conflict.Attack
:Event_0000008	mention.actual	"abusing"	iraqwar_guardian__1000-01-01__timeline:52428-52434	1.000
:Event_0000008	canonical_mention.actual	"abusing"	iraqwar_guardian__1000-01-01__timeline:52428-52434	1.000
:Event_0000008	Conflict.Attack_Target.actual	:Entity_EDL_0000595	iraqwar_guardian__1000-01-01__timeline:52442-52450	1.000
:Event_0000008	type	Conflict.Attack
:Event_0000008	mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:46016-46020	1.000
:Event_0000008	canonical_mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:46016-46020	1.000
:Event_0000008	Conflict.Attack_Attacker.actual	:Entity_EDL_0000325	iraqwar_guardian__1000-01-01__timeline:45955-45960	1.000
:Event_0000008	Conflict.Attack_Target.actual	:Entity_EDL_0000685	iraqwar_guardian__1000-01-01__timeline:46059-46067	1.000
:Event_0000008	type	Conflict.Attack
:Event_0000008	mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:52111-52115	1.000
:Event_0000008	canonical_mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:52111-52115	1.000
:Event_0000008	Conflict.Attack_Target.actual	:Entity_EDL_0000265	iraqwar_guardian__1000-01-01__timeline:52077-52082	1.000
:Event_0000008	Conflict.Attack_Target.actual	:Entity_EDL_0000042	iraqwar_guardian__1000-01-01__timeline:52120-52128	1.000
:Event_0000008	type	Conflict.Attack
:Event_0000008	mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:45419-45423	1.000
:Event_0000008	canonical_mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:45419-45423	1.000
:Event_0000008	Conflict.Attack_Attacker.actual	:Entity_EDL_0000658	iraqwar_guardian__1000-01-01__timeline:45389-45396	1.000
:Event_0000008	Conflict.Attack_Target.actual	:Entity_EDL_0000585	iraqwar_guardian__1000-01-01__timeline:45434-45442	1.000
:Event_0000008	type	Conflict.Attack
:Event_0000008	mention.actual	"abusing"	iraqwar_guardian__1000-01-01__timeline:51444-51450	1.000
:Event_0000008	canonical_mention.actual	"abusing"	iraqwar_guardian__1000-01-01__timeline:51444-51450	1.000
:Event_0000008	Conflict.Attack_Attacker.actual	:Entity_EDL_0000462	iraqwar_guardian__1000-01-01__timeline:51427-51432	1.000
:Event_0000008	Conflict.Attack_Target.actual	:Entity_EDL_0000335	iraqwar_guardian__1000-01-01__timeline:51474-51482	1.000
:Event_0000009	type	Conflict.Attack
:Event_0000009	mention.actual	"offensives"	iraqwar_guardian__1000-01-01__timeline:28016-28025	1.000
:Event_0000009	canonical_mention.actual	"offensives"	iraqwar_guardian__1000-01-01__timeline:28016-28025	1.000
:Event_0000009	Conflict.Attack_Attacker.actual	:Entity_EDL_0000704	iraqwar_guardian__1000-01-01__timeline:27941-27946	1.000
:Event_0000009	Conflict.Attack_Target.actual	:Entity_EDL_0000592	iraqwar_guardian__1000-01-01__timeline:28052-28061	1.000
:Event_0000009	Conflict.Attack_Place.actual	:Entity_EDL_0000341	iraqwar_guardian__1000-01-01__timeline:28074-28079	1.000
:Event_0000009	type	Conflict.Attack
:Event_0000009	mention.actual	"offensive"	iraqwar_guardian__1000-01-01__timeline:27687-27695	1.000
:Event_0000009	canonical_mention.actual	"offensive"	iraqwar_guardian__1000-01-01__timeline:27687-27695	1.000
:Event_0000009	Conflict.Attack_Instrument.actual	:Entity_EDL_0000098	iraqwar_guardian__1000-01-01__timeline:27667-27675	1.000
:Event_0000009	Conflict.Attack_Attacker.actual	:Entity_EDL_0000726	iraqwar_guardian__1000-01-01__timeline:27684-27685	1.000
:Event_0000009	Conflict.Attack_Target.actual	:Entity_EDL_0000351	iraqwar_guardian__1000-01-01__timeline:27705-27714	1.000
:Event_0000009	Conflict.Attack_Place.actual	:Entity_EDL_0000599	iraqwar_guardian__1000-01-01__timeline:27728-27731	1.000
:Event_0000009	type	Conflict.Attack
:Event_0000009	mention.actual	"assault"	iraqwar_guardian__1000-01-01__timeline:27885-27891	1.000
:Event_0000009	canonical_mention.actual	"assault"	iraqwar_guardian__1000-01-01__timeline:27885-27891	1.000
:Event_0000009	Conflict.Attack_Attacker.actual	:Entity_EDL_0000176	iraqwar_guardian__1000-01-01__timeline:27870-27875	1.000
:Event_0000009	Conflict.Attack_Place.actual	:Entity_EDL_0000405	iraqwar_guardian__1000-01-01__timeline:27880-27883	1.000
:Event_0000009	type	Conflict.Attack
:Event_0000009	mention.actual	"offensive"	iraqwar_guardian__1000-01-01__timeline:28222-28230	1.000
:Event_0000009	canonical_mention.actual	"offensive"	iraqwar_guardian__1000-01-01__timeline:28222-28230	1.000
:Event_0000009	Conflict.Attack_Attacker.actual	:Entity_EDL_0000391	iraqwar_guardian__1000-01-01__timeline:28199-28204	1.000
:Event_0000009	Conflict.Attack_Place.actual	:Entity_EDL_0000073	iraqwar_guardian__1000-01-01__timeline:28217-28220	1.000
:Event_0000009	type	Conflict.Attack
:Event_0000009	mention.actual	"assault"	iraqwar_guardian__1000-01-01__timeline:27827-27833	1.000
:Event_0000009	canonical_mention.actual	"assault"	iraqwar_guardian__1000-01-01__timeline:27827-27833	1.000
:Event_0000009	Conflict.Attack_Attacker.actual	:Entity_EDL_0000172	iraqwar_guardian__1000-01-01__timeline:27798-27800	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:48037-48043	1.000
:Event_0000010	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:48037-48043	1.000
:Event_0000010	Conflict.Attack_Target.actual	:Entity_EDL_0000019	iraqwar_guardian__1000-01-01__timeline:48016-48021	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:53235-53241	1.000
:Event_0000010	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:53235-53241	1.000
:Event_0000010	Conflict.Attack_Target.actual	:Entity_EDL_0000295	iraqwar_guardian__1000-01-01__timeline:53199-53204	1.000
:Event_0000010	Conflict.Attack_Place.actual	:Entity_EDL_0000479	iraqwar_guardian__1000-01-01__timeline:53246-53249	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:53381-53387	1.000
:Event_0000010	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:53381-53387	1.000
:Event_0000010	Conflict.Attack_Place.actual	:Entity_EDL_0000612	iraqwar_guardian__1000-01-01__timeline:53376-53379	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:54530-54536	1.000
:Event_0000010	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:54530-54536	1.000
:Event_0000010	Conflict.Attack_Target.actual	:Entity_EDL_0000507	iraqwar_guardian__1000-01-01__timeline:54546-54551	1.000
:Event_0000011	type	Conflict.Attack
:Event_0000011	mention.actual	"violence"	iraqwar_guardian__1000-01-01__timeline:33900-33907	1.000
:Event_0000011	canonical_mention.actual	"violence"	iraqwar_guardian__1000-01-01__timeline:33900-33907	1.000
:Event_0000011	Conflict.Attack_Place.actual	:Entity_EDL_0000590	iraqwar_guardian__1000-01-01__timeline:33912-33915	1.000
:Event_0000011	type	Conflict.Attack
:Event_0000011	mention.actual	"violence"	iraqwar_guardian__1000-01-01__timeline:48496-48503	1.000
:Event_0000011	canonical_mention.actual	"violence"	iraqwar_guardian__1000-01-01__timeline:48496-48503	1.000
:Event_0000011	type	Conflict.Attack
:Event_0000011	mention.actual	"violence"	iraqwar_guardian__1000-01-01__timeline:51944-51951	1.000
:Event_0000011	canonical_mention.actual	"violence"	iraqwar_guardian__1000-01-01__timeline:51944-51951	1.000
:Event_0000011	type	Conflict.Attack
:Event_0000011	mention.actual	"violence"	iraqwar_guardian__1000-01-01__timeline:28814-28821	1.000
:Event_0000011	canonical_mention.actual	"violence"	iraqwar_guardian__1000-01-01__timeline:28814-28821	1.000
:Event_0000012	type	Justice.TrialHearing
:Event_0000012	mention.actual	"trial"	iraqwar_guardian__1000-01-01__timeline:6621-6625	1.000
:Event_0000012	canonical_mention.actual	"trial"	iraqwar_guardian__1000-01-01__timeline:6621-6625	1.000
:Event_0000012	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000628	iraqwar_guardian__1000-01-01__timeline:6630-6643	1.000
:Event_0000012	type	Justice.TrialHearing
:Event_0000012	mention.actual	"trial"	iraqwar_guardian__1000-01-01__timeline:778-782	1.000
:Event_0000012	canonical_mention.actual	"trial"	iraqwar_guardian__1000-01-01__timeline:778-782	1.000
:Event_0000012	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000450	iraqwar_guardian__1000-01-01__timeline:774-776	1.000
:Event_0000012	type	Justice.TrialHearing
:Event_0000012	mention.actual	"trial"	iraqwar_guardian__1000-01-01__timeline:6788-6792	1.000
:Event_0000012	canonical_mention.actual	"trial"	iraqwar_guardian__1000-01-01__timeline:6788-6792	1.000
:Event_0000012	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000466	iraqwar_guardian__1000-01-01__timeline:6731-6744	1.000
:Event_0000012	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000322	iraqwar_guardian__1000-01-01__timeline:6784-6786	1.000
:Event_0000012	type	Justice.TrialHearing
:Event_0000012	mention.actual	"trial"	iraqwar_guardian__1000-01-01__timeline:7003-7007	1.000
:Event_0000012	canonical_mention.actual	"trial"	iraqwar_guardian__1000-01-01__timeline:7003-7007	1.000
:Event_0000012	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000427	iraqwar_guardian__1000-01-01__timeline:6985-6990	1.000
:Event_0000013	type	Life.Die
:Event_0000013	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:15174-15179	1.000
:Event_0000013	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:15174-15179	1.000
:Event_0000013	Life.Die_Victim.actual	:Entity_EDL_0000667	iraqwar_guardian__1000-01-01__timeline:15167-15172	1.000
:Event_0000013	Life.Die_Agent.actual	:Entity_EDL_0000017	iraqwar_guardian__1000-01-01__timeline:15197-15202	1.000
:Event_0000013	type	Life.Die
:Event_0000013	mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:14898-14901	1.000
:Event_0000013	canonical_mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:14898-14901	1.000
:Event_0000013	Life.Die_Agent.actual	:Entity_EDL_0000467	iraqwar_guardian__1000-01-01__timeline:14866-14874	1.000
:Event_0000013	Life.Die_Victim.actual	:Entity_EDL_0000305	iraqwar_guardian__1000-01-01__timeline:14891-14896	1.000
:Event_0000013	type	Life.Die
:Event_0000013	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:13851-13856	1.000
:Event_0000013	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:13851-13856	1.000
:Event_0000013	Life.Die_Victim.actual	:Entity_EDL_0000059	iraqwar_guardian__1000-01-01__timeline:13839-13844	1.000
:Event_0000013	type	Life.Die
:Event_0000013	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:14150-14155	1.000
:Event_0000013	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:14150-14155	1.000
:Event_0000013	Life.Die_Victim.actual	:Entity_EDL_0000272	iraqwar_guardian__1000-01-01__timeline:14139-14144	1.000
:Event_0000013	Life.Die_Place.actual	:Entity_EDL_0000509	iraqwar_guardian__1000-01-01__timeline:14240-14246	1.000
:Event_0000014	type	Justice.ReleaseParole
:Event_0000014	mention.actual	"release"	iraqwar_guardian__1000-01-01__timeline:28333-28339	1.000
:Event_0000014	canonical_mention.actual	"release"	iraqwar_guardian__1000-01-01__timeline:28333-28339	1.000
:Event_0000014	Justice.ReleaseParole_Agent.actual	:Entity_EDL_0000029	iraqwar_guardian__1000-01-01__timeline:28307-28308	1.000
:Event_0000014	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000759	iraqwar_guardian__1000-01-01__timeline:28346-28355	1.000
:Event_0000014	type	Justice.ReleaseParole
:Event_0000014	mention.actual	"release"	iraqwar_guardian__1000-01-01__timeline:17508-17514	1.000
:Event_0000014	canonical_mention.actual	"release"	iraqwar_guardian__1000-01-01__timeline:17508-17514	1.000
:Event_0000014	type	Justice.ReleaseParole
:Event_0000014	mention.actual	"freed"	iraqwar_guardian__1000-01-01__timeline:28551-28555	1.000
:Event_0000014	canonical_mention.actual	"freed"	iraqwar_guardian__1000-01-01__timeline:28551-28555	1.000
:Event_0000014	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000755	iraqwar_guardian__1000-01-01__timeline:28534-28549	1.000
:Event_0000015	type	Life.Die
:Event_0000015	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:24501-24507	1.000
:Event_0000015	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:24501-24507	1.000
:Event_0000015	Life.Die_Victim.actual	:Entity_EDL_0000531	iraqwar_guardian__1000-01-01__timeline:24509-24514	1.000
:Event_0000015	type	Life.Die
:Event_0000015	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:21515-21521	1.000
:Event_0000015	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:21515-21521	1.000
:Event_0000015	Life.Die_Victim.actual	:Entity_EDL_0000627	iraqwar_guardian__1000-01-01__timeline:21523-21528	1.000
:Event_0000015	Life.Die_Place.actual	:Entity_EDL_0000171	iraqwar_guardian__1000-01-01__timeline:21547-21556	1.000
:Event_0000015	type	Life.Die
:Event_0000015	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:22603-22609	1.000
:Event_0000015	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:22603-22609	1.000
:Event_0000015	Life.Die_Victim.actual	:Entity_EDL_0000672	iraqwar_guardian__1000-01-01__timeline:22617-22622	1.000
:Event_0000015	Life.Die_Place.actual	:Entity_EDL_0000633	iraqwar_guardian__1000-01-01__timeline:22635-22641	1.000
:Event_0000016	type	Conflict.Attack
:Event_0000016	mention.actual	"detonates"	iraqwar_guardian__1000-01-01__timeline:50814-50822	1.000
:Event_0000016	canonical_mention.actual	"detonates"	iraqwar_guardian__1000-01-01__timeline:50814-50822	1.000
:Event_0000016	Conflict.Attack_Attacker.actual	:Entity_EDL_0000118	iraqwar_guardian__1000-01-01__timeline:50807-50812	1.000
:Event_0000016	Conflict.Attack_Instrument.actual	:Entity_EDL_0000423	iraqwar_guardian__1000-01-01__timeline:50827-50835	1.000
:Event_0000016	Conflict.Attack_Place.actual	:Entity_EDL_0000160	iraqwar_guardian__1000-01-01__timeline:50866-50872	1.000
:Event_0000016	type	Conflict.Attack
:Event_0000016	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:50923-50929	1.000
:Event_0000016	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:50923-50929	1.000
:Event_0000016	type	Conflict.Attack
:Event_0000016	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:51011-51017	1.000
:Event_0000016	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:51011-51017	1.000
:Event_0000016	Conflict.Attack_Place.actual	:Entity_EDL_0000267	iraqwar_guardian__1000-01-01__timeline:51030-51035	1.000
:Event_0000017	type	Justice.ArrestJail
:Event_0000017	mention.actual	"arrest"	iraqwar_guardian__1000-01-01__timeline:11261-11266	1.000
:Event_0000017	canonical_mention.actual	"arrest"	iraqwar_guardian__1000-01-01__timeline:11261-11266	1.000
:Event_0000017	Justice.ArrestJail_Person.actual	:Entity_EDL_0000163	iraqwar_guardian__1000-01-01__timeline:11288-11293	1.000
:Event_0000017	type	Justice.ArrestJail
:Event_0000017	mention.actual	"arrest"	iraqwar_guardian__1000-01-01__timeline:12651-12656	1.000
:Event_0000017	canonical_mention.actual	"arrest"	iraqwar_guardian__1000-01-01__timeline:12651-12656	1.000
:Event_0000017	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000664	iraqwar_guardian__1000-01-01__timeline:12615-12625	1.000
:Event_0000017	Justice.ArrestJail_Person.actual	:Entity_EDL_0000690	iraqwar_guardian__1000-01-01__timeline:12685-12697	1.000
:Event_0000017	type	Justice.ArrestJail
:Event_0000017	mention.actual	"arrest"	iraqwar_guardian__1000-01-01__timeline:10979-10984	1.000
:Event_0000017	canonical_mention.actual	"arrest"	iraqwar_guardian__1000-01-01__timeline:10979-10984	1.000
:Event_0000017	Justice.ArrestJail_Person.actual	:Entity_EDL_0000481	iraqwar_guardian__1000-01-01__timeline:11014-11021	1.000
:Event_0000018	type	Movement.TransportPerson
:Event_0000018	mention.actual	"withdraw"	iraqwar_guardian__1000-01-01__timeline:11868-11875	1.000
:Event_0000018	canonical_mention.actual	"withdraw"	iraqwar_guardian__1000-01-01__timeline:11868-11875	1.000
:Event_0000018	Movement.TransportPerson_Person.actual	:Entity_EDL_0000720	iraqwar_guardian__1000-01-01__timeline:11852-11857	1.000
:Event_0000018	type	Movement.TransportPerson
:Event_0000018	mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:12224-12233	1.000
:Event_0000018	canonical_mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:12224-12233	1.000
:Event_0000018	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000219	iraqwar_guardian__1000-01-01__timeline:12189-12192	1.000
:Event_0000018	Movement.TransportPerson_Person.actual	:Entity_EDL_0000131	iraqwar_guardian__1000-01-01__timeline:12246-12251	1.000
:Event_0000018	type	Movement.TransportPerson
:Event_0000018	mention.actual	"pull-out"	iraqwar_guardian__1000-01-01__timeline:22103-22110	1.000
:Event_0000018	canonical_mention.actual	"pull-out"	iraqwar_guardian__1000-01-01__timeline:22103-22110	1.000
:Event_0000018	Movement.TransportPerson_Person.actual	:Entity_EDL_0000278	iraqwar_guardian__1000-01-01__timeline:22118-22123	1.000
:Event_0000019	type	Justice.ChargeIndict
:Event_0000019	mention.actual	"charged"	iraqwar_guardian__1000-01-01__timeline:47075-47081	1.000
:Event_0000019	canonical_mention.actual	"charged"	iraqwar_guardian__1000-01-01__timeline:47075-47081	1.000
:Event_0000019	type	Justice.ChargeIndict
:Event_0000019	mention.actual	"charges"	iraqwar_guardian__1000-01-01__timeline:37106-37112	1.000
:Event_0000019	canonical_mention.actual	"charges"	iraqwar_guardian__1000-01-01__timeline:37106-37112	1.000
:Event_0000019	Justice.ChargeIndict_Prosecutor.actual	:Entity_EDL_0000649	iraqwar_guardian__1000-01-01__timeline:37073-37076	1.000
:Event_0000019	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000331	iraqwar_guardian__1000-01-01__timeline:37089-37093	1.000
:Event_0000019	type	Justice.ChargeIndict
:Event_0000019	mention.actual	"charge"	iraqwar_guardian__1000-01-01__timeline:47295-47300	1.000
:Event_0000019	canonical_mention.actual	"charge"	iraqwar_guardian__1000-01-01__timeline:47295-47300	1.000
:Event_0000019	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000342	iraqwar_guardian__1000-01-01__timeline:47272-47276	1.000
:Event_0000020	type	Contact.Meet
:Event_0000020	mention.actual	"talks"	iraqwar_guardian__1000-01-01__timeline:18510-18514	1.000
:Event_0000020	canonical_mention.actual	"talks"	iraqwar_guardian__1000-01-01__timeline:18510-18514	1.000
:Event_0000020	Contact.Meet_Participant.actual	:Entity_EDL_0000134	iraqwar_guardian__1000-01-01__timeline:18491-18501	1.000
:Event_0000020	type	Contact.Meet
:Event_0000020	mention.actual	"talks"	iraqwar_guardian__1000-01-01__timeline:29020-29024	1.000
:Event_0000020	canonical_mention.actual	"talks"	iraqwar_guardian__1000-01-01__timeline:29020-29024	1.000
:Event_0000020	Contact.Meet_Participant.actual	:Entity_EDL_0000147	iraqwar_guardian__1000-01-01__timeline:29014-29015	1.000
:Event_0000020	Contact.Meet_Participant.actual	:Entity_EDL_0000087	iraqwar_guardian__1000-01-01__timeline:29037-29046	1.000
:Event_0000020	type	Contact.Meet
:Event_0000020	mention.actual	"talks"	iraqwar_guardian__1000-01-01__timeline:28704-28708	1.000
:Event_0000020	canonical_mention.actual	"talks"	iraqwar_guardian__1000-01-01__timeline:28704-28708	1.000
:Event_0000020	Contact.Meet_Participant.actual	:Entity_EDL_0000239	iraqwar_guardian__1000-01-01__timeline:28655-28663	1.000
:Event_0000020	Contact.Meet_Participant.actual	:Entity_EDL_0000230	iraqwar_guardian__1000-01-01__timeline:28674-28683	1.000
:Event_0000020	Contact.Meet_Participant.actual	:Entity_EDL_0000409	iraqwar_guardian__1000-01-01__timeline:28715-28724	1.000
:Event_0000020	Contact.Meet_Place.actual	:Entity_EDL_0000445	iraqwar_guardian__1000-01-01__timeline:28729-28732	1.000
:Event_0000021	type	Conflict.Attack
:Event_0000021	mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:32293-32297	1.000
:Event_0000021	canonical_mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:32293-32297	1.000
:Event_0000021	Conflict.Attack_Target.actual	:Entity_EDL_0000321	iraqwar_guardian__1000-01-01__timeline:32302-32307	1.000
:Event_0000021	Conflict.Attack_Attacker.actual	:Entity_EDL_0000441	iraqwar_guardian__1000-01-01__timeline:32320-32325	1.000
:Event_0000021	type	Conflict.Attack
:Event_0000021	mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:37047-37051	1.000
:Event_0000021	canonical_mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:37047-37051	1.000
:Event_0000021	Conflict.Attack_Target.actual	:Entity_EDL_0000070	iraqwar_guardian__1000-01-01__timeline:37038-37045	1.000
:Event_0000021	Conflict.Attack_Place.actual	:Entity_EDL_0000353	iraqwar_guardian__1000-01-01__timeline:37056-37065	1.000
:Event_0000021	type	Conflict.Attack
:Event_0000021	mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:32076-32080	1.000
:Event_0000021	canonical_mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:32076-32080	1.000
:Event_0000021	Conflict.Attack_Target.actual	:Entity_EDL_0000456	iraqwar_guardian__1000-01-01__timeline:32085-32090	1.000
:Event_0000021	Conflict.Attack_Attacker.actual	:Entity_EDL_0000620	iraqwar_guardian__1000-01-01__timeline:32103-32110	1.000
:Event_0000022	type	Contact.Contact
:Event_0000022	mention.actual	"talks"	iraqwar_guardian__1000-01-01__timeline:18897-18901	1.000
:Event_0000022	canonical_mention.actual	"talks"	iraqwar_guardian__1000-01-01__timeline:18897-18901	1.000
:Event_0000022	Contact.Contact_Participant.actual	:Entity_EDL_0000055	iraqwar_guardian__1000-01-01__timeline:18968-18973	1.000
:Event_0000022	type	Contact.Contact
:Event_0000022	mention.actual	"contact"	iraqwar_guardian__1000-01-01__timeline:28768-28774	1.000
:Event_0000022	canonical_mention.actual	"contact"	iraqwar_guardian__1000-01-01__timeline:28768-28774	1.000
:Event_0000022	Contact.Contact_Participant.actual	:Entity_EDL_0000409	iraqwar_guardian__1000-01-01__timeline:28715-28724	1.000
:Event_0000022	Contact.Contact_Participant.actual	:Entity_EDL_0000122	iraqwar_guardian__1000-01-01__timeline:28792-28796	1.000
:Event_0000022	type	Contact.Contact
:Event_0000022	mention.actual	"contact"	iraqwar_guardian__1000-01-01__timeline:27288-27294	1.000
:Event_0000022	canonical_mention.actual	"contact"	iraqwar_guardian__1000-01-01__timeline:27288-27294	1.000
:Event_0000022	Contact.Contact_Participant.actual	:Entity_EDL_0000563	iraqwar_guardian__1000-01-01__timeline:27285-27286	1.000
:Event_0000022	Contact.Contact_Participant.actual	:Entity_EDL_0000154	iraqwar_guardian__1000-01-01__timeline:27301-27310	1.000
:Event_0000023	type	Life.Die
:Event_0000023	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:38479-38485	1.000
:Event_0000023	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:38479-38485	1.000
:Event_0000023	Life.Die_Victim.actual	:Entity_EDL_0000120	iraqwar_guardian__1000-01-01__timeline:38458-38459	1.000
:Event_0000023	Life.Die_Place.actual	:Entity_EDL_0000490	iraqwar_guardian__1000-01-01__timeline:38471-38477	1.000
:Event_0000023	type	Life.Die
:Event_0000023	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:29493-29499	1.000
:Event_0000023	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:29493-29499	1.000
:Event_0000023	Life.Die_Place.actual	:Entity_EDL_0000761	iraqwar_guardian__1000-01-01__timeline:29541-29544	1.000
:Event_0000023	type	Life.Die
:Event_0000023	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:38362-38368	1.000
:Event_0000023	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:38362-38368	1.000
:Event_0000023	Life.Die_Place.actual	:Entity_EDL_0000205	iraqwar_guardian__1000-01-01__timeline:38447-38453	1.000
:Event_0000024	type	Conflict.Attack
:Event_0000024	mention.actual	"violence"	iraqwar_guardian__1000-01-01__timeline:13304-13311	1.000
:Event_0000024	canonical_mention.actual	"violence"	iraqwar_guardian__1000-01-01__timeline:13304-13311	1.000
:Event_0000024	Conflict.Attack_Place.actual	:Entity_EDL_0000016	iraqwar_guardian__1000-01-01__timeline:13316-13320	1.000
:Event_0000024	type	Conflict.Attack
:Event_0000024	mention.actual	"violence"	iraqwar_guardian__1000-01-01__timeline:14491-14498	1.000
:Event_0000024	canonical_mention.actual	"violence"	iraqwar_guardian__1000-01-01__timeline:14491-14498	1.000
:Event_0000025	type	Conflict.Attack
:Event_0000025	mention.actual	"clashes"	iraqwar_guardian__1000-01-01__timeline:49697-49703	1.000
:Event_0000025	canonical_mention.actual	"clashes"	iraqwar_guardian__1000-01-01__timeline:49697-49703	1.000
:Event_0000025	Conflict.Attack_Target.actual	:Entity_EDL_0000697	iraqwar_guardian__1000-01-01__timeline:49669-49677	1.000
:Event_0000025	Conflict.Attack_Place.actual	:Entity_EDL_0000740	iraqwar_guardian__1000-01-01__timeline:49689-49695	1.000
:Event_0000025	type	Conflict.Attack
:Event_0000025	mention.actual	"clashes"	iraqwar_guardian__1000-01-01__timeline:49260-49266	1.000
:Event_0000025	canonical_mention.actual	"clashes"	iraqwar_guardian__1000-01-01__timeline:49260-49266	1.000
:Event_0000025	Conflict.Attack_Place.actual	:Entity_EDL_0000113	iraqwar_guardian__1000-01-01__timeline:49290-49297	1.000
:Event_0000025	Conflict.Attack_Attacker.actual	:Entity_EDL_0000038	iraqwar_guardian__1000-01-01__timeline:49329-49334	1.000
:Event_0000026	type	Transaction.TransferOwnership
:Event_0000026	mention.actual	"capture"	iraqwar_guardian__1000-01-01__timeline:15204-15210	1.000
:Event_0000026	canonical_mention.actual	"capture"	iraqwar_guardian__1000-01-01__timeline:15204-15210	1.000
:Event_0000026	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000017	iraqwar_guardian__1000-01-01__timeline:15197-15202	1.000
:Event_0000026	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000130	iraqwar_guardian__1000-01-01__timeline:15222-15231	1.000
:Event_0000026	type	Transaction.TransferOwnership
:Event_0000026	mention.actual	"seize"	iraqwar_guardian__1000-01-01__timeline:14802-14806	1.000
:Event_0000026	canonical_mention.actual	"seize"	iraqwar_guardian__1000-01-01__timeline:14802-14806	1.000
:Event_0000026	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000363	iraqwar_guardian__1000-01-01__timeline:14795-14800	1.000
:Event_0000026	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000290	iraqwar_guardian__1000-01-01__timeline:14832-14841	1.000
:Event_0000027	type	Conflict.Attack
:Event_0000027	mention.actual	"raid"	iraqwar_guardian__1000-01-01__timeline:27370-27373	1.000
:Event_0000027	canonical_mention.actual	"raid"	iraqwar_guardian__1000-01-01__timeline:27370-27373	1.000
:Event_0000027	Conflict.Attack_Attacker.actual	:Entity_EDL_0000050	iraqwar_guardian__1000-01-01__timeline:27363-27368	1.000
:Event_0000027	Conflict.Attack_Target.actual	:Entity_EDL_0000416	iraqwar_guardian__1000-01-01__timeline:27386-27389	1.000
:Event_0000027	Conflict.Attack_Place.actual	:Entity_EDL_0000589	iraqwar_guardian__1000-01-01__timeline:27394-27403	1.000
:Event_0000027	type	Conflict.Attack
:Event_0000027	mention.actual	"raid"	iraqwar_guardian__1000-01-01__timeline:27576-27579	1.000
:Event_0000027	canonical_mention.actual	"raid"	iraqwar_guardian__1000-01-01__timeline:27576-27579	1.000
:Event_0000027	Conflict.Attack_Attacker.actual	:Entity_EDL_0000527	iraqwar_guardian__1000-01-01__timeline:27569-27574	1.000
:Event_0000027	Conflict.Attack_Place.actual	:Entity_EDL_0000528	iraqwar_guardian__1000-01-01__timeline:27609-27612	1.000
:Event_0000028	type	Conflict.Attack
:Event_0000028	mention.actual	"explosions"	iraqwar_guardian__1000-01-01__timeline:14278-14287	1.000
:Event_0000028	canonical_mention.actual	"explosions"	iraqwar_guardian__1000-01-01__timeline:14278-14287	1.000
:Event_0000028	type	Conflict.Attack
:Event_0000028	mention.actual	"shootings"	iraqwar_guardian__1000-01-01__timeline:14193-14201	1.000
:Event_0000028	canonical_mention.actual	"shootings"	iraqwar_guardian__1000-01-01__timeline:14193-14201	1.000
:Event_0000028	Conflict.Attack_Target.actual	:Entity_EDL_0000272	iraqwar_guardian__1000-01-01__timeline:14139-14144	1.000
:Event_0000028	Conflict.Attack_Target.actual	:Entity_EDL_0000617	iraqwar_guardian__1000-01-01__timeline:14218-14224	1.000
:Event_0000028	Conflict.Attack_Place.actual	:Entity_EDL_0000509	iraqwar_guardian__1000-01-01__timeline:14240-14246	1.000
:Event_0000029	type	Life.Die
:Event_0000029	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:38383-38386	1.000
:Event_0000029	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:38383-38386	1.000
:Event_0000029	Life.Die_Instrument.actual	:Entity_EDL_0000307	iraqwar_guardian__1000-01-01__timeline:38370-38372	1.000
:Event_0000029	Life.Die_Victim.actual	:Entity_EDL_0000719	iraqwar_guardian__1000-01-01__timeline:38400-38405	1.000
:Event_0000029	Life.Die_Place.actual	:Entity_EDL_0000205	iraqwar_guardian__1000-01-01__timeline:38447-38453	1.000
:Event_0000029	type	Life.Die
:Event_0000029	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:29514-29517	1.000
:Event_0000029	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:29514-29517	1.000
:Event_0000029	Life.Die_Instrument.actual	:Entity_EDL_0000636	iraqwar_guardian__1000-01-01__timeline:29501-29503	1.000
:Event_0000029	Life.Die_Victim.actual	:Entity_EDL_0000099	iraqwar_guardian__1000-01-01__timeline:29522-29527	1.000
:Event_0000029	Life.Die_Place.actual	:Entity_EDL_0000761	iraqwar_guardian__1000-01-01__timeline:29541-29544	1.000
:Event_0000029	Life.Die_Victim.actual	:Entity_EDL_0000400	iraqwar_guardian__1000-01-01__timeline:29575-29580	1.000
:Event_0000029	Life.Die_Victim.actual	:Entity_EDL_0000421	iraqwar_guardian__1000-01-01__timeline:29586-29588	1.000
:Event_0000030	type	Personnel.EndPosition
:Event_0000030	mention.actual	"fall"	iraqwar_guardian__1000-01-01__timeline:35316-35319	1.000
:Event_0000030	canonical_mention.actual	"fall"	iraqwar_guardian__1000-01-01__timeline:35316-35319	1.000
:Event_0000030	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000373	iraqwar_guardian__1000-01-01__timeline:35295-35304	1.000
:Event_0000030	type	Personnel.EndPosition
:Event_0000030	mention.actual	"fall"	iraqwar_guardian__1000-01-01__timeline:35534-35537	1.000
:Event_0000030	canonical_mention.actual	"fall"	iraqwar_guardian__1000-01-01__timeline:35534-35537	1.000
:Event_0000030	Personnel.EndPosition_Person.actual	:Entity_EDL_0000143	iraqwar_guardian__1000-01-01__timeline:35542-35555	1.000
:Event_0000031	type	Conflict.Attack
:Event_0000031	mention.actual	"strike"	iraqwar_guardian__1000-01-01__timeline:41182-41187	1.000
:Event_0000031	canonical_mention.actual	"strike"	iraqwar_guardian__1000-01-01__timeline:41182-41187	1.000
:Event_0000031	Conflict.Attack_Place.actual	:Entity_EDL_0000225	iraqwar_guardian__1000-01-01__timeline:41166-41169	1.000
:Event_0000031	Conflict.Attack_Attacker.actual	:Entity_EDL_0000577	iraqwar_guardian__1000-01-01__timeline:41171-41180	1.000
:Event_0000031	type	Conflict.Attack
:Event_0000031	mention.actual	"strike"	iraqwar_guardian__1000-01-01__timeline:41005-41010	1.000
:Event_0000031	canonical_mention.actual	"strike"	iraqwar_guardian__1000-01-01__timeline:41005-41010	1.000
:Event_0000031	Conflict.Attack_Attacker.actual	:Entity_EDL_0000372	iraqwar_guardian__1000-01-01__timeline:40994-41003	1.000
:Event_0000032	type	Conflict.Attack
:Event_0000032	mention.actual	"insurgency"	iraqwar_guardian__1000-01-01__timeline:22368-22377	1.000
:Event_0000032	canonical_mention.actual	"insurgency"	iraqwar_guardian__1000-01-01__timeline:22368-22377	1.000
:Event_0000032	Conflict.Attack_Place.actual	:Entity_EDL_0000195	iraqwar_guardian__1000-01-01__timeline:22382-22385	1.000
:Event_0000032	type	Conflict.Attack
:Event_0000032	mention.actual	"insurgency"	iraqwar_guardian__1000-01-01__timeline:25165-25174	1.000
:Event_0000032	canonical_mention.actual	"insurgency"	iraqwar_guardian__1000-01-01__timeline:25165-25174	1.000
:Event_0000032	Conflict.Attack_Attacker.actual	:Entity_EDL_0000601	iraqwar_guardian__1000-01-01__timeline:25159-25163	1.000
:Event_0000033	type	Life.Die
:Event_0000033	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:50499-50504	1.000
:Event_0000033	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:50499-50504	1.000
:Event_0000033	Life.Die_Victim.actual	:Entity_EDL_0000075	iraqwar_guardian__1000-01-01__timeline:50515-50522	1.000
:Event_0000033	type	Life.Die
:Event_0000033	mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:50594-50597	1.000
:Event_0000033	canonical_mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:50594-50597	1.000
:Event_0000033	Life.Die_Victim.actual	:Entity_EDL_0000706	iraqwar_guardian__1000-01-01__timeline:50576-50583	1.000
:Event_0000034	type	Justice.ReleaseParole
:Event_0000034	mention.actual	"freed"	iraqwar_guardian__1000-01-01__timeline:6680-6684	1.000
:Event_0000034	canonical_mention.actual	"freed"	iraqwar_guardian__1000-01-01__timeline:6680-6684	1.000
:Event_0000034	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000061	iraqwar_guardian__1000-01-01__timeline:6666-6675	1.000
:Event_0000034	type	Justice.ReleaseParole
:Event_0000034	mention.actual	"freed"	iraqwar_guardian__1000-01-01__timeline:6472-6476	1.000
:Event_0000034	canonical_mention.actual	"freed"	iraqwar_guardian__1000-01-01__timeline:6472-6476	1.000
:Event_0000034	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000144	iraqwar_guardian__1000-01-01__timeline:6445-6454	1.000
:Event_0000034	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000591	iraqwar_guardian__1000-01-01__timeline:6456-6467	1.000
:Event_0000035	type	Business.Start
:Event_0000035	mention.actual	"formation"	iraqwar_guardian__1000-01-01__timeline:42101-42109	1.000
:Event_0000035	canonical_mention.actual	"formation"	iraqwar_guardian__1000-01-01__timeline:42101-42109	1.000
:Event_0000035	Business.Start_Place.actual	:Entity_EDL_0000161	iraqwar_guardian__1000-01-01__timeline:42114-42117	1.000
:Event_0000035	Business.Start_Organization.actual	:Entity_EDL_0000733	iraqwar_guardian__1000-01-01__timeline:42143-42152	1.000
:Event_0000035	type	Business.Start
:Event_0000035	mention.actual	"form"	iraqwar_guardian__1000-01-01__timeline:44008-44011	1.000
:Event_0000035	canonical_mention.actual	"form"	iraqwar_guardian__1000-01-01__timeline:44008-44011	1.000
:Event_0000035	Business.Start_Agent.actual	:Entity_EDL_0000431	iraqwar_guardian__1000-01-01__timeline:43931-43939	1.000
:Event_0000035	Business.Start_Organization.actual	:Entity_EDL_0000710	iraqwar_guardian__1000-01-01__timeline:44030-44039	1.000
:Event_0000036	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000036	mention.actual	"crime"	iraqwar_guardian__1000-01-01__timeline:23890-23894	1.000
:Event_0000036	canonical_mention.actual	"crime"	iraqwar_guardian__1000-01-01__timeline:23890-23894	1.000
:Event_0000036	GenericCrime.GenericCrime.GenericCrime_Victim.actual	:Entity_EDL_0000508	iraqwar_guardian__1000-01-01__timeline:23910-23918	1.000
:Event_0000036	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000036	mention.actual	"crimes"	iraqwar_guardian__1000-01-01__timeline:23610-23615	1.000
:Event_0000036	canonical_mention.actual	"crimes"	iraqwar_guardian__1000-01-01__timeline:23610-23615	1.000
:Event_0000036	GenericCrime.GenericCrime.GenericCrime_Perpetrator.actual	:Entity_EDL_0000119	iraqwar_guardian__1000-01-01__timeline:23551-23558	1.000
:Event_0000036	GenericCrime.GenericCrime.GenericCrime_Perpetrator.actual	:Entity_EDL_0000506	iraqwar_guardian__1000-01-01__timeline:23625-23629	1.000
:Event_0000036	GenericCrime.GenericCrime.GenericCrime_Perpetrator.actual	:Entity_EDL_0000197	iraqwar_guardian__1000-01-01__timeline:23631-23639	1.000
:Event_0000037	type	Movement.TransportArtifact
:Event_0000037	mention.actual	"sent"	iraqwar_guardian__1000-01-01__timeline:53661-53664	1.000
:Event_0000037	canonical_mention.actual	"sent"	iraqwar_guardian__1000-01-01__timeline:53661-53664	1.000
:Event_0000037	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000436	iraqwar_guardian__1000-01-01__timeline:53648-53653	1.000
:Event_0000037	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000003	iraqwar_guardian__1000-01-01__timeline:53669-53672	1.000
:Event_0000037	type	Movement.TransportArtifact
:Event_0000037	mention.actual	"sent"	iraqwar_guardian__1000-01-01__timeline:53472-53475	1.000
:Event_0000037	canonical_mention.actual	"sent"	iraqwar_guardian__1000-01-01__timeline:53472-53475	1.000
:Event_0000037	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000568	iraqwar_guardian__1000-01-01__timeline:53455-53460	1.000
:Event_0000037	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000283	iraqwar_guardian__1000-01-01__timeline:53480-53483	1.000
:Event_0000038	type	Justice.TrialHearing
:Event_0000038	mention.actual	"court martial"	iraqwar_guardian__1000-01-01__timeline:47467-47479	1.000
:Event_0000038	canonical_mention.actual	"court martial"	iraqwar_guardian__1000-01-01__timeline:47467-47479	1.000
:Event_0000038	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000106	iraqwar_guardian__1000-01-01__timeline:47454-47461	1.000
:Event_0000038	Justice.TrialHearing_Adjudicator.actual	:Entity_EDL_0000157	iraqwar_guardian__1000-01-01__timeline:47467-47471	1.000
:Event_0000038	Justice.TrialHearing_Place.actual	:Entity_EDL_0000625	iraqwar_guardian__1000-01-01__timeline:47484-47490	1.000
:Event_0000038	type	Justice.TrialHearing
:Event_0000038	mention.actual	"court martial"	iraqwar_guardian__1000-01-01__timeline:47689-47701	1.000
:Event_0000038	canonical_mention.actual	"court martial"	iraqwar_guardian__1000-01-01__timeline:47689-47701	1.000
:Event_0000038	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000018	iraqwar_guardian__1000-01-01__timeline:47651-47653	1.000
:Event_0000038	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000328	iraqwar_guardian__1000-01-01__timeline:47661-47669	1.000
:Event_0000039	type	Life.Die
:Event_0000039	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:1856-1862	1.000
:Event_0000039	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:1856-1862	1.000
:Event_0000039	Life.Die_Victim.actual	:Entity_EDL_0000356	iraqwar_guardian__1000-01-01__timeline:1864-1870	1.000
:Event_0000039	type	Life.Die
:Event_0000039	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:1971-1977	1.000
:Event_0000039	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:1971-1977	1.000
:Event_0000039	Life.Die_Victim.actual	:Entity_EDL_0000670	iraqwar_guardian__1000-01-01__timeline:1979-1985	1.000
:Event_0000039	Life.Die_Place.actual	:Entity_EDL_0000103	iraqwar_guardian__1000-01-01__timeline:2005-2011	1.000
:Event_0000040	type	Movement.TransportArtifact
:Event_0000040	mention.actual	"leave"	iraqwar_guardian__1000-01-01__timeline:3061-3065	1.000
:Event_0000040	canonical_mention.actual	"leave"	iraqwar_guardian__1000-01-01__timeline:3061-3065	1.000
:Event_0000040	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000244	iraqwar_guardian__1000-01-01__timeline:3019-3025	1.000
:Event_0000040	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000555	iraqwar_guardian__1000-01-01__timeline:3044-3047	1.000
:Event_0000040	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000666	iraqwar_guardian__1000-01-01__timeline:3067-3070	1.000
:Event_0000040	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000611	iraqwar_guardian__1000-01-01__timeline:3108-3112	1.000
:Event_0000040	type	Movement.TransportArtifact
:Event_0000040	mention.actual	"leave"	iraqwar_guardian__1000-01-01__timeline:2897-2901	1.000
:Event_0000040	canonical_mention.actual	"leave"	iraqwar_guardian__1000-01-01__timeline:2897-2901	1.000
:Event_0000040	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000309	iraqwar_guardian__1000-01-01__timeline:2890-2895	1.000
:Event_0000040	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000136	iraqwar_guardian__1000-01-01__timeline:2903-2906	1.000
:Event_0000041	type	Contact.Meet
:Event_0000041	mention.actual	"meeting"	iraqwar_guardian__1000-01-01__timeline:4584-4590	1.000
:Event_0000041	canonical_mention.actual	"meeting"	iraqwar_guardian__1000-01-01__timeline:4584-4590	1.000
:Event_0000041	Contact.Meet_Participant.actual	:Entity_EDL_0000227	iraqwar_guardian__1000-01-01__timeline:4560-4568	1.000
:Event_0000041	type	Contact.Meet
:Event_0000041	mention.actual	"meeting"	iraqwar_guardian__1000-01-01__timeline:4280-4286	1.000
:Event_0000041	canonical_mention.actual	"meeting"	iraqwar_guardian__1000-01-01__timeline:4280-4286	1.000
:Event_0000041	Contact.Meet_Participant.actual	:Entity_EDL_0000366	iraqwar_guardian__1000-01-01__timeline:4231-4240	1.000
:Event_0000041	Contact.Meet_Place.actual	:Entity_EDL_0000133	iraqwar_guardian__1000-01-01__timeline:4266-4272	1.000
:Event_0000041	Contact.Meet_Participant.actual	:Entity_EDL_0000007	iraqwar_guardian__1000-01-01__timeline:4318-4335	1.000
:Event_0000042	type	Justice.Convict
:Event_0000042	mention.actual	"found"	iraqwar_guardian__1000-01-01__timeline:9761-9765	1.000
:Event_0000042	canonical_mention.actual	"found"	iraqwar_guardian__1000-01-01__timeline:9761-9765	1.000
:Event_0000042	Justice.Convict_Defendant.actual	:Entity_EDL_0000074	iraqwar_guardian__1000-01-01__timeline:9742-9756	1.000
:Event_0000042	type	Justice.Convict
:Event_0000042	mention.actual	"guilty"	iraqwar_guardian__1000-01-01__timeline:9767-9772	1.000
:Event_0000042	canonical_mention.actual	"guilty"	iraqwar_guardian__1000-01-01__timeline:9767-9772	1.000
:Event_0000042	Justice.Convict_Defendant.actual	:Entity_EDL_0000074	iraqwar_guardian__1000-01-01__timeline:9742-9756	1.000
:Event_0000043	type	Life.Die
:Event_0000043	mention.actual	"Suicide"	iraqwar_guardian__1000-01-01__timeline:13753-13759	1.000
:Event_0000043	canonical_mention.actual	"Suicide"	iraqwar_guardian__1000-01-01__timeline:13753-13759	1.000
:Event_0000043	Life.Die_Place.actual	:Entity_EDL_0000202	iraqwar_guardian__1000-01-01__timeline:13775-13782	1.000
:Event_0000043	type	Life.Die
:Event_0000043	mention.actual	"Suicide"	iraqwar_guardian__1000-01-01__timeline:14029-14035	1.000
:Event_0000043	canonical_mention.actual	"Suicide"	iraqwar_guardian__1000-01-01__timeline:14029-14035	1.000
:Event_0000043	Life.Die_Victim.actual	:Entity_EDL_0000736	iraqwar_guardian__1000-01-01__timeline:14037-14043	1.000
:Event_0000044	type	Conflict.Attack
:Event_0000044	mention.actual	"torture"	iraqwar_guardian__1000-01-01__timeline:39401-39407	1.000
:Event_0000044	canonical_mention.actual	"torture"	iraqwar_guardian__1000-01-01__timeline:39401-39407	1.000
:Event_0000044	Conflict.Attack_Attacker.actual	:Entity_EDL_0000716	iraqwar_guardian__1000-01-01__timeline:39339-39340	1.000
:Event_0000044	type	Conflict.Attack
:Event_0000044	mention.actual	"torture"	iraqwar_guardian__1000-01-01__timeline:32124-32130	1.000
:Event_0000044	canonical_mention.actual	"torture"	iraqwar_guardian__1000-01-01__timeline:32124-32130	1.000
:Event_0000044	Conflict.Attack_Target.actual	:Entity_EDL_0000456	iraqwar_guardian__1000-01-01__timeline:32085-32090	1.000
:Event_0000044	Conflict.Attack_Attacker.actual	:Entity_EDL_0000620	iraqwar_guardian__1000-01-01__timeline:32103-32110	1.000
:Event_0000045	type	Life.Die
:Event_0000045	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:14172-14178	1.000
:Event_0000045	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:14172-14178	1.000
:Event_0000045	type	Life.Die
:Event_0000045	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:24120-24126	1.000
:Event_0000045	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:24120-24126	1.000
:Event_0000046	type	Conflict.Demonstrate
:Event_0000046	mention.actual	"demonstrate"	iraqwar_guardian__1000-01-01__timeline:12194-12204	1.000
:Event_0000046	canonical_mention.actual	"demonstrate"	iraqwar_guardian__1000-01-01__timeline:12194-12204	1.000
:Event_0000046	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000504	iraqwar_guardian__1000-01-01__timeline:12164-12171	1.000
:Event_0000046	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000219	iraqwar_guardian__1000-01-01__timeline:12189-12192	1.000
:Event_0000046	type	Conflict.Demonstrate
:Event_0000046	mention.actual	"demonstrate"	iraqwar_guardian__1000-01-01__timeline:16347-16357	1.000
:Event_0000046	canonical_mention.actual	"demonstrate"	iraqwar_guardian__1000-01-01__timeline:16347-16357	1.000
:Event_0000046	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000613	iraqwar_guardian__1000-01-01__timeline:16291-16299	1.000
:Event_0000046	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000097	iraqwar_guardian__1000-01-01__timeline:16328-16334	1.000
:Event_0000047	type	Conflict.Attack
:Event_0000047	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:29668-29675	1.000
:Event_0000047	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:29668-29675	1.000
:Event_0000047	Conflict.Attack_Place.actual	:Entity_EDL_0000037	iraqwar_guardian__1000-01-01__timeline:29663-29666	1.000
:Event_0000047	type	Conflict.Attack
:Event_0000047	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:33633-33640	1.000
:Event_0000047	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:33633-33640	1.000
:Event_0000047	Conflict.Attack_Place.actual	:Entity_EDL_0000274	iraqwar_guardian__1000-01-01__timeline:33619-33623	1.000
:Event_0000048	type	Conflict.Attack
:Event_0000048	mention.actual	"beating"	iraqwar_guardian__1000-01-01__timeline:711-717	1.000
:Event_0000048	canonical_mention.actual	"beating"	iraqwar_guardian__1000-01-01__timeline:711-717	1.000
:Event_0000048	Conflict.Attack_Attacker.actual	:Entity_EDL_0000189	iraqwar_guardian__1000-01-01__timeline:700-706	1.000
:Event_0000048	Conflict.Attack_Target.actual	:Entity_EDL_0000115	iraqwar_guardian__1000-01-01__timeline:719-721	1.000
:Event_0000048	type	Conflict.Attack
:Event_0000048	mention.actual	"beating"	iraqwar_guardian__1000-01-01__timeline:850-856	1.000
:Event_0000048	canonical_mention.actual	"beating"	iraqwar_guardian__1000-01-01__timeline:850-856	1.000
:Event_0000048	Conflict.Attack_Attacker.actual	:Entity_EDL_0000722	iraqwar_guardian__1000-01-01__timeline:839-845	1.000
:Event_0000049	type	Personnel.EndPosition
:Event_0000049	mention.actual	"suspended"	iraqwar_guardian__1000-01-01__timeline:46876-46884	1.000
:Event_0000049	canonical_mention.actual	"suspended"	iraqwar_guardian__1000-01-01__timeline:46876-46884	1.000
:Event_0000049	Personnel.EndPosition_Person.actual	:Entity_EDL_0000537	iraqwar_guardian__1000-01-01__timeline:46844-46847	1.000
:Event_0000049	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000734	iraqwar_guardian__1000-01-01__timeline:46852-46853	1.000
:Event_0000049	type	Personnel.EndPosition
:Event_0000049	mention.actual	"suspended"	iraqwar_guardian__1000-01-01__timeline:46738-46746	1.000
:Event_0000049	canonical_mention.actual	"suspended"	iraqwar_guardian__1000-01-01__timeline:46738-46746	1.000
:Event_0000049	Personnel.EndPosition_Person.actual	:Entity_EDL_0000312	iraqwar_guardian__1000-01-01__timeline:46624-46627	1.000
:Event_0000049	Personnel.EndPosition_Place.actual	:Entity_EDL_0000586	iraqwar_guardian__1000-01-01__timeline:46663-46666	1.000
:Event_0000049	Personnel.EndPosition_Person.actual	:Entity_EDL_0000549	iraqwar_guardian__1000-01-01__timeline:46684-46691	1.000
:Event_0000050	type	Conflict.Attack
:Event_0000050	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:53681-53684	1.000
:Event_0000050	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:53681-53684	1.000
:Event_0000050	Conflict.Attack_Attacker.actual	:Entity_EDL_0000269	iraqwar_guardian__1000-01-01__timeline:53674-53679	1.000
:Event_0000050	Conflict.Attack_Target.actual	:Entity_EDL_0000243	iraqwar_guardian__1000-01-01__timeline:53693-53697	1.000
:Event_0000050	type	Conflict.Attack
:Event_0000050	mention.actual	"assassinate"	iraqwar_guardian__1000-01-01__timeline:53590-53600	1.000
:Event_0000050	canonical_mention.actual	"assassinate"	iraqwar_guardian__1000-01-01__timeline:53590-53600	1.000
:Event_0000050	Conflict.Attack_Attacker.actual	:Entity_EDL_0000320	iraqwar_guardian__1000-01-01__timeline:53583-53588	1.000
:Event_0000050	Conflict.Attack_Target.actual	:Entity_EDL_0000382	iraqwar_guardian__1000-01-01__timeline:53627-53631	1.000
:Event_0000051	type	Life.Die
:Event_0000051	mention.actual	"murdering"	iraqwar_guardian__1000-01-01__timeline:4978-4986	1.000
:Event_0000051	canonical_mention.actual	"murdering"	iraqwar_guardian__1000-01-01__timeline:4978-4986	1.000
:Event_0000051	Life.Die_Agent.actual	:Entity_EDL_0000203	iraqwar_guardian__1000-01-01__timeline:4954-4965	1.000
:Event_0000051	Life.Die_Victim.actual	:Entity_EDL_0000196	iraqwar_guardian__1000-01-01__timeline:4988-4992	1.000
:Event_0000051	type	Life.Die
:Event_0000051	mention.actual	"murdering"	iraqwar_guardian__1000-01-01__timeline:4785-4793	1.000
:Event_0000051	canonical_mention.actual	"murdering"	iraqwar_guardian__1000-01-01__timeline:4785-4793	1.000
:Event_0000051	Life.Die_Agent.actual	:Entity_EDL_0000624	iraqwar_guardian__1000-01-01__timeline:4765-4772	1.000
:Event_0000051	Life.Die_Victim.actual	:Entity_EDL_0000718	iraqwar_guardian__1000-01-01__timeline:4804-4811	1.000
:Event_0000052	type	Conflict.Attack
:Event_0000052	mention.actual	"abusing"	iraqwar_guardian__1000-01-01__timeline:10070-10076	1.000
:Event_0000052	canonical_mention.actual	"abusing"	iraqwar_guardian__1000-01-01__timeline:10070-10076	1.000
:Event_0000052	Conflict.Attack_Target.actual	:Entity_EDL_0000104	iraqwar_guardian__1000-01-01__timeline:10052-10058	1.000
:Event_0000052	Conflict.Attack_Target.actual	:Entity_EDL_0000028	iraqwar_guardian__1000-01-01__timeline:10084-10092	1.000
:Event_0000052	type	Conflict.Attack
:Event_0000052	mention.actual	"abusing"	iraqwar_guardian__1000-01-01__timeline:9777-9783	1.000
:Event_0000052	canonical_mention.actual	"abusing"	iraqwar_guardian__1000-01-01__timeline:9777-9783	1.000
:Event_0000052	Conflict.Attack_Attacker.actual	:Entity_EDL_0000074	iraqwar_guardian__1000-01-01__timeline:9742-9756	1.000
:Event_0000052	Conflict.Attack_Target.actual	:Entity_EDL_0000560	iraqwar_guardian__1000-01-01__timeline:9785-9791	1.000
:Event_0000052	Conflict.Attack_Place.actual	:Entity_EDL_0000126	iraqwar_guardian__1000-01-01__timeline:9796-9810	1.000
:Event_0000053	type	Conflict.Attack
:Event_0000053	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:23886-23888	1.000
:Event_0000053	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:23886-23888	1.000
:Event_0000053	type	Conflict.Attack
:Event_0000053	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:23606-23608	1.000
:Event_0000053	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:23606-23608	1.000
:Event_0000054	type	Transaction.TransferMoney
:Event_0000054	mention.actual	"paying"	iraqwar_guardian__1000-01-01__timeline:28574-28579	1.000
:Event_0000054	canonical_mention.actual	"paying"	iraqwar_guardian__1000-01-01__timeline:28574-28579	1.000
:Event_0000054	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000210	iraqwar_guardian__1000-01-01__timeline:28560-28565	1.000
:Event_0000054	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000413	iraqwar_guardian__1000-01-01__timeline:28596-28605	1.000
:Event_0000054	type	Transaction.TransferMoney
:Event_0000054	mention.actual	"paid"	iraqwar_guardian__1000-01-01__timeline:28310-28313	1.000
:Event_0000054	canonical_mention.actual	"paid"	iraqwar_guardian__1000-01-01__timeline:28310-28313	1.000
:Event_0000054	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000029	iraqwar_guardian__1000-01-01__timeline:28307-28308	1.000
:Event_0000055	type	Personnel.EndPosition
:Event_0000055	mention.actual	"former"	iraqwar_guardian__1000-01-01__timeline:33231-33236	1.000
:Event_0000055	canonical_mention.actual	"former"	iraqwar_guardian__1000-01-01__timeline:33231-33236	1.000
:Event_0000055	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000727	iraqwar_guardian__1000-01-01__timeline:33238-33242	1.000
:Event_0000055	Personnel.EndPosition_Person.actual	:Entity_EDL_0000088	iraqwar_guardian__1000-01-01__timeline:33244-33245	1.000
:Event_0000055	type	Personnel.EndPosition
:Event_0000055	mention.actual	"former"	iraqwar_guardian__1000-01-01__timeline:31824-31829	1.000
:Event_0000055	canonical_mention.actual	"former"	iraqwar_guardian__1000-01-01__timeline:31824-31829	1.000
:Event_0000055	Personnel.EndPosition_Person.actual	:Entity_EDL_0000263	iraqwar_guardian__1000-01-01__timeline:31837-31844	1.000
:Event_0000056	type	Justice.Convict
:Event_0000056	mention.actual	"found guilty"	iraqwar_guardian__1000-01-01__timeline:45573-45584	1.000
:Event_0000056	canonical_mention.actual	"found guilty"	iraqwar_guardian__1000-01-01__timeline:45573-45584	1.000
:Event_0000056	Justice.Convict_Defendant.actual	:Entity_EDL_0000333	iraqwar_guardian__1000-01-01__timeline:45564-45571	1.000
:Event_0000056	type	Justice.Convict
:Event_0000056	mention.actual	"convicted"	iraqwar_guardian__1000-01-01__timeline:45402-45410	1.000
:Event_0000056	canonical_mention.actual	"convicted"	iraqwar_guardian__1000-01-01__timeline:45402-45410	1.000
:Event_0000056	Justice.Convict_Defendant.actual	:Entity_EDL_0000658	iraqwar_guardian__1000-01-01__timeline:45389-45396	1.000
:Event_0000057	type	Conflict.Demonstrate
:Event_0000057	mention.actual	"protest"	iraqwar_guardian__1000-01-01__timeline:42713-42719	1.000
:Event_0000057	canonical_mention.actual	"protest"	iraqwar_guardian__1000-01-01__timeline:42713-42719	1.000
:Event_0000057	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000639	iraqwar_guardian__1000-01-01__timeline:42615-42630	1.000
:Event_0000057	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000287	iraqwar_guardian__1000-01-01__timeline:42649-42655	1.000
:Event_0000057	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000748	iraqwar_guardian__1000-01-01__timeline:42692-42697	1.000
:Event_0000057	type	Conflict.Demonstrate
:Event_0000057	mention.actual	"protest"	iraqwar_guardian__1000-01-01__timeline:42871-42877	1.000
:Event_0000057	canonical_mention.actual	"protest"	iraqwar_guardian__1000-01-01__timeline:42871-42877	1.000
:Event_0000057	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000544	iraqwar_guardian__1000-01-01__timeline:42799-42805	1.000
:Event_0000057	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000129	iraqwar_guardian__1000-01-01__timeline:42884-42889	1.000
:Event_0000058	type	Life.Die
:Event_0000058	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:7245-7250	1.000
:Event_0000058	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:7245-7250	1.000
:Event_0000058	Life.Die_Victim.actual	:Entity_EDL_0000026	iraqwar_guardian__1000-01-01__timeline:7231-7234	1.000
:Event_0000058	type	Life.Die
:Event_0000058	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:7110-7115	1.000
:Event_0000058	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:7110-7115	1.000
:Event_0000058	Life.Die_Victim.actual	:Entity_EDL_0000135	iraqwar_guardian__1000-01-01__timeline:7089-7098	1.000
:Event_0000058	Life.Die_Instrument.actual	:Entity_EDL_0000234	iraqwar_guardian__1000-01-01__timeline:7131-7140	1.000
:Event_0000058	Life.Die_Instrument.actual	:Entity_EDL_0000566	iraqwar_guardian__1000-01-01__timeline:7146-7156	1.000
:Event_0000058	Life.Die_Place.actual	:Entity_EDL_0000392	iraqwar_guardian__1000-01-01__timeline:7161-7168	1.000
:Event_0000059	type	Justice.Convict
:Event_0000059	mention.actual	"found guilty"	iraqwar_guardian__1000-01-01__timeline:11151-11162	1.000
:Event_0000059	canonical_mention.actual	"found guilty"	iraqwar_guardian__1000-01-01__timeline:11151-11162	1.000
:Event_0000059	Justice.Convict_Defendant.actual	:Entity_EDL_0000609	iraqwar_guardian__1000-01-01__timeline:11053-11056	1.000
:Event_0000060	type	Conflict.Attack
:Event_0000060	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:47809-47815	1.000
:Event_0000060	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:47809-47815	1.000
:Event_0000061	type	Personnel.EndPosition
:Event_0000061	mention.actual	"former"	iraqwar_guardian__1000-01-01__timeline:12661-12666	1.000
:Event_0000061	canonical_mention.actual	"former"	iraqwar_guardian__1000-01-01__timeline:12661-12666	1.000
:Event_0000061	Personnel.EndPosition_Person.actual	:Entity_EDL_0000690	iraqwar_guardian__1000-01-01__timeline:12685-12697	1.000
:Event_0000062	type	Conflict.Attack
:Event_0000062	mention.actual	"fire"	iraqwar_guardian__1000-01-01__timeline:43394-43397	1.000
:Event_0000062	canonical_mention.actual	"fire"	iraqwar_guardian__1000-01-01__timeline:43394-43397	1.000
:Event_0000062	Conflict.Attack_Place.actual	:Entity_EDL_0000728	iraqwar_guardian__1000-01-01__timeline:43402-43405	1.000
:Event_0000063	type	Justice.Acquit
:Event_0000063	mention.actual	"cleared"	iraqwar_guardian__1000-01-01__timeline:4967-4973	1.000
:Event_0000063	canonical_mention.actual	"cleared"	iraqwar_guardian__1000-01-01__timeline:4967-4973	1.000
:Event_0000063	Justice.Acquit_Defendant.actual	:Entity_EDL_0000203	iraqwar_guardian__1000-01-01__timeline:4954-4965	1.000
:Event_0000063	Justice.Acquit_Adjudicator.actual	:Entity_EDL_0000558	iraqwar_guardian__1000-01-01__timeline:5000-5004	1.000
:Event_0000064	type	Conflict.Attack
:Event_0000064	mention.actual	"clashes"	iraqwar_guardian__1000-01-01__timeline:12903-12909	1.000
:Event_0000064	canonical_mention.actual	"clashes"	iraqwar_guardian__1000-01-01__timeline:12903-12909	1.000
:Event_0000064	Conflict.Attack_Attacker.actual	:Entity_EDL_0000496	iraqwar_guardian__1000-01-01__timeline:12931-12938	1.000
:Event_0000064	Conflict.Attack_Place.actual	:Entity_EDL_0000303	iraqwar_guardian__1000-01-01__timeline:12943-12947	1.000
:Event_0000064	Conflict.Attack_Attacker.actual	:Entity_EDL_0000447	iraqwar_guardian__1000-01-01__timeline:12959-12964	1.000
:Event_0000065	type	Conflict.Attack
:Event_0000065	mention.actual	"battle"	iraqwar_guardian__1000-01-01__timeline:41926-41931	1.000
:Event_0000065	canonical_mention.actual	"battle"	iraqwar_guardian__1000-01-01__timeline:41926-41931	1.000
:Event_0000065	Conflict.Attack_Attacker.actual	:Entity_EDL_0000460	iraqwar_guardian__1000-01-01__timeline:41891-41896	1.000
:Event_0000066	type	Life.Die
:Event_0000066	mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:18746-18749	1.000
:Event_0000066	canonical_mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:18746-18749	1.000
:Event_0000066	Life.Die_Place.actual	:Entity_EDL_0000637	iraqwar_guardian__1000-01-01__timeline:18690-18696	1.000
:Event_0000066	Life.Die_Victim.actual	:Entity_EDL_0000571	iraqwar_guardian__1000-01-01__timeline:18751-18756	1.000
:Event_0000067	type	Disaster.AccidentCrash.AccidentCrash
:Event_0000067	mention.actual	"crash"	iraqwar_guardian__1000-01-01__timeline:11455-11459	1.000
:Event_0000067	canonical_mention.actual	"crash"	iraqwar_guardian__1000-01-01__timeline:11455-11459	1.000
:Event_0000067	Disaster.AccidentCrash.AccidentCrash_Place.actual	:Entity_EDL_0000052	iraqwar_guardian__1000-01-01__timeline:11464-11467	1.000
:Event_0000068	type	Conflict.Attack
:Event_0000068	mention.actual	"storm"	iraqwar_guardian__1000-01-01__timeline:12800-12804	1.000
:Event_0000068	canonical_mention.actual	"storm"	iraqwar_guardian__1000-01-01__timeline:12800-12804	1.000
:Event_0000068	Conflict.Attack_Attacker.actual	:Entity_EDL_0000395	iraqwar_guardian__1000-01-01__timeline:12786-12792	1.000
:Event_0000068	Conflict.Attack_Instrument.actual	:Entity_EDL_0000349	iraqwar_guardian__1000-01-01__timeline:12794-12798	1.000
:Event_0000068	Conflict.Attack_Place.actual	:Entity_EDL_0000632	iraqwar_guardian__1000-01-01__timeline:12806-12810	1.000
:Event_0000068	Conflict.Attack_Target.actual	:Entity_EDL_0000311	iraqwar_guardian__1000-01-01__timeline:12812-12815	1.000
:Event_0000069	type	Justice.TrialHearing
:Event_0000069	mention.actual	"courts martial"	iraqwar_guardian__1000-01-01__timeline:51499-51512	1.000
:Event_0000069	canonical_mention.actual	"courts martial"	iraqwar_guardian__1000-01-01__timeline:51499-51512	1.000
:Event_0000069	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000462	iraqwar_guardian__1000-01-01__timeline:51427-51432	1.000
:Event_0000069	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000035	iraqwar_guardian__1000-01-01__timeline:51531-51538	1.000
:Event_0000069	Justice.TrialHearing_Place.actual	:Entity_EDL_0000264	iraqwar_guardian__1000-01-01__timeline:51543-51549	1.000
:Event_0000070	type	Life.Die
:Event_0000070	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:1399-1405	1.000
:Event_0000070	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:1399-1405	1.000
:Event_0000071	type	Conflict.Attack
:Event_0000071	mention.actual	"bombing"	iraqwar_guardian__1000-01-01__timeline:14543-14549	1.000
:Event_0000071	canonical_mention.actual	"bombing"	iraqwar_guardian__1000-01-01__timeline:14543-14549	1.000
:Event_0000071	Conflict.Attack_Attacker.actual	:Entity_EDL_0000406	iraqwar_guardian__1000-01-01__timeline:14438-14442	1.000
:Event_0000072	type	Life.Die
:Event_0000072	mention.actual	"died"	iraqwar_guardian__1000-01-01__timeline:23801-23804	1.000
:Event_0000072	canonical_mention.actual	"died"	iraqwar_guardian__1000-01-01__timeline:23801-23804	1.000
:Event_0000072	Life.Die_Victim.actual	:Entity_EDL_0000232	iraqwar_guardian__1000-01-01__timeline:23782-23790	1.000
:Event_0000072	Life.Die_Place.actual	:Entity_EDL_0000357	iraqwar_guardian__1000-01-01__timeline:23847-23853	1.000
:Event_0000072	Life.Die_Victim.actual	:Entity_EDL_0000089	iraqwar_guardian__1000-01-01__timeline:23858-23863	1.000
:Event_0000073	type	Life.Injure
:Event_0000073	mention.actual	"wounding"	iraqwar_guardian__1000-01-01__timeline:21586-21593	1.000
:Event_0000073	canonical_mention.actual	"wounding"	iraqwar_guardian__1000-01-01__timeline:21586-21593	1.000
:Event_0000073	Life.Injure_Place.actual	:Entity_EDL_0000579	iraqwar_guardian__1000-01-01__timeline:21503-21509	1.000
:Event_0000073	Life.Injure_Agent.actual	:Entity_EDL_0000627	iraqwar_guardian__1000-01-01__timeline:21523-21528	1.000
:Event_0000073	Life.Injure_Place.actual	:Entity_EDL_0000171	iraqwar_guardian__1000-01-01__timeline:21547-21556	1.000
:Event_0000073	Life.Injure_Victim.actual	:Entity_EDL_0000083	iraqwar_guardian__1000-01-01__timeline:21595-21596	1.000
:Event_0000074	type	Life.Injure
:Event_0000074	mention.actual	"crushing"	iraqwar_guardian__1000-01-01__timeline:16100-16107	1.000
:Event_0000074	canonical_mention.actual	"crushing"	iraqwar_guardian__1000-01-01__timeline:16100-16107	1.000
:Event_0000074	Life.Injure_Victim.actual	:Entity_EDL_0000127	iraqwar_guardian__1000-01-01__timeline:16109-16116	1.000
:Event_0000075	type	Life.Die
:Event_0000075	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:35188-35194	1.000
:Event_0000075	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:35188-35194	1.000
:Event_0000075	Life.Die_Agent.actual	:Entity_EDL_0000397	iraqwar_guardian__1000-01-01__timeline:35137-35146	1.000
:Event_0000075	Life.Die_Instrument.actual	:Entity_EDL_0000532	iraqwar_guardian__1000-01-01__timeline:35172-35176	1.000
:Event_0000075	Life.Die_Place.actual	:Entity_EDL_0000541	iraqwar_guardian__1000-01-01__timeline:35181-35184	1.000
:Event_0000075	Life.Die_Victim.actual	:Entity_EDL_0000580	iraqwar_guardian__1000-01-01__timeline:35208-35213	1.000
:Event_0000076	type	Conflict.Attack
:Event_0000076	mention.actual	"massacres"	iraqwar_guardian__1000-01-01__timeline:37591-37599	1.000
:Event_0000076	canonical_mention.actual	"massacres"	iraqwar_guardian__1000-01-01__timeline:37591-37599	1.000
:Event_0000076	Conflict.Attack_Target.actual	:Entity_EDL_0000079	iraqwar_guardian__1000-01-01__timeline:37552-37557	1.000
:Event_0000077	type	Life.Die
:Event_0000077	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:21280-21285	1.000
:Event_0000077	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:21280-21285	1.000
:Event_0000077	Life.Die_Victim.actual	:Entity_EDL_0000739	iraqwar_guardian__1000-01-01__timeline:21261-21268	1.000
:Event_0000077	Life.Die_Place.actual	:Entity_EDL_0000256	iraqwar_guardian__1000-01-01__timeline:21290-21293	1.000
:Event_0000078	type	Life.Injure
:Event_0000078	mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:14916-14922	1.000
:Event_0000078	canonical_mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:14916-14922	1.000
:Event_0000078	Life.Injure_Victim.actual	:Entity_EDL_0000064	iraqwar_guardian__1000-01-01__timeline:14907-14914	1.000
:Event_0000079	type	Movement.TransportArtifact
:Event_0000079	mention.actual	"withdrawing"	iraqwar_guardian__1000-01-01__timeline:43526-43536	1.000
:Event_0000079	canonical_mention.actual	"withdrawing"	iraqwar_guardian__1000-01-01__timeline:43526-43536	1.000
:Event_0000079	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000551	iraqwar_guardian__1000-01-01__timeline:43553-43558	1.000
:Event_0000079	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000092	iraqwar_guardian__1000-01-01__timeline:43565-43568	1.000
:Event_0000080	type	Transaction.TransferOwnership
:Event_0000080	mention.actual	"allocated"	iraqwar_guardian__1000-01-01__timeline:33251-33259	1.000
:Event_0000080	canonical_mention.actual	"allocated"	iraqwar_guardian__1000-01-01__timeline:33251-33259	1.000
:Event_0000080	Transaction.TransferOwnership_Giver.actual	:Entity_EDL_0000546	iraqwar_guardian__1000-01-01__timeline:33304-33309	1.000
:Event_0000081	type	Conflict.Attack
:Event_0000081	mention.actual	"detonate"	iraqwar_guardian__1000-01-01__timeline:45753-45760	1.000
:Event_0000081	canonical_mention.actual	"detonate"	iraqwar_guardian__1000-01-01__timeline:45753-45760	1.000
:Event_0000081	Conflict.Attack_Attacker.actual	:Entity_EDL_0000141	iraqwar_guardian__1000-01-01__timeline:45710-45713	1.000
:Event_0000081	Conflict.Attack_Instrument.actual	:Entity_EDL_0000047	iraqwar_guardian__1000-01-01__timeline:45762-45771	1.000
:Event_0000082	type	Life.Die
:Event_0000082	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:16197-16203	1.000
:Event_0000082	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:16197-16203	1.000
:Event_0000082	Life.Die_Victim.actual	:Entity_EDL_0000396	iraqwar_guardian__1000-01-01__timeline:16205-16210	1.000
:Event_0000083	type	Conflict.Attack
:Event_0000083	mention.actual	"torturer"	iraqwar_guardian__1000-01-01__timeline:52356-52363	1.000
:Event_0000083	canonical_mention.actual	"torturer"	iraqwar_guardian__1000-01-01__timeline:52356-52363	1.000
:Event_0000083	Conflict.Attack_Attacker.actual	:Entity_EDL_0000616	iraqwar_guardian__1000-01-01__timeline:52323-52331	1.000
:Event_0000083	Conflict.Attack_Target.actual	:Entity_EDL_0000313	iraqwar_guardian__1000-01-01__timeline:52371-52380	1.000
:Event_0000084	type	Movement.TransportArtifact
:Event_0000084	mention.actual	"leaving"	iraqwar_guardian__1000-01-01__timeline:8957-8963	1.000
:Event_0000084	canonical_mention.actual	"leaving"	iraqwar_guardian__1000-01-01__timeline:8957-8963	1.000
:Event_0000084	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000536	iraqwar_guardian__1000-01-01__timeline:8948-8955	1.000
:Event_0000084	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000375	iraqwar_guardian__1000-01-01__timeline:8965-8968	1.000
:Event_0000085	type	Conflict.Attack
:Event_0000085	mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:14062-14067	1.000
:Event_0000085	canonical_mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:14062-14067	1.000
:Event_0000085	Conflict.Attack_Attacker.actual	:Entity_EDL_0000736	iraqwar_guardian__1000-01-01__timeline:14037-14043	1.000
:Event_0000085	Conflict.Attack_Place.actual	:Entity_EDL_0000096	iraqwar_guardian__1000-01-01__timeline:14072-14078	1.000
:Event_0000086	type	Life.Die
:Event_0000086	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:3705-3710	1.000
:Event_0000086	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:3705-3710	1.000
:Event_0000086	Life.Die_Victim.actual	:Entity_EDL_0000013	iraqwar_guardian__1000-01-01__timeline:3696-3703	1.000
:Event_0000086	Life.Die_Place.actual	:Entity_EDL_0000484	iraqwar_guardian__1000-01-01__timeline:3715-3718	1.000
:Event_0000087	type	Life.Injure
:Event_0000087	mention.actual	"injures"	iraqwar_guardian__1000-01-01__timeline:50723-50729	1.000
:Event_0000087	canonical_mention.actual	"injures"	iraqwar_guardian__1000-01-01__timeline:50723-50729	1.000
:Event_0000087	Life.Injure_Instrument.actual	:Entity_EDL_0000480	iraqwar_guardian__1000-01-01__timeline:50654-50657	1.000
:Event_0000087	Life.Injure_Place.actual	:Entity_EDL_0000425	iraqwar_guardian__1000-01-01__timeline:50676-50681	1.000
:Event_0000087	Life.Injure_Victim.actual	:Entity_EDL_0000486	iraqwar_guardian__1000-01-01__timeline:50741-50742	1.000
:Event_0000087	Life.Injure_Agent.actual	:Entity_EDL_0000185	iraqwar_guardian__1000-01-01__timeline:50749-50759	1.000
:Event_0000088	type	Movement.TransportArtifact
:Event_0000088	mention.actual	"returning"	iraqwar_guardian__1000-01-01__timeline:3160-3168	1.000
:Event_0000088	canonical_mention.actual	"returning"	iraqwar_guardian__1000-01-01__timeline:3160-3168	1.000
:Event_0000088	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000228	iraqwar_guardian__1000-01-01__timeline:3121-3127	1.000
:Event_0000088	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000547	iraqwar_guardian__1000-01-01__timeline:3129-3135	1.000
:Event_0000088	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000209	iraqwar_guardian__1000-01-01__timeline:3175-3178	1.000
:Event_0000089	type	Contact.Meet
:Event_0000089	mention.actual	"talks"	iraqwar_guardian__1000-01-01__timeline:4671-4675	1.000
:Event_0000089	canonical_mention.actual	"talks"	iraqwar_guardian__1000-01-01__timeline:4671-4675	1.000
:Event_0000089	Contact.Meet_Participant.actual	:Entity_EDL_0000258	iraqwar_guardian__1000-01-01__timeline:4666-4669	1.000
:Event_0000090	type	Life.Injure
:Event_0000090	mention.actual	"injured"	iraqwar_guardian__1000-01-01__timeline:34413-34419	1.000
:Event_0000090	canonical_mention.actual	"injured"	iraqwar_guardian__1000-01-01__timeline:34413-34419	1.000
:Event_0000090	Life.Injure_Victim.actual	:Entity_EDL_0000503	iraqwar_guardian__1000-01-01__timeline:34405-34411	1.000
:Event_0000090	Life.Injure_Instrument.actual	:Entity_EDL_0000557	iraqwar_guardian__1000-01-01__timeline:34435-34438	1.000
:Event_0000090	Life.Injure_Place.actual	:Entity_EDL_0000376	iraqwar_guardian__1000-01-01__timeline:34452-34455	1.000
:Event_0000091	type	Life.Injure
:Event_0000091	mention.actual	"injuring"	iraqwar_guardian__1000-01-01__timeline:35219-35226	1.000
:Event_0000091	canonical_mention.actual	"injuring"	iraqwar_guardian__1000-01-01__timeline:35219-35226	1.000
:Event_0000091	Life.Injure_Agent.actual	:Entity_EDL_0000397	iraqwar_guardian__1000-01-01__timeline:35137-35146	1.000
:Event_0000091	Life.Injure_Instrument.actual	:Entity_EDL_0000532	iraqwar_guardian__1000-01-01__timeline:35172-35176	1.000
:Event_0000091	Life.Injure_Place.actual	:Entity_EDL_0000541	iraqwar_guardian__1000-01-01__timeline:35181-35184	1.000
:Event_0000091	Life.Injure_Victim.actual	:Entity_EDL_0000659	iraqwar_guardian__1000-01-01__timeline:35238-35240	1.000
:Event_0000092	type	Life.Die
:Event_0000092	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:44646-44649	1.000
:Event_0000092	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:44646-44649	1.000
:Event_0000092	Life.Die_Agent.actual	:Entity_EDL_0000390	iraqwar_guardian__1000-01-01__timeline:44639-44644	1.000
:Event_0000092	Life.Die_Victim.actual	:Entity_EDL_0000086	iraqwar_guardian__1000-01-01__timeline:44651-44657	1.000
:Event_0000093	type	Contact.Meet
:Event_0000093	mention.actual	"summit"	iraqwar_guardian__1000-01-01__timeline:26068-26073	1.000
:Event_0000093	canonical_mention.actual	"summit"	iraqwar_guardian__1000-01-01__timeline:26068-26073	1.000
:Event_0000093	Contact.Meet_Place.actual	:Entity_EDL_0000140	iraqwar_guardian__1000-01-01__timeline:26054-26066	1.000
:Event_0000093	Contact.Meet_Participant.actual	:Entity_EDL_0000638	iraqwar_guardian__1000-01-01__timeline:26080-26089	1.000
:Event_0000094	type	Conflict.Attack
:Event_0000094	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:14180-14187	1.000
:Event_0000094	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:14180-14187	1.000
:Event_0000094	Conflict.Attack_Target.actual	:Entity_EDL_0000272	iraqwar_guardian__1000-01-01__timeline:14139-14144	1.000
:Event_0000094	Conflict.Attack_Target.actual	:Entity_EDL_0000617	iraqwar_guardian__1000-01-01__timeline:14218-14224	1.000
:Event_0000094	Conflict.Attack_Place.actual	:Entity_EDL_0000509	iraqwar_guardian__1000-01-01__timeline:14240-14246	1.000
:Event_0000095	type	Life.Die
:Event_0000095	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:48904-48907	1.000
:Event_0000095	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:48904-48907	1.000
:Event_0000095	Life.Die_Agent.actual	:Entity_EDL_0000286	iraqwar_guardian__1000-01-01__timeline:48893-48902	1.000
:Event_0000095	Life.Die_Victim.actual	:Entity_EDL_0000606	iraqwar_guardian__1000-01-01__timeline:48924-48929	1.000
:Event_0000095	Life.Die_Victim.actual	:Entity_EDL_0000329	iraqwar_guardian__1000-01-01__timeline:48940-48945	1.000
:Event_0000096	type	Conflict.Attack
:Event_0000096	mention.actual	"fire"	iraqwar_guardian__1000-01-01__timeline:49336-49339	1.000
:Event_0000096	canonical_mention.actual	"fire"	iraqwar_guardian__1000-01-01__timeline:49336-49339	1.000
:Event_0000096	Conflict.Attack_Target.actual	:Entity_EDL_0000497	iraqwar_guardian__1000-01-01__timeline:49236-49244	1.000
:Event_0000096	Conflict.Attack_Place.actual	:Entity_EDL_0000113	iraqwar_guardian__1000-01-01__timeline:49290-49297	1.000
:Event_0000096	Conflict.Attack_Attacker.actual	:Entity_EDL_0000038	iraqwar_guardian__1000-01-01__timeline:49329-49334	1.000
:Event_0000096	Conflict.Attack_Target.actual	:Entity_EDL_0000109	iraqwar_guardian__1000-01-01__timeline:49344-49352	1.000
:Event_0000097	type	Movement.TransportArtifact
:Event_0000097	mention.actual	"visits"	iraqwar_guardian__1000-01-01__timeline:356-361	1.000
:Event_0000097	canonical_mention.actual	"visits"	iraqwar_guardian__1000-01-01__timeline:356-361	1.000
:Event_0000097	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000060	iraqwar_guardian__1000-01-01__timeline:345-354	1.000
:Event_0000097	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000005	iraqwar_guardian__1000-01-01__timeline:363-367	1.000
:Event_0000098	type	Life.Injure
:Event_0000098	mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:44996-45002	1.000
:Event_0000098	canonical_mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:44996-45002	1.000
:Event_0000098	Life.Injure_Victim.actual	:Entity_EDL_0000689	iraqwar_guardian__1000-01-01__timeline:44988-44990	1.000
:Event_0000098	Life.Injure_Place.actual	:Entity_EDL_0000582	iraqwar_guardian__1000-01-01__timeline:45024-45027	1.000
:Event_0000099	type	Conflict.Attack
:Event_0000099	mention.actual	"massacre"	iraqwar_guardian__1000-01-01__timeline:6841-6848	1.000
:Event_0000099	canonical_mention.actual	"massacre"	iraqwar_guardian__1000-01-01__timeline:6841-6848	1.000
:Event_0000099	Conflict.Attack_Target.actual	:Entity_EDL_0000268	iraqwar_guardian__1000-01-01__timeline:6858-6864	1.000
:Event_0000100	type	Life.Die
:Event_0000100	mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:50991-50993	1.000
:Event_0000100	canonical_mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:50991-50993	1.000
:Event_0000100	Life.Die_Victim.actual	:Entity_EDL_0000402	iraqwar_guardian__1000-01-01__timeline:50984-50989	1.000
:Event_0000101	type	Contact.Broadcast
:Event_0000101	mention.actual	"announced"	iraqwar_guardian__1000-01-01__timeline:34002-34010	1.000
:Event_0000101	canonical_mention.actual	"announced"	iraqwar_guardian__1000-01-01__timeline:34002-34010	1.000
:Event_0000101	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000201	iraqwar_guardian__1000-01-01__timeline:33981-33998	1.000
:Event_0000102	type	Conflict.Attack
:Event_0000102	mention.actual	"torture"	iraqwar_guardian__1000-01-01__timeline:3966-3972	1.000
:Event_0000102	canonical_mention.actual	"torture"	iraqwar_guardian__1000-01-01__timeline:3966-3972	1.000
:Event_0000102	Conflict.Attack_Target.actual	:Entity_EDL_0000535	iraqwar_guardian__1000-01-01__timeline:3929-3932	1.000
:Event_0000102	Conflict.Attack_Target.actual	:Entity_EDL_0000417	iraqwar_guardian__1000-01-01__timeline:3948-3954	1.000
:Event_0000103	type	Life.Die
:Event_0000103	mention.actual	"murder"	iraqwar_guardian__1000-01-01__timeline:47088-47093	1.000
:Event_0000103	canonical_mention.actual	"murder"	iraqwar_guardian__1000-01-01__timeline:47088-47093	1.000
:Event_0000103	Life.Die_Place.actual	:Entity_EDL_0000429	iraqwar_guardian__1000-01-01__timeline:47119-47122	1.000
:Event_0000104	type	Life.Die
:Event_0000104	mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:5444-5448	1.000
:Event_0000104	canonical_mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:5444-5448	1.000
:Event_0000105	type	Disaster.AccidentCrash.AccidentCrash
:Event_0000105	mention.actual	"crashes"	iraqwar_guardian__1000-01-01__timeline:48083-48089	1.000
:Event_0000105	canonical_mention.actual	"crashes"	iraqwar_guardian__1000-01-01__timeline:48083-48089	1.000
:Event_0000105	Disaster.AccidentCrash.AccidentCrash_Vehicle.actual	:Entity_EDL_0000233	iraqwar_guardian__1000-01-01__timeline:48074-48081	1.000
:Event_0000105	Disaster.AccidentCrash.AccidentCrash_Place.actual	:Entity_EDL_0000285	iraqwar_guardian__1000-01-01__timeline:48100-48106	1.000
:Event_0000106	type	Life.Die
:Event_0000106	mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:4175-4177	1.000
:Event_0000106	canonical_mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:4175-4177	1.000
:Event_0000106	Life.Die_Victim.actual	:Entity_EDL_0000487	iraqwar_guardian__1000-01-01__timeline:4168-4173	1.000
:Event_0000107	type	Justice.ReleaseParole
:Event_0000107	mention.actual	"freed"	iraqwar_guardian__1000-01-01__timeline:11023-11027	1.000
:Event_0000107	canonical_mention.actual	"freed"	iraqwar_guardian__1000-01-01__timeline:11023-11027	1.000
:Event_0000107	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000481	iraqwar_guardian__1000-01-01__timeline:11014-11021	1.000
:Event_0000107	Justice.ReleaseParole_Agent.actual	:Entity_EDL_0000379	iraqwar_guardian__1000-01-01__timeline:11035-11040	1.000
:Event_0000108	type	Personnel.EndPosition
:Event_0000108	mention.actual	"former"	iraqwar_guardian__1000-01-01__timeline:47045-47050	1.000
:Event_0000108	canonical_mention.actual	"former"	iraqwar_guardian__1000-01-01__timeline:47045-47050	1.000
:Event_0000108	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000552	iraqwar_guardian__1000-01-01__timeline:46981-46984	1.000
:Event_0000108	Personnel.EndPosition_Person.actual	:Entity_EDL_0000151	iraqwar_guardian__1000-01-01__timeline:47052-47063	1.000
:Event_0000108	Personnel.EndPosition_Place.actual	:Entity_EDL_0000429	iraqwar_guardian__1000-01-01__timeline:47119-47122	1.000
:Event_0000109	type	Conflict.Attack
:Event_0000109	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:4364-4371	1.000
:Event_0000109	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:4364-4371	1.000
:Event_0000109	Conflict.Attack_Target.actual	:Entity_EDL_0000567	iraqwar_guardian__1000-01-01__timeline:4340-4341	1.000
:Event_0000109	Conflict.Attack_Place.actual	:Entity_EDL_0000150	iraqwar_guardian__1000-01-01__timeline:4351-4354	1.000
:Event_0000110	type	Life.Die
:Event_0000110	mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:48801-48804	1.000
:Event_0000110	canonical_mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:48801-48804	1.000
:Event_0000110	Life.Die_Agent.actual	:Entity_EDL_0000152	iraqwar_guardian__1000-01-01__timeline:48727-48736	1.000
:Event_0000110	Life.Die_Victim.actual	:Entity_EDL_0000640	iraqwar_guardian__1000-01-01__timeline:48794-48799	1.000
:Event_0000111	type	Conflict.Attack
:Event_0000111	mention.actual	"rape"	iraqwar_guardian__1000-01-01__timeline:46086-46089	1.000
:Event_0000111	canonical_mention.actual	"rape"	iraqwar_guardian__1000-01-01__timeline:46086-46089	1.000
:Event_0000111	Conflict.Attack_Attacker.actual	:Entity_EDL_0000325	iraqwar_guardian__1000-01-01__timeline:45955-45960	1.000
:Event_0000111	Conflict.Attack_Target.actual	:Entity_EDL_0000685	iraqwar_guardian__1000-01-01__timeline:46059-46067	1.000
:Event_0000112	type	Life.Marry
:Event_0000112	mention.actual	"wedding"	iraqwar_guardian__1000-01-01__timeline:51041-51047	1.000
:Event_0000112	canonical_mention.actual	"wedding"	iraqwar_guardian__1000-01-01__timeline:51041-51047	1.000
:Event_0000112	Life.Marry_Person.actual	:Entity_EDL_0000315	iraqwar_guardian__1000-01-01__timeline:51024-51025	1.000
:Event_0000113	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000113	mention.actual	"criminal"	iraqwar_guardian__1000-01-01__timeline:47213-47220	1.000
:Event_0000113	canonical_mention.actual	"criminal"	iraqwar_guardian__1000-01-01__timeline:47213-47220	1.000
:Event_0000113	GenericCrime.GenericCrime.GenericCrime_Place.actual	:Entity_EDL_0000173	iraqwar_guardian__1000-01-01__timeline:47258-47261	1.000
:Event_0000114	type	Life.Injure
:Event_0000114	mention.actual	"wounding"	iraqwar_guardian__1000-01-01__timeline:43848-43855	1.000
:Event_0000114	canonical_mention.actual	"wounding"	iraqwar_guardian__1000-01-01__timeline:43848-43855	1.000
:Event_0000114	Life.Injure_Agent.actual	:Entity_EDL_0000381	iraqwar_guardian__1000-01-01__timeline:43742-43747	1.000
:Event_0000114	Life.Injure_Place.actual	:Entity_EDL_0000020	iraqwar_guardian__1000-01-01__timeline:43799-43804	1.000
:Event_0000114	Life.Injure_Victim.actual	:Entity_EDL_0000545	iraqwar_guardian__1000-01-01__timeline:43868-43873	1.000
:Event_0000115	type	Conflict.Attack
:Event_0000115	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:43286-43288	1.000
:Event_0000115	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:43286-43288	1.000
:Event_0000115	Conflict.Attack_Place.actual	:Entity_EDL_0000249	iraqwar_guardian__1000-01-01__timeline:43276-43284	1.000
:Event_0000116	type	Conflict.Attack
:Event_0000116	mention.actual	"airstrikes"	iraqwar_guardian__1000-01-01__timeline:7273-7282	1.000
:Event_0000116	canonical_mention.actual	"airstrikes"	iraqwar_guardian__1000-01-01__timeline:7273-7282	1.000
:Event_0000116	Conflict.Attack_Attacker.actual	:Entity_EDL_0000237	iraqwar_guardian__1000-01-01__timeline:7270-7271	1.000
:Event_0000116	Conflict.Attack_Target.actual	:Entity_EDL_0000167	iraqwar_guardian__1000-01-01__timeline:7291-7292	1.000
:Event_0000117	type	Life.Die
:Event_0000117	mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:4343-4346	1.000
:Event_0000117	canonical_mention.actual	"dead"	iraqwar_guardian__1000-01-01__timeline:4343-4346	1.000
:Event_0000117	Life.Die_Victim.actual	:Entity_EDL_0000567	iraqwar_guardian__1000-01-01__timeline:4340-4341	1.000
:Event_0000117	Life.Die_Place.actual	:Entity_EDL_0000150	iraqwar_guardian__1000-01-01__timeline:4351-4354	1.000
:Event_0000118	type	Life.Die
:Event_0000118	mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:49077-49079	1.000
:Event_0000118	canonical_mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:49077-49079	1.000
:Event_0000118	Life.Die_Victim.actual	:Entity_EDL_0000570	iraqwar_guardian__1000-01-01__timeline:49072-49075	1.000
:Event_0000119	type	Conflict.Attack
:Event_0000119	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:8604-8611	1.000
:Event_0000119	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:8604-8611	1.000
:Event_0000119	Conflict.Attack_Place.actual	:Entity_EDL_0000459	iraqwar_guardian__1000-01-01__timeline:8599-8602	1.000
:Event_0000120	type	Justice.ArrestJail
:Event_0000120	mention.actual	"arrested"	iraqwar_guardian__1000-01-01__timeline:12993-13000	1.000
:Event_0000120	canonical_mention.actual	"arrested"	iraqwar_guardian__1000-01-01__timeline:12993-13000	1.000
:Event_0000120	Justice.ArrestJail_Place.actual	:Entity_EDL_0000303	iraqwar_guardian__1000-01-01__timeline:12943-12947	1.000
:Event_0000120	Justice.ArrestJail_Person.actual	:Entity_EDL_0000596	iraqwar_guardian__1000-01-01__timeline:12980-12987	1.000
:Event_0000121	type	Life.Die
:Event_0000121	mention.actual	"claims"	iraqwar_guardian__1000-01-01__timeline:24705-24710	1.000
:Event_0000121	canonical_mention.actual	"claims"	iraqwar_guardian__1000-01-01__timeline:24705-24710	1.000
:Event_0000121	Life.Die_Victim.actual	:Entity_EDL_0000516	iraqwar_guardian__1000-01-01__timeline:24739-24746	1.000
:Event_0000121	Life.Die_Instrument.actual	:Entity_EDL_0000457	iraqwar_guardian__1000-01-01__timeline:24762-24765	1.000
:Event_0000122	type	Conflict.Attack
:Event_0000122	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:51806-51813	1.000
:Event_0000122	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:51806-51813	1.000
:Event_0000122	Conflict.Attack_Target.actual	:Entity_EDL_0000137	iraqwar_guardian__1000-01-01__timeline:51771-51776	1.000
:Event_0000122	Conflict.Attack_Instrument.actual	:Entity_EDL_0000354	iraqwar_guardian__1000-01-01__timeline:51802-51804	1.000
:Event_0000123	type	Contact.Meet
:Event_0000123	mention.actual	"meeting"	iraqwar_guardian__1000-01-01__timeline:40799-40805	1.000
:Event_0000123	canonical_mention.actual	"meeting"	iraqwar_guardian__1000-01-01__timeline:40799-40805	1.000
:Event_0000123	Contact.Meet_Participant.actual	:Entity_EDL_0000735	iraqwar_guardian__1000-01-01__timeline:40827-40834	1.000
:Event_0000124	type	Life.Die
:Event_0000124	mention.actual	"assassinated"	iraqwar_guardian__1000-01-01__timeline:52864-52875	1.000
:Event_0000124	canonical_mention.actual	"assassinated"	iraqwar_guardian__1000-01-01__timeline:52864-52875	1.000
:Event_0000124	Life.Die_Victim.actual	:Entity_EDL_0000652	iraqwar_guardian__1000-01-01__timeline:52784-52788	1.000
:Event_0000125	type	Life.Die
:Event_0000125	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:21220-21226	1.000
:Event_0000125	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:21220-21226	1.000
:Event_0000125	Life.Die_Victim.actual	:Entity_EDL_0000444	iraqwar_guardian__1000-01-01__timeline:21180-21188	1.000
:Event_0000125	Life.Die_Victim.actual	:Entity_EDL_0000317	iraqwar_guardian__1000-01-01__timeline:21232-21241	1.000
:Event_0000126	type	Movement.TransportPerson
:Event_0000126	mention.actual	"patrol"	iraqwar_guardian__1000-01-01__timeline:35033-35038	1.000
:Event_0000126	canonical_mention.actual	"patrol"	iraqwar_guardian__1000-01-01__timeline:35033-35038	1.000
:Event_0000126	Movement.TransportPerson_Person.actual	:Entity_EDL_0000443	iraqwar_guardian__1000-01-01__timeline:35017-35023	1.000
:Event_0000126	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000665	iraqwar_guardian__1000-01-01__timeline:35028-35031	1.000
:Event_0000127	type	Transaction.TransferMoney
:Event_0000127	mention.actual	"pay"	iraqwar_guardian__1000-01-01__timeline:10773-10775	1.000
:Event_0000127	canonical_mention.actual	"pay"	iraqwar_guardian__1000-01-01__timeline:10773-10775	1.000
:Event_0000127	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000192	iraqwar_guardian__1000-01-01__timeline:10723-10736	1.000
:Event_0000128	type	Conflict.Attack
:Event_0000128	mention.actual	"blasts"	iraqwar_guardian__1000-01-01__timeline:14730-14735	1.000
:Event_0000128	canonical_mention.actual	"blasts"	iraqwar_guardian__1000-01-01__timeline:14730-14735	1.000
:Event_0000128	Conflict.Attack_Place.actual	:Entity_EDL_0000663	iraqwar_guardian__1000-01-01__timeline:14722-14728	1.000
:Event_0000129	type	Life.Die
:Event_0000129	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:51778-51783	1.000
:Event_0000129	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:51778-51783	1.000
:Event_0000129	Life.Die_Victim.actual	:Entity_EDL_0000137	iraqwar_guardian__1000-01-01__timeline:51771-51776	1.000
:Event_0000129	Life.Die_Instrument.actual	:Entity_EDL_0000354	iraqwar_guardian__1000-01-01__timeline:51802-51804	1.000
:Event_0000130	type	Life.Die
:Event_0000130	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:7286-7289	1.000
:Event_0000130	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:7286-7289	1.000
:Event_0000130	Life.Die_Agent.actual	:Entity_EDL_0000237	iraqwar_guardian__1000-01-01__timeline:7270-7271	1.000
:Event_0000130	Life.Die_Victim.actual	:Entity_EDL_0000167	iraqwar_guardian__1000-01-01__timeline:7291-7292	1.000
:Event_0000131	type	Life.Die
:Event_0000131	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:33926-33931	1.000
:Event_0000131	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:33926-33931	1.000
:Event_0000131	Life.Die_Place.actual	:Entity_EDL_0000590	iraqwar_guardian__1000-01-01__timeline:33912-33915	1.000
:Event_0000131	Life.Die_Victim.actual	:Entity_EDL_0000476	iraqwar_guardian__1000-01-01__timeline:33947-33952	1.000
:Event_0000132	type	Conflict.Attack
:Event_0000132	mention.actual	"assault"	iraqwar_guardian__1000-01-01__timeline:39582-39588	1.000
:Event_0000132	canonical_mention.actual	"assault"	iraqwar_guardian__1000-01-01__timeline:39582-39588	1.000
:Event_0000132	Conflict.Attack_Attacker.actual	:Entity_EDL_0000041	iraqwar_guardian__1000-01-01__timeline:39555-39564	1.000
:Event_0000132	Conflict.Attack_Target.actual	:Entity_EDL_0000564	iraqwar_guardian__1000-01-01__timeline:39604-39618	1.000
:Event_0000132	Conflict.Attack_Target.actual	:Entity_EDL_0000213	iraqwar_guardian__1000-01-01__timeline:39646-39651	1.000
:Event_0000133	type	Conflict.Attack
:Event_0000133	mention.actual	"bombers target"	iraqwar_guardian__1000-01-01__timeline:45823-45836	1.000
:Event_0000133	canonical_mention.actual	"bombers target"	iraqwar_guardian__1000-01-01__timeline:45823-45836	1.000
:Event_0000133	Conflict.Attack_Attacker.actual	:Entity_EDL_0000110	iraqwar_guardian__1000-01-01__timeline:45823-45829	1.000
:Event_0000133	Conflict.Attack_Place.actual	:Entity_EDL_0000745	iraqwar_guardian__1000-01-01__timeline:45838-45841	1.000
:Event_0000133	Conflict.Attack_Target.actual	:Entity_EDL_0000067	iraqwar_guardian__1000-01-01__timeline:45851-45857	1.000
:Event_0000134	type	Conflict.Attack
:Event_0000134	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:8929-8935	1.000
:Event_0000134	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:8929-8935	1.000
:Event_0000134	Conflict.Attack_Attacker.actual	:Entity_EDL_0000489	iraqwar_guardian__1000-01-01__timeline:8846-8855	1.000
:Event_0000134	Conflict.Attack_Place.actual	:Entity_EDL_0000488	iraqwar_guardian__1000-01-01__timeline:8902-8910	1.000
:Event_0000135	type	Life.Injure
:Event_0000135	mention.actual	"torture"	iraqwar_guardian__1000-01-01__timeline:39477-39483	1.000
:Event_0000135	canonical_mention.actual	"torture"	iraqwar_guardian__1000-01-01__timeline:39477-39483	1.000
:Event_0000136	type	Justice.TrialHearing
:Event_0000136	mention.actual	"trial"	iraqwar_guardian__1000-01-01__timeline:51649-51653	1.000
:Event_0000136	canonical_mention.actual	"trial"	iraqwar_guardian__1000-01-01__timeline:51649-51653	1.000
:Event_0000136	Justice.TrialHearing_Place.actual	:Entity_EDL_0000114	iraqwar_guardian__1000-01-01__timeline:51625-51631	1.000
:Event_0000136	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000040	iraqwar_guardian__1000-01-01__timeline:51638-51647	1.000
:Event_0000137	type	Transaction.TransferMoney
:Event_0000137	mention.actual	"received"	iraqwar_guardian__1000-01-01__timeline:5832-5839	1.000
:Event_0000137	canonical_mention.actual	"received"	iraqwar_guardian__1000-01-01__timeline:5832-5839	1.000
:Event_0000137	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000252	iraqwar_guardian__1000-01-01__timeline:5789-5803	1.000
:Event_0000137	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000352	iraqwar_guardian__1000-01-01__timeline:5827-5830	1.000
:Event_0000137	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000318	iraqwar_guardian__1000-01-01__timeline:5869-5875	1.000
:Event_0000138	type	Conflict.Attack
:Event_0000138	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:47788-47795	1.000
:Event_0000138	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:47788-47795	1.000
:Event_0000139	type	Movement.TransportArtifact
:Event_0000139	mention.actual	"leaving"	iraqwar_guardian__1000-01-01__timeline:50765-50771	1.000
:Event_0000139	canonical_mention.actual	"leaving"	iraqwar_guardian__1000-01-01__timeline:50765-50771	1.000
:Event_0000139	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000425	iraqwar_guardian__1000-01-01__timeline:50676-50681	1.000
:Event_0000139	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000185	iraqwar_guardian__1000-01-01__timeline:50749-50759	1.000
:Event_0000140	type	Life.Die
:Event_0000140	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:23920-23925	1.000
:Event_0000140	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:23920-23925	1.000
:Event_0000140	Life.Die_Victim.actual	:Entity_EDL_0000508	iraqwar_guardian__1000-01-01__timeline:23910-23918	1.000
:Event_0000141	type	Life.Die
:Event_0000141	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:50893-50899	1.000
:Event_0000141	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:50893-50899	1.000
:Event_0000141	Life.Die_Agent.actual	:Entity_EDL_0000118	iraqwar_guardian__1000-01-01__timeline:50807-50812	1.000
:Event_0000141	Life.Die_Instrument.actual	:Entity_EDL_0000423	iraqwar_guardian__1000-01-01__timeline:50827-50835	1.000
:Event_0000141	Life.Die_Place.actual	:Entity_EDL_0000160	iraqwar_guardian__1000-01-01__timeline:50866-50872	1.000
:Event_0000141	Life.Die_Victim.actual	:Entity_EDL_0000194	iraqwar_guardian__1000-01-01__timeline:50910-50914	1.000
:Event_0000142	type	Conflict.Attack
:Event_0000142	mention.actual	"fight"	iraqwar_guardian__1000-01-01__timeline:9226-9230	1.000
:Event_0000142	canonical_mention.actual	"fight"	iraqwar_guardian__1000-01-01__timeline:9226-9230	1.000
:Event_0000142	Conflict.Attack_Attacker.actual	:Entity_EDL_0000694	iraqwar_guardian__1000-01-01__timeline:9210-9215	1.000
:Event_0000143	type	Contact.Contact
:Event_0000143	mention.actual	"leaked"	iraqwar_guardian__1000-01-01__timeline:36352-36357	1.000
:Event_0000143	canonical_mention.actual	"leaked"	iraqwar_guardian__1000-01-01__timeline:36352-36357	1.000
:Event_0000143	Contact.Contact_Participant.actual	:Entity_EDL_0000107	iraqwar_guardian__1000-01-01__timeline:36366-36373	1.000
:Event_0000144	type	Life.Die
:Event_0000144	mention.actual	"died"	iraqwar_guardian__1000-01-01__timeline:25051-25054	1.000
:Event_0000144	canonical_mention.actual	"died"	iraqwar_guardian__1000-01-01__timeline:25051-25054	1.000
:Event_0000144	Life.Die_Victim.actual	:Entity_EDL_0000216	iraqwar_guardian__1000-01-01__timeline:25040-25044	1.000
:Event_0000145	type	Conflict.Attack
:Event_0000145	mention.actual	"blasts"	iraqwar_guardian__1000-01-01__timeline:21633-21638	1.000
:Event_0000145	canonical_mention.actual	"blasts"	iraqwar_guardian__1000-01-01__timeline:21633-21638	1.000
:Event_0000145	Conflict.Attack_Place.actual	:Entity_EDL_0000699	iraqwar_guardian__1000-01-01__timeline:21620-21623	1.000
:Event_0000145	Conflict.Attack_Instrument.actual	:Entity_EDL_0000684	iraqwar_guardian__1000-01-01__timeline:21628-21631	1.000
:Event_0000146	type	Movement.TransportArtifact
:Event_0000146	mention.actual	"passing"	iraqwar_guardian__1000-01-01__timeline:8353-8359	1.000
:Event_0000146	canonical_mention.actual	"passing"	iraqwar_guardian__1000-01-01__timeline:8353-8359	1.000
:Event_0000146	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000142	iraqwar_guardian__1000-01-01__timeline:8330-8333	1.000
:Event_0000146	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000542	iraqwar_guardian__1000-01-01__timeline:8384-8388	1.000
:Event_0000147	type	ArtifactExistence.Shortage.Shortage
:Event_0000147	mention.actual	"shortfalls"	iraqwar_guardian__1000-01-01__timeline:9380-9389	1.000
:Event_0000147	canonical_mention.actual	"shortfalls"	iraqwar_guardian__1000-01-01__timeline:9380-9389	1.000
:Event_0000148	type	Movement.TransportArtifact
:Event_0000148	mention.actual	"return"	iraqwar_guardian__1000-01-01__timeline:8881-8886	1.000
:Event_0000148	canonical_mention.actual	"return"	iraqwar_guardian__1000-01-01__timeline:8881-8886	1.000
:Event_0000148	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000489	iraqwar_guardian__1000-01-01__timeline:8846-8855	1.000
:Event_0000148	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000009	iraqwar_guardian__1000-01-01__timeline:8860-8863	1.000
:Event_0000148	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000488	iraqwar_guardian__1000-01-01__timeline:8902-8910	1.000
:Event_0000149	type	Life.Injure
:Event_0000149	mention.actual	"wounding"	iraqwar_guardian__1000-01-01__timeline:18329-18336	1.000
:Event_0000149	canonical_mention.actual	"wounding"	iraqwar_guardian__1000-01-01__timeline:18329-18336	1.000
:Event_0000149	Life.Injure_Instrument.actual	:Entity_EDL_0000762	iraqwar_guardian__1000-01-01__timeline:18263-18266	1.000
:Event_0000149	Life.Injure_Victim.actual	:Entity_EDL_0000415	iraqwar_guardian__1000-01-01__timeline:18338-18343	1.000
:Event_0000150	type	Justice.TrialHearing
:Event_0000150	mention.actual	"court martial"	iraqwar_guardian__1000-01-01__timeline:4734-4746	1.000
:Event_0000150	canonical_mention.actual	"court martial"	iraqwar_guardian__1000-01-01__timeline:4734-4746	1.000
:Event_0000150	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000624	iraqwar_guardian__1000-01-01__timeline:4765-4772	1.000
:Event_0000150	Justice.TrialHearing_Adjudicator.actual	:Entity_EDL_0000515	iraqwar_guardian__1000-01-01__timeline:4839-4843	1.000
:Event_0000151	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000151	mention.actual	"murder"	iraqwar_guardian__1000-01-01__timeline:47288-47293	1.000
:Event_0000151	canonical_mention.actual	"murder"	iraqwar_guardian__1000-01-01__timeline:47288-47293	1.000
:Event_0000151	GenericCrime.GenericCrime.GenericCrime_Victim.actual	:Entity_EDL_0000342	iraqwar_guardian__1000-01-01__timeline:47272-47276	1.000
:Event_0000152	type	Life.Injure
:Event_0000152	mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:3596-3602	1.000
:Event_0000152	canonical_mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:3596-3602	1.000
:Event_0000152	Life.Injure_Victim.actual	:Entity_EDL_0000700	iraqwar_guardian__1000-01-01__timeline:3569-3575	1.000
:Event_0000152	Life.Injure_Victim.actual	:Entity_EDL_0000455	iraqwar_guardian__1000-01-01__timeline:3591-3594	1.000
:Event_0000152	Life.Injure_Instrument.actual	:Entity_EDL_0000539	iraqwar_guardian__1000-01-01__timeline:3618-3621	1.000
:Event_0000152	Life.Injure_Place.actual	:Entity_EDL_0000484	iraqwar_guardian__1000-01-01__timeline:3715-3718	1.000
:Event_0000153	type	Business.Start
:Event_0000153	mention.actual	"took office"	iraqwar_guardian__1000-01-01__timeline:25108-25118	1.000
:Event_0000153	canonical_mention.actual	"took office"	iraqwar_guardian__1000-01-01__timeline:25108-25118	1.000
:Event_0000153	Business.Start_Organization.actual	:Entity_EDL_0000199	iraqwar_guardian__1000-01-01__timeline:25075-25084	1.000
:Event_0000154	type	Life.Injure
:Event_0000154	mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:34253-34259	1.000
:Event_0000154	canonical_mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:34253-34259	1.000
:Event_0000154	Life.Injure_Agent.actual	:Entity_EDL_0000514	iraqwar_guardian__1000-01-01__timeline:34148-34152	1.000
:Event_0000154	Life.Injure_Victim.actual	:Entity_EDL_0000123	iraqwar_guardian__1000-01-01__timeline:34272-34277	1.000
:Event_0000155	type	Movement.TransportPerson
:Event_0000155	mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:26100-26109	1.000
:Event_0000155	canonical_mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:26100-26109	1.000
:Event_0000156	type	Transaction.TransferMoney
:Event_0000156	mention.actual	"raises"	iraqwar_guardian__1000-01-01__timeline:10896-10901	1.000
:Event_0000156	canonical_mention.actual	"raises"	iraqwar_guardian__1000-01-01__timeline:10896-10901	1.000
:Event_0000157	type	Movement.TransportArtifact
:Event_0000157	mention.actual	"traveled"	iraqwar_guardian__1000-01-01__timeline:27501-27508	1.000
:Event_0000157	canonical_mention.actual	"traveled"	iraqwar_guardian__1000-01-01__timeline:27501-27508	1.000
:Event_0000157	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000432	iraqwar_guardian__1000-01-01__timeline:27479-27486	1.000
:Event_0000157	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000384	iraqwar_guardian__1000-01-01__timeline:27515-27521	1.000
:Event_0000157	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000438	iraqwar_guardian__1000-01-01__timeline:27561-27564	1.000
:Event_0000158	type	Justice.Convict
:Event_0000158	mention.actual	"convicted"	iraqwar_guardian__1000-01-01__timeline:37823-37831	1.000
:Event_0000158	canonical_mention.actual	"convicted"	iraqwar_guardian__1000-01-01__timeline:37823-37831	1.000
:Event_0000158	Justice.Convict_Defendant.actual	:Entity_EDL_0000554	iraqwar_guardian__1000-01-01__timeline:37799-37812	1.000
:Event_0000159	type	Personnel.Elect
:Event_0000159	mention.actual	"winning"	iraqwar_guardian__1000-01-01__timeline:46254-46260	1.000
:Event_0000159	canonical_mention.actual	"winning"	iraqwar_guardian__1000-01-01__timeline:46254-46260	1.000
:Event_0000159	Personnel.Elect_Place.actual	:Entity_EDL_0000332	iraqwar_guardian__1000-01-01__timeline:46189-46192	1.000
:Event_0000159	Personnel.Elect_Elect.actual	:Entity_EDL_0000434	iraqwar_guardian__1000-01-01__timeline:46202-46208	1.000
:Event_0000159	Personnel.Elect_Place.actual	:Entity_EDL_0000744	iraqwar_guardian__1000-01-01__timeline:46298-46304	1.000
:Event_0000160	type	Conflict.Attack
:Event_0000160	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:30804-30811	1.000
:Event_0000160	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:30804-30811	1.000
:Event_0000161	type	Life.Die
:Event_0000161	mention.actual	"assassinated"	iraqwar_guardian__1000-01-01__timeline:54375-54386	1.000
:Event_0000161	canonical_mention.actual	"assassinated"	iraqwar_guardian__1000-01-01__timeline:54375-54386	1.000
:Event_0000161	Life.Die_Victim.actual	:Entity_EDL_0000168	iraqwar_guardian__1000-01-01__timeline:54352-54359	1.000
:Event_0000161	Life.Die_Place.actual	:Entity_EDL_0000292	iraqwar_guardian__1000-01-01__timeline:54401-54407	1.000
:Event_0000162	type	Conflict.Attack
:Event_0000162	mention.actual	"fire"	iraqwar_guardian__1000-01-01__timeline:43180-43183	1.000
:Event_0000162	canonical_mention.actual	"fire"	iraqwar_guardian__1000-01-01__timeline:43180-43183	1.000
:Event_0000162	Conflict.Attack_Target.actual	:Entity_EDL_0000308	iraqwar_guardian__1000-01-01__timeline:43065-43071	1.000
:Event_0000162	Conflict.Attack_Place.actual	:Entity_EDL_0000714	iraqwar_guardian__1000-01-01__timeline:43188-43191	1.000
:Event_0000163	type	Conflict.Attack
:Event_0000163	mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:4193-4198	1.000
:Event_0000163	canonical_mention.actual	"attack"	iraqwar_guardian__1000-01-01__timeline:4193-4198	1.000
:Event_0000163	Conflict.Attack_Target.actual	:Entity_EDL_0000487	iraqwar_guardian__1000-01-01__timeline:4168-4173	1.000
:Event_0000164	type	Conflict.Attack
:Event_0000164	mention.actual	"battle"	iraqwar_guardian__1000-01-01__timeline:56-61	1.000
:Event_0000164	canonical_mention.actual	"battle"	iraqwar_guardian__1000-01-01__timeline:56-61	1.000
:Event_0000164	Conflict.Attack_Target.actual	:Entity_EDL_0000084	iraqwar_guardian__1000-01-01__timeline:16-21	1.000
:Event_0000164	Conflict.Attack_Attacker.actual	:Entity_EDL_0000410	iraqwar_guardian__1000-01-01__timeline:33-42	1.000
:Event_0000164	Conflict.Attack_Instrument.actual	:Entity_EDL_0000474	iraqwar_guardian__1000-01-01__timeline:52-54	1.000
:Event_0000164	Conflict.Attack_Attacker.actual	:Entity_EDL_0000364	iraqwar_guardian__1000-01-01__timeline:74-81	1.000
:Event_0000164	Conflict.Attack_Attacker.actual	:Entity_EDL_0000584	iraqwar_guardian__1000-01-01__timeline:87-93	1.000
:Event_0000164	Conflict.Attack_Place.actual	:Entity_EDL_0000324	iraqwar_guardian__1000-01-01__timeline:114-117	1.000
:Event_0000165	type	Conflict.Attack
:Event_0000165	mention.actual	"assault"	iraqwar_guardian__1000-01-01__timeline:29335-29341	1.000
:Event_0000165	canonical_mention.actual	"assault"	iraqwar_guardian__1000-01-01__timeline:29335-29341	1.000
:Event_0000165	Conflict.Attack_Place.actual	:Entity_EDL_0000262	iraqwar_guardian__1000-01-01__timeline:29265-29268	1.000
:Event_0000165	Conflict.Attack_Target.actual	:Entity_EDL_0000380	iraqwar_guardian__1000-01-01__timeline:29361-29366	1.000
:Event_0000165	Conflict.Attack_Target.actual	:Entity_EDL_0000675	iraqwar_guardian__1000-01-01__timeline:29375-29380	1.000
:Event_0000166	type	Life.Injure
:Event_0000166	mention.actual	"maiming"	iraqwar_guardian__1000-01-01__timeline:45787-45793	1.000
:Event_0000166	canonical_mention.actual	"maiming"	iraqwar_guardian__1000-01-01__timeline:45787-45793	1.000
:Event_0000166	Life.Injure_Agent.actual	:Entity_EDL_0000141	iraqwar_guardian__1000-01-01__timeline:45710-45713	1.000
:Event_0000166	Life.Injure_Instrument.actual	:Entity_EDL_0000047	iraqwar_guardian__1000-01-01__timeline:45762-45771	1.000
:Event_0000166	Life.Injure_Victim.actual	:Entity_EDL_0000175	iraqwar_guardian__1000-01-01__timeline:45805-45810	1.000
:Event_0000167	type	Life.Die
:Event_0000167	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:51019-51022	1.000
:Event_0000167	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:51019-51022	1.000
:Event_0000167	Life.Die_Victim.actual	:Entity_EDL_0000315	iraqwar_guardian__1000-01-01__timeline:51024-51025	1.000
:Event_0000167	Life.Die_Place.actual	:Entity_EDL_0000267	iraqwar_guardian__1000-01-01__timeline:51030-51035	1.000
:Event_0000168	type	Life.Die
:Event_0000168	mention.actual	"drown"	iraqwar_guardian__1000-01-01__timeline:16179-16183	1.000
:Event_0000168	canonical_mention.actual	"drown"	iraqwar_guardian__1000-01-01__timeline:16179-16183	1.000
:Event_0000168	Life.Die_Place.actual	:Entity_EDL_0000465	iraqwar_guardian__1000-01-01__timeline:16153-16164	1.000
:Event_0000168	Life.Die_Victim.actual	:Entity_EDL_0000261	iraqwar_guardian__1000-01-01__timeline:16174-16177	1.000
:Event_0000169	type	Life.Die
:Event_0000169	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:30915-30921	1.000
:Event_0000169	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:30915-30921	1.000
:Event_0000169	Life.Die_Place.actual	:Entity_EDL_0000370	iraqwar_guardian__1000-01-01__timeline:30965-30971	1.000
:Event_0000170	type	Conflict.Attack
:Event_0000170	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:18715-18722	1.000
:Event_0000170	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:18715-18722	1.000
:Event_0000170	Conflict.Attack_Place.actual	:Entity_EDL_0000637	iraqwar_guardian__1000-01-01__timeline:18690-18696	1.000
:Event_0000171	type	Life.Die
:Event_0000171	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:48027-48032	1.000
:Event_0000171	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:48027-48032	1.000
:Event_0000171	Life.Die_Victim.actual	:Entity_EDL_0000019	iraqwar_guardian__1000-01-01__timeline:48016-48021	1.000
:Event_0000172	type	Conflict.Attack
:Event_0000172	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:54434-54440	1.000
:Event_0000172	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:54434-54440	1.000
:Event_0000172	Conflict.Attack_Place.actual	:Entity_EDL_0000292	iraqwar_guardian__1000-01-01__timeline:54401-54407	1.000
:Event_0000173	type	Movement.TransportArtifact
:Event_0000173	mention.actual	"smuggled"	iraqwar_guardian__1000-01-01__timeline:17355-17362	1.000
:Event_0000173	canonical_mention.actual	"smuggled"	iraqwar_guardian__1000-01-01__timeline:17355-17362	1.000
:Event_0000173	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000218	iraqwar_guardian__1000-01-01__timeline:17347-17353	1.000
:Event_0000173	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000344	iraqwar_guardian__1000-01-01__timeline:17383-17392	1.000
:Event_0000173	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000034	iraqwar_guardian__1000-01-01__timeline:17405-17414	1.000
:Event_0000173	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000650	iraqwar_guardian__1000-01-01__timeline:17471-17477	1.000
:Event_0000174	type	Justice.Sentence
:Event_0000174	mention.actual	"sentence"	iraqwar_guardian__1000-01-01__timeline:11139-11146	1.000
:Event_0000174	canonical_mention.actual	"sentence"	iraqwar_guardian__1000-01-01__timeline:11139-11146	1.000
:Event_0000174	Justice.Sentence_Defendant.actual	:Entity_EDL_0000609	iraqwar_guardian__1000-01-01__timeline:11053-11056	1.000
:Event_0000175	type	Movement.TransportArtifact
:Event_0000175	mention.actual	"traveling"	iraqwar_guardian__1000-01-01__timeline:15645-15653	1.000
:Event_0000175	canonical_mention.actual	"traveling"	iraqwar_guardian__1000-01-01__timeline:15645-15653	1.000
:Event_0000175	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000671	iraqwar_guardian__1000-01-01__timeline:15636-15643	1.000
:Event_0000175	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000424	iraqwar_guardian__1000-01-01__timeline:15669-15678	1.000
:Event_0000175	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000011	iraqwar_guardian__1000-01-01__timeline:15692-15695	1.000
:Event_0000176	type	Conflict.Attack
:Event_0000176	mention.actual	"fire"	iraqwar_guardian__1000-01-01__timeline:44460-44463	1.000
:Event_0000176	canonical_mention.actual	"fire"	iraqwar_guardian__1000-01-01__timeline:44460-44463	1.000
:Event_0000176	Conflict.Attack_Attacker.actual	:Entity_EDL_0000051	iraqwar_guardian__1000-01-01__timeline:44438-44445	1.000
:Event_0000176	Conflict.Attack_Target.actual	:Entity_EDL_0000186	iraqwar_guardian__1000-01-01__timeline:44470-44472	1.000
:Event_0000176	Conflict.Attack_Target.actual	:Entity_EDL_0000603	iraqwar_guardian__1000-01-01__timeline:44494-44503	1.000
:Event_0000176	Conflict.Attack_Target.actual	:Entity_EDL_0000377	iraqwar_guardian__1000-01-01__timeline:44558-44562	1.000
:Event_0000177	type	Conflict.Attack
:Event_0000177	mention.actual	"abused"	iraqwar_guardian__1000-01-01__timeline:47436-47441	1.000
:Event_0000177	canonical_mention.actual	"abused"	iraqwar_guardian__1000-01-01__timeline:47436-47441	1.000
:Event_0000177	Conflict.Attack_Attacker.actual	:Entity_EDL_0000106	iraqwar_guardian__1000-01-01__timeline:47454-47461	1.000
:Event_0000178	type	Life.Die
:Event_0000178	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:24899-24904	1.000
:Event_0000178	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:24899-24904	1.000
:Event_0000178	Life.Die_Victim.actual	:Entity_EDL_0000296	iraqwar_guardian__1000-01-01__timeline:24859-24867	1.000
:Event_0000178	Life.Die_Victim.actual	:Entity_EDL_0000404	iraqwar_guardian__1000-01-01__timeline:24880-24887	1.000
:Event_0000178	Life.Die_Agent.actual	:Entity_EDL_0000583	iraqwar_guardian__1000-01-01__timeline:24909-24918	1.000
:Event_0000178	Life.Die_Victim.actual	:Entity_EDL_0000482	iraqwar_guardian__1000-01-01__timeline:24943-24945	1.000
:Event_0000179	type	Conflict.Attack
:Event_0000179	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:51150-51157	1.000
:Event_0000179	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:51150-51157	1.000
:Event_0000179	Conflict.Attack_Target.actual	:Entity_EDL_0000721	iraqwar_guardian__1000-01-01__timeline:51106-51111	1.000
:Event_0000179	Conflict.Attack_Place.actual	:Entity_EDL_0000512	iraqwar_guardian__1000-01-01__timeline:51127-51133	1.000
:Event_0000179	Conflict.Attack_Target.actual	:Entity_EDL_0000358	iraqwar_guardian__1000-01-01__timeline:51184-51190	1.000
:Event_0000179	Conflict.Attack_Target.actual	:Entity_EDL_0000711	iraqwar_guardian__1000-01-01__timeline:51203-51209	1.000
:Event_0000179	Conflict.Attack_Target.actual	:Entity_EDL_0000698	iraqwar_guardian__1000-01-01__timeline:51224-51230	1.000
:Event_0000179	Conflict.Attack_Target.actual	:Entity_EDL_0000712	iraqwar_guardian__1000-01-01__timeline:51238-51241	1.000
:Event_0000180	type	Conflict.Attack
:Event_0000180	mention.actual	"conflict"	iraqwar_guardian__1000-01-01__timeline:18678-18685	1.000
:Event_0000180	canonical_mention.actual	"conflict"	iraqwar_guardian__1000-01-01__timeline:18678-18685	1.000
:Event_0000180	Conflict.Attack_Place.actual	:Entity_EDL_0000501	iraqwar_guardian__1000-01-01__timeline:18590-18593	1.000
:Event_0000181	type	Life.Die
:Event_0000181	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:21560-21566	1.000
:Event_0000181	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:21560-21566	1.000
:Event_0000181	Life.Die_Agent.actual	:Entity_EDL_0000627	iraqwar_guardian__1000-01-01__timeline:21523-21528	1.000
:Event_0000181	Life.Die_Place.actual	:Entity_EDL_0000171	iraqwar_guardian__1000-01-01__timeline:21547-21556	1.000
:Event_0000181	Life.Die_Victim.actual	:Entity_EDL_0000407	iraqwar_guardian__1000-01-01__timeline:21577-21580	1.000
:Event_0000182	type	Life.Die
:Event_0000182	mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:21613-21615	1.000
:Event_0000182	canonical_mention.actual	"die"	iraqwar_guardian__1000-01-01__timeline:21613-21615	1.000
:Event_0000182	Life.Die_Victim.actual	:Entity_EDL_0000635	iraqwar_guardian__1000-01-01__timeline:21605-21611	1.000
:Event_0000182	Life.Die_Place.actual	:Entity_EDL_0000699	iraqwar_guardian__1000-01-01__timeline:21620-21623	1.000
:Event_0000182	Life.Die_Instrument.actual	:Entity_EDL_0000684	iraqwar_guardian__1000-01-01__timeline:21628-21631	1.000
:Event_0000183	type	Life.Die
:Event_0000183	mention.actual	"fatalities"	iraqwar_guardian__1000-01-01__timeline:15745-15754	1.000
:Event_0000183	canonical_mention.actual	"fatalities"	iraqwar_guardian__1000-01-01__timeline:15745-15754	1.000
:Event_0000184	type	Life.Die
:Event_0000184	mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:40109-40113	1.000
:Event_0000184	canonical_mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:40109-40113	1.000
:Event_0000184	Life.Die_Place.actual	:Entity_EDL_0000174	iraqwar_guardian__1000-01-01__timeline:40123-40126	1.000
:Event_0000185	type	Life.Die
:Event_0000185	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:54557-54562	1.000
:Event_0000185	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:54557-54562	1.000
:Event_0000185	Life.Die_Victim.actual	:Entity_EDL_0000507	iraqwar_guardian__1000-01-01__timeline:54546-54551	1.000
:Event_0000185	Life.Die_Agent.actual	:Entity_EDL_0000240	iraqwar_guardian__1000-01-01__timeline:54613-54618	1.000
:Event_0000186	type	Life.Injure
:Event_0000186	mention.actual	"injures"	iraqwar_guardian__1000-01-01__timeline:49972-49978	1.000
:Event_0000186	canonical_mention.actual	"injures"	iraqwar_guardian__1000-01-01__timeline:49972-49978	1.000
:Event_0000186	Life.Injure_Agent.actual	:Entity_EDL_0000117	iraqwar_guardian__1000-01-01__timeline:49928-49938	1.000
:Event_0000186	Life.Injure_Victim.actual	:Entity_EDL_0000578	iraqwar_guardian__1000-01-01__timeline:49983-49988	1.000
:Event_0000187	type	Conflict.Attack
:Event_0000187	mention.actual	"attacked"	iraqwar_guardian__1000-01-01__timeline:21194-21201	1.000
:Event_0000187	canonical_mention.actual	"attacked"	iraqwar_guardian__1000-01-01__timeline:21194-21201	1.000
:Event_0000187	Conflict.Attack_Target.actual	:Entity_EDL_0000444	iraqwar_guardian__1000-01-01__timeline:21180-21188	1.000
:Event_0000188	type	Life.Injure
:Event_0000188	mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:29217-29223	1.000
:Event_0000188	canonical_mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:29217-29223	1.000
:Event_0000188	Life.Injure_Victim.actual	:Entity_EDL_0000378	iraqwar_guardian__1000-01-01__timeline:29212-29215	1.000
:Event_0000189	type	Life.Die
:Event_0000189	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:39990-39995	1.000
:Event_0000189	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:39990-39995	1.000
:Event_0000189	Life.Die_Victim.actual	:Entity_EDL_0000676	iraqwar_guardian__1000-01-01__timeline:39981-39988	1.000
:Event_0000189	Life.Die_Place.actual	:Entity_EDL_0000642	iraqwar_guardian__1000-01-01__timeline:40000-40003	1.000
:Event_0000190	type	Justice.TrialHearing
:Event_0000190	mention.actual	"trials"	iraqwar_guardian__1000-01-01__timeline:23896-23901	1.000
:Event_0000190	canonical_mention.actual	"trials"	iraqwar_guardian__1000-01-01__timeline:23896-23901	1.000
:Event_0000190	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000473	iraqwar_guardian__1000-01-01__timeline:23868-23874	1.000
:Event_0000190	Justice.TrialHearing_Place.actual	:Entity_EDL_0000044	iraqwar_guardian__1000-01-01__timeline:23881-23884	1.000
:Event_0000191	type	Life.Die
:Event_0000191	mention.actual	"murder"	iraqwar_guardian__1000-01-01__timeline:49137-49142	1.000
:Event_0000191	canonical_mention.actual	"murder"	iraqwar_guardian__1000-01-01__timeline:49137-49142	1.000
:Event_0000191	Life.Die_Agent.actual	:Entity_EDL_0000193	iraqwar_guardian__1000-01-01__timeline:49126-49135	1.000
:Event_0000191	Life.Die_Victim.actual	:Entity_EDL_0000746	iraqwar_guardian__1000-01-01__timeline:49157-49175	1.000
:Event_0000191	Life.Die_Victim.actual	:Entity_EDL_0000687	iraqwar_guardian__1000-01-01__timeline:49185-49187	1.000
:Event_0000191	Life.Die_Place.actual	:Entity_EDL_0000521	iraqwar_guardian__1000-01-01__timeline:49213-49219	1.000
:Event_0000192	type	Conflict.Attack
:Event_0000192	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:13761-13768	1.000
:Event_0000192	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:13761-13768	1.000
:Event_0000192	Conflict.Attack_Place.actual	:Entity_EDL_0000202	iraqwar_guardian__1000-01-01__timeline:13775-13782	1.000
:Event_0000193	type	Conflict.Attack
:Event_0000193	mention.actual	"offensive"	iraqwar_guardian__1000-01-01__timeline:14594-14602	1.000
:Event_0000193	canonical_mention.actual	"offensive"	iraqwar_guardian__1000-01-01__timeline:14594-14602	1.000
:Event_0000193	Conflict.Attack_Attacker.actual	:Entity_EDL_0000207	iraqwar_guardian__1000-01-01__timeline:14585-14592	1.000
:Event_0000193	Conflict.Attack_Target.actual	:Entity_EDL_0000169	iraqwar_guardian__1000-01-01__timeline:14612-14617	1.000
:Event_0000194	type	Personnel.EndPosition
:Event_0000194	mention.actual	"Former"	iraqwar_guardian__1000-01-01__timeline:1104-1109	1.000
:Event_0000194	canonical_mention.actual	"Former"	iraqwar_guardian__1000-01-01__timeline:1104-1109	1.000
:Event_0000194	Personnel.EndPosition_Person.actual	:Entity_EDL_0000182	iraqwar_guardian__1000-01-01__timeline:1126-1136	1.000
:Event_0000194	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000742	iraqwar_guardian__1000-01-01__timeline:1141-1145	1.000
:Event_0000195	type	Life.Die
:Event_0000195	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:10025-10029	1.000
:Event_0000195	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:10025-10029	1.000
:Event_0000195	Life.Die_Agent.actual	:Entity_EDL_0000418	iraqwar_guardian__1000-01-01__timeline:10017-10023	1.000
:Event_0000195	Life.Die_Agent.actual	:Entity_EDL_0000104	iraqwar_guardian__1000-01-01__timeline:10052-10058	1.000
:Event_0000196	type	Personnel.EndPosition
:Event_0000196	mention.actual	"leaving"	iraqwar_guardian__1000-01-01__timeline:28474-28480	1.000
:Event_0000196	canonical_mention.actual	"leaving"	iraqwar_guardian__1000-01-01__timeline:28474-28480	1.000
:Event_0000196	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000556	iraqwar_guardian__1000-01-01__timeline:28428-28434	1.000
:Event_0000196	Personnel.EndPosition_Person.actual	:Entity_EDL_0000212	iraqwar_guardian__1000-01-01__timeline:28436-28443	1.000
:Event_0000196	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000284	iraqwar_guardian__1000-01-01__timeline:28486-28495	1.000
:Event_0000197	type	Conflict.Attack
:Event_0000197	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:51746-51752	1.000
:Event_0000197	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:51746-51752	1.000
:Event_0000197	Conflict.Attack_Attacker.actual	:Entity_EDL_0000081	iraqwar_guardian__1000-01-01__timeline:51708-51717	1.000
:Event_0000198	type	Conflict.Attack
:Event_0000198	mention.actual	"shootings"	iraqwar_guardian__1000-01-01__timeline:30944-30952	1.000
:Event_0000198	canonical_mention.actual	"shootings"	iraqwar_guardian__1000-01-01__timeline:30944-30952	1.000
:Event_0000198	Conflict.Attack_Target.actual	:Entity_EDL_0000248	iraqwar_guardian__1000-01-01__timeline:30876-30881	1.000
:Event_0000198	Conflict.Attack_Place.actual	:Entity_EDL_0000370	iraqwar_guardian__1000-01-01__timeline:30965-30971	1.000
:Event_0000199	type	Justice.ArrestJail
:Event_0000199	mention.actual	"arrest"	iraqwar_guardian__1000-01-01__timeline:27409-27414	1.000
:Event_0000199	canonical_mention.actual	"arrest"	iraqwar_guardian__1000-01-01__timeline:27409-27414	1.000
:Event_0000199	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000050	iraqwar_guardian__1000-01-01__timeline:27363-27368	1.000
:Event_0000199	Justice.ArrestJail_Place.actual	:Entity_EDL_0000416	iraqwar_guardian__1000-01-01__timeline:27386-27389	1.000
:Event_0000199	Justice.ArrestJail_Place.actual	:Entity_EDL_0000589	iraqwar_guardian__1000-01-01__timeline:27394-27403	1.000
:Event_0000199	Justice.ArrestJail_Person.actual	:Entity_EDL_0000198	iraqwar_guardian__1000-01-01__timeline:27430-27432	1.000
:Event_0000200	type	Life.Die
:Event_0000200	mention.actual	"Suicide"	iraqwar_guardian__1000-01-01__timeline:45640-45646	1.000
:Event_0000200	canonical_mention.actual	"Suicide"	iraqwar_guardian__1000-01-01__timeline:45640-45646	1.000
:Event_0000200	Life.Die_Victim.actual	:Entity_EDL_0000651	iraqwar_guardian__1000-01-01__timeline:45648-45654	1.000
:Event_0000200	Life.Die_Instrument.actual	:Entity_EDL_0000047	iraqwar_guardian__1000-01-01__timeline:45762-45771	1.000
:Event_0000201	type	Life.Die
:Event_0000201	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:14535-14541	1.000
:Event_0000201	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:14535-14541	1.000
:Event_0000202	type	Life.Die
:Event_0000202	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:4115-4121	1.000
:Event_0000202	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:4115-4121	1.000
:Event_0000202	Life.Die_Place.actual	:Entity_EDL_0000208	iraqwar_guardian__1000-01-01__timeline:4143-4152	1.000
:Event_0000203	type	Justice.TrialHearing
:Event_0000203	mention.actual	"try"	iraqwar_guardian__1000-01-01__timeline:52218-52220	1.000
:Event_0000203	canonical_mention.actual	"try"	iraqwar_guardian__1000-01-01__timeline:52218-52220	1.000
:Event_0000203	Justice.TrialHearing_Prosecutor.actual	:Entity_EDL_0000310	iraqwar_guardian__1000-01-01__timeline:52212-52213	1.000
:Event_0000203	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000522	iraqwar_guardian__1000-01-01__timeline:52230-52235	1.000
:Event_0000204	type	Conflict.Attack
:Event_0000204	mention.actual	"offensive"	iraqwar_guardian__1000-01-01__timeline:15066-15074	1.000
:Event_0000204	canonical_mention.actual	"offensive"	iraqwar_guardian__1000-01-01__timeline:15066-15074	1.000
:Event_0000204	Conflict.Attack_Attacker.actual	:Entity_EDL_0000276	iraqwar_guardian__1000-01-01__timeline:14927-14934	1.000
:Event_0000205	type	Justice.Sentence
:Event_0000205	mention.actual	"faces"	iraqwar_guardian__1000-01-01__timeline:9945-9949	1.000
:Event_0000205	canonical_mention.actual	"faces"	iraqwar_guardian__1000-01-01__timeline:9945-9949	1.000
:Event_0000205	Justice.Sentence_Defendant.actual	:Entity_EDL_0000266	iraqwar_guardian__1000-01-01__timeline:9941-9943	1.000
:Event_0000206	type	Conflict.Attack
:Event_0000206	mention.actual	"explode"	iraqwar_guardian__1000-01-01__timeline:35148-35154	1.000
:Event_0000206	canonical_mention.actual	"explode"	iraqwar_guardian__1000-01-01__timeline:35148-35154	1.000
:Event_0000206	Conflict.Attack_Attacker.actual	:Entity_EDL_0000397	iraqwar_guardian__1000-01-01__timeline:35137-35146	1.000
:Event_0000206	Conflict.Attack_Instrument.actual	:Entity_EDL_0000532	iraqwar_guardian__1000-01-01__timeline:35172-35176	1.000
:Event_0000206	Conflict.Attack_Place.actual	:Entity_EDL_0000541	iraqwar_guardian__1000-01-01__timeline:35181-35184	1.000
:Event_0000207	type	Movement.TransportArtifact
:Event_0000207	mention.actual	"kidnap"	iraqwar_guardian__1000-01-01__timeline:13421-13426	1.000
:Event_0000207	canonical_mention.actual	"kidnap"	iraqwar_guardian__1000-01-01__timeline:13421-13426	1.000
:Event_0000207	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000615	iraqwar_guardian__1000-01-01__timeline:13389-13391	1.000
:Event_0000207	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000440	iraqwar_guardian__1000-01-01__timeline:13437-13440	1.000
:Event_0000207	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000145	iraqwar_guardian__1000-01-01__timeline:13460-13467	1.000
:Event_0000208	type	Life.Die
:Event_0000208	mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:37973-37977	1.000
:Event_0000208	canonical_mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:37973-37977	1.000
:Event_0000208	Life.Die_Victim.actual	:Entity_EDL_0000022	iraqwar_guardian__1000-01-01__timeline:37991-37996	1.000
:Event_0000209	type	Movement.TransportArtifact
:Event_0000209	mention.actual	"arrive"	iraqwar_guardian__1000-01-01__timeline:4252-4257	1.000
:Event_0000209	canonical_mention.actual	"arrive"	iraqwar_guardian__1000-01-01__timeline:4252-4257	1.000
:Event_0000209	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000366	iraqwar_guardian__1000-01-01__timeline:4231-4240	1.000
:Event_0000209	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000133	iraqwar_guardian__1000-01-01__timeline:4266-4272	1.000
:Event_0000210	type	Conflict.Attack
:Event_0000210	mention.actual	"shootings"	iraqwar_guardian__1000-01-01__timeline:51788-51796	1.000
:Event_0000210	canonical_mention.actual	"shootings"	iraqwar_guardian__1000-01-01__timeline:51788-51796	1.000
:Event_0000211	type	Conflict.Attack
:Event_0000211	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:13995-14001	1.000
:Event_0000211	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:13995-14001	1.000
:Event_0000211	Conflict.Attack_Target.actual	:Entity_EDL_0000713	iraqwar_guardian__1000-01-01__timeline:13940-13945	1.000
:Event_0000211	Conflict.Attack_Target.actual	:Entity_EDL_0000338	iraqwar_guardian__1000-01-01__timeline:13956-13964	1.000
:Event_0000211	Conflict.Attack_Place.actual	:Entity_EDL_0000337	iraqwar_guardian__1000-01-01__timeline:14019-14022	1.000
:Event_0000212	type	Life.Die
:Event_0000212	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:4103-4108	1.000
:Event_0000212	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:4103-4108	1.000
:Event_0000212	Life.Die_Victim.actual	:Entity_EDL_0000024	iraqwar_guardian__1000-01-01__timeline:4096-4097	1.000
:Event_0000212	Life.Die_Place.actual	:Entity_EDL_0000208	iraqwar_guardian__1000-01-01__timeline:4143-4152	1.000
:Event_0000213	type	Conflict.Attack
:Event_0000213	mention.actual	"gunpoint"	iraqwar_guardian__1000-01-01__timeline:49615-49622	1.000
:Event_0000213	canonical_mention.actual	"gunpoint"	iraqwar_guardian__1000-01-01__timeline:49615-49622	1.000
:Event_0000213	Conflict.Attack_Target.actual	:Entity_EDL_0000039	iraqwar_guardian__1000-01-01__timeline:49587-49597	1.000
:Event_0000213	Conflict.Attack_Instrument.actual	:Entity_EDL_0000530	iraqwar_guardian__1000-01-01__timeline:49615-49622	1.000
:Event_0000214	type	Justice.ReleaseParole
:Event_0000214	mention.actual	"release"	iraqwar_guardian__1000-01-01__timeline:53011-53017	1.000
:Event_0000214	canonical_mention.actual	"release"	iraqwar_guardian__1000-01-01__timeline:53011-53017	1.000
:Event_0000214	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000306	iraqwar_guardian__1000-01-01__timeline:53036-53045	1.000
:Event_0000215	type	Conflict.Attack
:Event_0000215	mention.actual	"raid"	iraqwar_guardian__1000-01-01__timeline:41796-41799	1.000
:Event_0000215	canonical_mention.actual	"raid"	iraqwar_guardian__1000-01-01__timeline:41796-41799	1.000
:Event_0000215	Conflict.Attack_Attacker.actual	:Entity_EDL_0000491	iraqwar_guardian__1000-01-01__timeline:41746-41754	1.000
:Event_0000215	Conflict.Attack_Attacker.actual	:Entity_EDL_0000709	iraqwar_guardian__1000-01-01__timeline:41771-41776	1.000
:Event_0000215	Conflict.Attack_Instrument.actual	:Entity_EDL_0000183	iraqwar_guardian__1000-01-01__timeline:41782-41792	1.000
:Event_0000215	Conflict.Attack_Target.actual	:Entity_EDL_0000449	iraqwar_guardian__1000-01-01__timeline:41801-41804	1.000
:Event_0000215	Conflict.Attack_Target.actual	:Entity_EDL_0000294	iraqwar_guardian__1000-01-01__timeline:41845-41848	1.000
:Event_0000215	Conflict.Attack_Place.actual	:Entity_EDL_0000433	iraqwar_guardian__1000-01-01__timeline:41860-41864	1.000
:Event_0000216	type	Life.Injure
:Event_0000216	mention.actual	"injured"	iraqwar_guardian__1000-01-01__timeline:5544-5550	1.000
:Event_0000216	canonical_mention.actual	"injured"	iraqwar_guardian__1000-01-01__timeline:5544-5550	1.000
:Event_0000216	Life.Injure_Victim.actual	:Entity_EDL_0000754	iraqwar_guardian__1000-01-01__timeline:5518-5523	1.000
:Event_0000217	type	Contact.Correspondence
:Event_0000217	mention.actual	"letter"	iraqwar_guardian__1000-01-01__timeline:7745-7750	1.000
:Event_0000217	canonical_mention.actual	"letter"	iraqwar_guardian__1000-01-01__timeline:7745-7750	1.000
:Event_0000217	Contact.Correspondence_Participant.actual	:Entity_EDL_0000483	iraqwar_guardian__1000-01-01__timeline:7777-7793	1.000
:Event_0000217	Contact.Correspondence_Participant.actual	:Entity_EDL_0000108	iraqwar_guardian__1000-01-01__timeline:7817-7836	1.000
:Event_0000218	type	Movement.TransportArtifact
:Event_0000218	mention.actual	"leave"	iraqwar_guardian__1000-01-01__timeline:52965-52969	1.000
:Event_0000218	canonical_mention.actual	"leave"	iraqwar_guardian__1000-01-01__timeline:52965-52969	1.000
:Event_0000218	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000553	iraqwar_guardian__1000-01-01__timeline:52883-52895	1.000
:Event_0000218	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000250	iraqwar_guardian__1000-01-01__timeline:52971-52974	1.000
:Event_0000219	type	Life.Injure
:Event_0000219	mention.actual	"injuring"	iraqwar_guardian__1000-01-01__timeline:44545-44552	1.000
:Event_0000219	canonical_mention.actual	"injuring"	iraqwar_guardian__1000-01-01__timeline:44545-44552	1.000
:Event_0000219	Life.Injure_Agent.actual	:Entity_EDL_0000051	iraqwar_guardian__1000-01-01__timeline:44438-44445	1.000
:Event_0000219	Life.Injure_Victim.actual	:Entity_EDL_0000603	iraqwar_guardian__1000-01-01__timeline:44494-44503	1.000
:Event_0000219	Life.Injure_Victim.actual	:Entity_EDL_0000377	iraqwar_guardian__1000-01-01__timeline:44558-44562	1.000
:Event_0000220	type	Life.Injure
:Event_0000220	mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:24186-24192	1.000
:Event_0000220	canonical_mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:24186-24192	1.000
:Event_0000220	Life.Injure_Victim.actual	:Entity_EDL_0000289	iraqwar_guardian__1000-01-01__timeline:24182-24184	1.000
:Event_0000221	type	Manufacture.Artifact
:Event_0000221	mention.actual	"build"	iraqwar_guardian__1000-01-01__timeline:31646-31650	1.000
:Event_0000221	canonical_mention.actual	"build"	iraqwar_guardian__1000-01-01__timeline:31646-31650	1.000
:Event_0000221	Manufacture.Artifact_Manufacturer.actual	:Entity_EDL_0000273	iraqwar_guardian__1000-01-01__timeline:31634-31641	1.000
:Event_0000221	Manufacture.Artifact_Artifact.actual	:Entity_EDL_0000619	iraqwar_guardian__1000-01-01__timeline:31667-31671	1.000
:Event_0000221	Manufacture.Artifact_Place.actual	:Entity_EDL_0000387	iraqwar_guardian__1000-01-01__timeline:31676-31679	1.000
:Event_0000222	type	Conflict.Attack
:Event_0000222	mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:1407-1413	1.000
:Event_0000222	canonical_mention.actual	"attacks"	iraqwar_guardian__1000-01-01__timeline:1407-1413	1.000
:Event_0000223	type	Contact.Contact
:Event_0000223	mention.actual	"interview"	iraqwar_guardian__1000-01-01__timeline:6561-6569	1.000
:Event_0000223	canonical_mention.actual	"interview"	iraqwar_guardian__1000-01-01__timeline:6561-6569	1.000
:Event_0000223	Contact.Contact_Participant.actual	:Entity_EDL_0000388	iraqwar_guardian__1000-01-01__timeline:6583-6588	1.000
:Event_0000223	Contact.Contact_Place.actual	:Entity_EDL_0000054	iraqwar_guardian__1000-01-01__timeline:6593-6599	1.000
:Event_0000224	type	Life.Die
:Event_0000224	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:49449-49454	1.000
:Event_0000224	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:49449-49454	1.000
:Event_0000224	Life.Die_Victim.actual	:Entity_EDL_0000686	iraqwar_guardian__1000-01-01__timeline:49436-49443	1.000
:Event_0000224	Life.Die_Instrument.actual	:Entity_EDL_0000030	iraqwar_guardian__1000-01-01__timeline:49475-49481	1.000
:Event_0000225	type	Movement.TransportArtifact
:Event_0000225	mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:7917-7926	1.000
:Event_0000225	canonical_mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:7917-7926	1.000
:Event_0000225	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000691	iraqwar_guardian__1000-01-01__timeline:7934-7939	1.000
:Event_0000226	type	Life.Die
:Event_0000226	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:13970-13975	1.000
:Event_0000226	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:13970-13975	1.000
:Event_0000226	Life.Die_Victim.actual	:Entity_EDL_0000713	iraqwar_guardian__1000-01-01__timeline:13940-13945	1.000
:Event_0000226	Life.Die_Victim.actual	:Entity_EDL_0000338	iraqwar_guardian__1000-01-01__timeline:13956-13964	1.000
:Event_0000226	Life.Die_Place.actual	:Entity_EDL_0000337	iraqwar_guardian__1000-01-01__timeline:14019-14022	1.000
:Event_0000227	type	Conflict.Attack
:Event_0000227	mention.actual	"explosions"	iraqwar_guardian__1000-01-01__timeline:30902-30911	1.000
:Event_0000227	canonical_mention.actual	"explosions"	iraqwar_guardian__1000-01-01__timeline:30902-30911	1.000
:Event_0000228	type	Conflict.Attack
:Event_0000228	mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:51587-51591	1.000
:Event_0000228	canonical_mention.actual	"abuse"	iraqwar_guardian__1000-01-01__timeline:51587-51591	1.000
:Event_0000228	Conflict.Attack_Attacker.actual	:Entity_EDL_0000495	iraqwar_guardian__1000-01-01__timeline:51584-51585	1.000
:Event_0000228	Conflict.Attack_Place.actual	:Entity_EDL_0000077	iraqwar_guardian__1000-01-01__timeline:51604-51620	1.000
:Event_0000229	type	Life.Die
:Event_0000229	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:45775-45781	1.000
:Event_0000229	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:45775-45781	1.000
:Event_0000229	Life.Die_Agent.actual	:Entity_EDL_0000651	iraqwar_guardian__1000-01-01__timeline:45648-45654	1.000
:Event_0000229	Life.Die_Agent.actual	:Entity_EDL_0000141	iraqwar_guardian__1000-01-01__timeline:45710-45713	1.000
:Event_0000229	Life.Die_Instrument.actual	:Entity_EDL_0000047	iraqwar_guardian__1000-01-01__timeline:45762-45771	1.000
:Event_0000229	Life.Die_Victim.actual	:Entity_EDL_0000175	iraqwar_guardian__1000-01-01__timeline:45805-45810	1.000
:Event_0000230	type	Personnel.EndPosition
:Event_0000230	mention.actual	"former"	iraqwar_guardian__1000-01-01__timeline:28421-28426	1.000
:Event_0000230	canonical_mention.actual	"former"	iraqwar_guardian__1000-01-01__timeline:28421-28426	1.000
:Event_0000230	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000556	iraqwar_guardian__1000-01-01__timeline:28428-28434	1.000
:Event_0000230	Personnel.EndPosition_Person.actual	:Entity_EDL_0000212	iraqwar_guardian__1000-01-01__timeline:28436-28443	1.000
:Event_0000230	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000284	iraqwar_guardian__1000-01-01__timeline:28486-28495	1.000
:Event_0000231	type	Life.Injure
:Event_0000231	mention.actual	"wound"	iraqwar_guardian__1000-01-01__timeline:38411-38415	1.000
:Event_0000231	canonical_mention.actual	"wound"	iraqwar_guardian__1000-01-01__timeline:38411-38415	1.000
:Event_0000231	Life.Injure_Victim.actual	:Entity_EDL_0000575	iraqwar_guardian__1000-01-01__timeline:38424-38425	1.000
:Event_0000231	Life.Injure_Place.actual	:Entity_EDL_0000205	iraqwar_guardian__1000-01-01__timeline:38447-38453	1.000
:Event_0000232	type	Life.Injure
:Event_0000232	mention.actual	"casualties"	iraqwar_guardian__1000-01-01__timeline:5618-5627	1.000
:Event_0000232	canonical_mention.actual	"casualties"	iraqwar_guardian__1000-01-01__timeline:5618-5627	1.000
:Event_0000233	type	Life.Injure
:Event_0000233	mention.actual	"wounding"	iraqwar_guardian__1000-01-01__timeline:36637-36644	1.000
:Event_0000233	canonical_mention.actual	"wounding"	iraqwar_guardian__1000-01-01__timeline:36637-36644	1.000
:Event_0000233	Life.Injure_Instrument.actual	:Entity_EDL_0000477	iraqwar_guardian__1000-01-01__timeline:36553-36557	1.000
:Event_0000233	Life.Injure_Place.actual	:Entity_EDL_0000281	iraqwar_guardian__1000-01-01__timeline:36586-36591	1.000
:Event_0000233	Life.Injure_Victim.actual	:Entity_EDL_0000148	iraqwar_guardian__1000-01-01__timeline:36656-36661	1.000
:Event_0000234	type	Life.Die
:Event_0000234	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:41156-41161	1.000
:Event_0000234	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:41156-41161	1.000
:Event_0000234	Life.Die_Victim.actual	:Entity_EDL_0000621	iraqwar_guardian__1000-01-01__timeline:41109-41119	1.000
:Event_0000235	type	Personnel.Elect
:Event_0000235	mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:42807-42815	1.000
:Event_0000235	canonical_mention.actual	"elections"	iraqwar_guardian__1000-01-01__timeline:42807-42815	1.000
:Event_0000235	Personnel.Elect_Place.actual	:Entity_EDL_0000544	iraqwar_guardian__1000-01-01__timeline:42799-42805	1.000
:Event_0000236	type	Justice.Execute
:Event_0000236	mention.actual	"execute"	iraqwar_guardian__1000-01-01__timeline:37791-37797	1.000
:Event_0000236	canonical_mention.actual	"execute"	iraqwar_guardian__1000-01-01__timeline:37791-37797	1.000
:Event_0000236	Justice.Execute_Agent.actual	:Entity_EDL_0000605	iraqwar_guardian__1000-01-01__timeline:37746-37749	1.000
:Event_0000236	Justice.Execute_Agent.actual	:Entity_EDL_0000369	iraqwar_guardian__1000-01-01__timeline:37758-37763	1.000
:Event_0000236	Justice.Execute_Person.actual	:Entity_EDL_0000554	iraqwar_guardian__1000-01-01__timeline:37799-37812	1.000
:Event_0000237	type	Movement.TransportArtifact
:Event_0000237	mention.actual	"drives"	iraqwar_guardian__1000-01-01__timeline:36755-36760	1.000
:Event_0000237	canonical_mention.actual	"drives"	iraqwar_guardian__1000-01-01__timeline:36755-36760	1.000
:Event_0000237	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000339	iraqwar_guardian__1000-01-01__timeline:36739-36744	1.000
:Event_0000237	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000646	iraqwar_guardian__1000-01-01__timeline:36751-36753	1.000
:Event_0000238	type	Conflict.Attack
:Event_0000238	mention.actual	"beaten"	iraqwar_guardian__1000-01-01__timeline:3997-4002	1.000
:Event_0000238	canonical_mention.actual	"beaten"	iraqwar_guardian__1000-01-01__timeline:3997-4002	1.000
:Event_0000238	Conflict.Attack_Target.actual	:Entity_EDL_0000682	iraqwar_guardian__1000-01-01__timeline:3981-3989	1.000
:Event_0000239	type	Life.Die
:Event_0000239	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:9055-9061	1.000
:Event_0000239	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:9055-9061	1.000
:Event_0000239	Life.Die_Instrument.actual	:Entity_EDL_0000468	iraqwar_guardian__1000-01-01__timeline:9063-9066	1.000
:Event_0000239	Life.Die_Place.actual	:Entity_EDL_0000260	iraqwar_guardian__1000-01-01__timeline:9090-9094	1.000
:Event_0000239	Life.Die_Victim.actual	:Entity_EDL_0000049	iraqwar_guardian__1000-01-01__timeline:9152-9153	1.000
:Event_0000240	type	Personnel.EndPosition
:Event_0000240	mention.actual	"outgoing"	iraqwar_guardian__1000-01-01__timeline:38549-38556	1.000
:Event_0000240	canonical_mention.actual	"outgoing"	iraqwar_guardian__1000-01-01__timeline:38549-38556	1.000
:Event_0000240	Personnel.EndPosition_Place.actual	:Entity_EDL_0000181	iraqwar_guardian__1000-01-01__timeline:38541-38544	1.000
:Event_0000240	Personnel.EndPosition_Person.actual	:Entity_EDL_0000139	iraqwar_guardian__1000-01-01__timeline:38564-38571	1.000
:Event_0000241	type	Personnel.EndPosition
:Event_0000241	mention.actual	"worked"	iraqwar_guardian__1000-01-01__timeline:26524-26529	1.000
:Event_0000241	canonical_mention.actual	"worked"	iraqwar_guardian__1000-01-01__timeline:26524-26529	1.000
:Event_0000241	Personnel.EndPosition_Person.actual	:Entity_EDL_0000399	iraqwar_guardian__1000-01-01__timeline:26510-26511	1.000
:Event_0000241	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000732	iraqwar_guardian__1000-01-01__timeline:26543-26549	1.000
:Event_0000241	Personnel.EndPosition_Place.actual	:Entity_EDL_0000062	iraqwar_guardian__1000-01-01__timeline:26554-26559	1.000
:Event_0000242	type	Justice.TrialHearing
:Event_0000242	mention.actual	"trial"	iraqwar_guardian__1000-01-01__timeline:23596-23600	1.000
:Event_0000242	canonical_mention.actual	"trial"	iraqwar_guardian__1000-01-01__timeline:23596-23600	1.000
:Event_0000242	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000119	iraqwar_guardian__1000-01-01__timeline:23551-23558	1.000
:Event_0000243	type	Conflict.Attack
:Event_0000243	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:50175-50177	1.000
:Event_0000243	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:50175-50177	1.000
:Event_0000243	Conflict.Attack_Attacker.actual	:Entity_EDL_0000068	iraqwar_guardian__1000-01-01__timeline:50118-50137	1.000
:Event_0000244	type	Life.Die
:Event_0000244	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:30400-30405	1.000
:Event_0000244	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:30400-30405	1.000
:Event_0000244	Life.Die_Victim.actual	:Entity_EDL_0000223	iraqwar_guardian__1000-01-01__timeline:30421-30426	1.000
:Event_0000245	type	Contact.Meet
:Event_0000245	mention.actual	"meets"	iraqwar_guardian__1000-01-01__timeline:11978-11982	1.000
:Event_0000245	canonical_mention.actual	"meets"	iraqwar_guardian__1000-01-01__timeline:11978-11982	1.000
:Event_0000245	Contact.Meet_Participant.actual	:Entity_EDL_0000367	iraqwar_guardian__1000-01-01__timeline:11966-11974	1.000
:Event_0000245	Contact.Meet_Participant.actual	:Entity_EDL_0000255	iraqwar_guardian__1000-01-01__timeline:11998-12005	1.000
:Event_0000245	Contact.Meet_Place.actual	:Entity_EDL_0000394	iraqwar_guardian__1000-01-01__timeline:12030-12035	1.000
:Event_0000246	type	Life.Injure
:Event_0000246	mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:17369-17375	1.000
:Event_0000246	canonical_mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:17369-17375	1.000
:Event_0000246	Life.Injure_Victim.actual	:Entity_EDL_0000344	iraqwar_guardian__1000-01-01__timeline:17383-17392	1.000
:Event_0000247	type	Justice.ReleaseParole
:Event_0000247	mention.actual	"free"	iraqwar_guardian__1000-01-01__timeline:204-207	1.000
:Event_0000247	canonical_mention.actual	"free"	iraqwar_guardian__1000-01-01__timeline:204-207	1.000
:Event_0000247	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000025	iraqwar_guardian__1000-01-01__timeline:168-176	1.000
:Event_0000247	Justice.ReleaseParole_Agent.actual	:Entity_EDL_0000188	iraqwar_guardian__1000-01-01__timeline:182-191	1.000
:Event_0000248	type	Personnel.EndPosition
:Event_0000248	mention.actual	"resign"	iraqwar_guardian__1000-01-01__timeline:37895-37900	1.000
:Event_0000248	canonical_mention.actual	"resign"	iraqwar_guardian__1000-01-01__timeline:37895-37900	1.000
:Event_0000248	Personnel.EndPosition_Person.actual	:Entity_EDL_0000398	iraqwar_guardian__1000-01-01__timeline:37864-37877	1.000
:Event_0000249	type	Life.Die
:Event_0000249	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:47801-47807	1.000
:Event_0000249	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:47801-47807	1.000
:Event_0000250	type	Life.Injure
:Event_0000250	mention.actual	"wounding"	iraqwar_guardian__1000-01-01__timeline:39622-39629	1.000
:Event_0000250	canonical_mention.actual	"wounding"	iraqwar_guardian__1000-01-01__timeline:39622-39629	1.000
:Event_0000250	Life.Injure_Agent.actual	:Entity_EDL_0000041	iraqwar_guardian__1000-01-01__timeline:39555-39564	1.000
:Event_0000250	Life.Injure_Place.actual	:Entity_EDL_0000564	iraqwar_guardian__1000-01-01__timeline:39604-39618	1.000
:Event_0000250	Life.Injure_Victim.actual	:Entity_EDL_0000213	iraqwar_guardian__1000-01-01__timeline:39646-39651	1.000
:Event_0000250	Life.Injure_Victim.actual	:Entity_EDL_0000401	iraqwar_guardian__1000-01-01__timeline:39660-39668	1.000
:Event_0000251	type	Conflict.Attack
:Event_0000251	mention.actual	"clashes"	iraqwar_guardian__1000-01-01__timeline:28173-28179	1.000
:Event_0000251	canonical_mention.actual	"clashes"	iraqwar_guardian__1000-01-01__timeline:28173-28179	1.000
:Event_0000251	Conflict.Attack_Place.actual	:Entity_EDL_0000461	iraqwar_guardian__1000-01-01__timeline:28188-28191	1.000
:Event_0000252	type	Life.Injure
:Event_0000252	mention.actual	"injuring"	iraqwar_guardian__1000-01-01__timeline:1947-1954	1.000
:Event_0000252	canonical_mention.actual	"injuring"	iraqwar_guardian__1000-01-01__timeline:1947-1954	1.000
:Event_0000252	Life.Injure_Agent.actual	:Entity_EDL_0000356	iraqwar_guardian__1000-01-01__timeline:1864-1870	1.000
:Event_0000252	Life.Injure_Place.actual	:Entity_EDL_0000111	iraqwar_guardian__1000-01-01__timeline:1937-1943	1.000
:Event_0000252	Life.Injure_Victim.actual	:Entity_EDL_0000100	iraqwar_guardian__1000-01-01__timeline:1959-1962	1.000
:Event_0000253	type	Justice.Sentence
:Event_0000253	mention.actual	"sentenced"	iraqwar_guardian__1000-01-01__timeline:52387-52395	1.000
:Event_0000253	canonical_mention.actual	"sentenced"	iraqwar_guardian__1000-01-01__timeline:52387-52395	1.000
:Event_0000253	Justice.Sentence_Defendant.actual	:Entity_EDL_0000616	iraqwar_guardian__1000-01-01__timeline:52323-52331	1.000
:Event_0000254	type	Movement.TransportPerson
:Event_0000254	mention.actual	"Return"	iraqwar_guardian__1000-01-01__timeline:17221-17226	1.000
:Event_0000254	canonical_mention.actual	"Return"	iraqwar_guardian__1000-01-01__timeline:17221-17226	1.000
:Event_0000254	Movement.TransportPerson_Person.actual	:Entity_EDL_0000657	iraqwar_guardian__1000-01-01__timeline:17251-17257	1.000
:Event_0000255	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000255	mention.actual	"crimes"	iraqwar_guardian__1000-01-01__timeline:37840-37845	1.000
:Event_0000255	canonical_mention.actual	"crimes"	iraqwar_guardian__1000-01-01__timeline:37840-37845	1.000
:Event_0000255	GenericCrime.GenericCrime.GenericCrime_Perpetrator.actual	:Entity_EDL_0000598	iraqwar_guardian__1000-01-01__timeline:37817-37818	1.000
:Event_0000256	type	Movement.TransportPerson
:Event_0000256	mention.actual	"pilgrimage"	iraqwar_guardian__1000-01-01__timeline:3084-3093	1.000
:Event_0000256	canonical_mention.actual	"pilgrimage"	iraqwar_guardian__1000-01-01__timeline:3084-3093	1.000
:Event_0000256	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000666	iraqwar_guardian__1000-01-01__timeline:3067-3070	1.000
:Event_0000256	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000611	iraqwar_guardian__1000-01-01__timeline:3108-3112	1.000
:Event_0000257	type	Life.Die
:Event_0000257	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:37568-37573	1.000
:Event_0000257	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:37568-37573	1.000
:Event_0000257	Life.Die_Victim.actual	:Entity_EDL_0000079	iraqwar_guardian__1000-01-01__timeline:37552-37557	1.000
:Event_0000258	type	Contact.Meet
:Event_0000258	mention.actual	"converge"	iraqwar_guardian__1000-01-01__timeline:16052-16059	1.000
:Event_0000258	canonical_mention.actual	"converge"	iraqwar_guardian__1000-01-01__timeline:16052-16059	1.000
:Event_0000258	Contact.Meet_Participant.actual	:Entity_EDL_0000078	iraqwar_guardian__1000-01-01__timeline:16014-16034	1.000
:Event_0000259	type	Life.Die
:Event_0000259	mention.actual	"died"	iraqwar_guardian__1000-01-01__timeline:53911-53914	1.000
:Event_0000259	canonical_mention.actual	"died"	iraqwar_guardian__1000-01-01__timeline:53911-53914	1.000
:Event_0000259	Life.Die_Victim.actual	:Entity_EDL_0000063	iraqwar_guardian__1000-01-01__timeline:53904-53909	1.000
:Event_0000259	Life.Die_Place.actual	:Entity_EDL_0000206	iraqwar_guardian__1000-01-01__timeline:53938-53944	1.000
:Event_0000260	type	Conflict.Attack
:Event_0000260	mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:21846-21853	1.000
:Event_0000260	canonical_mention.actual	"bombings"	iraqwar_guardian__1000-01-01__timeline:21846-21853	1.000
:Event_0000260	Conflict.Attack_Place.actual	:Entity_EDL_0000360	iraqwar_guardian__1000-01-01__timeline:21839-21844	1.000
:Event_0000261	type	Movement.TransportPerson
:Event_0000261	mention.actual	"walking into"	iraqwar_guardian__1000-01-01__timeline:1906-1917	1.000
:Event_0000261	canonical_mention.actual	"walking into"	iraqwar_guardian__1000-01-01__timeline:1906-1917	1.000
:Event_0000261	Movement.TransportPerson_Agent.actual	:Entity_EDL_0000356	iraqwar_guardian__1000-01-01__timeline:1864-1870	1.000
:Event_0000261	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000111	iraqwar_guardian__1000-01-01__timeline:1937-1943	1.000
:Event_0000262	type	Conflict.Attack
:Event_0000262	mention.actual	"bombed"	iraqwar_guardian__1000-01-01__timeline:48984-48989	1.000
:Event_0000262	canonical_mention.actual	"bombed"	iraqwar_guardian__1000-01-01__timeline:48984-48989	1.000
:Event_0000262	Conflict.Attack_Attacker.actual	:Entity_EDL_0000286	iraqwar_guardian__1000-01-01__timeline:48893-48902	1.000
:Event_0000262	Conflict.Attack_Target.actual	:Entity_EDL_0000329	iraqwar_guardian__1000-01-01__timeline:48940-48945	1.000
:Event_0000262	Conflict.Attack_Target.actual	:Entity_EDL_0000270	iraqwar_guardian__1000-01-01__timeline:48971-48978	1.000
:Event_0000263	type	Movement.TransportArtifact
:Event_0000263	mention.actual	"returns"	iraqwar_guardian__1000-01-01__timeline:17087-17093	1.000
:Event_0000263	canonical_mention.actual	"returns"	iraqwar_guardian__1000-01-01__timeline:17087-17093	1.000
:Event_0000263	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000437	iraqwar_guardian__1000-01-01__timeline:17112-17118	1.000
:Event_0000263	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000184	iraqwar_guardian__1000-01-01__timeline:17132-17135	1.000
:Event_0000264	type	Conflict.Attack
:Event_0000264	mention.actual	"assassinate"	iraqwar_guardian__1000-01-01__timeline:29895-29905	1.000
:Event_0000264	canonical_mention.actual	"assassinate"	iraqwar_guardian__1000-01-01__timeline:29895-29905	1.000
:Event_0000264	Conflict.Attack_Attacker.actual	:Entity_EDL_0000362	iraqwar_guardian__1000-01-01__timeline:29836-29843	1.000
:Event_0000264	Conflict.Attack_Target.actual	:Entity_EDL_0000101	iraqwar_guardian__1000-01-01__timeline:29907-29915	1.000
:Event_0000265	type	Life.Die
:Event_0000265	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:44568-44574	1.000
:Event_0000265	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:44568-44574	1.000
:Event_0000265	Life.Die_Agent.actual	:Entity_EDL_0000051	iraqwar_guardian__1000-01-01__timeline:44438-44445	1.000
:Event_0000265	Life.Die_Victim.actual	:Entity_EDL_0000377	iraqwar_guardian__1000-01-01__timeline:44558-44562	1.000
:Event_0000265	Life.Die_Victim.actual	:Entity_EDL_0000048	iraqwar_guardian__1000-01-01__timeline:44602-44606	1.000
:Event_0000266	type	Movement.TransportArtifact
:Event_0000266	mention.actual	"flee"	iraqwar_guardian__1000-01-01__timeline:14876-14879	1.000
:Event_0000266	canonical_mention.actual	"flee"	iraqwar_guardian__1000-01-01__timeline:14876-14879	1.000
:Event_0000266	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000363	iraqwar_guardian__1000-01-01__timeline:14795-14800	1.000
:Event_0000266	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000290	iraqwar_guardian__1000-01-01__timeline:14832-14841	1.000
:Event_0000266	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000467	iraqwar_guardian__1000-01-01__timeline:14866-14874	1.000
:Event_0000267	type	Conflict.Attack
:Event_0000267	mention.actual	"fire"	iraqwar_guardian__1000-01-01__timeline:34969-34972	1.000
:Event_0000267	canonical_mention.actual	"fire"	iraqwar_guardian__1000-01-01__timeline:34969-34972	1.000
:Event_0000267	Conflict.Attack_Target.actual	:Entity_EDL_0000548	iraqwar_guardian__1000-01-01__timeline:34923-34930	1.000
:Event_0000268	type	Life.Die
:Event_0000268	mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:4356-4362	1.000
:Event_0000268	canonical_mention.actual	"suicide"	iraqwar_guardian__1000-01-01__timeline:4356-4362	1.000
:Event_0000268	Life.Die_Victim.actual	:Entity_EDL_0000567	iraqwar_guardian__1000-01-01__timeline:4340-4341	1.000
:Event_0000268	Life.Die_Place.actual	:Entity_EDL_0000150	iraqwar_guardian__1000-01-01__timeline:4351-4354	1.000
:Event_0000269	type	Conflict.Demonstrate
:Event_0000269	mention.actual	"uprisings"	iraqwar_guardian__1000-01-01__timeline:30628-30636	1.000
:Event_0000269	canonical_mention.actual	"uprisings"	iraqwar_guardian__1000-01-01__timeline:30628-30636	1.000
:Event_0000270	type	Conflict.Attack
:Event_0000270	mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:18120-18122	1.000
:Event_0000270	canonical_mention.actual	"war"	iraqwar_guardian__1000-01-01__timeline:18120-18122	1.000
:Event_0000271	type	Conflict.Demonstrate
:Event_0000271	mention.actual	"take"	iraqwar_guardian__1000-01-01__timeline:16316-16319	1.000
:Event_0000271	canonical_mention.actual	"take"	iraqwar_guardian__1000-01-01__timeline:16316-16319	1.000
:Event_0000271	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000613	iraqwar_guardian__1000-01-01__timeline:16291-16299	1.000
:Event_0000271	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000097	iraqwar_guardian__1000-01-01__timeline:16328-16334	1.000
:Event_0000272	type	Life.Die
:Event_0000272	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:33532-33537	1.000
:Event_0000272	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:33532-33537	1.000
:Event_0000272	Life.Die_Victim.actual	:Entity_EDL_0000271	iraqwar_guardian__1000-01-01__timeline:33515-33520	1.000
:Event_0000272	Life.Die_Place.actual	:Entity_EDL_0000741	iraqwar_guardian__1000-01-01__timeline:33542-33545	1.000
:Event_0000273	type	Justice.ChargeIndict
:Event_0000273	mention.actual	"indictment"	iraqwar_guardian__1000-01-01__timeline:32510-32519	1.000
:Event_0000273	canonical_mention.actual	"indictment"	iraqwar_guardian__1000-01-01__timeline:32510-32519	1.000
:Event_0000274	type	Life.Die
:Event_0000274	mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:50694-50698	1.000
:Event_0000274	canonical_mention.actual	"kills"	iraqwar_guardian__1000-01-01__timeline:50694-50698	1.000
:Event_0000274	Life.Die_Instrument.actual	:Entity_EDL_0000480	iraqwar_guardian__1000-01-01__timeline:50654-50657	1.000
:Event_0000274	Life.Die_Place.actual	:Entity_EDL_0000425	iraqwar_guardian__1000-01-01__timeline:50676-50681	1.000
:Event_0000274	Life.Die_Victim.actual	:Entity_EDL_0000146	iraqwar_guardian__1000-01-01__timeline:50712-50717	1.000
:Event_0000275	type	Justice.ArrestJail
:Event_0000275	mention.actual	"imprisonment"	iraqwar_guardian__1000-01-01__timeline:52411-52422	1.000
:Event_0000275	canonical_mention.actual	"imprisonment"	iraqwar_guardian__1000-01-01__timeline:52411-52422	1.000
:Event_0000275	Justice.ArrestJail_Person.actual	:Entity_EDL_0000616	iraqwar_guardian__1000-01-01__timeline:52323-52331	1.000
:Event_0000276	type	Justice.ChargeIndict
:Event_0000276	mention.actual	"charges"	iraqwar_guardian__1000-01-01__timeline:47222-47228	1.000
:Event_0000276	canonical_mention.actual	"charges"	iraqwar_guardian__1000-01-01__timeline:47222-47228	1.000
:Event_0000277	type	Movement.TransportArtifact
:Event_0000277	mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:2784-2793	1.000
:Event_0000277	canonical_mention.actual	"withdrawal"	iraqwar_guardian__1000-01-01__timeline:2784-2793	1.000
:Event_0000277	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000403	iraqwar_guardian__1000-01-01__timeline:2778-2782	1.000
:Event_0000278	type	Justice.Execute
:Event_0000278	mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:37926-37930	1.000
:Event_0000278	canonical_mention.actual	"death"	iraqwar_guardian__1000-01-01__timeline:37926-37930	1.000
:Event_0000279	type	Conflict.Attack
:Event_0000279	mention.actual	"pelted"	iraqwar_guardian__1000-01-01__timeline:13137-13142	1.000
:Event_0000279	canonical_mention.actual	"pelted"	iraqwar_guardian__1000-01-01__timeline:13137-13142	1.000
:Event_0000279	Conflict.Attack_Target.actual	:Entity_EDL_0000715	iraqwar_guardian__1000-01-01__timeline:13126-13132	1.000
:Event_0000279	Conflict.Attack_Instrument.actual	:Entity_EDL_0000138	iraqwar_guardian__1000-01-01__timeline:13156-13160	1.000
:Event_0000279	Conflict.Attack_Instrument.actual	:Entity_EDL_0000220	iraqwar_guardian__1000-01-01__timeline:13166-13171	1.000
:Event_0000280	type	Movement.TransportArtifact
:Event_0000280	mention.actual	"enter"	iraqwar_guardian__1000-01-01__timeline:15003-15007	1.000
:Event_0000280	canonical_mention.actual	"enter"	iraqwar_guardian__1000-01-01__timeline:15003-15007	1.000
:Event_0000280	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000276	iraqwar_guardian__1000-01-01__timeline:14927-14934	1.000
:Event_0000280	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000027	iraqwar_guardian__1000-01-01__timeline:14946-14953	1.000
:Event_0000280	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000214	iraqwar_guardian__1000-01-01__timeline:14998-15001	1.000
:Event_0000280	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000316	iraqwar_guardian__1000-01-01__timeline:15009-15016	1.000
:Event_0000281	type	Life.Die
:Event_0000281	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:18580-18585	1.000
:Event_0000281	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:18580-18585	1.000
:Event_0000281	Life.Die_Victim.actual	:Entity_EDL_0000688	iraqwar_guardian__1000-01-01__timeline:18571-18578	1.000
:Event_0000281	Life.Die_Place.actual	:Entity_EDL_0000501	iraqwar_guardian__1000-01-01__timeline:18590-18593	1.000
:Event_0000282	type	Life.Die
:Event_0000282	mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:6803-6809	1.000
:Event_0000282	canonical_mention.actual	"killing"	iraqwar_guardian__1000-01-01__timeline:6803-6809	1.000
:Event_0000282	Life.Die_Agent.actual	:Entity_EDL_0000466	iraqwar_guardian__1000-01-01__timeline:6731-6744	1.000
:Event_0000282	Life.Die_Victim.actual	:Entity_EDL_0000574	iraqwar_guardian__1000-01-01__timeline:6818-6820	1.000
:Event_0000282	Life.Die_Victim.actual	:Entity_EDL_0000069	iraqwar_guardian__1000-01-01__timeline:6826-6829	1.000
:Event_0000283	type	Life.Die
:Event_0000283	mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:9342-9345	1.000
:Event_0000283	canonical_mention.actual	"kill"	iraqwar_guardian__1000-01-01__timeline:9342-9345	1.000
:Event_0000283	Life.Die_Agent.actual	:Entity_EDL_0000517	iraqwar_guardian__1000-01-01__timeline:9334-9340	1.000
:Event_0000283	Life.Die_Victim.actual	:Entity_EDL_0000222	iraqwar_guardian__1000-01-01__timeline:9347-9348	1.000
:Event_0000284	type	Justice.TrialHearing
:Event_0000284	mention.actual	"court martial"	iraqwar_guardian__1000-01-01__timeline:32240-32252	1.000
:Event_0000284	canonical_mention.actual	"court martial"	iraqwar_guardian__1000-01-01__timeline:32240-32252	1.000
:Event_0000285	type	Conflict.Attack
:Event_0000285	mention.actual	"blasts"	iraqwar_guardian__1000-01-01__timeline:13069-13074	1.000
:Event_0000285	canonical_mention.actual	"blasts"	iraqwar_guardian__1000-01-01__timeline:13069-13074	1.000
:Event_0000285	Conflict.Attack_Attacker.actual	:Entity_EDL_0000238	iraqwar_guardian__1000-01-01__timeline:13059-13062	1.000
:Event_0000285	Conflict.Attack_Instrument.actual	:Entity_EDL_0000156	iraqwar_guardian__1000-01-01__timeline:13064-13067	1.000
:Event_0000285	Conflict.Attack_Target.actual	:Entity_EDL_0000648	iraqwar_guardian__1000-01-01__timeline:13088-13092	1.000
:Event_0000286	type	Conflict.Attack
:Event_0000286	mention.actual	"strikes"	iraqwar_guardian__1000-01-01__timeline:7120-7126	1.000
:Event_0000286	canonical_mention.actual	"strikes"	iraqwar_guardian__1000-01-01__timeline:7120-7126	1.000
:Event_0000286	Conflict.Attack_Target.actual	:Entity_EDL_0000135	iraqwar_guardian__1000-01-01__timeline:7089-7098	1.000
:Event_0000286	Conflict.Attack_Instrument.actual	:Entity_EDL_0000234	iraqwar_guardian__1000-01-01__timeline:7131-7140	1.000
:Event_0000286	Conflict.Attack_Instrument.actual	:Entity_EDL_0000566	iraqwar_guardian__1000-01-01__timeline:7146-7156	1.000
:Event_0000286	Conflict.Attack_Place.actual	:Entity_EDL_0000392	iraqwar_guardian__1000-01-01__timeline:7161-7168	1.000
:Event_0000287	type	Transaction.TransferOwnership
:Event_0000287	mention.actual	"hand over"	iraqwar_guardian__1000-01-01__timeline:44346-44354	1.000
:Event_0000287	canonical_mention.actual	"hand over"	iraqwar_guardian__1000-01-01__timeline:44346-44354	1.000
:Event_0000287	Transaction.TransferOwnership_Giver.actual	:Entity_EDL_0000717	iraqwar_guardian__1000-01-01__timeline:44340-44341	1.000
:Event_0000287	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000622	iraqwar_guardian__1000-01-01__timeline:44356-44365	1.000
:Event_0000287	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000124	iraqwar_guardian__1000-01-01__timeline:44367-44372	1.000
:Event_0000287	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000033	iraqwar_guardian__1000-01-01__timeline:44377-44382	1.000
:Event_0000288	type	Life.Die
:Event_0000288	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:5534-5539	1.000
:Event_0000288	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:5534-5539	1.000
:Event_0000288	Life.Die_Victim.actual	:Entity_EDL_0000754	iraqwar_guardian__1000-01-01__timeline:5518-5523	1.000
:Event_0000289	type	Life.Injure
:Event_0000289	mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:25292-25298	1.000
:Event_0000289	canonical_mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:25292-25298	1.000
:Event_0000289	Life.Injure_Victim.actual	:Entity_EDL_0000597	iraqwar_guardian__1000-01-01__timeline:25289-25290	1.000
:Event_0000289	Life.Injure_Instrument.actual	:Entity_EDL_0000420	iraqwar_guardian__1000-01-01__timeline:25309-25311	1.000
:Event_0000289	Life.Injure_Victim.actual	:Entity_EDL_0000454	iraqwar_guardian__1000-01-01__timeline:25359-25366	1.000
:Event_0000289	Life.Injure_Place.actual	:Entity_EDL_0000737	iraqwar_guardian__1000-01-01__timeline:25411-25414	1.000
:Event_0000290	type	Life.Die
:Event_0000290	mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:14712-14717	1.000
:Event_0000290	canonical_mention.actual	"killed"	iraqwar_guardian__1000-01-01__timeline:14712-14717	1.000
:Event_0000290	Life.Die_Victim.actual	:Entity_EDL_0000350	iraqwar_guardian__1000-01-01__timeline:14705-14710	1.000
:Event_0000290	Life.Die_Place.actual	:Entity_EDL_0000663	iraqwar_guardian__1000-01-01__timeline:14722-14728	1.000
:Event_0000291	type	Life.Injure
:Event_0000291	mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:33724-33730	1.000
:Event_0000291	canonical_mention.actual	"wounded"	iraqwar_guardian__1000-01-01__timeline:33724-33730	1.000
:Event_0000291	Life.Injure_Victim.actual	:Entity_EDL_0000526	iraqwar_guardian__1000-01-01__timeline:33699-33704	1.000
:Event_0000291	Life.Injure_Victim.actual	:Entity_EDL_0000451	iraqwar_guardian__1000-01-01__timeline:33721-33722	1.000
:Event_0000291	Life.Injure_Agent.actual	:Entity_EDL_0000602	iraqwar_guardian__1000-01-01__timeline:33747-33754	1.000
:Event_0000291	Life.Injure_Instrument.actual	:Entity_EDL_0000343	iraqwar_guardian__1000-01-01__timeline:33771-33774	1.000
:Event_0000291	Life.Injure_Place.actual	:Entity_EDL_0000680	iraqwar_guardian__1000-01-01__timeline:33793-33798	1.000
:Event_0000291	Life.Injure_Place.actual	:Entity_EDL_0000008	iraqwar_guardian__1000-01-01__timeline:33824-33827	1.000
:Event_0000292	type	Conflict.Attack
:Event_0000292	mention.actual	"ambush"	iraqwar_guardian__1000-01-01__timeline:49195-49200	1.000
:Event_0000292	canonical_mention.actual	"ambush"	iraqwar_guardian__1000-01-01__timeline:49195-49200	1.000
:Event_0000292	Conflict.Attack_Attacker.actual	:Entity_EDL_0000193	iraqwar_guardian__1000-01-01__timeline:49126-49135	1.000
:Event_0000292	Conflict.Attack_Target.actual	:Entity_EDL_0000746	iraqwar_guardian__1000-01-01__timeline:49157-49175	1.000
:Event_0000292	Conflict.Attack_Target.actual	:Entity_EDL_0000687	iraqwar_guardian__1000-01-01__timeline:49185-49187	1.000
:Event_0000292	Conflict.Attack_Place.actual	:Entity_EDL_0000521	iraqwar_guardian__1000-01-01__timeline:49213-49219	1.000
:Event_0000293	type	Conflict.Attack
:Event_0000293	mention.actual	"shot"	iraqwar_guardian__1000-01-01__timeline:50589-50592	1.000
:Event_0000293	canonical_mention.actual	"shot"	iraqwar_guardian__1000-01-01__timeline:50589-50592	1.000
:Event_0000293	Conflict.Attack_Target.actual	:Entity_EDL_0000706	iraqwar_guardian__1000-01-01__timeline:50576-50583	1.000
