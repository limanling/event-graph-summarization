:Entity_EDL_0000000	type	Organization
:Entity_EDL_0000000	nominal_mention	"army"	syriancrisis_bbc__1000-01-01__timeline:1171-1174	1.0
:Entity_EDL_0000000	link	NIL000000001
:Entity_EDL_0000001	type	Person
:Entity_EDL_0000001	canonical_mention	"children"	syriancrisis_bbc__1000-01-01__timeline:2673-2680	1.0
:Entity_EDL_0000001	nominal_mention	"children"	syriancrisis_bbc__1000-01-01__timeline:2673-2680	1.0
:Entity_EDL_0000001	link	NIL000000002
:Entity_EDL_0000002	type	Person
:Entity_EDL_0000002	canonical_mention	"Hassan Turkomani"	syriancrisis_bbc__1000-01-01__timeline:4006-4021	1.0
:Entity_EDL_0000002	mention	"Hassan Turkomani"	syriancrisis_bbc__1000-01-01__timeline:4006-4021	1.0
:Entity_EDL_0000002	link	NIL000000003
:Entity_EDL_0000003	type	Weapon
:Entity_EDL_0000003	nominal_mention	"machine-guns"	syriancrisis_bbc__1000-01-01__timeline:800-811	0.000
:Entity_EDL_0000003	link	NIL000000004
:Entity_EDL_0000004	type	GeopoliticalEntity
:Entity_EDL_0000004	nominal_mention	"village"	syriancrisis_bbc__1000-01-01__timeline:2484-2490	1.0
:Entity_EDL_0000004	link	NIL000000005
:Entity_EDL_0000005	type	GeopoliticalEntity
:Entity_EDL_0000005	canonical_mention	"village"	syriancrisis_bbc__1000-01-01__timeline:3404-3410	1.0
:Entity_EDL_0000005	nominal_mention	"village"	syriancrisis_bbc__1000-01-01__timeline:3404-3410	1.0
:Entity_EDL_0000005	link	NIL000000006
:Entity_EDL_0000006	type	Person
:Entity_EDL_0000006	canonical_mention	"protesters"	syriancrisis_bbc__1000-01-01__timeline:109-118	1.0
:Entity_EDL_0000006	nominal_mention	"protesters"	syriancrisis_bbc__1000-01-01__timeline:109-118	1.0
:Entity_EDL_0000006	link	NIL000000007
:Entity_EDL_0000007	type	Person
:Entity_EDL_0000007	canonical_mention	"soldiers"	syriancrisis_bbc__1000-01-01__timeline:773-780	1.0
:Entity_EDL_0000007	nominal_mention	"soldiers"	syriancrisis_bbc__1000-01-01__timeline:773-780	1.0
:Entity_EDL_0000007	link	NIL000000008
:Entity_EDL_0000008	type	Person
:Entity_EDL_0000008	canonical_mention	"hundreds"	syriancrisis_bbc__1000-01-01__timeline:834-841	1.0
:Entity_EDL_0000008	pronominal_mention	"hundreds"	syriancrisis_bbc__1000-01-01__timeline:834-841	1.0
:Entity_EDL_0000008	link	NIL000000009
:Entity_EDL_0000009	type	GeopoliticalEntity
:Entity_EDL_0000009	canonical_mention	"Syrian"	syriancrisis_bbc__1000-01-01__timeline:15-20	1.0
:Entity_EDL_0000009	mention	"Syrian"	syriancrisis_bbc__1000-01-01__timeline:15-20	1.0
:Entity_EDL_0000009	link	163843
:Entity_EDL_0000010	type	GeopoliticalEntity
:Entity_EDL_0000010	canonical_mention	"Villages"	syriancrisis_bbc__1000-01-01__timeline:630-637	1.0
:Entity_EDL_0000010	nominal_mention	"Villages"	syriancrisis_bbc__1000-01-01__timeline:630-637	1.0
:Entity_EDL_0000010	link	NIL000000010
:Entity_EDL_0000011	type	Person
:Entity_EDL_0000011	canonical_mention	"Bashar al-Assad"	syriancrisis_bbc__1000-01-01__timeline:400-414	1.0
:Entity_EDL_0000011	mention	"Bashar al-Assad"	syriancrisis_bbc__1000-01-01__timeline:400-414	1.0
:Entity_EDL_0000011	link	30004507
:Entity_EDL_0000012	type	GeopoliticalEntity
:Entity_EDL_0000012	nominal_mention	"villages"	syriancrisis_bbc__1000-01-01__timeline:876-883	1.0
:Entity_EDL_0000012	link	NIL000000011
:Entity_EDL_0000013	type	Person
:Entity_EDL_0000013	nominal_mention	"militiamen"	syriancrisis_bbc__1000-01-01__timeline:3452-3461	1.0
:Entity_EDL_0000013	link	NIL000000012
:Entity_EDL_0000014	type	Organization
:Entity_EDL_0000014	nominal_mention	"group"	syriancrisis_bbc__1000-01-01__timeline:4325-4329	1.0
:Entity_EDL_0000014	link	NIL000000013
:Entity_EDL_0000015	type	Vehicle
:Entity_EDL_0000015	canonical_mention	"tanks"	syriancrisis_bbc__1000-01-01__timeline:3384-3388	1.0
:Entity_EDL_0000015	nominal_mention	"tanks"	syriancrisis_bbc__1000-01-01__timeline:3384-3388	1.0
:Entity_EDL_0000015	link	NIL000000014
:Entity_EDL_0000016	type	GeopoliticalEntity
:Entity_EDL_0000016	mention	"Tremseh"	syriancrisis_bbc__1000-01-01__timeline:3678-3684	1.0
:Entity_EDL_0000016	link	9847679
:Entity_EDL_0000017	type	Person
:Entity_EDL_0000017	nominal_mention	"general"	syriancrisis_bbc__1000-01-01__timeline:3002-3008	1.0
:Entity_EDL_0000017	link	NIL000000015
:Entity_EDL_0000018	type	Organization
:Entity_EDL_0000018	nominal_mention	"groups"	syriancrisis_bbc__1000-01-01__timeline:2326-2331	1.0
:Entity_EDL_0000018	link	NIL000000016
:Entity_EDL_0000019	type	Person
:Entity_EDL_0000019	nominal_mention	"forces"	syriancrisis_bbc__1000-01-01__timeline:144-149	0.000
:Entity_EDL_0000019	link	NIL000000017
:Entity_EDL_0000020	type	Person
:Entity_EDL_0000020	nominal_mention	"fighters"	syriancrisis_bbc__1000-01-01__timeline:3605-3612	0.000
:Entity_EDL_0000020	link	NIL000000018
:Entity_EDL_0000021	type	Person
:Entity_EDL_0000021	canonical_mention	"crowds"	syriancrisis_bbc__1000-01-01__timeline:161-166	1.0
:Entity_EDL_0000021	nominal_mention	"crowds"	syriancrisis_bbc__1000-01-01__timeline:161-166	1.0
:Entity_EDL_0000021	link	NIL000000019
:Entity_EDL_0000022	type	Organization
:Entity_EDL_0000022	canonical_mention	"Syrian National Council"	syriancrisis_bbc__1000-01-01__timeline:342-364	1.0
:Entity_EDL_0000022	mention	"Syrian National Council"	syriancrisis_bbc__1000-01-01__timeline:342-364	1.0
:Entity_EDL_0000022	link	NIL000000020
:Entity_EDL_0000023	type	Person
:Entity_EDL_0000023	canonical_mention	"forces"	syriancrisis_bbc__1000-01-01__timeline:1285-1290	1.0
:Entity_EDL_0000023	nominal_mention	"forces"	syriancrisis_bbc__1000-01-01__timeline:1285-1290	1.0
:Entity_EDL_0000023	link	NIL000000021
:Entity_EDL_0000024	type	Person
:Entity_EDL_0000024	canonical_mention	"Daoud Rajiha"	syriancrisis_bbc__1000-01-01__timeline:3795-3806	1.0
:Entity_EDL_0000024	mention	"Daoud Rajiha"	syriancrisis_bbc__1000-01-01__timeline:3795-3806	1.0
:Entity_EDL_0000024	link	NIL000000022
:Entity_EDL_0000025	type	Person
:Entity_EDL_0000025	canonical_mention	"defectors"	syriancrisis_bbc__1000-01-01__timeline:724-732	1.0
:Entity_EDL_0000025	nominal_mention	"defectors"	syriancrisis_bbc__1000-01-01__timeline:724-732	1.0
:Entity_EDL_0000025	link	NIL000000023
:Entity_EDL_0000026	type	Person
:Entity_EDL_0000026	canonical_mention	"people"	syriancrisis_bbc__1000-01-01__timeline:1109-1114	1.0
:Entity_EDL_0000026	nominal_mention	"people"	syriancrisis_bbc__1000-01-01__timeline:1109-1114	1.0
:Entity_EDL_0000026	link	NIL000000024
:Entity_EDL_0000027	type	Person
:Entity_EDL_0000027	nominal_mention	"people"	syriancrisis_bbc__1000-01-01__timeline:3289-3294	1.0
:Entity_EDL_0000027	link	NIL000000025
:Entity_EDL_0000028	type	Person
:Entity_EDL_0000028	nominal_mention	"deputy"	syriancrisis_bbc__1000-01-01__timeline:3816-3821	1.0
:Entity_EDL_0000028	link	NIL000000026
:Entity_EDL_0000029	type	Facility
:Entity_EDL_0000029	canonical_mention	"headquarters"	syriancrisis_bbc__1000-01-01__timeline:3959-3970	1.0
:Entity_EDL_0000029	nominal_mention	"headquarters"	syriancrisis_bbc__1000-01-01__timeline:3959-3970	1.0
:Entity_EDL_0000029	link	NIL000000027
:Entity_EDL_0000030	type	Person
:Entity_EDL_0000030	canonical_mention	"victims"	syriancrisis_bbc__1000-01-01__timeline:3496-3502	1.0
:Entity_EDL_0000030	nominal_mention	"victims"	syriancrisis_bbc__1000-01-01__timeline:3496-3502	1.0
:Entity_EDL_0000030	link	NIL000000028
:Entity_EDL_0000031	type	Person
:Entity_EDL_0000031	nominal_mention	"people"	syriancrisis_bbc__1000-01-01__timeline:2140-2145	1.0
:Entity_EDL_0000031	link	NIL000000029
:Entity_EDL_0000032	type	Person
:Entity_EDL_0000032	nominal_mention	"people"	syriancrisis_bbc__1000-01-01__timeline:3656-3661	1.0
:Entity_EDL_0000032	link	NIL000000030
:Entity_EDL_0000033	type	Person
:Entity_EDL_0000033	pronominal_mention	"Some"	syriancrisis_bbc__1000-01-01__timeline:2685-2688	1.0
:Entity_EDL_0000033	link	NIL000000031
:Entity_EDL_0000034	type	Person
:Entity_EDL_0000034	canonical_mention	"chief"	syriancrisis_bbc__1000-01-01__timeline:4138-4142	1.0
:Entity_EDL_0000034	nominal_mention	"chief"	syriancrisis_bbc__1000-01-01__timeline:4138-4142	1.0
:Entity_EDL_0000034	link	NIL000000032
:Entity_EDL_0000035	type	Person
:Entity_EDL_0000035	nominal_mention	"people"	syriancrisis_bbc__1000-01-01__timeline:3556-3561	1.0
:Entity_EDL_0000035	link	NIL000000033
:Entity_EDL_0000036	type	GeopoliticalEntity
:Entity_EDL_0000036	canonical_mention	"Tremseh"	syriancrisis_bbc__1000-01-01__timeline:3299-3305	1.0
:Entity_EDL_0000036	mention	"Tremseh"	syriancrisis_bbc__1000-01-01__timeline:3299-3305	1.0
:Entity_EDL_0000036	link	9847679
:Entity_EDL_0000037	type	GeopoliticalEntity
:Entity_EDL_0000037	canonical_mention	"capital"	syriancrisis_bbc__1000-01-01__timeline:2118-2124	1.0
:Entity_EDL_0000037	nominal_mention	"capital"	syriancrisis_bbc__1000-01-01__timeline:2118-2124	1.0
:Entity_EDL_0000037	link	NIL000000034
:Entity_EDL_0000038	type	GeopoliticalEntity
:Entity_EDL_0000038	mention	"Syria"	syriancrisis_bbc__1000-01-01__timeline:2576-2580	1.0
:Entity_EDL_0000038	link	163843
:Entity_EDL_0000039	type	GeopoliticalEntity
:Entity_EDL_0000039	nominal_mention	"city"	syriancrisis_bbc__1000-01-01__timeline:1319-1322	1.0
:Entity_EDL_0000039	link	NIL000000035
:Entity_EDL_0000040	type	Facility
:Entity_EDL_0000040	canonical_mention	"facilities"	syriancrisis_bbc__1000-01-01__timeline:2258-2267	1.0
:Entity_EDL_0000040	nominal_mention	"facilities"	syriancrisis_bbc__1000-01-01__timeline:2258-2267	1.0
:Entity_EDL_0000040	link	NIL000000036
:Entity_EDL_0000041	type	Person
:Entity_EDL_0000041	canonical_mention	"Assef Shawkat"	syriancrisis_bbc__1000-01-01__timeline:3823-3835	1.0
:Entity_EDL_0000041	mention	"Assef Shawkat"	syriancrisis_bbc__1000-01-01__timeline:3823-3835	1.0
:Entity_EDL_0000041	link	NIL000000037
:Entity_EDL_0000042	type	Weapon
:Entity_EDL_0000042	canonical_mention	"shell"	syriancrisis_bbc__1000-01-01__timeline:2709-2713	1.0
:Entity_EDL_0000042	nominal_mention	"shell"	syriancrisis_bbc__1000-01-01__timeline:2709-2713	1.0
:Entity_EDL_0000042	link	NIL000000038
:Entity_EDL_0000043	type	Person
:Entity_EDL_0000043	canonical_mention	"minister"	syriancrisis_bbc__1000-01-01__timeline:4107-4114	1.0
:Entity_EDL_0000043	nominal_mention	"minister"	syriancrisis_bbc__1000-01-01__timeline:4107-4114	1.0
:Entity_EDL_0000043	link	NIL000000039
:Entity_EDL_0000044	type	Organization
:Entity_EDL_0000044	nominal_mention	"groups"	syriancrisis_bbc__1000-01-01__timeline:3721-3726	1.0
:Entity_EDL_0000044	link	NIL000000040
:Entity_EDL_0000045	type	Organization
:Entity_EDL_0000045	canonical_mention	"groups"	syriancrisis_bbc__1000-01-01__timeline:324-329	1.0
:Entity_EDL_0000045	nominal_mention	"groups"	syriancrisis_bbc__1000-01-01__timeline:324-329	1.0
:Entity_EDL_0000045	link	NIL000000041
:Entity_EDL_0000046	type	Person
:Entity_EDL_0000046	canonical_mention	"Manaf Tlas"	syriancrisis_bbc__1000-01-01__timeline:2987-2996	1.0
:Entity_EDL_0000046	mention	"Manaf Tlas"	syriancrisis_bbc__1000-01-01__timeline:2987-2996	1.0
:Entity_EDL_0000046	link	NIL000000042
:Entity_EDL_0000047	type	GeopoliticalEntity
:Entity_EDL_0000047	mention	"Syria"	syriancrisis_bbc__1000-01-01__timeline:3057-3061	1.0
:Entity_EDL_0000047	link	163843
:Entity_EDL_0000048	type	Person
:Entity_EDL_0000048	canonical_mention	"majority"	syriancrisis_bbc__1000-01-01__timeline:2730-2737	1.0
:Entity_EDL_0000048	nominal_mention	"majority"	syriancrisis_bbc__1000-01-01__timeline:2730-2737	1.0
:Entity_EDL_0000048	link	NIL000000043
:Entity_EDL_0000049	type	Facility
:Entity_EDL_0000049	canonical_mention	"building"	syriancrisis_bbc__1000-01-01__timeline:2203-2210	1.0
:Entity_EDL_0000049	nominal_mention	"building"	syriancrisis_bbc__1000-01-01__timeline:2203-2210	1.0
:Entity_EDL_0000049	link	NIL000000044
:Entity_EDL_0000050	type	Person
:Entity_EDL_0000050	nominal_mention	"people"	syriancrisis_bbc__1000-01-01__timeline:2629-2634	1.0
:Entity_EDL_0000050	link	NIL000000045
:Entity_EDL_0000051	type	Person
:Entity_EDL_0000051	canonical_mention	"bombers"	syriancrisis_bbc__1000-01-01__timeline:2103-2109	1.0
:Entity_EDL_0000051	nominal_mention	"bombers"	syriancrisis_bbc__1000-01-01__timeline:2103-2109	1.0
:Entity_EDL_0000051	link	NIL000000046
