:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"explosion"	bpoil_bbc__1000-01-01__timeline:14266-14274	1.000
:Event_0000000	canonical_mention.actual	"explosion"	bpoil_bbc__1000-01-01__timeline:14266-14274	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000033	bpoil_bbc__1000-01-01__timeline:14314-14316	1.000
:Event_0000000	Conflict.Attack_Place.actual	:Entity_EDL_0000041	bpoil_bbc__1000-01-01__timeline:14325-14338	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"explosion"	bpoil_bbc__1000-01-01__timeline:7964-7972	1.000
:Event_0000000	canonical_mention.actual	"explosion"	bpoil_bbc__1000-01-01__timeline:7964-7972	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"explosion"	bpoil_bbc__1000-01-01__timeline:487-495	1.000
:Event_0000000	canonical_mention.actual	"explosion"	bpoil_bbc__1000-01-01__timeline:487-495	1.000
:Event_0000000	Conflict.Attack_Place.actual	:Entity_EDL_0000034	bpoil_bbc__1000-01-01__timeline:375-388	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"explosion"	bpoil_bbc__1000-01-01__timeline:1055-1063	1.000
:Event_0000000	canonical_mention.actual	"explosion"	bpoil_bbc__1000-01-01__timeline:1055-1063	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000017	bpoil_bbc__1000-01-01__timeline:1090-1092	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000007	bpoil_bbc__1000-01-01__timeline:1142-1145	1.000
:Event_0000001	type	Movement.TransportArtifact
:Event_0000001	mention.actual	"trip"	bpoil_bbc__1000-01-01__timeline:12066-12069	1.000
:Event_0000001	canonical_mention.actual	"trip"	bpoil_bbc__1000-01-01__timeline:12066-12069	1.000
:Event_0000001	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000027	bpoil_bbc__1000-01-01__timeline:12044-12048	1.000
:Event_0000001	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000016	bpoil_bbc__1000-01-01__timeline:12078-12087	1.000
:Event_0000001	type	Movement.TransportArtifact
:Event_0000001	mention.actual	"trip"	bpoil_bbc__1000-01-01__timeline:8444-8447	1.000
:Event_0000001	canonical_mention.actual	"trip"	bpoil_bbc__1000-01-01__timeline:8444-8447	1.000
:Event_0000001	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000001	bpoil_bbc__1000-01-01__timeline:8423-8427	1.000
:Event_0000001	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000028	bpoil_bbc__1000-01-01__timeline:8456-8459	1.000
:Event_0000001	type	Movement.TransportArtifact
:Event_0000001	mention.actual	"trip"	bpoil_bbc__1000-01-01__timeline:9641-9644	1.000
:Event_0000001	canonical_mention.actual	"trip"	bpoil_bbc__1000-01-01__timeline:9641-9644	1.000
:Event_0000001	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000020	bpoil_bbc__1000-01-01__timeline:9621-9625	1.000
:Event_0000001	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000013	bpoil_bbc__1000-01-01__timeline:9653-9658	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"leave"	bpoil_bbc__1000-01-01__timeline:3727-3731	1.000
:Event_0000002	canonical_mention.actual	"leave"	bpoil_bbc__1000-01-01__timeline:3727-3731	1.000
:Event_0000002	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000005	bpoil_bbc__1000-01-01__timeline:3676-3677	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000014	bpoil_bbc__1000-01-01__timeline:3709-3720	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"steps down"	bpoil_bbc__1000-01-01__timeline:4519-4528	1.000
:Event_0000002	canonical_mention.actual	"steps down"	bpoil_bbc__1000-01-01__timeline:4519-4528	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000003	bpoil_bbc__1000-01-01__timeline:4516-4517	1.000
:Event_0000002	type	Personnel.EndPosition
:Event_0000002	mention.actual	"leave"	bpoil_bbc__1000-01-01__timeline:3650-3654	1.000
:Event_0000002	canonical_mention.actual	"leave"	bpoil_bbc__1000-01-01__timeline:3650-3654	1.000
:Event_0000002	Personnel.EndPosition_Person.actual	:Entity_EDL_0000037	bpoil_bbc__1000-01-01__timeline:3637-3643	1.000
:Event_0000002	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000005	bpoil_bbc__1000-01-01__timeline:3676-3677	1.000
:Event_0000003	type	Transaction.TransferMoney
:Event_0000003	mention.actual	"salary"	bpoil_bbc__1000-01-01__timeline:4454-4459	1.000
:Event_0000003	canonical_mention.actual	"salary"	bpoil_bbc__1000-01-01__timeline:4454-4459	1.000
:Event_0000003	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000032	bpoil_bbc__1000-01-01__timeline:4418-4429	1.000
:Event_0000003	type	Transaction.TransferMoney
:Event_0000003	mention.actual	"pension"	bpoil_bbc__1000-01-01__timeline:4576-4582	1.000
:Event_0000003	canonical_mention.actual	"pension"	bpoil_bbc__1000-01-01__timeline:4576-4582	1.000
:Event_0000003	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000018	bpoil_bbc__1000-01-01__timeline:4533-4534	1.000
:Event_0000004	type	Personnel.StartPosition
:Event_0000004	mention.actual	"replacing"	bpoil_bbc__1000-01-01__timeline:7586-7594	1.000
:Event_0000004	canonical_mention.actual	"replacing"	bpoil_bbc__1000-01-01__timeline:7586-7594	1.000
:Event_0000004	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000031	bpoil_bbc__1000-01-01__timeline:7526-7527	1.000
:Event_0000004	Personnel.StartPosition_Person.actual	:Entity_EDL_0000000	bpoil_bbc__1000-01-01__timeline:7573-7582	1.000
:Event_0000005	type	Movement.TransportArtifact
:Event_0000005	mention.actual	"sends"	bpoil_bbc__1000-01-01__timeline:13568-13572	1.000
:Event_0000005	canonical_mention.actual	"sends"	bpoil_bbc__1000-01-01__timeline:13568-13572	1.000
:Event_0000005	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000010	bpoil_bbc__1000-01-01__timeline:13565-13566	1.000
:Event_0000005	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000029	bpoil_bbc__1000-01-01__timeline:13583-13588	1.000
:Event_0000005	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000012	bpoil_bbc__1000-01-01__timeline:13597-13604	1.000
:Event_0000006	type	Transaction.TransferMoney
:Event_0000006	mention.actual	"grants"	bpoil_bbc__1000-01-01__timeline:2353-2358	1.000
:Event_0000006	canonical_mention.actual	"grants"	bpoil_bbc__1000-01-01__timeline:2353-2358	1.000
:Event_0000006	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000004	bpoil_bbc__1000-01-01__timeline:2372-2377	1.000
:Event_0000007	type	Personnel.StartPosition
:Event_0000007	mention.actual	"replace"	bpoil_bbc__1000-01-01__timeline:4027-4033	1.000
:Event_0000007	canonical_mention.actual	"replace"	bpoil_bbc__1000-01-01__timeline:4027-4033	1.000
:Event_0000007	Personnel.StartPosition_Person.actual	:Entity_EDL_0000038	bpoil_bbc__1000-01-01__timeline:3960-3969	1.000
:Event_0000007	Personnel.StartPosition_Person.actual	:Entity_EDL_0000035	bpoil_bbc__1000-01-01__timeline:3973-3975	1.000
:Event_0000008	type	Movement.TransportArtifact
:Event_0000008	mention.actual	"leave"	bpoil_bbc__1000-01-01__timeline:5091-5095	1.000
:Event_0000008	canonical_mention.actual	"leave"	bpoil_bbc__1000-01-01__timeline:5091-5095	1.000
:Event_0000008	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000006	bpoil_bbc__1000-01-01__timeline:4985-4991	1.000
:Event_0000008	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000036	bpoil_bbc__1000-01-01__timeline:5009-5011	1.000
:Event_0000008	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000019	bpoil_bbc__1000-01-01__timeline:5101-5104	1.000
:Event_0000009	type	Justice.TrialHearing
:Event_0000009	mention.actual	"hearing"	bpoil_bbc__1000-01-01__timeline:7809-7815	1.000
:Event_0000009	canonical_mention.actual	"hearing"	bpoil_bbc__1000-01-01__timeline:7809-7815	1.000
:Event_0000009	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000024	bpoil_bbc__1000-01-01__timeline:7765-7776	1.000
:Event_0000010	type	ArtifactExistence.DamageDestroy.Destroy
:Event_0000010	mention.actual	"broken"	bpoil_bbc__1000-01-01__timeline:10858-10863	1.000
:Event_0000010	canonical_mention.actual	"broken"	bpoil_bbc__1000-01-01__timeline:10858-10863	1.000
:Event_0000011	type	Life.Die
:Event_0000011	mention.actual	"kills"	bpoil_bbc__1000-01-01__timeline:14403-14407	1.000
:Event_0000011	canonical_mention.actual	"kills"	bpoil_bbc__1000-01-01__timeline:14403-14407	1.000
:Event_0000011	Life.Die_Place.actual	:Entity_EDL_0000041	bpoil_bbc__1000-01-01__timeline:14325-14338	1.000
:Event_0000011	Life.Die_Victim.actual	:Entity_EDL_0000039	bpoil_bbc__1000-01-01__timeline:14412-14418	1.000
:Event_0000012	type	Movement.TransportArtifact
:Event_0000012	mention.actual	"visits"	bpoil_bbc__1000-01-01__timeline:10055-10060	1.000
:Event_0000012	canonical_mention.actual	"visits"	bpoil_bbc__1000-01-01__timeline:10055-10060	1.000
:Event_0000012	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000025	bpoil_bbc__1000-01-01__timeline:10049-10053	1.000
:Event_0000012	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000002	bpoil_bbc__1000-01-01__timeline:10066-10075	1.000
:Event_0000013	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000013	mention.actual	"criminal"	bpoil_bbc__1000-01-01__timeline:9726-9733	1.000
:Event_0000013	canonical_mention.actual	"criminal"	bpoil_bbc__1000-01-01__timeline:9726-9733	1.000
:Event_0000014	type	Transaction.TransferMoney
:Event_0000014	mention.actual	"paid"	bpoil_bbc__1000-01-01__timeline:7167-7170	1.000
:Event_0000014	canonical_mention.actual	"paid"	bpoil_bbc__1000-01-01__timeline:7167-7170	1.000
:Event_0000014	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000026	bpoil_bbc__1000-01-01__timeline:7195-7198	1.000
:Event_0000015	type	Personnel.Nominate
:Event_0000015	mention.actual	"nominate"	bpoil_bbc__1000-01-01__timeline:3843-3850	1.000
:Event_0000015	canonical_mention.actual	"nominate"	bpoil_bbc__1000-01-01__timeline:3843-3850	1.000
:Event_0000015	Personnel.Nominate_Nominator.actual	:Entity_EDL_0000008	bpoil_bbc__1000-01-01__timeline:3831-3832	1.000
:Event_0000015	Personnel.Nominate_Nominee.actual	:Entity_EDL_0000021	bpoil_bbc__1000-01-01__timeline:3852-3854	1.000
:Event_0000016	type	Transaction.TransferMoney
:Event_0000016	mention.actual	"paying"	bpoil_bbc__1000-01-01__timeline:12137-12142	1.000
:Event_0000016	canonical_mention.actual	"paying"	bpoil_bbc__1000-01-01__timeline:12137-12142	1.000
:Event_0000016	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000011	bpoil_bbc__1000-01-01__timeline:12098-12099	1.000
:Event_0000017	type	Transaction.TransferMoney
:Event_0000017	mention.actual	"pay"	bpoil_bbc__1000-01-01__timeline:8147-8149	1.000
:Event_0000017	canonical_mention.actual	"pay"	bpoil_bbc__1000-01-01__timeline:8147-8149	1.000
:Event_0000017	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000022	bpoil_bbc__1000-01-01__timeline:8135-8136	1.000
:Event_0000018	type	Contact.Meet
:Event_0000018	mention.actual	"consulting"	bpoil_bbc__1000-01-01__timeline:9170-9179	1.000
:Event_0000018	canonical_mention.actual	"consulting"	bpoil_bbc__1000-01-01__timeline:9170-9179	1.000
:Event_0000018	Contact.Meet_Participant.actual	:Entity_EDL_0000023	bpoil_bbc__1000-01-01__timeline:9147-9151	1.000
:Event_0000018	Contact.Meet_Participant.actual	:Entity_EDL_0000015	bpoil_bbc__1000-01-01__timeline:9158-9159	1.000
:Event_0000018	Contact.Meet_Participant.actual	:Entity_EDL_0000009	bpoil_bbc__1000-01-01__timeline:9186-9192	1.000
:Event_0000019	type	Transaction.TransferMoney
:Event_0000019	mention.actual	"paid"	bpoil_bbc__1000-01-01__timeline:2407-2410	1.000
:Event_0000019	canonical_mention.actual	"paid"	bpoil_bbc__1000-01-01__timeline:2407-2410	1.000
:Event_0000019	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000040	bpoil_bbc__1000-01-01__timeline:2435-2438	1.000
:Event_0000019	Transaction.TransferMoney_Beneficiary.actual	:Entity_EDL_0000030	bpoil_bbc__1000-01-01__timeline:2443-2447	1.000
