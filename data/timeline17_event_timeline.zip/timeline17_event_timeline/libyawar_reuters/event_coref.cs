:Event_0000000	type	Life.BeBorn
:Event_0000000	mention.actual	"birth"	libyawar_reuters__1000-01-01__timeline:1906-1910	1.000
:Event_0000000	canonical_mention.actual	"birth"	libyawar_reuters__1000-01-01__timeline:1906-1910	1.000
:Event_0000000	Life.BeBorn_Person.actual	:Entity_EDL_0000020	libyawar_reuters__1000-01-01__timeline:1886-1898	1.000
:Event_0000000	Life.BeBorn_Place.actual	:Entity_EDL_0000037	libyawar_reuters__1000-01-01__timeline:1917-1922	1.000
:Event_0000000	Life.BeBorn_Place.actual	:Entity_EDL_0000010	libyawar_reuters__1000-01-01__timeline:1936-1939	1.000
:Event_0000001	type	Justice.ArrestJail
:Event_0000001	mention.actual	"arrest"	libyawar_reuters__1000-01-01__timeline:1276-1281	1.000
:Event_0000001	canonical_mention.actual	"arrest"	libyawar_reuters__1000-01-01__timeline:1276-1281	1.000
:Event_0000001	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000041	libyawar_reuters__1000-01-01__timeline:1265-1267	1.000
:Event_0000001	Justice.ArrestJail_Person.actual	:Entity_EDL_0000036	libyawar_reuters__1000-01-01__timeline:1296-1302	1.000
:Event_0000001	Justice.ArrestJail_Person.actual	:Entity_EDL_0000038	libyawar_reuters__1000-01-01__timeline:1314-1326	1.000
:Event_0000001	Justice.ArrestJail_Person.actual	:Entity_EDL_0000061	libyawar_reuters__1000-01-01__timeline:1351-1369	1.000
:Event_0000002	type	Life.Die
:Event_0000002	mention.actual	"kills"	libyawar_reuters__1000-01-01__timeline:1138-1142	1.000
:Event_0000002	canonical_mention.actual	"kills"	libyawar_reuters__1000-01-01__timeline:1138-1142	1.000
:Event_0000002	Life.Die_Agent.actual	:Entity_EDL_0000014	libyawar_reuters__1000-01-01__timeline:1096-1099	1.000
:Event_0000002	Life.Die_Instrument.actual	:Entity_EDL_0000042	libyawar_reuters__1000-01-01__timeline:1101-1107	1.000
:Event_0000002	Life.Die_Place.actual	:Entity_EDL_0000062	libyawar_reuters__1000-01-01__timeline:1121-1125	1.000
:Event_0000002	Life.Die_Victim.actual	:Entity_EDL_0000057	libyawar_reuters__1000-01-01__timeline:1164-1166	1.000
:Event_0000002	Life.Die_Victim.actual	:Entity_EDL_0000025	libyawar_reuters__1000-01-01__timeline:1178-1190	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"fighting"	libyawar_reuters__1000-01-01__timeline:4702-4709	1.000
:Event_0000003	canonical_mention.actual	"fighting"	libyawar_reuters__1000-01-01__timeline:4702-4709	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000034	libyawar_reuters__1000-01-01__timeline:4724-4730	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"siege"	libyawar_reuters__1000-01-01__timeline:5015-5019	1.000
:Event_0000004	canonical_mention.actual	"siege"	libyawar_reuters__1000-01-01__timeline:5015-5019	1.000
:Event_0000004	Conflict.Attack_Attacker.actual	:Entity_EDL_0000059	libyawar_reuters__1000-01-01__timeline:4949-4956	1.000
:Event_0000005	type	Movement.TransportArtifact
:Event_0000005	mention.actual	"shipped"	libyawar_reuters__1000-01-01__timeline:3754-3760	1.000
:Event_0000005	canonical_mention.actual	"shipped"	libyawar_reuters__1000-01-01__timeline:3754-3760	1.000
:Event_0000005	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000040	libyawar_reuters__1000-01-01__timeline:3795-3798	1.000
:Event_0000005	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000063	libyawar_reuters__1000-01-01__timeline:3823-3827	1.000
:Event_0000006	type	Justice.ChargeIndict
:Event_0000006	mention.actual	"charges"	libyawar_reuters__1000-01-01__timeline:1374-1380	1.000
:Event_0000006	canonical_mention.actual	"charges"	libyawar_reuters__1000-01-01__timeline:1374-1380	1.000
:Event_0000006	Justice.ChargeIndict_Adjudicator.actual	:Entity_EDL_0000041	libyawar_reuters__1000-01-01__timeline:1265-1267	1.000
:Event_0000006	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000036	libyawar_reuters__1000-01-01__timeline:1296-1302	1.000
:Event_0000006	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000038	libyawar_reuters__1000-01-01__timeline:1314-1326	1.000
:Event_0000006	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000061	libyawar_reuters__1000-01-01__timeline:1351-1369	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"overrun"	libyawar_reuters__1000-01-01__timeline:1666-1672	1.000
:Event_0000007	canonical_mention.actual	"overrun"	libyawar_reuters__1000-01-01__timeline:1666-1672	1.000
:Event_0000007	Conflict.Attack_Attacker.actual	:Entity_EDL_0000060	libyawar_reuters__1000-01-01__timeline:1659-1664	1.000
:Event_0000007	Conflict.Attack_Target.actual	:Entity_EDL_0000055	libyawar_reuters__1000-01-01__timeline:1710-1717	1.000
:Event_0000007	Conflict.Attack_Place.actual	:Entity_EDL_0000018	libyawar_reuters__1000-01-01__timeline:1722-1728	1.000
:Event_0000008	type	Movement.TransportArtifact
:Event_0000008	mention.actual	"arrives"	libyawar_reuters__1000-01-01__timeline:4831-4837	1.000
:Event_0000008	canonical_mention.actual	"arrives"	libyawar_reuters__1000-01-01__timeline:4831-4837	1.000
:Event_0000008	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000017	libyawar_reuters__1000-01-01__timeline:4816-4829	1.000
:Event_0000008	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000024	libyawar_reuters__1000-01-01__timeline:4842-4846	1.000
:Event_0000009	type	Movement.TransportPerson
:Event_0000009	mention.actual	"crossing"	libyawar_reuters__1000-01-01__timeline:1953-1960	1.000
:Event_0000009	canonical_mention.actual	"crossing"	libyawar_reuters__1000-01-01__timeline:1953-1960	1.000
:Event_0000009	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000010	libyawar_reuters__1000-01-01__timeline:1936-1939	1.000
:Event_0000009	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000030	libyawar_reuters__1000-01-01__timeline:1966-1973	1.000
:Event_0000010	type	Contact.Meet
:Event_0000010	mention.actual	"meet"	libyawar_reuters__1000-01-01__timeline:2046-2049	1.000
:Event_0000010	canonical_mention.actual	"meet"	libyawar_reuters__1000-01-01__timeline:2046-2049	1.000
:Event_0000010	Contact.Meet_Participant.actual	:Entity_EDL_0000052	libyawar_reuters__1000-01-01__timeline:2039-2044	1.000
:Event_0000010	Contact.Meet_Participant.actual	:Entity_EDL_0000026	libyawar_reuters__1000-01-01__timeline:2057-2063	1.000
:Event_0000010	Contact.Meet_Place.actual	:Entity_EDL_0000050	libyawar_reuters__1000-01-01__timeline:2084-2088	1.000
:Event_0000011	type	Conflict.Demonstrate
:Event_0000011	mention.actual	"riot"	libyawar_reuters__1000-01-01__timeline:69-72	1.000
:Event_0000011	canonical_mention.actual	"riot"	libyawar_reuters__1000-01-01__timeline:69-72	1.000
:Event_0000011	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000029	libyawar_reuters__1000-01-01__timeline:77-84	1.000
:Event_0000012	type	ArtifactExistence.DamageDestroy.Damage
:Event_0000012	mention.actual	"trashing"	libyawar_reuters__1000-01-01__timeline:1732-1739	1.000
:Event_0000012	canonical_mention.actual	"trashing"	libyawar_reuters__1000-01-01__timeline:1732-1739	1.000
:Event_0000012	ArtifactExistence.DamageDestroy.Damage_Artifact.actual	:Entity_EDL_0000055	libyawar_reuters__1000-01-01__timeline:1710-1717	1.000
:Event_0000012	ArtifactExistence.DamageDestroy.Damage_Place.actual	:Entity_EDL_0000018	libyawar_reuters__1000-01-01__timeline:1722-1728	1.000
:Event_0000012	ArtifactExistence.DamageDestroy.Damage_Artifact.actual	:Entity_EDL_0000051	libyawar_reuters__1000-01-01__timeline:1745-1751	1.000
:Event_0000013	type	Conflict.Attack
:Event_0000013	mention.actual	"fight"	libyawar_reuters__1000-01-01__timeline:1577-1581	1.000
:Event_0000013	canonical_mention.actual	"fight"	libyawar_reuters__1000-01-01__timeline:1577-1581	1.000
:Event_0000013	Conflict.Attack_Attacker.actual	:Entity_EDL_0000002	libyawar_reuters__1000-01-01__timeline:1566-1572	1.000
:Event_0000014	type	Movement.TransportArtifact
:Event_0000014	mention.actual	"escape"	libyawar_reuters__1000-01-01__timeline:4123-4128	1.000
:Event_0000014	canonical_mention.actual	"escape"	libyawar_reuters__1000-01-01__timeline:4123-4128	1.000
:Event_0000014	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000023	libyawar_reuters__1000-01-01__timeline:4111-4112	1.000
:Event_0000014	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000035	libyawar_reuters__1000-01-01__timeline:4130-4134	1.000
:Event_0000015	type	Conflict.Attack
:Event_0000015	mention.actual	"strikes"	libyawar_reuters__1000-01-01__timeline:956-962	1.000
:Event_0000015	canonical_mention.actual	"strikes"	libyawar_reuters__1000-01-01__timeline:956-962	1.000
:Event_0000015	Conflict.Attack_Attacker.actual	:Entity_EDL_0000054	libyawar_reuters__1000-01-01__timeline:995-1000	1.000
:Event_0000016	type	Contact.Broadcast
:Event_0000016	mention.actual	"addresses"	libyawar_reuters__1000-01-01__timeline:1523-1531	1.000
:Event_0000016	canonical_mention.actual	"addresses"	libyawar_reuters__1000-01-01__timeline:1523-1531	1.000
:Event_0000016	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000003	libyawar_reuters__1000-01-01__timeline:1503-1509	1.000
:Event_0000017	type	Contact.Broadcast
:Event_0000017	mention.actual	"speech"	libyawar_reuters__1000-01-01__timeline:3338-3343	1.000
:Event_0000017	canonical_mention.actual	"speech"	libyawar_reuters__1000-01-01__timeline:3338-3343	1.000
:Event_0000017	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000027	libyawar_reuters__1000-01-01__timeline:3313-3319	1.000
:Event_0000017	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000053	libyawar_reuters__1000-01-01__timeline:3388-3394	1.000
:Event_0000018	type	Conflict.Attack
:Event_0000018	mention.actual	"attack"	libyawar_reuters__1000-01-01__timeline:1109-1114	1.000
:Event_0000018	canonical_mention.actual	"attack"	libyawar_reuters__1000-01-01__timeline:1109-1114	1.000
:Event_0000018	Conflict.Attack_Attacker.actual	:Entity_EDL_0000014	libyawar_reuters__1000-01-01__timeline:1096-1099	1.000
:Event_0000018	Conflict.Attack_Instrument.actual	:Entity_EDL_0000042	libyawar_reuters__1000-01-01__timeline:1101-1107	1.000
:Event_0000018	Conflict.Attack_Target.actual	:Entity_EDL_0000062	libyawar_reuters__1000-01-01__timeline:1121-1125	1.000
:Event_0000018	Conflict.Attack_Place.actual	:Entity_EDL_0000008	libyawar_reuters__1000-01-01__timeline:1130-1136	1.000
:Event_0000018	Conflict.Attack_Target.actual	:Entity_EDL_0000057	libyawar_reuters__1000-01-01__timeline:1164-1166	1.000
:Event_0000018	Conflict.Attack_Target.actual	:Entity_EDL_0000025	libyawar_reuters__1000-01-01__timeline:1178-1190	1.000
:Event_0000019	type	Movement.TransportArtifact
:Event_0000019	mention.actual	"enter"	libyawar_reuters__1000-01-01__timeline:1463-1467	1.000
:Event_0000019	canonical_mention.actual	"enter"	libyawar_reuters__1000-01-01__timeline:1463-1467	1.000
:Event_0000019	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000043	libyawar_reuters__1000-01-01__timeline:1456-1461	1.000
:Event_0000019	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000005	libyawar_reuters__1000-01-01__timeline:1469-1475	1.000
:Event_0000020	type	Movement.TransportPerson
:Event_0000020	mention.actual	"evicting"	libyawar_reuters__1000-01-01__timeline:212-219	1.000
:Event_0000020	canonical_mention.actual	"evicting"	libyawar_reuters__1000-01-01__timeline:212-219	1.000
:Event_0000020	Movement.TransportPerson_Agent.actual	:Entity_EDL_0000004	libyawar_reuters__1000-01-01__timeline:149-156	1.000
:Event_0000020	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000019	libyawar_reuters__1000-01-01__timeline:190-193	1.000
:Event_0000020	Movement.TransportPerson_Person.actual	:Entity_EDL_0000046	libyawar_reuters__1000-01-01__timeline:221-226	1.000
:Event_0000021	type	Contact.Meet
:Event_0000021	mention.actual	"conference"	libyawar_reuters__1000-01-01__timeline:2070-2079	1.000
:Event_0000021	canonical_mention.actual	"conference"	libyawar_reuters__1000-01-01__timeline:2070-2079	1.000
:Event_0000021	Contact.Meet_Participant.actual	:Entity_EDL_0000052	libyawar_reuters__1000-01-01__timeline:2039-2044	1.000
:Event_0000021	Contact.Meet_Participant.actual	:Entity_EDL_0000026	libyawar_reuters__1000-01-01__timeline:2057-2063	1.000
:Event_0000021	Contact.Meet_Place.actual	:Entity_EDL_0000050	libyawar_reuters__1000-01-01__timeline:2084-2088	1.000
:Event_0000022	type	Life.Die
:Event_0000022	mention.actual	"died"	libyawar_reuters__1000-01-01__timeline:4694-4697	1.000
:Event_0000022	canonical_mention.actual	"died"	libyawar_reuters__1000-01-01__timeline:4694-4697	1.000
:Event_0000022	Life.Die_Victim.actual	:Entity_EDL_0000001	libyawar_reuters__1000-01-01__timeline:4683-4685	1.000
:Event_0000022	Life.Die_Victim.actual	:Entity_EDL_0000039	libyawar_reuters__1000-01-01__timeline:4687-4692	1.000
:Event_0000022	Life.Die_Place.actual	:Entity_EDL_0000034	libyawar_reuters__1000-01-01__timeline:4724-4730	1.000
:Event_0000023	type	Conflict.Yield.Surrender
:Event_0000023	mention.actual	"surrender"	libyawar_reuters__1000-01-01__timeline:3239-3247	1.000
:Event_0000023	canonical_mention.actual	"surrender"	libyawar_reuters__1000-01-01__timeline:3239-3247	1.000
:Event_0000024	type	Movement.TransportArtifact
:Event_0000024	mention.actual	"arrives"	libyawar_reuters__1000-01-01__timeline:2297-2303	1.000
:Event_0000024	canonical_mention.actual	"arrives"	libyawar_reuters__1000-01-01__timeline:2297-2303	1.000
:Event_0000024	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000031	libyawar_reuters__1000-01-01__timeline:2282-2295	1.000
:Event_0000024	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000058	libyawar_reuters__1000-01-01__timeline:2308-2314	1.000
:Event_0000025	type	Justice.ArrestJail
:Event_0000025	mention.actual	"arrest"	libyawar_reuters__1000-01-01__timeline:15-20	1.000
:Event_0000025	canonical_mention.actual	"arrest"	libyawar_reuters__1000-01-01__timeline:15-20	1.000
:Event_0000025	Justice.ArrestJail_Person.actual	:Entity_EDL_0000013	libyawar_reuters__1000-01-01__timeline:47-58	1.000
:Event_0000025	Justice.ArrestJail_Place.actual	:Entity_EDL_0000029	libyawar_reuters__1000-01-01__timeline:77-84	1.000
:Event_0000026	type	Movement.TransportArtifact
:Event_0000026	mention.actual	"advance"	libyawar_reuters__1000-01-01__timeline:973-979	1.000
:Event_0000026	canonical_mention.actual	"advance"	libyawar_reuters__1000-01-01__timeline:973-979	1.000
:Event_0000026	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000054	libyawar_reuters__1000-01-01__timeline:995-1000	1.000
:Event_0000026	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000022	libyawar_reuters__1000-01-01__timeline:1005-1012	1.000
:Event_0000027	type	Contact.Broadcast
:Event_0000027	mention.actual	"speech"	libyawar_reuters__1000-01-01__timeline:2609-2614	1.000
:Event_0000027	canonical_mention.actual	"speech"	libyawar_reuters__1000-01-01__timeline:2609-2614	1.000
:Event_0000027	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000032	libyawar_reuters__1000-01-01__timeline:2573-2591	1.000
:Event_0000027	Contact.Broadcast_Place.actual	:Entity_EDL_0000015	libyawar_reuters__1000-01-01__timeline:2619-2625	1.000
:Event_0000027	Contact.Broadcast_Audience.actual	:Entity_EDL_0000009	libyawar_reuters__1000-01-01__timeline:2632-2636	1.000
:Event_0000028	type	Movement.TransportArtifact
:Event_0000028	mention.actual	"sails"	libyawar_reuters__1000-01-01__timeline:3772-3776	1.000
:Event_0000028	canonical_mention.actual	"sails"	libyawar_reuters__1000-01-01__timeline:3772-3776	1.000
:Event_0000028	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000040	libyawar_reuters__1000-01-01__timeline:3795-3798	1.000
:Event_0000028	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000063	libyawar_reuters__1000-01-01__timeline:3823-3827	1.000
:Event_0000029	type	Movement.TransportArtifact
:Event_0000029	mention.actual	"land"	libyawar_reuters__1000-01-01__timeline:2756-2759	1.000
:Event_0000029	canonical_mention.actual	"land"	libyawar_reuters__1000-01-01__timeline:2756-2759	1.000
:Event_0000029	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000021	libyawar_reuters__1000-01-01__timeline:2711-2725	1.000
:Event_0000029	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000006	libyawar_reuters__1000-01-01__timeline:2742-2754	1.000
:Event_0000029	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000044	libyawar_reuters__1000-01-01__timeline:2764-2768	1.000
:Event_0000030	type	Movement.TransportArtifact
:Event_0000030	mention.actual	"arrived"	libyawar_reuters__1000-01-01__timeline:2487-2493	1.000
:Event_0000030	canonical_mention.actual	"arrived"	libyawar_reuters__1000-01-01__timeline:2487-2493	1.000
:Event_0000030	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000016	libyawar_reuters__1000-01-01__timeline:2473-2475	1.000
:Event_0000030	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000047	libyawar_reuters__1000-01-01__timeline:2477-2481	1.000
:Event_0000030	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000049	libyawar_reuters__1000-01-01__timeline:2495-2499	1.000
:Event_0000031	type	Movement.TransportPerson
:Event_0000031	mention.actual	"return"	libyawar_reuters__1000-01-01__timeline:3269-3274	1.000
:Event_0000031	canonical_mention.actual	"return"	libyawar_reuters__1000-01-01__timeline:3269-3274	1.000
:Event_0000031	Movement.TransportPerson_Person.actual	:Entity_EDL_0000012	libyawar_reuters__1000-01-01__timeline:3288-3297	1.000
:Event_0000031	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000007	libyawar_reuters__1000-01-01__timeline:3302-3308	1.000
:Event_0000032	type	Conflict.Attack
:Event_0000032	mention.actual	"Gunfights"	libyawar_reuters__1000-01-01__timeline:4356-4364	1.000
:Event_0000032	canonical_mention.actual	"Gunfights"	libyawar_reuters__1000-01-01__timeline:4356-4364	1.000
:Event_0000032	Conflict.Attack_Place.actual	:Entity_EDL_0000045	libyawar_reuters__1000-01-01__timeline:4379-4385	1.000
:Event_0000032	Conflict.Attack_Attacker.actual	:Entity_EDL_0000028	libyawar_reuters__1000-01-01__timeline:4403-4412	1.000
:Event_0000032	Conflict.Attack_Attacker.actual	:Entity_EDL_0000033	libyawar_reuters__1000-01-01__timeline:4422-4427	1.000
:Event_0000033	type	Personnel.StartPosition
:Event_0000033	mention.actual	"coming"	libyawar_reuters__1000-01-01__timeline:2161-2166	1.000
:Event_0000033	canonical_mention.actual	"coming"	libyawar_reuters__1000-01-01__timeline:2161-2166	1.000
:Event_0000033	Personnel.StartPosition_Person.actual	:Entity_EDL_0000011	libyawar_reuters__1000-01-01__timeline:2157-2159	1.000
:Event_0000034	type	Movement.TransportArtifact
:Event_0000034	mention.actual	"enter"	libyawar_reuters__1000-01-01__timeline:1869-1873	1.000
:Event_0000034	canonical_mention.actual	"enter"	libyawar_reuters__1000-01-01__timeline:1869-1873	1.000
:Event_0000034	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000048	libyawar_reuters__1000-01-01__timeline:1843-1847	1.000
:Event_0000034	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000056	libyawar_reuters__1000-01-01__timeline:1853-1855	1.000
:Event_0000034	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000000	libyawar_reuters__1000-01-01__timeline:1875-1881	1.000
