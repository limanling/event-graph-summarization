:Entity_EDL_0000000	type	GeopoliticalEntity
:Entity_EDL_0000000	mention	"Mexico"	h1n1_guardian__1000-01-01__timeline:207-212	1.0
:Entity_EDL_0000000	link	3996063
:Entity_EDL_0000001	type	Organization
:Entity_EDL_0000001	canonical_mention	"department"	h1n1_guardian__1000-01-01__timeline:4586-4595	1.0
:Entity_EDL_0000001	nominal_mention	"department"	h1n1_guardian__1000-01-01__timeline:4586-4595	1.0
:Entity_EDL_0000001	link	NIL000000001
:Entity_EDL_0000002	type	Person
:Entity_EDL_0000002	canonical_mention	"people"	h1n1_guardian__1000-01-01__timeline:159-164	1.0
:Entity_EDL_0000002	nominal_mention	"people"	h1n1_guardian__1000-01-01__timeline:159-164	1.0
:Entity_EDL_0000002	link	NIL000000002
:Entity_EDL_0000003	type	GeopoliticalEntity
:Entity_EDL_0000003	mention	"Mexico"	h1n1_guardian__1000-01-01__timeline:1975-1980	1.0
:Entity_EDL_0000003	link	3996063
:Entity_EDL_0000004	type	GeopoliticalEntity
:Entity_EDL_0000004	canonical_mention	"Mexicali"	h1n1_guardian__1000-01-01__timeline:3564-3571	1.0
:Entity_EDL_0000004	mention	"Mexicali"	h1n1_guardian__1000-01-01__timeline:3564-3571	1.0
:Entity_EDL_0000004	link	3996069
:Entity_EDL_0000005	type	Person
:Entity_EDL_0000005	canonical_mention	"woman"	h1n1_guardian__1000-01-01__timeline:4767-4771	1.0
:Entity_EDL_0000005	nominal_mention	"woman"	h1n1_guardian__1000-01-01__timeline:4767-4771	1.0
:Entity_EDL_0000005	link	NIL000000003
:Entity_EDL_0000006	type	GeopoliticalEntity
:Entity_EDL_0000006	canonical_mention	"home"	h1n1_guardian__1000-01-01__timeline:1555-1558	1.0
:Entity_EDL_0000006	nominal_mention	"home"	h1n1_guardian__1000-01-01__timeline:1555-1558	1.0
:Entity_EDL_0000006	link	NIL000000004
:Entity_EDL_0000007	type	MHI
:Entity_EDL_0000007	mention	"flu"	h1n1_guardian__1000-01-01__timeline:4693-4695	1.0
:Entity_EDL_0000007	link	NIL000000005
:Entity_EDL_0000008	type	Person
:Entity_EDL_0000008	canonical_mention	"holidaymakers"	h1n1_guardian__1000-01-01__timeline:1541-1553	1.0
:Entity_EDL_0000008	nominal_mention	"holidaymakers"	h1n1_guardian__1000-01-01__timeline:1541-1553	1.0
:Entity_EDL_0000008	link	NIL000000006
:Entity_EDL_0000009	type	GeopoliticalEntity
:Entity_EDL_0000009	canonical_mention	"Mexico City"	h1n1_guardian__1000-01-01__timeline:3415-3425	1.0
:Entity_EDL_0000009	mention	"Mexico City"	h1n1_guardian__1000-01-01__timeline:3415-3425	1.0
:Entity_EDL_0000009	link	3530597
:Entity_EDL_0000010	type	GeopoliticalEntity
:Entity_EDL_0000010	mention	"San Luis Potosi"	h1n1_guardian__1000-01-01__timeline:4831-4845	1.0
:Entity_EDL_0000010	link	3985605
:Entity_EDL_0000011	type	GeopoliticalEntity
:Entity_EDL_0000011	mention	"Mexico"	h1n1_guardian__1000-01-01__timeline:777-782	1.0
:Entity_EDL_0000011	link	3996063
:Entity_EDL_0000012	type	Organization
:Entity_EDL_0000012	canonical_mention	"operators"	h1n1_guardian__1000-01-01__timeline:1466-1474	1.0
:Entity_EDL_0000012	nominal_mention	"operators"	h1n1_guardian__1000-01-01__timeline:1466-1474	1.0
:Entity_EDL_0000012	link	NIL000000007
:Entity_EDL_0000013	type	GeopoliticalEntity
:Entity_EDL_0000013	mention	"Mexico"	h1n1_guardian__1000-01-01__timeline:2474-2479	1.0
:Entity_EDL_0000013	link	3996063
:Entity_EDL_0000014	type	Person
:Entity_EDL_0000014	nominal_mention	"students"	h1n1_guardian__1000-01-01__timeline:2449-2456	1.0
:Entity_EDL_0000014	link	NIL000000008
:Entity_EDL_0000015	type	GeopoliticalEntity
:Entity_EDL_0000015	nominal_mention	"country"	h1n1_guardian__1000-01-01__timeline:4088-4094	1.0
:Entity_EDL_0000015	link	NIL000000009
:Entity_EDL_0000016	type	Person
:Entity_EDL_0000016	canonical_mention	"newlyweds"	h1n1_guardian__1000-01-01__timeline:1941-1949	1.0
:Entity_EDL_0000016	nominal_mention	"newlyweds"	h1n1_guardian__1000-01-01__timeline:1941-1949	1.0
:Entity_EDL_0000016	link	NIL000000010
:Entity_EDL_0000017	type	GeopoliticalEntity
:Entity_EDL_0000017	nominal_mention	"country"	h1n1_guardian__1000-01-01__timeline:1633-1639	1.0
:Entity_EDL_0000017	link	NIL000000011
:Entity_EDL_0000018	type	GeopoliticalEntity
:Entity_EDL_0000018	canonical_mention	"San Luis Potosi"	h1n1_guardian__1000-01-01__timeline:3465-3479	1.0
:Entity_EDL_0000018	mention	"San Luis Potosi"	h1n1_guardian__1000-01-01__timeline:3465-3479	1.0
:Entity_EDL_0000018	link	3985605
:Entity_EDL_0000019	type	Organization
:Entity_EDL_0000019	canonical_mention	"agencies"	h1n1_guardian__1000-01-01__timeline:1448-1455	1.0
:Entity_EDL_0000019	nominal_mention	"agencies"	h1n1_guardian__1000-01-01__timeline:1448-1455	1.0
:Entity_EDL_0000019	link	NIL000000012
:Entity_EDL_0000020	type	GeopoliticalEntity
:Entity_EDL_0000020	mention	"Mexico"	h1n1_guardian__1000-01-01__timeline:1100-1105	1.0
:Entity_EDL_0000020	link	3996063
:Entity_EDL_0000021	type	Person
:Entity_EDL_0000021	canonical_mention	"152"	h1n1_guardian__1000-01-01__timeline:1116-1118	1.0
:Entity_EDL_0000021	nominal_mention	"152"	h1n1_guardian__1000-01-01__timeline:1116-1118	1.0
:Entity_EDL_0000021	link	NIL000000013
:Entity_EDL_0000022	type	Person
:Entity_EDL_0000022	canonical_mention	"150"	h1n1_guardian__1000-01-01__timeline:2343-2345	1.0
:Entity_EDL_0000022	nominal_mention	"150"	h1n1_guardian__1000-01-01__timeline:2343-2345	1.0
:Entity_EDL_0000022	link	NIL000000014
:Entity_EDL_0000023	type	GeopoliticalEntity
:Entity_EDL_0000023	mention	"Mexico"	h1n1_guardian__1000-01-01__timeline:77-82	1.0
:Entity_EDL_0000023	link	3996063
:Entity_EDL_0000024	type	GeopoliticalEntity
:Entity_EDL_0000024	mention	"Mexico"	h1n1_guardian__1000-01-01__timeline:2324-2329	1.0
:Entity_EDL_0000024	link	3996063
:Entity_EDL_0000025	type	GeopoliticalEntity
:Entity_EDL_0000025	canonical_mention	"New Zealand"	h1n1_guardian__1000-01-01__timeline:669-679	1.0
:Entity_EDL_0000025	mention	"New Zealand"	h1n1_guardian__1000-01-01__timeline:669-679	1.0
:Entity_EDL_0000025	link	2186224
:Entity_EDL_0000026	type	Person
:Entity_EDL_0000026	nominal_mention	"people"	h1n1_guardian__1000-01-01__timeline:4070-4075	1.0
:Entity_EDL_0000026	link	NIL000000015
:Entity_EDL_0000027	type	Organization
:Entity_EDL_0000027	canonical_mention	"Pan-American Health Organisation"	h1n1_guardian__1000-01-01__timeline:4610-4641	1.0
:Entity_EDL_0000027	mention	"Pan-American Health Organisation"	h1n1_guardian__1000-01-01__timeline:4610-4641	1.0
:Entity_EDL_0000027	link	NIL000000016
:Entity_EDL_0000028	type	GeopoliticalEntity
:Entity_EDL_0000028	mention	"Mexico"	h1n1_guardian__1000-01-01__timeline:1494-1499	1.0
:Entity_EDL_0000028	link	3996063
