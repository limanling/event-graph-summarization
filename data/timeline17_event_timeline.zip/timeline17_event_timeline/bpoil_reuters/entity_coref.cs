:Entity_EDL_0000000	type	Organization
:Entity_EDL_0000000	mention	"BP"	bpoil_reuters__1000-01-01__timeline:3871-3872	1.0
:Entity_EDL_0000000	link	NIL000000001
:Entity_EDL_0000001	type	Person
:Entity_EDL_0000001	canonical_mention	"fishermen"	bpoil_reuters__1000-01-01__timeline:1456-1464	1.0
:Entity_EDL_0000001	nominal_mention	"fishermen"	bpoil_reuters__1000-01-01__timeline:1456-1464	1.0
:Entity_EDL_0000001	link	NIL000000002
:Entity_EDL_0000002	type	Person
:Entity_EDL_0000002	mention	"Hayward"	bpoil_reuters__1000-01-01__timeline:2246-2252	1.0
:Entity_EDL_0000002	link	NIL000000003
:Entity_EDL_0000003	type	GeopoliticalEntity
:Entity_EDL_0000003	nominal_mention	"government"	bpoil_reuters__1000-01-01__timeline:3932-3941	1.0
:Entity_EDL_0000003	link	NIL000000004
:Entity_EDL_0000004	type	Organization
:Entity_EDL_0000004	mention	"BP"	bpoil_reuters__1000-01-01__timeline:2964-2965	1.0
:Entity_EDL_0000004	link	NIL000000005
:Entity_EDL_0000005	type	Person
:Entity_EDL_0000005	nominal_mention	"workers"	bpoil_reuters__1000-01-01__timeline:4040-4046	1.0
:Entity_EDL_0000005	link	NIL000000006
:Entity_EDL_0000006	type	Organization
:Entity_EDL_0000006	canonical_mention	"companies"	bpoil_reuters__1000-01-01__timeline:2983-2991	1.0
:Entity_EDL_0000006	nominal_mention	"companies"	bpoil_reuters__1000-01-01__timeline:2983-2991	1.0
:Entity_EDL_0000006	link	NIL000000007
:Entity_EDL_0000007	type	Person
:Entity_EDL_0000007	canonical_mention	"Robert Dudley"	bpoil_reuters__1000-01-01__timeline:2308-2320	1.0
:Entity_EDL_0000007	mention	"Robert Dudley"	bpoil_reuters__1000-01-01__timeline:2308-2320	1.0
:Entity_EDL_0000007	link	NIL000000008
:Entity_EDL_0000008	type	Person
:Entity_EDL_0000008	canonical_mention	"leaders"	bpoil_reuters__1000-01-01__timeline:4243-4249	1.0
:Entity_EDL_0000008	nominal_mention	"leaders"	bpoil_reuters__1000-01-01__timeline:4243-4249	1.0
:Entity_EDL_0000008	link	NIL000000009
:Entity_EDL_0000009	type	Organization
:Entity_EDL_0000009	canonical_mention	"company"	bpoil_reuters__1000-01-01__timeline:1039-1045	1.0
:Entity_EDL_0000009	nominal_mention	"company"	bpoil_reuters__1000-01-01__timeline:1039-1045	1.0
:Entity_EDL_0000009	link	NIL000000010
:Entity_EDL_0000010	type	Location
:Entity_EDL_0000010	mention	"Deepwater Horizon"	bpoil_reuters__1000-01-01__timeline:3330-3346	1.0
:Entity_EDL_0000010	link	NIL000000011
:Entity_EDL_0000011	type	Person
:Entity_EDL_0000011	pronominal_mention	"They"	bpoil_reuters__1000-01-01__timeline:3762-3765	1.0
:Entity_EDL_0000011	link	NIL000000012
:Entity_EDL_0000012	type	Organization
:Entity_EDL_0000012	mention	"BP"	bpoil_reuters__1000-01-01__timeline:3448-3449	1.0
:Entity_EDL_0000012	link	NIL000000013
:Entity_EDL_0000013	type	Organization
:Entity_EDL_0000013	canonical_mention	"Justice Department"	bpoil_reuters__1000-01-01__timeline:2926-2943	1.0
:Entity_EDL_0000013	mention	"Justice Department"	bpoil_reuters__1000-01-01__timeline:2926-2943	1.0
:Entity_EDL_0000013	link	NIL000000014
:Entity_EDL_0000014	type	Organization
:Entity_EDL_0000014	nominal_mention	"entities"	bpoil_reuters__1000-01-01__timeline:4214-4221	1.0
:Entity_EDL_0000014	link	NIL000000015
:Entity_EDL_0000015	type	Person
:Entity_EDL_0000015	canonical_mention	"workers"	bpoil_reuters__1000-01-01__timeline:92-98	1.0
:Entity_EDL_0000015	nominal_mention	"workers"	bpoil_reuters__1000-01-01__timeline:92-98	1.0
:Entity_EDL_0000015	link	NIL000000016
:Entity_EDL_0000016	type	Person
:Entity_EDL_0000016	canonical_mention	"lawyers"	bpoil_reuters__1000-01-01__timeline:3455-3461	1.0
:Entity_EDL_0000016	nominal_mention	"lawyers"	bpoil_reuters__1000-01-01__timeline:3455-3461	1.0
:Entity_EDL_0000016	link	NIL000000017
:Entity_EDL_0000017	type	Person
:Entity_EDL_0000017	canonical_mention	"executive"	bpoil_reuters__1000-01-01__timeline:4296-4304	1.0
:Entity_EDL_0000017	nominal_mention	"executive"	bpoil_reuters__1000-01-01__timeline:4296-4304	1.0
:Entity_EDL_0000017	link	NIL000000018
