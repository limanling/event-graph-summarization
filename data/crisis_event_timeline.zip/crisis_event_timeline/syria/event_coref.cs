:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syria_latimes__1000-01-01__timeline:4943-4950	1.000
:Event_0000000	canonical_mention.actual	"protests"	syria_latimes__1000-01-01__timeline:4943-4950	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	syria_latimes__1000-01-01__timeline:4971-4975	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syria_latimes__1000-01-01__timeline:5721-5728	1.000
:Event_0000000	canonical_mention.actual	"protests"	syria_latimes__1000-01-01__timeline:5721-5728	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000303	syria_latimes__1000-01-01__timeline:5697-5700	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000158	syria_latimes__1000-01-01__timeline:5715-5719	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:7016-7025	1.000
:Event_0000000	canonical_mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:7016-7025	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000089	syria_latimes__1000-01-01__timeline:7016-7025	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syria_latimes__1000-01-01__timeline:6419-6426	1.000
:Event_0000000	canonical_mention.actual	"protests"	syria_latimes__1000-01-01__timeline:6419-6426	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syria_latimes__1000-01-01__timeline:1607-1614	1.000
:Event_0000000	canonical_mention.actual	"protests"	syria_latimes__1000-01-01__timeline:1607-1614	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000271	syria_latimes__1000-01-01__timeline:1567-1570	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:3414-3423	1.000
:Event_0000000	canonical_mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:3414-3423	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000091	syria_latimes__1000-01-01__timeline:3414-3423	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syria_latimes__1000-01-01__timeline:881-888	1.000
:Event_0000000	canonical_mention.actual	"protests"	syria_latimes__1000-01-01__timeline:881-888	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000189	syria_latimes__1000-01-01__timeline:783-791	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000262	syria_latimes__1000-01-01__timeline:796-802	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000058	syria_latimes__1000-01-01__timeline:814-820	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syria_latimes__1000-01-01__timeline:3676-3683	1.000
:Event_0000000	canonical_mention.actual	"protests"	syria_latimes__1000-01-01__timeline:3676-3683	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000198	syria_latimes__1000-01-01__timeline:3636-3640	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"uprising"	syria_latimes__1000-01-01__timeline:10002-10009	1.000
:Event_0000000	canonical_mention.actual	"uprising"	syria_latimes__1000-01-01__timeline:10002-10009	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000201	syria_latimes__1000-01-01__timeline:9991-9997	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"Protests"	syria_latimes__1000-01-01__timeline:426-433	1.000
:Event_0000000	canonical_mention.actual	"Protests"	syria_latimes__1000-01-01__timeline:426-433	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"uprising"	syria_latimes__1000-01-01__timeline:10087-10094	1.000
:Event_0000000	canonical_mention.actual	"uprising"	syria_latimes__1000-01-01__timeline:10087-10094	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	syria_latimes__1000-01-01__timeline:10080-10085	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:4299-4308	1.000
:Event_0000000	canonical_mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:4299-4308	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000055	syria_latimes__1000-01-01__timeline:4299-4308	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syria_latimes__1000-01-01__timeline:1161-1168	1.000
:Event_0000000	canonical_mention.actual	"protests"	syria_latimes__1000-01-01__timeline:1161-1168	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000085	syria_latimes__1000-01-01__timeline:1139-1142	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:4069-4078	1.000
:Event_0000000	canonical_mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:4069-4078	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000077	syria_latimes__1000-01-01__timeline:4069-4078	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"Protests"	syria_latimes__1000-01-01__timeline:1217-1224	1.000
:Event_0000000	canonical_mention.actual	"Protests"	syria_latimes__1000-01-01__timeline:1217-1224	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000004	syria_latimes__1000-01-01__timeline:1272-1277	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syria_latimes__1000-01-01__timeline:6267-6274	1.000
:Event_0000000	canonical_mention.actual	"protests"	syria_latimes__1000-01-01__timeline:6267-6274	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000015	syria_latimes__1000-01-01__timeline:6283-6289	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"rallies"	syria_latimes__1000-01-01__timeline:10249-10255	1.000
:Event_0000000	canonical_mention.actual	"rallies"	syria_latimes__1000-01-01__timeline:10249-10255	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000164	syria_latimes__1000-01-01__timeline:10264-10270	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:3119-3128	1.000
:Event_0000000	canonical_mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:3119-3128	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000035	syria_latimes__1000-01-01__timeline:3119-3128	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syria_dailystar__1000-01-01__timeline:17-24	1.000
:Event_0000000	canonical_mention.actual	"protests"	syria_dailystar__1000-01-01__timeline:17-24	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syria_latimes__1000-01-01__timeline:5149-5156	1.000
:Event_0000000	canonical_mention.actual	"protests"	syria_latimes__1000-01-01__timeline:5149-5156	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	syria_latimes__1000-01-01__timeline:5178-5182	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000014	syria_latimes__1000-01-01__timeline:5200-5208	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"uprisings"	syria_latimes__1000-01-01__timeline:1259-1267	1.000
:Event_0000000	canonical_mention.actual	"uprisings"	syria_latimes__1000-01-01__timeline:1259-1267	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000004	syria_latimes__1000-01-01__timeline:1272-1277	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syria_latimes__1000-01-01__timeline:2643-2650	1.000
:Event_0000000	canonical_mention.actual	"protests"	syria_latimes__1000-01-01__timeline:2643-2650	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000067	syria_latimes__1000-01-01__timeline:2678-2683	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syria_latimes__1000-01-01__timeline:113-120	1.000
:Event_0000000	canonical_mention.actual	"protests"	syria_latimes__1000-01-01__timeline:113-120	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000104	syria_latimes__1000-01-01__timeline:159-164	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"uprising"	syria_latimes__1000-01-01__timeline:5673-5680	1.000
:Event_0000000	canonical_mention.actual	"uprising"	syria_latimes__1000-01-01__timeline:5673-5680	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000303	syria_latimes__1000-01-01__timeline:5697-5700	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:4732-4741	1.000
:Event_0000000	canonical_mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:4732-4741	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000161	syria_latimes__1000-01-01__timeline:4732-4741	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000141	syria_latimes__1000-01-01__timeline:4754-4760	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"demonstrations"	syria_latimes__1000-01-01__timeline:2482-2495	1.000
:Event_0000000	canonical_mention.actual	"demonstrations"	syria_latimes__1000-01-01__timeline:2482-2495	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:11282-11291	1.000
:Event_0000000	canonical_mention.actual	"protesters"	syria_latimes__1000-01-01__timeline:11282-11291	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000213	syria_latimes__1000-01-01__timeline:11262-11267	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000150	syria_latimes__1000-01-01__timeline:11282-11291	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	syria_dailystar__1000-01-01__timeline:1865-1870	1.000
:Event_0000001	canonical_mention.actual	"attack"	syria_dailystar__1000-01-01__timeline:1865-1870	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000001	syria_dailystar__1000-01-01__timeline:1856-1863	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attacks"	syria_bbc__1000-01-01__timeline:2077-2083	1.000
:Event_0000001	canonical_mention.actual	"attacks"	syria_bbc__1000-01-01__timeline:2077-2083	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000115	syria_bbc__1000-01-01__timeline:2103-2109	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000257	syria_bbc__1000-01-01__timeline:2118-2124	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"bombing"	syria_bbc__1000-01-01__timeline:4394-4400	1.000
:Event_0000001	canonical_mention.actual	"bombing"	syria_bbc__1000-01-01__timeline:4394-4400	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000180	syria_bbc__1000-01-01__timeline:4314-4318	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attacks"	syria_bbc__1000-01-01__timeline:2382-2388	1.000
:Event_0000001	canonical_mention.actual	"attacks"	syria_bbc__1000-01-01__timeline:2382-2388	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000312	syria_bbc__1000-01-01__timeline:2326-2331	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	syria_dailystar__1000-01-01__timeline:486-491	1.000
:Event_0000001	canonical_mention.actual	"attack"	syria_dailystar__1000-01-01__timeline:486-491	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000001	syria_dailystar__1000-01-01__timeline:498-505	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000078	syria_dailystar__1000-01-01__timeline:516-519	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attacks"	syria_bbc__1000-01-01__timeline:2227-2233	1.000
:Event_0000001	canonical_mention.actual	"attacks"	syria_bbc__1000-01-01__timeline:2227-2233	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000295	syria_bbc__1000-01-01__timeline:2258-2267	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	syria_bbc__1000-01-01__timeline:3900-3905	1.000
:Event_0000001	canonical_mention.actual	"attack"	syria_bbc__1000-01-01__timeline:3900-3905	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000130	syria_bbc__1000-01-01__timeline:3796-3807	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000251	syria_bbc__1000-01-01__timeline:3817-3822	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000156	syria_bbc__1000-01-01__timeline:3824-3836	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000090	syria_bbc__1000-01-01__timeline:3960-3971	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"explodes"	syria_dailystar__1000-01-01__timeline:2893-2900	1.000
:Event_0000001	canonical_mention.actual	"explodes"	syria_dailystar__1000-01-01__timeline:2893-2900	1.000
:Event_0000001	Conflict.Attack_Instrument.actual	:Entity_EDL_0000245	syria_dailystar__1000-01-01__timeline:2888-2891	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000275	syria_dailystar__1000-01-01__timeline:2913-2920	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000304	syria_dailystar__1000-01-01__timeline:2995-3000	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	syria_bbc__1000-01-01__timeline:4176-4181	1.000
:Event_0000001	canonical_mention.actual	"attack"	syria_bbc__1000-01-01__timeline:4176-4181	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000065	syria_bbc__1000-01-01__timeline:4108-4115	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000291	syria_bbc__1000-01-01__timeline:4139-4143	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"attack"	syria_bbc__1000-01-01__timeline:4085-4090	1.000
:Event_0000001	canonical_mention.actual	"attack"	syria_bbc__1000-01-01__timeline:4085-4090	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000247	syria_bbc__1000-01-01__timeline:4007-4022	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"violence"	syria_latimes__1000-01-01__timeline:6693-6700	1.000
:Event_0000002	canonical_mention.actual	"violence"	syria_latimes__1000-01-01__timeline:6693-6700	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"bloodshed"	syria_latimes__1000-01-01__timeline:8366-8374	1.000
:Event_0000002	canonical_mention.actual	"bloodshed"	syria_latimes__1000-01-01__timeline:8366-8374	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000064	syria_latimes__1000-01-01__timeline:8408-8414	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"violence"	syria_latimes__1000-01-01__timeline:9187-9194	1.000
:Event_0000002	canonical_mention.actual	"violence"	syria_latimes__1000-01-01__timeline:9187-9194	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000069	syria_latimes__1000-01-01__timeline:9215-9221	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"violence"	syria_dailystar__1000-01-01__timeline:1243-1250	1.000
:Event_0000002	canonical_mention.actual	"violence"	syria_dailystar__1000-01-01__timeline:1243-1250	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"violence"	syria_latimes__1000-01-01__timeline:11820-11827	1.000
:Event_0000002	canonical_mention.actual	"violence"	syria_latimes__1000-01-01__timeline:11820-11827	1.000
:Event_0000002	Conflict.Attack_Place.actual	:Entity_EDL_0000140	syria_latimes__1000-01-01__timeline:11836-11842	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"violence"	syria_latimes__1000-01-01__timeline:8902-8909	1.000
:Event_0000002	canonical_mention.actual	"violence"	syria_latimes__1000-01-01__timeline:8902-8909	1.000
:Event_0000002	type	Conflict.Attack
:Event_0000002	mention.actual	"violence"	syria_bbc__1000-01-01__timeline:1530-1537	1.000
:Event_0000002	canonical_mention.actual	"violence"	syria_bbc__1000-01-01__timeline:1530-1537	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"conflict"	syria_latimes__1000-01-01__timeline:10834-10841	1.000
:Event_0000003	canonical_mention.actual	"conflict"	syria_latimes__1000-01-01__timeline:10834-10841	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000000	syria_latimes__1000-01-01__timeline:10827-10832	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"war"	syria_latimes__1000-01-01__timeline:8427-8429	1.000
:Event_0000003	canonical_mention.actual	"war"	syria_latimes__1000-01-01__timeline:8427-8429	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000064	syria_latimes__1000-01-01__timeline:8408-8414	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"conflict"	syria_latimes__1000-01-01__timeline:14538-14545	1.000
:Event_0000003	canonical_mention.actual	"conflict"	syria_latimes__1000-01-01__timeline:14538-14545	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000000	syria_latimes__1000-01-01__timeline:14531-14536	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"fighting"	syria_latimes__1000-01-01__timeline:13656-13663	1.000
:Event_0000003	canonical_mention.actual	"fighting"	syria_latimes__1000-01-01__timeline:13656-13663	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000000	syria_latimes__1000-01-01__timeline:13668-13672	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"war"	syria_latimes__1000-01-01__timeline:13268-13270	1.000
:Event_0000003	canonical_mention.actual	"war"	syria_latimes__1000-01-01__timeline:13268-13270	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"conflict"	syria_sbs__1000-01-01__timeline:1631-1638	1.000
:Event_0000003	canonical_mention.actual	"conflict"	syria_sbs__1000-01-01__timeline:1631-1638	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000000	syria_sbs__1000-01-01__timeline:1625-1629	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"assault"	syria_latimes__1000-01-01__timeline:13894-13900	1.000
:Event_0000004	canonical_mention.actual	"assault"	syria_latimes__1000-01-01__timeline:13894-13900	1.000
:Event_0000004	Conflict.Attack_Attacker.actual	:Entity_EDL_0000184	syria_latimes__1000-01-01__timeline:13782-13787	1.000
:Event_0000004	Conflict.Attack_Place.actual	:Entity_EDL_0000001	syria_latimes__1000-01-01__timeline:13880-13887	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"assault"	syria_dailystar__1000-01-01__timeline:2113-2119	1.000
:Event_0000004	canonical_mention.actual	"assault"	syria_dailystar__1000-01-01__timeline:2113-2119	1.000
:Event_0000004	Conflict.Attack_Attacker.actual	:Entity_EDL_0000127	syria_dailystar__1000-01-01__timeline:2088-2095	1.000
:Event_0000004	Conflict.Attack_Target.actual	:Entity_EDL_0000125	syria_dailystar__1000-01-01__timeline:2142-2148	1.000
:Event_0000004	Conflict.Attack_Instrument.actual	:Entity_EDL_0000166	syria_dailystar__1000-01-01__timeline:2230-2237	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"assault"	syria_latimes__1000-01-01__timeline:5461-5467	1.000
:Event_0000004	canonical_mention.actual	"assault"	syria_latimes__1000-01-01__timeline:5461-5467	1.000
:Event_0000004	Conflict.Attack_Attacker.actual	:Entity_EDL_0000238	syria_latimes__1000-01-01__timeline:5370-5375	1.000
:Event_0000004	Conflict.Attack_Place.actual	:Entity_EDL_0000108	syria_latimes__1000-01-01__timeline:5474-5477	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"attack"	syria_latimes__1000-01-01__timeline:13833-13838	1.000
:Event_0000004	canonical_mention.actual	"attack"	syria_latimes__1000-01-01__timeline:13833-13838	1.000
:Event_0000004	Conflict.Attack_Attacker.actual	:Entity_EDL_0000184	syria_latimes__1000-01-01__timeline:13782-13787	1.000
:Event_0000004	Conflict.Attack_Target.actual	:Entity_EDL_0000143	syria_latimes__1000-01-01__timeline:13864-13875	1.000
:Event_0000004	Conflict.Attack_Place.actual	:Entity_EDL_0000001	syria_latimes__1000-01-01__timeline:13880-13887	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"assault"	syria_latimes__1000-01-01__timeline:1544-1550	1.000
:Event_0000004	canonical_mention.actual	"assault"	syria_latimes__1000-01-01__timeline:1544-1550	1.000
:Event_0000004	Conflict.Attack_Target.actual	:Entity_EDL_0000265	syria_latimes__1000-01-01__timeline:1474-1479	1.000
:Event_0000004	Conflict.Attack_Attacker.actual	:Entity_EDL_0000256	syria_latimes__1000-01-01__timeline:1523-1528	1.000
:Event_0000004	Conflict.Attack_Place.actual	:Entity_EDL_0000271	syria_latimes__1000-01-01__timeline:1567-1570	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"downed"	syria_latimes__1000-01-01__timeline:12238-12243	1.000
:Event_0000005	canonical_mention.actual	"downed"	syria_latimes__1000-01-01__timeline:12238-12243	1.000
:Event_0000005	Conflict.Attack_Attacker.actual	:Entity_EDL_0000293	syria_latimes__1000-01-01__timeline:12235-12236	1.000
:Event_0000005	Conflict.Attack_Target.actual	:Entity_EDL_0000109	syria_latimes__1000-01-01__timeline:12249-12251	1.000
:Event_0000005	Conflict.Attack_Place.actual	:Entity_EDL_0000301	syria_latimes__1000-01-01__timeline:12292-12299	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"shoots down"	syria_latimes__1000-01-01__timeline:11993-12003	1.000
:Event_0000005	canonical_mention.actual	"shoots down"	syria_latimes__1000-01-01__timeline:11993-12003	1.000
:Event_0000005	Conflict.Attack_Attacker.actual	:Entity_EDL_0000000	syria_latimes__1000-01-01__timeline:11987-11991	1.000
:Event_0000005	Conflict.Attack_Target.actual	:Entity_EDL_0000165	syria_latimes__1000-01-01__timeline:12024-12026	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"shot down"	syria_latimes__1000-01-01__timeline:12078-12086	1.000
:Event_0000005	canonical_mention.actual	"shot down"	syria_latimes__1000-01-01__timeline:12078-12086	1.000
:Event_0000005	Conflict.Attack_Target.actual	:Entity_EDL_0000255	syria_latimes__1000-01-01__timeline:12071-12072	1.000
:Event_0000005	Conflict.Attack_Place.actual	:Entity_EDL_0000260	syria_latimes__1000-01-01__timeline:12106-12113	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"attacks"	syria_latimes__1000-01-01__timeline:13103-13109	1.000
:Event_0000005	canonical_mention.actual	"attacks"	syria_latimes__1000-01-01__timeline:13103-13109	1.000
:Event_0000005	Conflict.Attack_Attacker.actual	:Entity_EDL_0000300	syria_latimes__1000-01-01__timeline:13082-13091	1.000
:Event_0000005	Conflict.Attack_Target.actual	:Entity_EDL_0000272	syria_latimes__1000-01-01__timeline:13125-13132	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"attack"	syria_latimes__1000-01-01__timeline:4725-4730	1.000
:Event_0000005	canonical_mention.actual	"attack"	syria_latimes__1000-01-01__timeline:4725-4730	1.000
:Event_0000005	Conflict.Attack_Attacker.actual	:Entity_EDL_0000298	syria_latimes__1000-01-01__timeline:4718-4723	1.000
:Event_0000005	Conflict.Attack_Target.actual	:Entity_EDL_0000161	syria_latimes__1000-01-01__timeline:4732-4741	1.000
:Event_0000005	Conflict.Attack_Place.actual	:Entity_EDL_0000141	syria_latimes__1000-01-01__timeline:4754-4760	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"killed"	syria_bbc__1000-01-01__timeline:125-130	1.000
:Event_0000006	canonical_mention.actual	"killed"	syria_bbc__1000-01-01__timeline:125-130	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000000	syria_bbc__1000-01-01__timeline:15-20	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000148	syria_bbc__1000-01-01__timeline:109-118	1.000
:Event_0000006	Life.Die_Agent.actual	:Entity_EDL_0000218	syria_bbc__1000-01-01__timeline:144-149	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"died"	syria_bbc__1000-01-01__timeline:2147-2150	1.000
:Event_0000006	canonical_mention.actual	"died"	syria_bbc__1000-01-01__timeline:2147-2150	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000257	syria_bbc__1000-01-01__timeline:2118-2124	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000268	syria_bbc__1000-01-01__timeline:2140-2145	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000259	syria_bbc__1000-01-01__timeline:2203-2210	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"killed"	syria_dailystar__1000-01-01__timeline:974-979	1.000
:Event_0000006	canonical_mention.actual	"killed"	syria_dailystar__1000-01-01__timeline:974-979	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000135	syria_dailystar__1000-01-01__timeline:928-933	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000190	syria_dailystar__1000-01-01__timeline:950-957	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000033	syria_dailystar__1000-01-01__timeline:966-970	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000284	syria_dailystar__1000-01-01__timeline:984-988	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"deaths"	syria_bbc__1000-01-01__timeline:3270-3275	1.000
:Event_0000006	canonical_mention.actual	"deaths"	syria_bbc__1000-01-01__timeline:3270-3275	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000110	syria_bbc__1000-01-01__timeline:3290-3295	1.000
:Event_0000006	Life.Die_Place.actual	:Entity_EDL_0000007	syria_bbc__1000-01-01__timeline:3300-3306	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"massacres"	syria_bbc__1000-01-01__timeline:2563-2571	1.000
:Event_0000007	canonical_mention.actual	"massacres"	syria_bbc__1000-01-01__timeline:2563-2571	1.000
:Event_0000007	Conflict.Attack_Place.actual	:Entity_EDL_0000227	syria_bbc__1000-01-01__timeline:2484-2490	1.000
:Event_0000007	Conflict.Attack_Place.actual	:Entity_EDL_0000000	syria_bbc__1000-01-01__timeline:2576-2580	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"massacre"	syria_bbc__1000-01-01__timeline:1219-1226	1.000
:Event_0000007	canonical_mention.actual	"massacre"	syria_bbc__1000-01-01__timeline:1219-1226	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"massacre"	syria_bbc__1000-01-01__timeline:707-714	1.000
:Event_0000007	canonical_mention.actual	"massacre"	syria_bbc__1000-01-01__timeline:707-714	1.000
:Event_0000007	Conflict.Attack_Place.actual	:Entity_EDL_0000267	syria_bbc__1000-01-01__timeline:630-637	1.000
:Event_0000007	Conflict.Attack_Target.actual	:Entity_EDL_0000263	syria_bbc__1000-01-01__timeline:724-732	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"massacre"	syria_dailystar__1000-01-01__timeline:1053-1060	1.000
:Event_0000007	canonical_mention.actual	"massacre"	syria_dailystar__1000-01-01__timeline:1053-1060	1.000
:Event_0000008	type	Life.Die
:Event_0000008	mention.actual	"killings"	syria_latimes__1000-01-01__timeline:12635-12642	1.000
:Event_0000008	canonical_mention.actual	"killings"	syria_latimes__1000-01-01__timeline:12635-12642	1.000
:Event_0000008	Life.Die_Place.actual	:Entity_EDL_0000212	syria_latimes__1000-01-01__timeline:12576-12579	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000296	syria_latimes__1000-01-01__timeline:12675-12683	1.000
:Event_0000008	type	Life.Die
:Event_0000008	mention.actual	"killing"	syria_latimes__1000-01-01__timeline:13614-13620	1.000
:Event_0000008	canonical_mention.actual	"killing"	syria_latimes__1000-01-01__timeline:13614-13620	1.000
:Event_0000008	Life.Die_Place.actual	:Entity_EDL_0000095	syria_latimes__1000-01-01__timeline:13547-13552	1.000
:Event_0000008	Life.Die_Place.actual	:Entity_EDL_0000000	syria_latimes__1000-01-01__timeline:13668-13672	1.000
:Event_0000008	type	Life.Die
:Event_0000008	mention.actual	"killed"	syria_latimes__1000-01-01__timeline:11580-11585	1.000
:Event_0000008	canonical_mention.actual	"killed"	syria_latimes__1000-01-01__timeline:11580-11585	1.000
:Event_0000008	Life.Die_Place.actual	:Entity_EDL_0000072	syria_latimes__1000-01-01__timeline:11509-11520	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000188	syria_latimes__1000-01-01__timeline:11532-11537	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000285	syria_latimes__1000-01-01__timeline:11554-11558	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000273	syria_latimes__1000-01-01__timeline:11564-11571	1.000
:Event_0000008	Life.Die_Agent.actual	:Entity_EDL_0000224	syria_latimes__1000-01-01__timeline:11648-11653	1.000
:Event_0000009	type	Life.Die
:Event_0000009	mention.actual	"dead"	syria_latimes__1000-01-01__timeline:4104-4107	1.000
:Event_0000009	canonical_mention.actual	"dead"	syria_latimes__1000-01-01__timeline:4104-4107	1.000
:Event_0000009	Life.Die_Victim.actual	:Entity_EDL_0000077	syria_latimes__1000-01-01__timeline:4069-4078	1.000
:Event_0000009	Life.Die_Victim.actual	:Entity_EDL_0000113	syria_latimes__1000-01-01__timeline:4101-4102	1.000
:Event_0000009	type	Life.Die
:Event_0000009	mention.actual	"killed"	syria_latimes__1000-01-01__timeline:1485-1490	1.000
:Event_0000009	canonical_mention.actual	"killed"	syria_latimes__1000-01-01__timeline:1485-1490	1.000
:Event_0000009	Life.Die_Victim.actual	:Entity_EDL_0000265	syria_latimes__1000-01-01__timeline:1474-1479	1.000
:Event_0000009	Life.Die_Agent.actual	:Entity_EDL_0000256	syria_latimes__1000-01-01__timeline:1523-1528	1.000
:Event_0000009	Life.Die_Place.actual	:Entity_EDL_0000271	syria_latimes__1000-01-01__timeline:1567-1570	1.000
:Event_0000009	type	Life.Die
:Event_0000009	mention.actual	"killed"	syria_latimes__1000-01-01__timeline:4314-4319	1.000
:Event_0000009	canonical_mention.actual	"killed"	syria_latimes__1000-01-01__timeline:4314-4319	1.000
:Event_0000009	Life.Die_Victim.actual	:Entity_EDL_0000055	syria_latimes__1000-01-01__timeline:4299-4308	1.000
:Event_0000009	Life.Die_Agent.actual	:Entity_EDL_0000239	syria_latimes__1000-01-01__timeline:4335-4340	1.000
:Event_0000009	Life.Die_Place.actual	:Entity_EDL_0000114	syria_latimes__1000-01-01__timeline:4367-4372	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"crackdown"	syria_latimes__1000-01-01__timeline:1984-1992	1.000
:Event_0000010	canonical_mention.actual	"crackdown"	syria_latimes__1000-01-01__timeline:1984-1992	1.000
:Event_0000010	Conflict.Attack_Attacker.actual	:Entity_EDL_0000126	syria_latimes__1000-01-01__timeline:1954-1959	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"crackdown"	syria_latimes__1000-01-01__timeline:6989-6997	1.000
:Event_0000010	canonical_mention.actual	"crackdown"	syria_latimes__1000-01-01__timeline:6989-6997	1.000
:Event_0000010	Conflict.Attack_Attacker.actual	:Entity_EDL_0000048	syria_latimes__1000-01-01__timeline:6971-6977	1.000
:Event_0000010	Conflict.Attack_Target.actual	:Entity_EDL_0000089	syria_latimes__1000-01-01__timeline:7016-7025	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"bloody crackdown"	syria_latimes__1000-01-01__timeline:3085-3100	1.000
:Event_0000010	canonical_mention.actual	"bloody crackdown"	syria_latimes__1000-01-01__timeline:3085-3100	1.000
:Event_0000010	Conflict.Attack_Target.actual	:Entity_EDL_0000035	syria_latimes__1000-01-01__timeline:3119-3128	1.000
:Event_0000011	type	Conflict.Attack
:Event_0000011	mention.actual	"massacre"	syria_latimes__1000-01-01__timeline:12567-12574	1.000
:Event_0000011	canonical_mention.actual	"massacre"	syria_latimes__1000-01-01__timeline:12567-12574	1.000
:Event_0000011	Conflict.Attack_Place.actual	:Entity_EDL_0000212	syria_latimes__1000-01-01__timeline:12576-12579	1.000
:Event_0000011	Conflict.Attack_Place.actual	:Entity_EDL_0000226	syria_latimes__1000-01-01__timeline:12584-12591	1.000
:Event_0000011	Conflict.Attack_Target.actual	:Entity_EDL_0000296	syria_latimes__1000-01-01__timeline:12675-12683	1.000
:Event_0000011	type	Conflict.Attack
:Event_0000011	mention.actual	"slaughter"	syria_latimes__1000-01-01__timeline:12662-12670	1.000
:Event_0000011	canonical_mention.actual	"slaughter"	syria_latimes__1000-01-01__timeline:12662-12670	1.000
:Event_0000011	Conflict.Attack_Place.actual	:Entity_EDL_0000226	syria_latimes__1000-01-01__timeline:12584-12591	1.000
:Event_0000011	Conflict.Attack_Target.actual	:Entity_EDL_0000296	syria_latimes__1000-01-01__timeline:12675-12683	1.000
:Event_0000011	Conflict.Attack_Attacker.actual	:Entity_EDL_0000204	syria_latimes__1000-01-01__timeline:12729-12734	1.000
:Event_0000012	type	Business.Start
:Event_0000012	mention.actual	"forming"	syria_latimes__1000-01-01__timeline:14823-14829	1.000
:Event_0000012	canonical_mention.actual	"forming"	syria_latimes__1000-01-01__timeline:14823-14829	1.000
:Event_0000012	Business.Start_Organization.actual	:Entity_EDL_0000107	syria_latimes__1000-01-01__timeline:14837-14845	1.000
:Event_0000012	type	Business.Start
:Event_0000012	mention.actual	"form"	syria_latimes__1000-01-01__timeline:15080-15083	1.000
:Event_0000012	canonical_mention.actual	"form"	syria_latimes__1000-01-01__timeline:15080-15083	1.000
:Event_0000012	Business.Start_Place.actual	:Entity_EDL_0000200	syria_latimes__1000-01-01__timeline:15045-15051	1.000
:Event_0000012	Business.Start_Agent.actual	:Entity_EDL_0000202	syria_latimes__1000-01-01__timeline:15069-15078	1.000
:Event_0000012	Business.Start_Organization.actual	:Entity_EDL_0000167	syria_latimes__1000-01-01__timeline:15089-15153	1.000
:Event_0000013	type	Conflict.Attack
:Event_0000013	mention.actual	"clashes"	syria_latimes__1000-01-01__timeline:12702-12708	1.000
:Event_0000013	canonical_mention.actual	"clashes"	syria_latimes__1000-01-01__timeline:12702-12708	1.000
:Event_0000013	Conflict.Attack_Target.actual	:Entity_EDL_0000204	syria_latimes__1000-01-01__timeline:12729-12734	1.000
:Event_0000013	Conflict.Attack_Attacker.actual	:Entity_EDL_0000306	syria_latimes__1000-01-01__timeline:12740-12749	1.000
:Event_0000013	type	Conflict.Attack
:Event_0000013	mention.actual	"clashes"	syria_latimes__1000-01-01__timeline:2659-2665	1.000
:Event_0000013	canonical_mention.actual	"clashes"	syria_latimes__1000-01-01__timeline:2659-2665	1.000
:Event_0000013	Conflict.Attack_Place.actual	:Entity_EDL_0000067	syria_latimes__1000-01-01__timeline:2678-2683	1.000
:Event_0000014	type	Personnel.EndPosition
:Event_0000014	mention.actual	"quit"	syria_sbs__1000-01-01__timeline:179-182	1.000
:Event_0000014	canonical_mention.actual	"quit"	syria_sbs__1000-01-01__timeline:179-182	1.000
:Event_0000014	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000124	syria_sbs__1000-01-01__timeline:124-125	1.000
:Event_0000014	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	syria_sbs__1000-01-01__timeline:170-174	1.000
:Event_0000014	type	Personnel.EndPosition
:Event_0000014	mention.actual	"step down"	syria_washington__1000-01-01__timeline:582-590	1.000
:Event_0000014	canonical_mention.actual	"step down"	syria_washington__1000-01-01__timeline:582-590	1.000
:Event_0000014	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	syria_washington__1000-01-01__timeline:573-577	1.000
:Event_0000015	type	Life.Die
:Event_0000015	mention.actual	"suicide"	syria_bbc__1000-01-01__timeline:2095-2101	1.000
:Event_0000015	canonical_mention.actual	"suicide"	syria_bbc__1000-01-01__timeline:2095-2101	1.000
:Event_0000015	Life.Die_Victim.actual	:Entity_EDL_0000115	syria_bbc__1000-01-01__timeline:2103-2109	1.000
:Event_0000015	Life.Die_Place.actual	:Entity_EDL_0000257	syria_bbc__1000-01-01__timeline:2118-2124	1.000
:Event_0000015	type	Life.Die
:Event_0000015	mention.actual	"suicide"	syria_bbc__1000-01-01__timeline:3892-3898	1.000
:Event_0000015	canonical_mention.actual	"suicide"	syria_bbc__1000-01-01__timeline:3892-3898	1.000
:Event_0000015	Life.Die_Place.actual	:Entity_EDL_0000090	syria_bbc__1000-01-01__timeline:3960-3971	1.000
:Event_0000016	type	Conflict.Demonstrate
:Event_0000016	mention.actual	"uprising"	syria_bbc__1000-01-01__timeline:2585-2592	1.000
:Event_0000016	canonical_mention.actual	"uprising"	syria_bbc__1000-01-01__timeline:2585-2592	1.000
:Event_0000016	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	syria_bbc__1000-01-01__timeline:2576-2580	1.000
:Event_0000016	type	Conflict.Demonstrate
:Event_0000016	mention.actual	"uprising"	syria_bbc__1000-01-01__timeline:22-29	1.000
:Event_0000016	canonical_mention.actual	"uprising"	syria_bbc__1000-01-01__timeline:22-29	1.000
:Event_0000016	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	syria_bbc__1000-01-01__timeline:15-20	1.000
:Event_0000017	type	Conflict.Attack
:Event_0000017	mention.actual	"offensive"	syria_latimes__1000-01-01__timeline:9867-9875	1.000
:Event_0000017	canonical_mention.actual	"offensive"	syria_latimes__1000-01-01__timeline:9867-9875	1.000
:Event_0000017	Conflict.Attack_Target.actual	:Entity_EDL_0000248	syria_latimes__1000-01-01__timeline:9885-9890	1.000
:Event_0000017	Conflict.Attack_Place.actual	:Entity_EDL_0000139	syria_latimes__1000-01-01__timeline:9917-9925	1.000
:Event_0000017	type	Conflict.Attack
:Event_0000017	mention.actual	"offensive"	syria_sbs__1000-01-01__timeline:1503-1511	1.000
:Event_0000017	canonical_mention.actual	"offensive"	syria_sbs__1000-01-01__timeline:1503-1511	1.000
:Event_0000017	Conflict.Attack_Attacker.actual	:Entity_EDL_0000282	syria_sbs__1000-01-01__timeline:1479-1484	1.000
:Event_0000017	Conflict.Attack_Place.actual	:Entity_EDL_0000232	syria_sbs__1000-01-01__timeline:1518-1523	1.000
:Event_0000018	type	Life.Die
:Event_0000018	mention.actual	"killed"	syria_bbc__1000-01-01__timeline:2641-2646	1.000
:Event_0000018	canonical_mention.actual	"killed"	syria_bbc__1000-01-01__timeline:2641-2646	1.000
:Event_0000018	Life.Die_Victim.actual	:Entity_EDL_0000254	syria_bbc__1000-01-01__timeline:2629-2634	1.000
:Event_0000018	Life.Die_Victim.actual	:Entity_EDL_0000205	syria_bbc__1000-01-01__timeline:2673-2680	1.000
:Event_0000018	type	Life.Die
:Event_0000018	mention.actual	"killed"	syria_bbc__1000-01-01__timeline:3569-3574	1.000
:Event_0000018	canonical_mention.actual	"killed"	syria_bbc__1000-01-01__timeline:3569-3574	1.000
:Event_0000018	Life.Die_Victim.actual	:Entity_EDL_0000235	syria_bbc__1000-01-01__timeline:3557-3562	1.000
:Event_0000018	Life.Die_Victim.actual	:Entity_EDL_0000225	syria_bbc__1000-01-01__timeline:3606-3613	1.000
:Event_0000019	type	Conflict.Attack
:Event_0000019	mention.actual	"bombing"	syria_washington__1000-01-01__timeline:1994-2000	1.000
:Event_0000019	canonical_mention.actual	"bombing"	syria_washington__1000-01-01__timeline:1994-2000	1.000
:Event_0000019	Conflict.Attack_Target.actual	:Entity_EDL_0000237	syria_washington__1000-01-01__timeline:2009-2025	1.000
:Event_0000019	Conflict.Attack_Target.actual	:Entity_EDL_0000157	syria_washington__1000-01-01__timeline:2027-2034	1.000
:Event_0000019	Conflict.Attack_Place.actual	:Entity_EDL_0000003	syria_washington__1000-01-01__timeline:2039-2046	1.000
:Event_0000019	type	Conflict.Attack
:Event_0000019	mention.actual	"attack"	syria_sbs__1000-01-01__timeline:856-861	1.000
:Event_0000019	canonical_mention.actual	"attack"	syria_sbs__1000-01-01__timeline:856-861	1.000
:Event_0000019	Conflict.Attack_Place.actual	:Entity_EDL_0000001	syria_sbs__1000-01-01__timeline:847-854	1.000
:Event_0000020	type	Life.Die
:Event_0000020	mention.actual	"dead"	syria_washington__1000-01-01__timeline:226-229	1.000
:Event_0000020	canonical_mention.actual	"dead"	syria_washington__1000-01-01__timeline:226-229	1.000
:Event_0000020	Life.Die_Place.actual	:Entity_EDL_0000211	syria_washington__1000-01-01__timeline:164-167	1.000
:Event_0000020	Life.Die_Agent.actual	:Entity_EDL_0000120	syria_washington__1000-01-01__timeline:194-199	1.000
:Event_0000020	Life.Die_Victim.actual	:Entity_EDL_0000059	syria_washington__1000-01-01__timeline:219-224	1.000
:Event_0000020	type	Life.Die
:Event_0000020	mention.actual	"dead"	syria_washington__1000-01-01__timeline:428-431	1.000
:Event_0000020	canonical_mention.actual	"dead"	syria_washington__1000-01-01__timeline:428-431	1.000
:Event_0000020	Life.Die_Victim.actual	:Entity_EDL_0000084	syria_washington__1000-01-01__timeline:421-426	1.000
:Event_0000020	Life.Die_Instrument.actual	:Entity_EDL_0000040	syria_washington__1000-01-01__timeline:444-448	1.000
:Event_0000020	Life.Die_Place.actual	:Entity_EDL_0000219	syria_washington__1000-01-01__timeline:460-463	1.000
:Event_0000021	type	Life.Die
:Event_0000021	mention.actual	"killed"	syria_bbc__1000-01-01__timeline:3880-3885	1.000
:Event_0000021	canonical_mention.actual	"killed"	syria_bbc__1000-01-01__timeline:3880-3885	1.000
:Event_0000021	Life.Die_Victim.actual	:Entity_EDL_0000130	syria_bbc__1000-01-01__timeline:3796-3807	1.000
:Event_0000021	Life.Die_Victim.actual	:Entity_EDL_0000251	syria_bbc__1000-01-01__timeline:3817-3822	1.000
:Event_0000021	Life.Die_Victim.actual	:Entity_EDL_0000156	syria_bbc__1000-01-01__timeline:3824-3836	1.000
:Event_0000021	Life.Die_Place.actual	:Entity_EDL_0000090	syria_bbc__1000-01-01__timeline:3960-3971	1.000
:Event_0000022	type	Life.Die
:Event_0000022	mention.actual	"deaths"	syria_latimes__1000-01-01__timeline:2704-2709	1.000
:Event_0000022	canonical_mention.actual	"deaths"	syria_latimes__1000-01-01__timeline:2704-2709	1.000
:Event_0000022	Life.Die_Place.actual	:Entity_EDL_0000067	syria_latimes__1000-01-01__timeline:2678-2683	1.000
:Event_0000023	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000023	mention.actual	"crimes"	syria_latimes__1000-01-01__timeline:8145-8150	1.000
:Event_0000023	canonical_mention.actual	"crimes"	syria_latimes__1000-01-01__timeline:8145-8150	1.000
:Event_0000023	GenericCrime.GenericCrime.GenericCrime_Perpetrator.actual	:Entity_EDL_0000000	syria_latimes__1000-01-01__timeline:8002-8006	1.000
:Event_0000023	GenericCrime.GenericCrime.GenericCrime_Perpetrator.actual	:Entity_EDL_0000045	syria_latimes__1000-01-01__timeline:8124-8129	1.000
:Event_0000024	type	Conflict.Attack
:Event_0000024	mention.actual	"strikes"	syria_sbs__1000-01-01__timeline:2212-2218	1.000
:Event_0000024	canonical_mention.actual	"strikes"	syria_sbs__1000-01-01__timeline:2212-2218	1.000
:Event_0000024	Conflict.Attack_Place.actual	:Entity_EDL_0000000	syria_sbs__1000-01-01__timeline:2149-2153	1.000
:Event_0000024	Conflict.Attack_Attacker.actual	:Entity_EDL_0000008	syria_sbs__1000-01-01__timeline:2201-2206	1.000
:Event_0000025	type	Conflict.Attack
:Event_0000025	mention.actual	"clashes"	syria_dailystar__1000-01-01__timeline:1707-1713	1.000
:Event_0000025	canonical_mention.actual	"clashes"	syria_dailystar__1000-01-01__timeline:1707-1713	1.000
:Event_0000025	Conflict.Attack_Attacker.actual	:Entity_EDL_0000129	syria_dailystar__1000-01-01__timeline:1616-1621	1.000
:Event_0000025	Conflict.Attack_Place.actual	:Entity_EDL_0000087	syria_dailystar__1000-01-01__timeline:1671-1677	1.000
:Event_0000026	type	Conflict.Attack
:Event_0000026	mention.actual	"shelling"	syria_latimes__1000-01-01__timeline:9043-9050	1.000
:Event_0000026	canonical_mention.actual	"shelling"	syria_latimes__1000-01-01__timeline:9043-9050	1.000
:Event_0000026	Conflict.Attack_Attacker.actual	:Entity_EDL_0000101	syria_latimes__1000-01-01__timeline:9032-9041	1.000
:Event_0000026	Conflict.Attack_Place.actual	:Entity_EDL_0000079	syria_latimes__1000-01-01__timeline:9122-9125	1.000
:Event_0000027	type	Conflict.Attack
:Event_0000027	mention.actual	"shoot down"	syria_washington__1000-01-01__timeline:2380-2389	1.000
:Event_0000027	canonical_mention.actual	"shoot down"	syria_washington__1000-01-01__timeline:2380-2389	1.000
:Event_0000027	Conflict.Attack_Attacker.actual	:Entity_EDL_0000258	syria_washington__1000-01-01__timeline:2373-2378	1.000
:Event_0000027	Conflict.Attack_Target.actual	:Entity_EDL_0000026	syria_washington__1000-01-01__timeline:2400-2409	1.000
:Event_0000027	Conflict.Attack_Place.actual	:Entity_EDL_0000289	syria_washington__1000-01-01__timeline:2414-2418	1.000
:Event_0000028	type	Life.Die
:Event_0000028	mention.actual	"killing"	syria_latimes__1000-01-01__timeline:3427-3433	1.000
:Event_0000028	canonical_mention.actual	"killing"	syria_latimes__1000-01-01__timeline:3427-3433	1.000
:Event_0000028	Life.Die_Agent.actual	:Entity_EDL_0000016	syria_latimes__1000-01-01__timeline:3315-3320	1.000
:Event_0000028	Life.Die_Victim.actual	:Entity_EDL_0000160	syria_latimes__1000-01-01__timeline:3444-3445	1.000
:Event_0000029	type	Conflict.Attack
:Event_0000029	mention.actual	"explosion"	syria_washington__1000-01-01__timeline:2860-2868	1.000
:Event_0000029	canonical_mention.actual	"explosion"	syria_washington__1000-01-01__timeline:2860-2868	1.000
:Event_0000029	Conflict.Attack_Instrument.actual	:Entity_EDL_0000286	syria_washington__1000-01-01__timeline:2762-2769	1.000
:Event_0000029	Conflict.Attack_Place.actual	:Entity_EDL_0000246	syria_washington__1000-01-01__timeline:2791-2800	1.000
:Event_0000030	type	Life.Die
:Event_0000030	mention.actual	"killed"	syria_latimes__1000-01-01__timeline:379-384	1.000
:Event_0000030	canonical_mention.actual	"killed"	syria_latimes__1000-01-01__timeline:379-384	1.000
:Event_0000030	Life.Die_Victim.actual	:Entity_EDL_0000092	syria_latimes__1000-01-01__timeline:361-373	1.000
:Event_0000030	Life.Die_Place.actual	:Entity_EDL_0000001	syria_latimes__1000-01-01__timeline:389-396	1.000
:Event_0000031	type	Conflict.Attack
:Event_0000031	mention.actual	"shell"	syria_latimes__1000-01-01__timeline:11256-11260	1.000
:Event_0000031	canonical_mention.actual	"shell"	syria_latimes__1000-01-01__timeline:11256-11260	1.000
:Event_0000031	Conflict.Attack_Place.actual	:Entity_EDL_0000082	syria_latimes__1000-01-01__timeline:11201-11207	1.000
:Event_0000031	Conflict.Attack_Attacker.actual	:Entity_EDL_0000309	syria_latimes__1000-01-01__timeline:11237-11242	1.000
:Event_0000031	Conflict.Attack_Target.actual	:Entity_EDL_0000213	syria_latimes__1000-01-01__timeline:11262-11267	1.000
:Event_0000032	type	Conflict.Demonstrate
:Event_0000032	mention.actual	"protest"	syria_latimes__1000-01-01__timeline:2033-2039	1.000
:Event_0000032	canonical_mention.actual	"protest"	syria_latimes__1000-01-01__timeline:2033-2039	1.000
:Event_0000032	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000025	syria_latimes__1000-01-01__timeline:2016-2024	1.000
:Event_0000033	type	Conflict.Demonstrate
:Event_0000033	mention.actual	"protests"	syria_sbs__1000-01-01__timeline:17-24	1.000
:Event_0000033	canonical_mention.actual	"protests"	syria_sbs__1000-01-01__timeline:17-24	1.000
:Event_0000034	type	Conflict.Attack
:Event_0000034	mention.actual	"massacre"	syria_washington__1000-01-01__timeline:2232-2239	1.000
:Event_0000034	canonical_mention.actual	"massacre"	syria_washington__1000-01-01__timeline:2232-2239	1.000
:Event_0000034	Conflict.Attack_Attacker.actual	:Entity_EDL_0000112	syria_washington__1000-01-01__timeline:2195-2202	1.000
:Event_0000034	Conflict.Attack_Target.actual	:Entity_EDL_0000210	syria_washington__1000-01-01__timeline:2258-2266	1.000
:Event_0000034	Conflict.Attack_Place.actual	:Entity_EDL_0000174	syria_washington__1000-01-01__timeline:2299-2305	1.000
:Event_0000035	type	Business.Start
:Event_0000035	mention.actual	"Creation"	syria_sbs__1000-01-01__timeline:295-302	1.000
:Event_0000035	canonical_mention.actual	"Creation"	syria_sbs__1000-01-01__timeline:295-302	1.000
:Event_0000035	Business.Start_Organization.actual	:Entity_EDL_0000183	syria_sbs__1000-01-01__timeline:322-348	1.000
:Event_0000036	type	Conflict.Attack
:Event_0000036	mention.actual	"fire"	syria_bbc__1000-01-01__timeline:2715-2718	1.000
:Event_0000036	canonical_mention.actual	"fire"	syria_bbc__1000-01-01__timeline:2715-2718	1.000
:Event_0000036	Conflict.Attack_Target.actual	:Entity_EDL_0000187	syria_bbc__1000-01-01__timeline:2685-2688	1.000
:Event_0000036	Conflict.Attack_Instrument.actual	:Entity_EDL_0000203	syria_bbc__1000-01-01__timeline:2709-2713	1.000
:Event_0000037	type	Personnel.Elect
:Event_0000037	mention.actual	"elected"	syria_washington__1000-01-01__timeline:4761-4767	1.000
:Event_0000037	canonical_mention.actual	"elected"	syria_washington__1000-01-01__timeline:4761-4767	1.000
:Event_0000037	Personnel.Elect_Elect.actual	:Entity_EDL_0000264	syria_washington__1000-01-01__timeline:4674-4687	1.000
:Event_0000037	Personnel.Elect_Elect.actual	:Entity_EDL_0000075	syria_washington__1000-01-01__timeline:4712-4717	1.000
:Event_0000037	Personnel.Elect_Elector.actual	:Entity_EDL_0000269	syria_washington__1000-01-01__timeline:4781-4807	1.000
:Event_0000038	type	Conflict.Attack
:Event_0000038	mention.actual	"gunfire"	syria_latimes__1000-01-01__timeline:5086-5092	1.000
:Event_0000038	canonical_mention.actual	"gunfire"	syria_latimes__1000-01-01__timeline:5086-5092	1.000
:Event_0000038	Conflict.Attack_Attacker.actual	:Entity_EDL_0000080	syria_latimes__1000-01-01__timeline:5010-5015	1.000
:Event_0000038	Conflict.Attack_Place.actual	:Entity_EDL_0000279	syria_latimes__1000-01-01__timeline:5060-5063	1.000
:Event_0000039	type	Conflict.Attack
:Event_0000039	mention.actual	"fire"	syria_latimes__1000-01-01__timeline:3390-3393	1.000
:Event_0000039	canonical_mention.actual	"fire"	syria_latimes__1000-01-01__timeline:3390-3393	1.000
:Event_0000039	Conflict.Attack_Attacker.actual	:Entity_EDL_0000016	syria_latimes__1000-01-01__timeline:3315-3320	1.000
:Event_0000039	Conflict.Attack_Target.actual	:Entity_EDL_0000091	syria_latimes__1000-01-01__timeline:3414-3423	1.000
:Event_0000040	type	Life.Die
:Event_0000040	mention.actual	"killed"	syria_latimes__1000-01-01__timeline:4797-4802	1.000
:Event_0000040	canonical_mention.actual	"killed"	syria_latimes__1000-01-01__timeline:4797-4802	1.000
:Event_0000040	Life.Die_Victim.actual	:Entity_EDL_0000116	syria_latimes__1000-01-01__timeline:4777-4782	1.000
:Event_0000040	Life.Die_Place.actual	:Entity_EDL_0000308	syria_latimes__1000-01-01__timeline:4843-4849	1.000
:Event_0000040	Life.Die_Place.actual	:Entity_EDL_0000216	syria_latimes__1000-01-01__timeline:4867-4871	1.000
:Event_0000041	type	Justice.ArrestJail
:Event_0000041	mention.actual	"arrests"	syria_latimes__1000-01-01__timeline:2748-2754	1.000
:Event_0000041	canonical_mention.actual	"arrests"	syria_latimes__1000-01-01__timeline:2748-2754	1.000
:Event_0000041	Justice.ArrestJail_Place.actual	:Entity_EDL_0000067	syria_latimes__1000-01-01__timeline:2678-2683	1.000
:Event_0000042	type	Life.Die
:Event_0000042	mention.actual	"dead"	syria_latimes__1000-01-01__timeline:8932-8935	1.000
:Event_0000042	canonical_mention.actual	"dead"	syria_latimes__1000-01-01__timeline:8932-8935	1.000
:Event_0000042	Life.Die_Place.actual	:Entity_EDL_0000000	syria_latimes__1000-01-01__timeline:8880-8884	1.000
:Event_0000043	type	Personnel.EndPosition
:Event_0000043	mention.actual	"step down"	syria_latimes__1000-01-01__timeline:7727-7735	1.000
:Event_0000043	canonical_mention.actual	"step down"	syria_latimes__1000-01-01__timeline:7727-7735	1.000
:Event_0000043	Personnel.EndPosition_Person.actual	:Entity_EDL_0000217	syria_latimes__1000-01-01__timeline:7715-7722	1.000
:Event_0000044	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000044	mention.actual	"crimes"	syria_washington__1000-01-01__timeline:2218-2223	1.000
:Event_0000044	canonical_mention.actual	"crimes"	syria_washington__1000-01-01__timeline:2218-2223	1.000
:Event_0000044	GenericCrime.GenericCrime.GenericCrime_Perpetrator.actual	:Entity_EDL_0000000	syria_washington__1000-01-01__timeline:2188-2193	1.000
:Event_0000044	GenericCrime.GenericCrime.GenericCrime_Perpetrator.actual	:Entity_EDL_0000112	syria_washington__1000-01-01__timeline:2195-2202	1.000
:Event_0000044	GenericCrime.GenericCrime.GenericCrime_Victim.actual	:Entity_EDL_0000210	syria_washington__1000-01-01__timeline:2258-2266	1.000
:Event_0000044	GenericCrime.GenericCrime.GenericCrime_Place.actual	:Entity_EDL_0000103	syria_washington__1000-01-01__timeline:2310-2314	1.000
:Event_0000045	type	Conflict.Attack
:Event_0000045	mention.actual	"war"	syria_latimes__1000-01-01__timeline:9598-9600	1.000
:Event_0000045	canonical_mention.actual	"war"	syria_latimes__1000-01-01__timeline:9598-9600	1.000
:Event_0000045	Conflict.Attack_Attacker.actual	:Entity_EDL_0000028	syria_latimes__1000-01-01__timeline:9585-9588	1.000
:Event_0000045	Conflict.Attack_Place.actual	:Entity_EDL_0000032	syria_latimes__1000-01-01__timeline:9661-9665	1.000
:Event_0000046	type	Conflict.Attack
:Event_0000046	mention.actual	"violence"	syria_washington__1000-01-01__timeline:4254-4261	1.000
:Event_0000046	canonical_mention.actual	"violence"	syria_washington__1000-01-01__timeline:4254-4261	1.000
:Event_0000046	Conflict.Attack_Place.actual	:Entity_EDL_0000000	syria_washington__1000-01-01__timeline:4266-4270	1.000
:Event_0000047	type	Business.End
:Event_0000047	mention.actual	"collapsing"	syria_dailystar__1000-01-01__timeline:2735-2744	1.000
:Event_0000047	canonical_mention.actual	"collapsing"	syria_dailystar__1000-01-01__timeline:2735-2744	1.000
:Event_0000047	Business.End_Organization.actual	:Entity_EDL_0000193	syria_dailystar__1000-01-01__timeline:2725-2730	1.000
:Event_0000048	type	Conflict.Attack
:Event_0000048	mention.actual	"used"	syria_washington__1000-01-01__timeline:3408-3411	1.000
:Event_0000048	canonical_mention.actual	"used"	syria_washington__1000-01-01__timeline:3408-3411	1.000
:Event_0000048	Conflict.Attack_Attacker.actual	:Entity_EDL_0000000	syria_washington__1000-01-01__timeline:3398-3402	1.000
:Event_0000048	Conflict.Attack_Instrument.actual	:Entity_EDL_0000241	syria_washington__1000-01-01__timeline:3422-3428	1.000
:Event_0000048	Conflict.Attack_Target.actual	:Entity_EDL_0000118	syria_washington__1000-01-01__timeline:3444-3449	1.000
:Event_0000049	type	Life.Injure
:Event_0000049	mention.actual	"bloodshed"	syria_washington__1000-01-01__timeline:4361-4369	1.000
:Event_0000049	canonical_mention.actual	"bloodshed"	syria_washington__1000-01-01__timeline:4361-4369	1.000
:Event_0000049	Life.Injure_Place.actual	:Entity_EDL_0000223	syria_washington__1000-01-01__timeline:4433-4438	1.000
:Event_0000050	type	Conflict.Attack
:Event_0000050	mention.actual	"violence"	syria_sbs__1000-01-01__timeline:2187-2194	1.000
:Event_0000050	canonical_mention.actual	"violence"	syria_sbs__1000-01-01__timeline:2187-2194	1.000
:Event_0000051	type	Life.Die
:Event_0000051	mention.actual	"deaths"	syria_latimes__1000-01-01__timeline:7219-7224	1.000
:Event_0000051	canonical_mention.actual	"deaths"	syria_latimes__1000-01-01__timeline:7219-7224	1.000
:Event_0000052	type	Business.Start
:Event_0000052	mention.actual	"set up"	syria_dailystar__1000-01-01__timeline:424-429	1.000
:Event_0000052	canonical_mention.actual	"set up"	syria_dailystar__1000-01-01__timeline:424-429	1.000
:Event_0000052	Business.Start_Organization.actual	:Entity_EDL_0000274	syria_dailystar__1000-01-01__timeline:401-416	1.000
:Event_0000052	Business.Start_Organization.actual	:Entity_EDL_0000222	syria_dailystar__1000-01-01__timeline:418-420	1.000
:Event_0000052	Business.Start_Place.actual	:Entity_EDL_0000005	syria_dailystar__1000-01-01__timeline:434-439	1.000
:Event_0000052	Business.Start_Agent.actual	:Entity_EDL_0000054	syria_dailystar__1000-01-01__timeline:446-453	1.000
:Event_0000053	type	Conflict.Demonstrate
:Event_0000053	mention.actual	"protest"	syria_washington__1000-01-01__timeline:41-47	1.000
:Event_0000053	canonical_mention.actual	"protest"	syria_washington__1000-01-01__timeline:41-47	1.000
:Event_0000053	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000030	syria_washington__1000-01-01__timeline:11-17	1.000
:Event_0000053	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000236	syria_washington__1000-01-01__timeline:52-59	1.000
:Event_0000054	type	Conflict.Attack
:Event_0000054	mention.actual	"firing"	syria_bbc__1000-01-01__timeline:151-156	1.000
:Event_0000054	canonical_mention.actual	"firing"	syria_bbc__1000-01-01__timeline:151-156	1.000
:Event_0000054	Conflict.Attack_Place.actual	:Entity_EDL_0000000	syria_bbc__1000-01-01__timeline:15-20	1.000
:Event_0000054	Conflict.Attack_Target.actual	:Entity_EDL_0000148	syria_bbc__1000-01-01__timeline:109-118	1.000
:Event_0000054	Conflict.Attack_Attacker.actual	:Entity_EDL_0000218	syria_bbc__1000-01-01__timeline:144-149	1.000
:Event_0000054	Conflict.Attack_Target.actual	:Entity_EDL_0000053	syria_bbc__1000-01-01__timeline:161-166	1.000
:Event_0000055	type	Life.Die
:Event_0000055	mention.actual	"killing"	syria_latimes__1000-01-01__timeline:11295-11301	1.000
:Event_0000055	canonical_mention.actual	"killing"	syria_latimes__1000-01-01__timeline:11295-11301	1.000
:Event_0000055	Life.Die_Agent.actual	:Entity_EDL_0000309	syria_latimes__1000-01-01__timeline:11237-11242	1.000
:Event_0000055	Life.Die_Victim.actual	:Entity_EDL_0000280	syria_latimes__1000-01-01__timeline:11313-11318	1.000
:Event_0000056	type	Conflict.Attack
:Event_0000056	mention.actual	"war"	syria_washington__1000-01-01__timeline:2214-2216	1.000
:Event_0000056	canonical_mention.actual	"war"	syria_washington__1000-01-01__timeline:2214-2216	1.000
:Event_0000056	Conflict.Attack_Attacker.actual	:Entity_EDL_0000112	syria_washington__1000-01-01__timeline:2195-2202	1.000
:Event_0000057	type	Life.Injure
:Event_0000057	mention.actual	"stabbing"	syria_bbc__1000-01-01__timeline:3488-3495	1.000
:Event_0000057	canonical_mention.actual	"stabbing"	syria_bbc__1000-01-01__timeline:3488-3495	1.000
:Event_0000057	Life.Injure_Place.actual	:Entity_EDL_0000088	syria_bbc__1000-01-01__timeline:3405-3411	1.000
:Event_0000057	Life.Injure_Agent.actual	:Entity_EDL_0000024	syria_bbc__1000-01-01__timeline:3453-3462	1.000
:Event_0000057	Life.Injure_Victim.actual	:Entity_EDL_0000022	syria_bbc__1000-01-01__timeline:3497-3503	1.000
:Event_0000058	type	Conflict.Attack
:Event_0000058	mention.actual	"fire"	syria_latimes__1000-01-01__timeline:23-26	1.000
:Event_0000058	canonical_mention.actual	"fire"	syria_latimes__1000-01-01__timeline:23-26	1.000
:Event_0000058	Conflict.Attack_Attacker.actual	:Entity_EDL_0000215	syria_latimes__1000-01-01__timeline:11-16	1.000
:Event_0000058	Conflict.Attack_Target.actual	:Entity_EDL_0000281	syria_latimes__1000-01-01__timeline:31-43	1.000
:Event_0000058	Conflict.Attack_Place.actual	:Entity_EDL_0000138	syria_latimes__1000-01-01__timeline:61-64	1.000
:Event_0000059	type	Movement.TransportArtifact
:Event_0000059	mention.actual	"fleeing"	syria_latimes__1000-01-01__timeline:14416-14422	1.000
:Event_0000059	canonical_mention.actual	"fleeing"	syria_latimes__1000-01-01__timeline:14416-14422	1.000
:Event_0000059	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000027	syria_latimes__1000-01-01__timeline:14363-14366	1.000
:Event_0000059	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000121	syria_latimes__1000-01-01__timeline:14409-14414	1.000
:Event_0000059	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000005	syria_latimes__1000-01-01__timeline:14441-14446	1.000
:Event_0000060	type	Justice.ArrestJail
:Event_0000060	mention.actual	"detentions"	syria_latimes__1000-01-01__timeline:2977-2986	1.000
:Event_0000060	canonical_mention.actual	"detentions"	syria_latimes__1000-01-01__timeline:2977-2986	1.000
:Event_0000060	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000209	syria_latimes__1000-01-01__timeline:3000-3005	1.000
:Event_0000061	type	Justice.ReleaseParole
:Event_0000061	mention.actual	"release"	syria_latimes__1000-01-01__timeline:251-257	1.000
:Event_0000061	canonical_mention.actual	"release"	syria_latimes__1000-01-01__timeline:251-257	1.000
:Event_0000061	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000023	syria_latimes__1000-01-01__timeline:272-280	1.000
:Event_0000062	type	Contact.Meet
:Event_0000062	mention.actual	"meeting"	syria_washington__1000-01-01__timeline:1639-1645	1.000
:Event_0000062	canonical_mention.actual	"meeting"	syria_washington__1000-01-01__timeline:1639-1645	1.000
:Event_0000062	Contact.Meet_Participant.actual	:Entity_EDL_0000105	syria_washington__1000-01-01__timeline:1562-1567	1.000
:Event_0000062	Contact.Meet_Place.actual	:Entity_EDL_0000122	syria_washington__1000-01-01__timeline:1603-1608	1.000
:Event_0000062	Contact.Meet_Participant.actual	:Entity_EDL_0000178	syria_washington__1000-01-01__timeline:1634-1637	1.000
:Event_0000063	type	Conflict.Attack
:Event_0000063	mention.actual	"airstrikes"	syria_washington__1000-01-01__timeline:3504-3513	1.000
:Event_0000063	canonical_mention.actual	"airstrikes"	syria_washington__1000-01-01__timeline:3504-3513	1.000
:Event_0000063	Conflict.Attack_Attacker.actual	:Entity_EDL_0000242	syria_washington__1000-01-01__timeline:3496-3502	1.000
:Event_0000063	Conflict.Attack_Target.actual	:Entity_EDL_0000060	syria_washington__1000-01-01__timeline:3531-3538	1.000
:Event_0000064	type	Life.Die
:Event_0000064	mention.actual	"killed"	syria_sbs__1000-01-01__timeline:835-840	1.000
:Event_0000064	canonical_mention.actual	"killed"	syria_sbs__1000-01-01__timeline:835-840	1.000
:Event_0000064	Life.Die_Victim.actual	:Entity_EDL_0000013	syria_sbs__1000-01-01__timeline:775-783	1.000
:Event_0000064	Life.Die_Victim.actual	:Entity_EDL_0000192	syria_sbs__1000-01-01__timeline:806-831	1.000
:Event_0000064	Life.Die_Place.actual	:Entity_EDL_0000001	syria_sbs__1000-01-01__timeline:847-854	1.000
:Event_0000065	type	Transaction.TransferOwnership
:Event_0000065	mention.actual	"capture"	syria_washington__1000-01-01__timeline:2472-2478	1.000
:Event_0000065	canonical_mention.actual	"capture"	syria_washington__1000-01-01__timeline:2472-2478	1.000
:Event_0000065	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000142	syria_washington__1000-01-01__timeline:2465-2470	1.000
:Event_0000065	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000170	syria_washington__1000-01-01__timeline:2489-2493	1.000
:Event_0000065	Transaction.TransferOwnership_Place.actual	:Entity_EDL_0000003	syria_washington__1000-01-01__timeline:2500-2507	1.000
:Event_0000066	type	Personnel.EndPosition
:Event_0000066	mention.actual	"defects"	syria_latimes__1000-01-01__timeline:13343-13349	1.000
:Event_0000066	canonical_mention.actual	"defects"	syria_latimes__1000-01-01__timeline:13343-13349	1.000
:Event_0000066	Personnel.EndPosition_Place.actual	:Entity_EDL_0000000	syria_latimes__1000-01-01__timeline:13319-13323	1.000
:Event_0000066	Personnel.EndPosition_Person.actual	:Entity_EDL_0000151	syria_latimes__1000-01-01__timeline:13334-13341	1.000
:Event_0000067	type	Life.Injure
:Event_0000067	mention.actual	"wounding"	syria_washington__1000-01-01__timeline:2890-2897	1.000
:Event_0000067	canonical_mention.actual	"wounding"	syria_washington__1000-01-01__timeline:2890-2897	1.000
:Event_0000067	Life.Injure_Place.actual	:Entity_EDL_0000246	syria_washington__1000-01-01__timeline:2791-2800	1.000
:Event_0000067	Life.Injure_Victim.actual	:Entity_EDL_0000176	syria_washington__1000-01-01__timeline:2909-2911	1.000
:Event_0000068	type	Conflict.Attack
:Event_0000068	mention.actual	"shelling"	syria_bbc__1000-01-01__timeline:1298-1305	1.000
:Event_0000068	canonical_mention.actual	"shelling"	syria_bbc__1000-01-01__timeline:1298-1305	1.000
:Event_0000068	Conflict.Attack_Attacker.actual	:Entity_EDL_0000119	syria_bbc__1000-01-01__timeline:1285-1290	1.000
:Event_0000068	Conflict.Attack_Place.actual	:Entity_EDL_0000276	syria_bbc__1000-01-01__timeline:1319-1322	1.000
:Event_0000069	type	Conflict.Demonstrate
:Event_0000069	mention.actual	"rally"	syria_washington__1000-01-01__timeline:134-138	1.000
:Event_0000069	canonical_mention.actual	"rally"	syria_washington__1000-01-01__timeline:134-138	1.000
:Event_0000069	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000211	syria_washington__1000-01-01__timeline:164-167	1.000
:Event_0000070	type	Conflict.Attack
:Event_0000070	mention.actual	"barrages"	syria_latimes__1000-01-01__timeline:11486-11493	1.000
:Event_0000070	canonical_mention.actual	"barrages"	syria_latimes__1000-01-01__timeline:11486-11493	1.000
:Event_0000070	Conflict.Attack_Attacker.actual	:Entity_EDL_0000240	syria_latimes__1000-01-01__timeline:11462-11465	1.000
:Event_0000070	Conflict.Attack_Instrument.actual	:Entity_EDL_0000052	syria_latimes__1000-01-01__timeline:11467-11475	1.000
:Event_0000070	Conflict.Attack_Instrument.actual	:Entity_EDL_0000071	syria_latimes__1000-01-01__timeline:11481-11484	1.000
:Event_0000070	Conflict.Attack_Place.actual	:Entity_EDL_0000072	syria_latimes__1000-01-01__timeline:11509-11520	1.000
:Event_0000071	type	Conflict.Attack
:Event_0000071	mention.actual	"fight"	syria_washington__1000-01-01__timeline:4488-4492	1.000
:Event_0000071	canonical_mention.actual	"fight"	syria_washington__1000-01-01__timeline:4488-4492	1.000
:Event_0000071	Conflict.Attack_Attacker.actual	:Entity_EDL_0000012	syria_washington__1000-01-01__timeline:4448-4457	1.000
:Event_0000071	Conflict.Attack_Instrument.actual	:Entity_EDL_0000106	syria_washington__1000-01-01__timeline:4473-4479	1.000
:Event_0000071	Conflict.Attack_Attacker.actual	:Entity_EDL_0000307	syria_washington__1000-01-01__timeline:4484-4486	1.000
:Event_0000071	Conflict.Attack_Target.actual	:Entity_EDL_0000168	syria_washington__1000-01-01__timeline:4513-4518	1.000
:Event_0000072	type	Justice.ArrestJail
:Event_0000072	mention.actual	"arresting"	syria_latimes__1000-01-01__timeline:2421-2429	1.000
:Event_0000072	canonical_mention.actual	"arresting"	syria_latimes__1000-01-01__timeline:2421-2429	1.000
:Event_0000072	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000230	syria_latimes__1000-01-01__timeline:2362-2372	1.000
:Event_0000072	Justice.ArrestJail_Person.actual	:Entity_EDL_0000277	syria_latimes__1000-01-01__timeline:2443-2448	1.000
:Event_0000073	type	Life.Die
:Event_0000073	mention.actual	"slain"	syria_latimes__1000-01-01__timeline:6495-6499	1.000
:Event_0000073	canonical_mention.actual	"slain"	syria_latimes__1000-01-01__timeline:6495-6499	1.000
:Event_0000073	Life.Die_Agent.actual	:Entity_EDL_0000097	syria_latimes__1000-01-01__timeline:6471-6476	1.000
:Event_0000073	Life.Die_Victim.actual	:Entity_EDL_0000299	syria_latimes__1000-01-01__timeline:6488-6493	1.000
:Event_0000074	type	Life.Die
:Event_0000074	mention.actual	"killed"	syria_latimes__1000-01-01__timeline:6683-6688	1.000
:Event_0000074	canonical_mention.actual	"killed"	syria_latimes__1000-01-01__timeline:6683-6688	1.000
:Event_0000074	Life.Die_Victim.actual	:Entity_EDL_0000136	syria_latimes__1000-01-01__timeline:6671-6677	1.000
:Event_0000074	Life.Die_Place.actual	:Entity_EDL_0000234	syria_latimes__1000-01-01__timeline:6754-6757	1.000
:Event_0000075	type	Conflict.Attack
:Event_0000075	mention.actual	"strike"	syria_latimes__1000-01-01__timeline:7200-7205	1.000
:Event_0000075	canonical_mention.actual	"strike"	syria_latimes__1000-01-01__timeline:7200-7205	1.000
:Event_0000076	type	Life.Injure
:Event_0000076	mention.actual	"wounding"	syria_dailystar__1000-01-01__timeline:2980-2987	1.000
:Event_0000076	canonical_mention.actual	"wounding"	syria_dailystar__1000-01-01__timeline:2980-2987	1.000
:Event_0000076	Life.Injure_Instrument.actual	:Entity_EDL_0000245	syria_dailystar__1000-01-01__timeline:2888-2891	1.000
:Event_0000076	Life.Injure_Place.actual	:Entity_EDL_0000275	syria_dailystar__1000-01-01__timeline:2913-2920	1.000
:Event_0000076	Life.Injure_Victim.actual	:Entity_EDL_0000304	syria_dailystar__1000-01-01__timeline:2995-3000	1.000
:Event_0000077	type	Justice.ArrestJail
:Event_0000077	mention.actual	"holding"	syria_dailystar__1000-01-01__timeline:1384-1390	1.000
:Event_0000077	canonical_mention.actual	"holding"	syria_dailystar__1000-01-01__timeline:1384-1390	1.000
:Event_0000077	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000000	syria_dailystar__1000-01-01__timeline:1375-1379	1.000
:Event_0000077	Justice.ArrestJail_Person.actual	:Entity_EDL_0000155	syria_dailystar__1000-01-01__timeline:1413-1421	1.000
:Event_0000077	Justice.ArrestJail_Place.actual	:Entity_EDL_0000194	syria_dailystar__1000-01-01__timeline:1439-1449	1.000
:Event_0000078	type	Conflict.Attack
:Event_0000078	mention.actual	"fire"	syria_latimes__1000-01-01__timeline:4342-4345	1.000
:Event_0000078	canonical_mention.actual	"fire"	syria_latimes__1000-01-01__timeline:4342-4345	1.000
:Event_0000078	Conflict.Attack_Target.actual	:Entity_EDL_0000055	syria_latimes__1000-01-01__timeline:4299-4308	1.000
:Event_0000078	Conflict.Attack_Attacker.actual	:Entity_EDL_0000239	syria_latimes__1000-01-01__timeline:4335-4340	1.000
:Event_0000078	Conflict.Attack_Target.actual	:Entity_EDL_0000311	syria_latimes__1000-01-01__timeline:4350-4362	1.000
:Event_0000078	Conflict.Attack_Place.actual	:Entity_EDL_0000114	syria_latimes__1000-01-01__timeline:4367-4372	1.000
:Event_0000079	type	Life.Die
:Event_0000079	mention.actual	"killings"	syria_latimes__1000-01-01__timeline:6440-6447	1.000
:Event_0000079	canonical_mention.actual	"killings"	syria_latimes__1000-01-01__timeline:6440-6447	1.000
:Event_0000079	Life.Die_Agent.actual	:Entity_EDL_0000097	syria_latimes__1000-01-01__timeline:6471-6476	1.000
:Event_0000080	type	Conflict.Attack
:Event_0000080	mention.actual	"assault"	syria_sbs__1000-01-01__timeline:1242-1248	1.000
:Event_0000080	canonical_mention.actual	"assault"	syria_sbs__1000-01-01__timeline:1242-1248	1.000
:Event_0000080	Conflict.Attack_Attacker.actual	:Entity_EDL_0000063	syria_sbs__1000-01-01__timeline:1217-1224	1.000
:Event_0000080	Conflict.Attack_Target.actual	:Entity_EDL_0000099	syria_sbs__1000-01-01__timeline:1271-1277	1.000
:Event_0000081	type	Conflict.Attack
:Event_0000081	mention.actual	"downed"	syria_dailystar__1000-01-01__timeline:2457-2462	1.000
:Event_0000081	canonical_mention.actual	"downed"	syria_dailystar__1000-01-01__timeline:2457-2462	1.000
:Event_0000081	Conflict.Attack_Attacker.actual	:Entity_EDL_0000292	syria_dailystar__1000-01-01__timeline:2452-2455	1.000
:Event_0000081	Conflict.Attack_Target.actual	:Entity_EDL_0000173	syria_dailystar__1000-01-01__timeline:2474-2476	1.000
:Event_0000082	type	Movement.TransportArtifact
:Event_0000082	mention.actual	"roll"	syria_washington__1000-01-01__timeline:333-336	1.000
:Event_0000082	canonical_mention.actual	"roll"	syria_washington__1000-01-01__timeline:333-336	1.000
:Event_0000082	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000131	syria_washington__1000-01-01__timeline:326-331	1.000
:Event_0000082	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000199	syria_washington__1000-01-01__timeline:341-345	1.000
:Event_0000082	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000070	syria_washington__1000-01-01__timeline:352-356	1.000
:Event_0000083	type	Personnel.StartPosition
:Event_0000083	mention.actual	"appointed"	syria_latimes__1000-01-01__timeline:1700-1708	1.000
:Event_0000083	canonical_mention.actual	"appointed"	syria_latimes__1000-01-01__timeline:1700-1708	1.000
:Event_0000083	Personnel.StartPosition_Person.actual	:Entity_EDL_0000017	syria_latimes__1000-01-01__timeline:1710-1716	1.000
:Event_0000084	type	Justice.Execute
:Event_0000084	mention.actual	"execution"	syria_washington__1000-01-01__timeline:2664-2672	1.000
:Event_0000084	canonical_mention.actual	"execution"	syria_washington__1000-01-01__timeline:2664-2672	1.000
:Event_0000084	Justice.Execute_Place.actual	:Entity_EDL_0000185	syria_washington__1000-01-01__timeline:2620-2623	1.000
:Event_0000085	type	Life.Die
:Event_0000085	mention.actual	"killed"	syria_latimes__1000-01-01__timeline:2254-2259	1.000
:Event_0000085	canonical_mention.actual	"killed"	syria_latimes__1000-01-01__timeline:2254-2259	1.000
:Event_0000085	Life.Die_Victim.actual	:Entity_EDL_0000031	syria_latimes__1000-01-01__timeline:2224-2229	1.000
:Event_0000085	Life.Die_Place.actual	:Entity_EDL_0000186	syria_latimes__1000-01-01__timeline:2242-2248	1.000
:Event_0000086	type	Life.Injure
:Event_0000086	mention.actual	"injured"	syria_bbc__1000-01-01__timeline:4161-4167	1.000
:Event_0000086	canonical_mention.actual	"injured"	syria_bbc__1000-01-01__timeline:4161-4167	1.000
:Event_0000086	Life.Injure_Victim.actual	:Entity_EDL_0000065	syria_bbc__1000-01-01__timeline:4108-4115	1.000
:Event_0000086	Life.Injure_Victim.actual	:Entity_EDL_0000291	syria_bbc__1000-01-01__timeline:4139-4143	1.000
:Event_0000087	type	Life.Injure
:Event_0000087	mention.actual	"wounded"	syria_latimes__1000-01-01__timeline:1503-1509	1.000
:Event_0000087	canonical_mention.actual	"wounded"	syria_latimes__1000-01-01__timeline:1503-1509	1.000
:Event_0000087	Life.Injure_Victim.actual	:Entity_EDL_0000179	syria_latimes__1000-01-01__timeline:1496-1501	1.000
:Event_0000087	Life.Injure_Place.actual	:Entity_EDL_0000271	syria_latimes__1000-01-01__timeline:1567-1570	1.000
:Event_0000088	type	Life.Die
:Event_0000088	mention.actual	"killed"	syria_bbc__1000-01-01__timeline:4071-4076	1.000
:Event_0000088	canonical_mention.actual	"killed"	syria_bbc__1000-01-01__timeline:4071-4076	1.000
:Event_0000088	Life.Die_Victim.actual	:Entity_EDL_0000247	syria_bbc__1000-01-01__timeline:4007-4022	1.000
:Event_0000089	type	Conflict.Attack
:Event_0000089	mention.actual	"war"	syria_latimes__1000-01-01__timeline:9654-9656	1.000
:Event_0000089	canonical_mention.actual	"war"	syria_latimes__1000-01-01__timeline:9654-9656	1.000
:Event_0000089	Conflict.Attack_Place.actual	:Entity_EDL_0000032	syria_latimes__1000-01-01__timeline:9661-9665	1.000
:Event_0000090	type	Movement.TransportPerson
:Event_0000090	mention.actual	"disperse"	syria_latimes__1000-01-01__timeline:962-969	1.000
:Event_0000090	canonical_mention.actual	"disperse"	syria_latimes__1000-01-01__timeline:962-969	1.000
:Event_0000090	Movement.TransportPerson_Person.actual	:Entity_EDL_0000051	syria_latimes__1000-01-01__timeline:971-974	1.000
:Event_0000091	type	Conflict.Attack
:Event_0000091	mention.actual	"bullets"	syria_latimes__1000-01-01__timeline:2188-2194	1.000
:Event_0000091	canonical_mention.actual	"bullets"	syria_latimes__1000-01-01__timeline:2188-2194	1.000
:Event_0000091	Conflict.Attack_Instrument.actual	:Entity_EDL_0000278	syria_latimes__1000-01-01__timeline:2188-2194	1.000
:Event_0000092	type	Movement.TransportArtifact
:Event_0000092	mention.actual	"visit"	syria_latimes__1000-01-01__timeline:12550-12554	1.000
:Event_0000092	canonical_mention.actual	"visit"	syria_latimes__1000-01-01__timeline:12550-12554	1.000
:Event_0000092	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000147	syria_latimes__1000-01-01__timeline:12540-12548	1.000
:Event_0000092	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000212	syria_latimes__1000-01-01__timeline:12576-12579	1.000
:Event_0000093	type	Business.Start
:Event_0000093	mention.actual	"Creation"	syria_dailystar__1000-01-01__timeline:295-302	1.000
:Event_0000093	canonical_mention.actual	"Creation"	syria_dailystar__1000-01-01__timeline:295-302	1.000
:Event_0000093	Business.Start_Organization.actual	:Entity_EDL_0000195	syria_dailystar__1000-01-01__timeline:322-348	1.000
:Event_0000094	type	Personnel.EndPosition
:Event_0000094	mention.actual	"resigns"	syria_dailystar__1000-01-01__timeline:2339-2345	1.000
:Event_0000094	canonical_mention.actual	"resigns"	syria_dailystar__1000-01-01__timeline:2339-2345	1.000
:Event_0000094	Personnel.EndPosition_Person.actual	:Entity_EDL_0000283	syria_dailystar__1000-01-01__timeline:2333-2337	1.000
:Event_0000095	type	Conflict.Attack
:Event_0000095	mention.actual	"shooting"	syria_bbc__1000-01-01__timeline:3475-3482	1.000
:Event_0000095	canonical_mention.actual	"shooting"	syria_bbc__1000-01-01__timeline:3475-3482	1.000
:Event_0000095	Conflict.Attack_Place.actual	:Entity_EDL_0000088	syria_bbc__1000-01-01__timeline:3405-3411	1.000
:Event_0000095	Conflict.Attack_Attacker.actual	:Entity_EDL_0000024	syria_bbc__1000-01-01__timeline:3453-3462	1.000
:Event_0000095	Conflict.Attack_Target.actual	:Entity_EDL_0000022	syria_bbc__1000-01-01__timeline:3497-3503	1.000
:Event_0000096	type	Life.Die
:Event_0000096	mention.actual	"killed"	syria_dailystar__1000-01-01__timeline:2559-2564	1.000
:Event_0000096	canonical_mention.actual	"killed"	syria_dailystar__1000-01-01__timeline:2559-2564	1.000
:Event_0000096	Life.Die_Victim.actual	:Entity_EDL_0000182	syria_dailystar__1000-01-01__timeline:2542-2547	1.000
:Event_0000097	type	Life.Die
:Event_0000097	mention.actual	"killed"	syria_dailystar__1000-01-01__timeline:1844-1849	1.000
:Event_0000097	canonical_mention.actual	"killed"	syria_dailystar__1000-01-01__timeline:1844-1849	1.000
:Event_0000097	Life.Die_Victim.actual	:Entity_EDL_0000172	syria_dailystar__1000-01-01__timeline:1780-1788	1.000
:Event_0000097	Life.Die_Victim.actual	:Entity_EDL_0000297	syria_dailystar__1000-01-01__timeline:1811-1836	1.000
:Event_0000097	Life.Die_Place.actual	:Entity_EDL_0000001	syria_dailystar__1000-01-01__timeline:1856-1863	1.000
:Event_0000098	type	Life.Die
:Event_0000098	mention.actual	"massacre"	syria_washington__1000-01-01__timeline:1696-1703	1.000
:Event_0000098	canonical_mention.actual	"massacre"	syria_washington__1000-01-01__timeline:1696-1703	1.000
:Event_0000098	Life.Die_Victim.actual	:Entity_EDL_0000046	syria_washington__1000-01-01__timeline:1720-1725	1.000
:Event_0000098	Life.Die_Place.actual	:Entity_EDL_0000207	syria_washington__1000-01-01__timeline:1730-1736	1.000
:Event_0000099	type	Conflict.Attack
:Event_0000099	mention.actual	"shoot"	syria_latimes__1000-01-01__timeline:11273-11277	1.000
:Event_0000099	canonical_mention.actual	"shoot"	syria_latimes__1000-01-01__timeline:11273-11277	1.000
:Event_0000099	Conflict.Attack_Attacker.actual	:Entity_EDL_0000309	syria_latimes__1000-01-01__timeline:11237-11242	1.000
:Event_0000099	Conflict.Attack_Place.actual	:Entity_EDL_0000213	syria_latimes__1000-01-01__timeline:11262-11267	1.000
:Event_0000099	Conflict.Attack_Target.actual	:Entity_EDL_0000150	syria_latimes__1000-01-01__timeline:11282-11291	1.000
:Event_0000100	type	Conflict.Attack
:Event_0000100	mention.actual	"clashes"	syria_sbs__1000-01-01__timeline:1158-1164	1.000
:Event_0000100	canonical_mention.actual	"clashes"	syria_sbs__1000-01-01__timeline:1158-1164	1.000
:Event_0000100	Conflict.Attack_Place.actual	:Entity_EDL_0000001	syria_sbs__1000-01-01__timeline:1121-1128	1.000
:Event_0000101	type	Justice.ReleaseParole
:Event_0000101	mention.actual	"release"	syria_washington__1000-01-01__timeline:72-78	1.000
:Event_0000101	canonical_mention.actual	"release"	syria_washington__1000-01-01__timeline:72-78	1.000
:Event_0000101	Justice.ReleaseParole_Place.actual	:Entity_EDL_0000236	syria_washington__1000-01-01__timeline:52-59	1.000
:Event_0000101	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000196	syria_washington__1000-01-01__timeline:93-101	1.000
:Event_0000102	type	Conflict.Attack
:Event_0000102	mention.actual	"shot"	syria_washington__1000-01-01__timeline:2659-2662	1.000
:Event_0000102	canonical_mention.actual	"shot"	syria_washington__1000-01-01__timeline:2659-2662	1.000
:Event_0000102	Conflict.Attack_Place.actual	:Entity_EDL_0000185	syria_washington__1000-01-01__timeline:2620-2623	1.000
:Event_0000102	Conflict.Attack_Target.actual	:Entity_EDL_0000208	syria_washington__1000-01-01__timeline:2636-2639	1.000
:Event_0000103	type	Conflict.Attack
:Event_0000103	mention.actual	"storm"	syria_washington__1000-01-01__timeline:450-454	1.000
:Event_0000103	canonical_mention.actual	"storm"	syria_washington__1000-01-01__timeline:450-454	1.000
:Event_0000103	Conflict.Attack_Instrument.actual	:Entity_EDL_0000040	syria_washington__1000-01-01__timeline:444-448	1.000
:Event_0000103	Conflict.Attack_Place.actual	:Entity_EDL_0000219	syria_washington__1000-01-01__timeline:460-463	1.000
:Event_0000104	type	Personnel.EndPosition
:Event_0000104	mention.actual	"former"	syria_latimes__1000-01-01__timeline:10502-10507	1.000
:Event_0000104	canonical_mention.actual	"former"	syria_latimes__1000-01-01__timeline:10502-10507	1.000
:Event_0000104	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000006	syria_latimes__1000-01-01__timeline:10509-10522	1.000
:Event_0000105	type	Life.Die
:Event_0000105	mention.actual	"kill"	syria_latimes__1000-01-01__timeline:9064-9067	1.000
:Event_0000105	canonical_mention.actual	"kill"	syria_latimes__1000-01-01__timeline:9064-9067	1.000
:Event_0000105	Life.Die_Agent.actual	:Entity_EDL_0000101	syria_latimes__1000-01-01__timeline:9032-9041	1.000
:Event_0000105	Life.Die_Victim.actual	:Entity_EDL_0000137	syria_latimes__1000-01-01__timeline:9083-9088	1.000
:Event_0000105	Life.Die_Place.actual	:Entity_EDL_0000079	syria_latimes__1000-01-01__timeline:9122-9125	1.000
:Event_0000106	type	Life.Die
:Event_0000106	mention.actual	"killing"	syria_washington__1000-01-01__timeline:2871-2877	1.000
:Event_0000106	canonical_mention.actual	"killing"	syria_washington__1000-01-01__timeline:2871-2877	1.000
:Event_0000106	Life.Die_Instrument.actual	:Entity_EDL_0000286	syria_washington__1000-01-01__timeline:2762-2769	1.000
:Event_0000106	Life.Die_Place.actual	:Entity_EDL_0000246	syria_washington__1000-01-01__timeline:2791-2800	1.000
:Event_0000106	Life.Die_Victim.actual	:Entity_EDL_0000128	syria_washington__1000-01-01__timeline:2879-2884	1.000
:Event_0000107	type	Conflict.Attack
:Event_0000107	mention.actual	"attacks"	syria_latimes__1000-01-01__timeline:9056-9062	1.000
:Event_0000107	canonical_mention.actual	"attacks"	syria_latimes__1000-01-01__timeline:9056-9062	1.000
:Event_0000107	Conflict.Attack_Attacker.actual	:Entity_EDL_0000101	syria_latimes__1000-01-01__timeline:9032-9041	1.000
:Event_0000107	Conflict.Attack_Place.actual	:Entity_EDL_0000079	syria_latimes__1000-01-01__timeline:9122-9125	1.000
:Event_0000108	type	Personnel.EndPosition
:Event_0000108	mention.actual	"quit"	syria_dailystar__1000-01-01__timeline:179-182	1.000
:Event_0000108	canonical_mention.actual	"quit"	syria_dailystar__1000-01-01__timeline:179-182	1.000
:Event_0000108	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000252	syria_dailystar__1000-01-01__timeline:124-125	1.000
:Event_0000108	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	syria_dailystar__1000-01-01__timeline:170-174	1.000
:Event_0000109	type	Movement.TransportArtifact
:Event_0000109	mention.actual	"sends"	syria_latimes__1000-01-01__timeline:14391-14395	1.000
:Event_0000109	canonical_mention.actual	"sends"	syria_latimes__1000-01-01__timeline:14391-14395	1.000
:Event_0000109	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000027	syria_latimes__1000-01-01__timeline:14363-14366	1.000
:Event_0000109	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000121	syria_latimes__1000-01-01__timeline:14409-14414	1.000
:Event_0000109	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000005	syria_latimes__1000-01-01__timeline:14441-14446	1.000
:Event_0000110	type	Life.Die
:Event_0000110	mention.actual	"kills"	syria_latimes__1000-01-01__timeline:12942-12946	1.000
:Event_0000110	canonical_mention.actual	"kills"	syria_latimes__1000-01-01__timeline:12942-12946	1.000
:Event_0000110	Life.Die_Place.actual	:Entity_EDL_0000042	syria_latimes__1000-01-01__timeline:12899-12903	1.000
:Event_0000110	Life.Die_Victim.actual	:Entity_EDL_0000086	syria_latimes__1000-01-01__timeline:12967-12975	1.000
:Event_0000110	Life.Die_Place.actual	:Entity_EDL_0000001	syria_latimes__1000-01-01__timeline:12980-12987	1.000
:Event_0000111	type	Life.Die
:Event_0000111	mention.actual	"killed"	syria_washington__1000-01-01__timeline:2053-2058	1.000
:Event_0000111	canonical_mention.actual	"killed"	syria_washington__1000-01-01__timeline:2053-2058	1.000
:Event_0000111	Life.Die_Place.actual	:Entity_EDL_0000157	syria_washington__1000-01-01__timeline:2027-2034	1.000
:Event_0000111	Life.Die_Victim.actual	:Entity_EDL_0000018	syria_washington__1000-01-01__timeline:2064-2070	1.000
:Event_0000112	type	Contact.Meet
:Event_0000112	mention.actual	"meeting"	syria_latimes__1000-01-01__timeline:7802-7808	1.000
:Event_0000112	canonical_mention.actual	"meeting"	syria_latimes__1000-01-01__timeline:7802-7808	1.000
:Event_0000112	Contact.Meet_Participant.actual	:Entity_EDL_0000123	syria_latimes__1000-01-01__timeline:7790-7800	1.000
:Event_0000112	Contact.Meet_Place.actual	:Entity_EDL_0000214	syria_latimes__1000-01-01__timeline:7813-7817	1.000
:Event_0000112	Contact.Meet_Participant.actual	:Entity_EDL_0000056	syria_latimes__1000-01-01__timeline:7821-7827	1.000
:Event_0000113	type	Contact.Contact
:Event_0000113	mention.actual	"reaching out"	syria_latimes__1000-01-01__timeline:10793-10804	1.000
:Event_0000113	canonical_mention.actual	"reaching out"	syria_latimes__1000-01-01__timeline:10793-10804	1.000
:Event_0000113	Contact.Contact_Participant.actual	:Entity_EDL_0000197	syria_latimes__1000-01-01__timeline:10698-10704	1.000
:Event_0000113	Contact.Contact_Participant.actual	:Entity_EDL_0000153	syria_latimes__1000-01-01__timeline:10814-10818	1.000
:Event_0000114	type	Movement.TransportPerson
:Event_0000114	mention.actual	"fled"	syria_bbc__1000-01-01__timeline:3053-3056	1.000
:Event_0000114	canonical_mention.actual	"fled"	syria_bbc__1000-01-01__timeline:3053-3056	1.000
:Event_0000114	Movement.TransportPerson_Person.actual	:Entity_EDL_0000037	syria_bbc__1000-01-01__timeline:2987-2997	1.000
:Event_0000114	Movement.TransportPerson_Person.actual	:Entity_EDL_0000162	syria_bbc__1000-01-01__timeline:3003-3009	1.000
:Event_0000114	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000000	syria_bbc__1000-01-01__timeline:3058-3062	1.000
:Event_0000115	type	Contact.Meet
:Event_0000115	mention.actual	"talks"	syria_latimes__1000-01-01__timeline:7106-7110	1.000
:Event_0000115	canonical_mention.actual	"talks"	syria_latimes__1000-01-01__timeline:7106-7110	1.000
:Event_0000115	Contact.Meet_Participant.actual	:Entity_EDL_0000049	syria_latimes__1000-01-01__timeline:7089-7098	1.000
:Event_0000115	Contact.Meet_Participant.actual	:Entity_EDL_0000002	syria_latimes__1000-01-01__timeline:7127-7138	1.000
:Event_0000116	type	Conflict.Demonstrate
:Event_0000116	mention.actual	"protests"	syria_washington__1000-01-01__timeline:367-374	1.000
:Event_0000116	canonical_mention.actual	"protests"	syria_washington__1000-01-01__timeline:367-374	1.000
:Event_0000116	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000070	syria_washington__1000-01-01__timeline:352-356	1.000
:Event_0000117	type	Life.Die
:Event_0000117	mention.actual	"killing"	syria_latimes__1000-01-01__timeline:3644-3650	1.000
:Event_0000117	canonical_mention.actual	"killing"	syria_latimes__1000-01-01__timeline:3644-3650	1.000
:Event_0000117	Life.Die_Agent.actual	:Entity_EDL_0000154	syria_latimes__1000-01-01__timeline:3614-3619	1.000
:Event_0000117	Life.Die_Place.actual	:Entity_EDL_0000198	syria_latimes__1000-01-01__timeline:3636-3640	1.000
:Event_0000117	Life.Die_Victim.actual	:Entity_EDL_0000250	syria_latimes__1000-01-01__timeline:3666-3671	1.000
:Event_0000118	type	Conflict.Demonstrate
:Event_0000118	mention.actual	"took to"	syria_latimes__1000-01-01__timeline:2887-2893	1.000
:Event_0000118	canonical_mention.actual	"took to"	syria_latimes__1000-01-01__timeline:2887-2893	1.000
:Event_0000118	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000132	syria_latimes__1000-01-01__timeline:2839-2846	1.000
:Event_0000118	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000288	syria_latimes__1000-01-01__timeline:2899-2905	1.000
:Event_0000119	type	Life.Die
:Event_0000119	mention.actual	"killed"	syria_bbc__1000-01-01__timeline:3669-3674	1.000
:Event_0000119	canonical_mention.actual	"killed"	syria_bbc__1000-01-01__timeline:3669-3674	1.000
:Event_0000119	Life.Die_Victim.actual	:Entity_EDL_0000270	syria_bbc__1000-01-01__timeline:3657-3662	1.000
:Event_0000119	Life.Die_Place.actual	:Entity_EDL_0000007	syria_bbc__1000-01-01__timeline:3679-3685	1.000
:Event_0000119	Life.Die_Agent.actual	:Entity_EDL_0000096	syria_bbc__1000-01-01__timeline:3722-3727	1.000
:Event_0000120	type	Conflict.Attack
:Event_0000120	mention.actual	"fire"	syria_latimes__1000-01-01__timeline:4061-4064	1.000
:Event_0000120	canonical_mention.actual	"fire"	syria_latimes__1000-01-01__timeline:4061-4064	1.000
:Event_0000120	Conflict.Attack_Attacker.actual	:Entity_EDL_0000066	syria_latimes__1000-01-01__timeline:4047-4054	1.000
:Event_0000120	Conflict.Attack_Target.actual	:Entity_EDL_0000077	syria_latimes__1000-01-01__timeline:4069-4078	1.000
:Event_0000121	type	Life.Injure
:Event_0000121	mention.actual	"injuries"	syria_latimes__1000-01-01__timeline:2723-2730	1.000
:Event_0000121	canonical_mention.actual	"injuries"	syria_latimes__1000-01-01__timeline:2723-2730	1.000
:Event_0000121	Life.Injure_Place.actual	:Entity_EDL_0000067	syria_latimes__1000-01-01__timeline:2678-2683	1.000
:Event_0000122	type	Conflict.Attack
:Event_0000122	mention.actual	"shot"	syria_bbc__1000-01-01__timeline:2748-2751	1.000
:Event_0000122	canonical_mention.actual	"shot"	syria_bbc__1000-01-01__timeline:2748-2751	1.000
:Event_0000122	Conflict.Attack_Target.actual	:Entity_EDL_0000243	syria_bbc__1000-01-01__timeline:2730-2737	1.000
:Event_0000123	type	Conflict.Demonstrate
:Event_0000123	mention.actual	"protesters"	syria_bbc__1000-01-01__timeline:109-118	1.000
:Event_0000123	canonical_mention.actual	"protesters"	syria_bbc__1000-01-01__timeline:109-118	1.000
:Event_0000123	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	syria_bbc__1000-01-01__timeline:15-20	1.000
:Event_0000123	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000148	syria_bbc__1000-01-01__timeline:109-118	1.000
:Event_0000124	type	Conflict.Attack
:Event_0000124	mention.actual	"bombardment"	syria_bbc__1000-01-01__timeline:1383-1393	1.000
:Event_0000124	canonical_mention.actual	"bombardment"	syria_bbc__1000-01-01__timeline:1383-1393	1.000
:Event_0000124	Conflict.Attack_Attacker.actual	:Entity_EDL_0000119	syria_bbc__1000-01-01__timeline:1285-1290	1.000
:Event_0000125	type	Movement.TransportArtifact
:Event_0000125	mention.actual	"fled"	syria_bbc__1000-01-01__timeline:843-846	1.000
:Event_0000125	canonical_mention.actual	"fled"	syria_bbc__1000-01-01__timeline:843-846	1.000
:Event_0000125	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000294	syria_bbc__1000-01-01__timeline:834-841	1.000
:Event_0000125	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000083	syria_bbc__1000-01-01__timeline:876-883	1.000
:Event_0000126	type	Life.Injure
:Event_0000126	mention.actual	"stabbed"	syria_bbc__1000-01-01__timeline:2777-2783	1.000
:Event_0000126	canonical_mention.actual	"stabbed"	syria_bbc__1000-01-01__timeline:2777-2783	1.000
:Event_0000126	Life.Injure_Victim.actual	:Entity_EDL_0000243	syria_bbc__1000-01-01__timeline:2730-2737	1.000
:Event_0000127	type	Life.Die
:Event_0000127	mention.actual	"dead"	syria_washington__1000-01-01__timeline:2583-2586	1.000
:Event_0000127	canonical_mention.actual	"dead"	syria_washington__1000-01-01__timeline:2583-2586	1.000
:Event_0000127	Life.Die_Victim.actual	:Entity_EDL_0000249	syria_washington__1000-01-01__timeline:2566-2571	1.000
:Event_0000127	Life.Die_Place.actual	:Entity_EDL_0000185	syria_washington__1000-01-01__timeline:2620-2623	1.000
:Event_0000128	type	Conflict.Attack
:Event_0000128	mention.actual	"attacks"	syria_sbs__1000-01-01__timeline:2271-2277	1.000
:Event_0000128	canonical_mention.actual	"attacks"	syria_sbs__1000-01-01__timeline:2271-2277	1.000
:Event_0000128	Conflict.Attack_Place.actual	:Entity_EDL_0000004	syria_sbs__1000-01-01__timeline:2225-2230	1.000
:Event_0000128	Conflict.Attack_Attacker.actual	:Entity_EDL_0000093	syria_sbs__1000-01-01__timeline:2265-2269	1.000
:Event_0000129	type	Conflict.Attack
:Event_0000129	mention.actual	"used"	syria_washington__1000-01-01__timeline:1856-1859	1.000
:Event_0000129	canonical_mention.actual	"used"	syria_washington__1000-01-01__timeline:1856-1859	1.000
:Event_0000129	Conflict.Attack_Instrument.actual	:Entity_EDL_0000057	syria_washington__1000-01-01__timeline:1843-1850	1.000
:Event_0000129	Conflict.Attack_Target.actual	:Entity_EDL_0000228	syria_washington__1000-01-01__timeline:1869-1877	1.000
:Event_0000130	type	Business.End
:Event_0000130	mention.actual	"abolishing"	syria_latimes__1000-01-01__timeline:1865-1874	1.000
:Event_0000130	canonical_mention.actual	"abolishing"	syria_latimes__1000-01-01__timeline:1865-1874	1.000
:Event_0000130	Business.End_Organization.actual	:Entity_EDL_0000009	syria_latimes__1000-01-01__timeline:1896-1900	1.000
:Event_0000131	type	Contact.Meet
:Event_0000131	mention.actual	"meeting"	syria_bbc__1000-01-01__timeline:3927-3933	1.000
:Event_0000131	canonical_mention.actual	"meeting"	syria_bbc__1000-01-01__timeline:3927-3933	1.000
:Event_0000131	Contact.Meet_Place.actual	:Entity_EDL_0000090	syria_bbc__1000-01-01__timeline:3960-3971	1.000
:Event_0000132	type	Conflict.Attack
:Event_0000132	mention.actual	"bombing"	syria_latimes__1000-01-01__timeline:12878-12884	1.000
:Event_0000132	canonical_mention.actual	"bombing"	syria_latimes__1000-01-01__timeline:12878-12884	1.000
:Event_0000132	Conflict.Attack_Place.actual	:Entity_EDL_0000042	syria_latimes__1000-01-01__timeline:12899-12903	1.000
:Event_0000132	Conflict.Attack_Target.actual	:Entity_EDL_0000086	syria_latimes__1000-01-01__timeline:12967-12975	1.000
:Event_0000133	type	Conflict.Demonstrate
:Event_0000133	mention.actual	"march"	syria_latimes__1000-01-01__timeline:3836-3840	1.000
:Event_0000133	canonical_mention.actual	"march"	syria_latimes__1000-01-01__timeline:3836-3840	1.000
:Event_0000133	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000144	syria_latimes__1000-01-01__timeline:3796-3804	1.000
:Event_0000133	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000253	syria_latimes__1000-01-01__timeline:3825-3834	1.000
:Event_0000133	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000001	syria_latimes__1000-01-01__timeline:3845-3852	1.000
:Event_0000133	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000047	syria_latimes__1000-01-01__timeline:3856-3859	1.000
:Event_0000133	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000039	syria_latimes__1000-01-01__timeline:3878-3883	1.000
:Event_0000134	type	Personnel.EndPosition
:Event_0000134	mention.actual	"Former"	syria_dailystar__1000-01-01__timeline:2649-2654	1.000
:Event_0000134	canonical_mention.actual	"Former"	syria_dailystar__1000-01-01__timeline:2649-2654	1.000
:Event_0000134	Personnel.EndPosition_Person.actual	:Entity_EDL_0000043	syria_dailystar__1000-01-01__timeline:2671-2680	1.000
:Event_0000135	type	Movement.TransportArtifact
:Event_0000135	mention.actual	"move"	syria_latimes__1000-01-01__timeline:5377-5380	1.000
:Event_0000135	canonical_mention.actual	"move"	syria_latimes__1000-01-01__timeline:5377-5380	1.000
:Event_0000135	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000238	syria_latimes__1000-01-01__timeline:5370-5375	1.000
:Event_0000135	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000073	syria_latimes__1000-01-01__timeline:5382-5386	1.000
:Event_0000135	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000177	syria_latimes__1000-01-01__timeline:5397-5401	1.000
:Event_0000136	type	Conflict.Attack
:Event_0000136	mention.actual	"bombarded"	syria_bbc__1000-01-01__timeline:3391-3399	1.000
:Event_0000136	canonical_mention.actual	"bombarded"	syria_bbc__1000-01-01__timeline:3391-3399	1.000
:Event_0000136	Conflict.Attack_Instrument.actual	:Entity_EDL_0000152	syria_bbc__1000-01-01__timeline:3385-3389	1.000
:Event_0000136	Conflict.Attack_Target.actual	:Entity_EDL_0000088	syria_bbc__1000-01-01__timeline:3405-3411	1.000
:Event_0000137	type	Movement.TransportPerson
:Event_0000137	mention.actual	"pour into"	syria_latimes__1000-01-01__timeline:4121-4129	1.000
:Event_0000137	canonical_mention.actual	"pour into"	syria_latimes__1000-01-01__timeline:4121-4129	1.000
:Event_0000137	Movement.TransportPerson_Person.actual	:Entity_EDL_0000229	syria_latimes__1000-01-01__timeline:4114-4119	1.000
:Event_0000137	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000221	syria_latimes__1000-01-01__timeline:4135-4141	1.000
:Event_0000138	type	Life.Die
:Event_0000138	mention.actual	"killed"	syria_washington__1000-01-01__timeline:4276-4281	1.000
:Event_0000138	canonical_mention.actual	"killed"	syria_washington__1000-01-01__timeline:4276-4281	1.000
:Event_0000138	Life.Die_Place.actual	:Entity_EDL_0000000	syria_washington__1000-01-01__timeline:4266-4270	1.000
:Event_0000138	Life.Die_Victim.actual	:Entity_EDL_0000134	syria_washington__1000-01-01__timeline:4297-4302	1.000
:Event_0000139	type	Conflict.Attack
:Event_0000139	mention.actual	"fight"	syria_washington__1000-01-01__timeline:3804-3808	1.000
:Event_0000139	canonical_mention.actual	"fight"	syria_washington__1000-01-01__timeline:3804-3808	1.000
:Event_0000139	Conflict.Attack_Attacker.actual	:Entity_EDL_0000171	syria_washington__1000-01-01__timeline:3793-3798	1.000
:Event_0000139	Conflict.Attack_Target.actual	:Entity_EDL_0000133	syria_washington__1000-01-01__timeline:3822-3827	1.000
:Event_0000139	Conflict.Attack_Place.actual	:Entity_EDL_0000191	syria_washington__1000-01-01__timeline:3832-3836	1.000
:Event_0000140	type	Movement.TransportArtifact
:Event_0000140	mention.actual	"herd"	syria_latimes__1000-01-01__timeline:5855-5858	1.000
:Event_0000140	canonical_mention.actual	"herd"	syria_latimes__1000-01-01__timeline:5855-5858	1.000
:Event_0000140	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000094	syria_latimes__1000-01-01__timeline:5837-5842	1.000
:Event_0000140	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000081	syria_latimes__1000-01-01__timeline:5847-5853	1.000
:Event_0000140	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000076	syria_latimes__1000-01-01__timeline:5873-5878	1.000
:Event_0000140	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000145	syria_latimes__1000-01-01__timeline:5887-5893	1.000
:Event_0000141	type	Movement.TransportArtifact
:Event_0000141	mention.actual	"swept in"	syria_bbc__1000-01-01__timeline:3464-3471	1.000
:Event_0000141	canonical_mention.actual	"swept in"	syria_bbc__1000-01-01__timeline:3464-3471	1.000
:Event_0000141	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000088	syria_bbc__1000-01-01__timeline:3405-3411	1.000
:Event_0000141	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000024	syria_bbc__1000-01-01__timeline:3453-3462	1.000
:Event_0000142	type	Contact.Meet
:Event_0000142	mention.actual	"discussions"	syria_latimes__1000-01-01__timeline:15019-15029	1.000
:Event_0000142	canonical_mention.actual	"discussions"	syria_latimes__1000-01-01__timeline:15019-15029	1.000
:Event_0000142	Contact.Meet_Place.actual	:Entity_EDL_0000200	syria_latimes__1000-01-01__timeline:15045-15051	1.000
:Event_0000142	Contact.Meet_Participant.actual	:Entity_EDL_0000202	syria_latimes__1000-01-01__timeline:15069-15078	1.000
:Event_0000143	type	Conflict.Attack
:Event_0000143	mention.actual	"using"	syria_latimes__1000-01-01__timeline:15272-15276	1.000
:Event_0000143	canonical_mention.actual	"using"	syria_latimes__1000-01-01__timeline:15272-15276	1.000
:Event_0000143	Conflict.Attack_Instrument.actual	:Entity_EDL_0000175	syria_latimes__1000-01-01__timeline:15287-15293	1.000
:Event_0000144	type	Conflict.Attack
:Event_0000144	mention.actual	"fighting"	syria_latimes__1000-01-01__timeline:14342-14349	1.000
:Event_0000144	canonical_mention.actual	"fighting"	syria_latimes__1000-01-01__timeline:14342-14349	1.000
:Event_0000144	Conflict.Attack_Place.actual	:Entity_EDL_0000027	syria_latimes__1000-01-01__timeline:14363-14366	1.000
:Event_0000145	type	Personnel.EndPosition
:Event_0000145	mention.actual	"Former"	syria_latimes__1000-01-01__timeline:9714-9719	1.000
:Event_0000145	canonical_mention.actual	"Former"	syria_latimes__1000-01-01__timeline:9714-9719	1.000
:Event_0000145	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000006	syria_latimes__1000-01-01__timeline:9721-9723	1.000
:Event_0000145	Personnel.EndPosition_Person.actual	:Entity_EDL_0000287	syria_latimes__1000-01-01__timeline:9726-9742	1.000
:Event_0000145	Personnel.EndPosition_Person.actual	:Entity_EDL_0000020	syria_latimes__1000-01-01__timeline:9744-9753	1.000
:Event_0000146	type	Manufacture.Artifact
:Event_0000146	mention.actual	"setting up"	syria_latimes__1000-01-01__timeline:10751-10760	1.000
:Event_0000146	canonical_mention.actual	"setting up"	syria_latimes__1000-01-01__timeline:10751-10760	1.000
:Event_0000146	Manufacture.Artifact_Manufacturer.actual	:Entity_EDL_0000197	syria_latimes__1000-01-01__timeline:10698-10704	1.000
:Event_0000146	Manufacture.Artifact_Artifact.actual	:Entity_EDL_0000098	syria_latimes__1000-01-01__timeline:10776-10787	1.000
:Event_0000147	type	Conflict.Attack
:Event_0000147	mention.actual	"overthrow"	syria_bbc__1000-01-01__timeline:380-388	1.000
:Event_0000147	canonical_mention.actual	"overthrow"	syria_bbc__1000-01-01__timeline:380-388	1.000
:Event_0000147	Conflict.Attack_Target.actual	:Entity_EDL_0000002	syria_bbc__1000-01-01__timeline:400-414	1.000
:Event_0000148	type	Life.Die
:Event_0000148	mention.actual	"killed"	syria_bbc__1000-01-01__timeline:1180-1185	1.000
:Event_0000148	canonical_mention.actual	"killed"	syria_bbc__1000-01-01__timeline:1180-1185	1.000
:Event_0000148	Life.Die_Victim.actual	:Entity_EDL_0000038	syria_bbc__1000-01-01__timeline:1109-1114	1.000
:Event_0000148	Life.Die_Agent.actual	:Entity_EDL_0000068	syria_bbc__1000-01-01__timeline:1171-1174	1.000
:Event_0000149	type	Conflict.Attack
:Event_0000149	mention.actual	"clashes"	syria_dailystar__1000-01-01__timeline:2165-2171	1.000
:Event_0000149	canonical_mention.actual	"clashes"	syria_dailystar__1000-01-01__timeline:2165-2171	1.000
:Event_0000149	Conflict.Attack_Place.actual	:Entity_EDL_0000011	syria_dailystar__1000-01-01__timeline:2159-2163	1.000
:Event_0000149	Conflict.Attack_Instrument.actual	:Entity_EDL_0000021	syria_dailystar__1000-01-01__timeline:2241-2249	1.000
:Event_0000150	type	Conflict.Attack
:Event_0000150	mention.actual	"fighting"	syria_latimes__1000-01-01__timeline:10559-10566	1.000
:Event_0000150	canonical_mention.actual	"fighting"	syria_latimes__1000-01-01__timeline:10559-10566	1.000
:Event_0000150	Conflict.Attack_Attacker.actual	:Entity_EDL_0000181	syria_latimes__1000-01-01__timeline:10596-10601	1.000
:Event_0000150	Conflict.Attack_Attacker.actual	:Entity_EDL_0000233	syria_latimes__1000-01-01__timeline:10607-10612	1.000
:Event_0000151	type	ArtifactExistence.DamageDestroy
:Event_0000151	mention.actual	"scorched"	syria_latimes__1000-01-01__timeline:13925-13932	1.000
:Event_0000151	canonical_mention.actual	"scorched"	syria_latimes__1000-01-01__timeline:13925-13932	1.000
:Event_0000151	ArtifactExistence.DamageDestroy_Artifact.actual	:Entity_EDL_0000061	syria_latimes__1000-01-01__timeline:13821-13828	1.000
:Event_0000151	ArtifactExistence.DamageDestroy_Place.actual	:Entity_EDL_0000001	syria_latimes__1000-01-01__timeline:13880-13887	1.000
:Event_0000152	type	Life.Die
:Event_0000152	mention.actual	"mown down"	syria_bbc__1000-01-01__timeline:787-795	1.000
:Event_0000152	canonical_mention.actual	"mown down"	syria_bbc__1000-01-01__timeline:787-795	1.000
:Event_0000152	Life.Die_Victim.actual	:Entity_EDL_0000146	syria_bbc__1000-01-01__timeline:773-780	1.000
:Event_0000152	Life.Die_Instrument.actual	:Entity_EDL_0000231	syria_bbc__1000-01-01__timeline:800-811	1.000
:Event_0000153	type	Conflict.Attack
:Event_0000153	mention.actual	"attack"	syria_latimes__1000-01-01__timeline:3621-3626	1.000
:Event_0000153	canonical_mention.actual	"attack"	syria_latimes__1000-01-01__timeline:3621-3626	1.000
:Event_0000153	Conflict.Attack_Attacker.actual	:Entity_EDL_0000154	syria_latimes__1000-01-01__timeline:3614-3619	1.000
:Event_0000153	Conflict.Attack_Place.actual	:Entity_EDL_0000198	syria_latimes__1000-01-01__timeline:3636-3640	1.000
:Event_0000154	type	Movement.TransportArtifact
:Event_0000154	mention.actual	"enter"	syria_latimes__1000-01-01__timeline:4477-4481	1.000
:Event_0000154	canonical_mention.actual	"enter"	syria_latimes__1000-01-01__timeline:4477-4481	1.000
:Event_0000154	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000302	syria_latimes__1000-01-01__timeline:4447-4451	1.000
:Event_0000154	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000062	syria_latimes__1000-01-01__timeline:4455-4460	1.000
:Event_0000154	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000149	syria_latimes__1000-01-01__timeline:4466-4475	1.000
:Event_0000154	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000100	syria_latimes__1000-01-01__timeline:4483-4486	1.000
:Event_0000155	type	Transaction.TransferOwnership
:Event_0000155	mention.actual	"captures"	syria_sbs__1000-01-01__timeline:1830-1837	1.000
:Event_0000155	canonical_mention.actual	"captures"	syria_sbs__1000-01-01__timeline:1830-1837	1.000
:Event_0000155	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000305	syria_sbs__1000-01-01__timeline:1822-1828	1.000
:Event_0000155	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000074	syria_sbs__1000-01-01__timeline:1850-1853	1.000
:Event_0000156	type	Conflict.Attack
:Event_0000156	mention.actual	"fighting"	syria_washington__1000-01-01__timeline:4131-4138	1.000
:Event_0000156	canonical_mention.actual	"fighting"	syria_washington__1000-01-01__timeline:4131-4138	1.000
:Event_0000156	Conflict.Attack_Attacker.actual	:Entity_EDL_0000244	syria_washington__1000-01-01__timeline:4151-4158	1.000
:Event_0000157	type	Conflict.Attack
:Event_0000157	mention.actual	"gunfire"	syria_latimes__1000-01-01__timeline:924-930	1.000
:Event_0000157	canonical_mention.actual	"gunfire"	syria_latimes__1000-01-01__timeline:924-930	1.000
:Event_0000157	Conflict.Attack_Attacker.actual	:Entity_EDL_0000050	syria_latimes__1000-01-01__timeline:909-914	1.000
:Event_0000157	Conflict.Attack_Attacker.actual	:Entity_EDL_0000163	syria_latimes__1000-01-01__timeline:916-918	1.000
:Event_0000157	Conflict.Attack_Instrument.actual	:Entity_EDL_0000041	syria_latimes__1000-01-01__timeline:936-943	1.000
:Event_0000158	type	Business.Start
:Event_0000158	mention.actual	"formed"	syria_bbc__1000-01-01__timeline:331-336	1.000
:Event_0000158	canonical_mention.actual	"formed"	syria_bbc__1000-01-01__timeline:331-336	1.000
:Event_0000158	Business.Start_Agent.actual	:Entity_EDL_0000220	syria_bbc__1000-01-01__timeline:324-329	1.000
:Event_0000158	Business.Start_Organization.actual	:Entity_EDL_0000261	syria_bbc__1000-01-01__timeline:342-364	1.000
:Event_0000159	type	Life.Die
:Event_0000159	mention.actual	"killed"	syria_bbc__1000-01-01__timeline:2699-2704	1.000
:Event_0000159	canonical_mention.actual	"killed"	syria_bbc__1000-01-01__timeline:2699-2704	1.000
:Event_0000159	Life.Die_Victim.actual	:Entity_EDL_0000187	syria_bbc__1000-01-01__timeline:2685-2688	1.000
:Event_0000159	Life.Die_Instrument.actual	:Entity_EDL_0000203	syria_bbc__1000-01-01__timeline:2709-2713	1.000
:Event_0000160	type	Conflict.Attack
:Event_0000160	mention.actual	"besieged"	syria_latimes__1000-01-01__timeline:13529-13536	1.000
:Event_0000160	canonical_mention.actual	"besieged"	syria_latimes__1000-01-01__timeline:13529-13536	1.000
:Event_0000160	Conflict.Attack_Place.actual	:Entity_EDL_0000095	syria_latimes__1000-01-01__timeline:13547-13552	1.000
:Event_0000161	type	Movement.TransportPerson
:Event_0000161	mention.actual	"pulling"	syria_latimes__1000-01-01__timeline:15511-15517	1.000
:Event_0000161	canonical_mention.actual	"pulling"	syria_latimes__1000-01-01__timeline:15511-15517	1.000
:Event_0000161	Movement.TransportPerson_Agent.actual	:Entity_EDL_0000111	syria_latimes__1000-01-01__timeline:15505-15506	1.000
:Event_0000161	Movement.TransportPerson_Person.actual	:Entity_EDL_0000266	syria_latimes__1000-01-01__timeline:15540-15544	1.000
:Event_0000161	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000000	syria_latimes__1000-01-01__timeline:15551-15555	1.000
:Event_0000162	type	Conflict.Attack
:Event_0000162	mention.actual	"clashes"	syria_washington__1000-01-01__timeline:254-260	1.000
:Event_0000162	canonical_mention.actual	"clashes"	syria_washington__1000-01-01__timeline:254-260	1.000
:Event_0000162	Conflict.Attack_Place.actual	:Entity_EDL_0000029	syria_washington__1000-01-01__timeline:179-183	1.000
:Event_0000162	Conflict.Attack_Attacker.actual	:Entity_EDL_0000120	syria_washington__1000-01-01__timeline:194-199	1.000
:Event_0000163	type	Personnel.EndPosition
:Event_0000163	mention.actual	"withdraws"	syria_latimes__1000-01-01__timeline:6851-6859	1.000
:Event_0000163	canonical_mention.actual	"withdraws"	syria_latimes__1000-01-01__timeline:6851-6859	1.000
:Event_0000163	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000206	syria_latimes__1000-01-01__timeline:6824-6837	1.000
:Event_0000163	Personnel.EndPosition_Person.actual	:Entity_EDL_0000169	syria_latimes__1000-01-01__timeline:6865-6874	1.000
:Event_0000164	type	Conflict.Attack
:Event_0000164	mention.actual	"raiding"	syria_latimes__1000-01-01__timeline:4574-4580	1.000
:Event_0000164	canonical_mention.actual	"raiding"	syria_latimes__1000-01-01__timeline:4574-4580	1.000
:Event_0000164	Conflict.Attack_Attacker.actual	:Entity_EDL_0000062	syria_latimes__1000-01-01__timeline:4455-4460	1.000
:Event_0000164	Conflict.Attack_Instrument.actual	:Entity_EDL_0000149	syria_latimes__1000-01-01__timeline:4466-4475	1.000
:Event_0000164	Conflict.Attack_Place.actual	:Entity_EDL_0000100	syria_latimes__1000-01-01__timeline:4483-4486	1.000
:Event_0000164	Conflict.Attack_Target.actual	:Entity_EDL_0000034	syria_latimes__1000-01-01__timeline:4582-4587	1.000
:Event_0000164	Conflict.Attack_Target.actual	:Entity_EDL_0000044	syria_latimes__1000-01-01__timeline:4606-4614	1.000
:Event_0000165	type	Conflict.Attack
:Event_0000165	mention.actual	"shoot"	syria_washington__1000-01-01__timeline:201-205	1.000
:Event_0000165	canonical_mention.actual	"shoot"	syria_washington__1000-01-01__timeline:201-205	1.000
:Event_0000165	Conflict.Attack_Place.actual	:Entity_EDL_0000211	syria_washington__1000-01-01__timeline:164-167	1.000
:Event_0000165	Conflict.Attack_Attacker.actual	:Entity_EDL_0000120	syria_washington__1000-01-01__timeline:194-199	1.000
:Event_0000165	Conflict.Attack_Target.actual	:Entity_EDL_0000059	syria_washington__1000-01-01__timeline:219-224	1.000
:Event_0000166	type	Movement.TransportPerson
:Event_0000166	mention.actual	"pour into"	syria_latimes__1000-01-01__timeline:2129-2137	1.000
:Event_0000166	canonical_mention.actual	"pour into"	syria_latimes__1000-01-01__timeline:2129-2137	1.000
:Event_0000166	Movement.TransportPerson_Person.actual	:Entity_EDL_0000102	syria_latimes__1000-01-01__timeline:2096-2104	1.000
:Event_0000166	Movement.TransportPerson_Person.actual	:Entity_EDL_0000310	syria_latimes__1000-01-01__timeline:2118-2127	1.000
:Event_0000166	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000159	syria_latimes__1000-01-01__timeline:2143-2149	1.000
:Event_0000167	type	Life.Die
:Event_0000167	mention.actual	"killed"	syria_latimes__1000-01-01__timeline:12811-12816	1.000
:Event_0000167	canonical_mention.actual	"killed"	syria_latimes__1000-01-01__timeline:12811-12816	1.000
:Event_0000167	Life.Die_Victim.actual	:Entity_EDL_0000290	syria_latimes__1000-01-01__timeline:12799-12804	1.000
:Event_0000168	type	Conflict.Attack
:Event_0000168	mention.actual	"fight"	syria_washington__1000-01-01__timeline:4423-4427	1.000
:Event_0000168	canonical_mention.actual	"fight"	syria_washington__1000-01-01__timeline:4423-4427	1.000
:Event_0000168	Conflict.Attack_Attacker.actual	:Entity_EDL_0000117	syria_washington__1000-01-01__timeline:4405-4410	1.000
:Event_0000168	Conflict.Attack_Place.actual	:Entity_EDL_0000223	syria_washington__1000-01-01__timeline:4433-4438	1.000
:Event_0000169	type	Conflict.Attack
:Event_0000169	mention.actual	"shoot down"	syria_washington__1000-01-01__timeline:1569-1578	1.000
:Event_0000169	canonical_mention.actual	"shoot down"	syria_washington__1000-01-01__timeline:1569-1578	1.000
:Event_0000169	Conflict.Attack_Attacker.actual	:Entity_EDL_0000105	syria_washington__1000-01-01__timeline:1562-1567	1.000
:Event_0000169	Conflict.Attack_Target.actual	:Entity_EDL_0000010	syria_washington__1000-01-01__timeline:1590-1592	1.000
:Event_0000169	Conflict.Attack_Place.actual	:Entity_EDL_0000122	syria_washington__1000-01-01__timeline:1603-1608	1.000
:Event_0000170	type	Movement.TransportArtifact
:Event_0000170	mention.actual	"retreating"	syria_washington__1000-01-01__timeline:1021-1030	1.000
:Event_0000170	canonical_mention.actual	"retreating"	syria_washington__1000-01-01__timeline:1021-1030	1.000
:Event_0000170	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000036	syria_washington__1000-01-01__timeline:975-990	1.000
:Event_0000170	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000019	syria_washington__1000-01-01__timeline:1059-1070	1.000
