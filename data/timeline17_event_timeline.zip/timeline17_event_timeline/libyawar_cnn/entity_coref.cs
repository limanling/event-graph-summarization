:Entity_EDL_0000000	type	Person
:Entity_EDL_0000000	nominal_mention	"men"	libyawar_cnn__1000-01-01__timeline:6434-6436	1.0
:Entity_EDL_0000000	link	NIL000000001
:Entity_EDL_0000001	type	Person
:Entity_EDL_0000001	canonical_mention	"Hosni Mubarak"	libyawar_cnn__1000-01-01__timeline:59-71	1.0
:Entity_EDL_0000001	mention	"Hosni Mubarak"	libyawar_cnn__1000-01-01__timeline:59-71	1.0
:Entity_EDL_0000001	link	NIL000000002
:Entity_EDL_0000002	type	Person
:Entity_EDL_0000002	canonical_mention	"woman"	libyawar_cnn__1000-01-01__timeline:5846-5850	1.0
:Entity_EDL_0000002	nominal_mention	"woman"	libyawar_cnn__1000-01-01__timeline:5846-5850	1.0
:Entity_EDL_0000002	link	NIL000000003
:Entity_EDL_0000003	type	Weapon
:Entity_EDL_0000003	canonical_mention	"tear gas"	libyawar_cnn__1000-01-01__timeline:1384-1391	1.0
:Entity_EDL_0000003	nominal_mention	"tear gas"	libyawar_cnn__1000-01-01__timeline:1384-1391	1.0
:Entity_EDL_0000003	link	NIL000000004
:Entity_EDL_0000004	type	GeopoliticalEntity
:Entity_EDL_0000004	pronominal_mention	"its"	libyawar_cnn__1000-01-01__timeline:5613-5615	1.0
:Entity_EDL_0000004	link	NIL000000005
:Entity_EDL_0000005	type	Vehicle
:Entity_EDL_0000005	canonical_mention	"flight"	libyawar_cnn__1000-01-01__timeline:9500-9505	1.0
:Entity_EDL_0000005	nominal_mention	"flight"	libyawar_cnn__1000-01-01__timeline:9500-9505	1.0
:Entity_EDL_0000005	link	NIL000000006
:Entity_EDL_0000006	type	GeopoliticalEntity
:Entity_EDL_0000006	mention	"United States"	libyawar_cnn__1000-01-01__timeline:9570-9582	1.0
:Entity_EDL_0000006	link	6252001
:Entity_EDL_0000007	type	Weapon
:Entity_EDL_0000007	canonical_mention	"bullets"	libyawar_cnn__1000-01-01__timeline:1397-1403	1.0
:Entity_EDL_0000007	nominal_mention	"bullets"	libyawar_cnn__1000-01-01__timeline:1397-1403	1.0
:Entity_EDL_0000007	link	NIL000000007
:Entity_EDL_0000008	type	GeopoliticalEntity
:Entity_EDL_0000008	nominal_mention	"country"	libyawar_cnn__1000-01-01__timeline:8545-8551	1.0
:Entity_EDL_0000008	link	NIL000000008
:Entity_EDL_0000009	type	Person
:Entity_EDL_0000009	canonical_mention	"traitors"	libyawar_cnn__1000-01-01__timeline:10496-10503	1.0
:Entity_EDL_0000009	nominal_mention	"traitors"	libyawar_cnn__1000-01-01__timeline:10496-10503	1.0
:Entity_EDL_0000009	link	NIL000000009
:Entity_EDL_0000010	type	Person
:Entity_EDL_0000010	nominal_mention	"minister"	libyawar_cnn__1000-01-01__timeline:8468-8475	1.0
:Entity_EDL_0000010	link	NIL000000010
:Entity_EDL_0000011	type	GeopoliticalEntity
:Entity_EDL_0000011	mention	"Libya"	libyawar_cnn__1000-01-01__timeline:10468-10472	1.0
:Entity_EDL_0000011	link	2215636
:Entity_EDL_0000012	type	Vehicle
:Entity_EDL_0000012	canonical_mention	"car"	libyawar_cnn__1000-01-01__timeline:6207-6209	1.0
:Entity_EDL_0000012	nominal_mention	"car"	libyawar_cnn__1000-01-01__timeline:6207-6209	1.0
:Entity_EDL_0000012	link	NIL000000011
:Entity_EDL_0000013	type	Person
:Entity_EDL_0000013	nominal_mention	"demonstrators"	libyawar_cnn__1000-01-01__timeline:1812-1824	1.0
:Entity_EDL_0000013	link	NIL000000012
:Entity_EDL_0000014	type	Person
:Entity_EDL_0000014	nominal_mention	"civilians"	libyawar_cnn__1000-01-01__timeline:7510-7518	1.0
:Entity_EDL_0000014	link	NIL000000013
:Entity_EDL_0000015	type	Organization
:Entity_EDL_0000015	nominal_mention	"military"	libyawar_cnn__1000-01-01__timeline:11017-11024	0.000
:Entity_EDL_0000015	link	NIL000000014
:Entity_EDL_0000016	type	GeopoliticalEntity
:Entity_EDL_0000016	mention	"Libya"	libyawar_cnn__1000-01-01__timeline:7975-7979	1.0
:Entity_EDL_0000016	link	2215636
:Entity_EDL_0000017	type	GeopoliticalEntity
:Entity_EDL_0000017	mention	"Tripoli"	libyawar_cnn__1000-01-01__timeline:7697-7703	1.0
:Entity_EDL_0000017	link	2210247
:Entity_EDL_0000018	type	Person
:Entity_EDL_0000018	canonical_mention	"commander"	libyawar_cnn__1000-01-01__timeline:9755-9763	1.0
:Entity_EDL_0000018	nominal_mention	"commander"	libyawar_cnn__1000-01-01__timeline:9755-9763	1.0
:Entity_EDL_0000018	link	NIL000000015
:Entity_EDL_0000019	type	Facility
:Entity_EDL_0000019	nominal_mention	"streets"	libyawar_cnn__1000-01-01__timeline:430-436	0.000
:Entity_EDL_0000019	link	NIL000000016
:Entity_EDL_0000020	type	Person
:Entity_EDL_0000020	pronominal_mention	"one"	libyawar_cnn__1000-01-01__timeline:7725-7727	1.0
:Entity_EDL_0000020	link	NIL000000017
:Entity_EDL_0000021	type	GeopoliticalEntity
:Entity_EDL_0000021	nominal_mention	"country"	libyawar_cnn__1000-01-01__timeline:7072-7078	1.0
:Entity_EDL_0000021	link	NIL000000018
:Entity_EDL_0000022	type	Person
:Entity_EDL_0000022	nominal_mention	"rebels"	libyawar_cnn__1000-01-01__timeline:11654-11659	1.0
:Entity_EDL_0000022	link	NIL000000019
:Entity_EDL_0000023	type	GeopoliticalEntity
:Entity_EDL_0000023	canonical_mention	"Tripoli"	libyawar_cnn__1000-01-01__timeline:912-918	1.0
:Entity_EDL_0000023	mention	"Tripoli"	libyawar_cnn__1000-01-01__timeline:912-918	1.0
:Entity_EDL_0000023	link	2210247
:Entity_EDL_0000024	type	Person
:Entity_EDL_0000024	canonical_mention	"soldiers"	libyawar_cnn__1000-01-01__timeline:1368-1375	1.0
:Entity_EDL_0000024	nominal_mention	"soldiers"	libyawar_cnn__1000-01-01__timeline:1368-1375	1.0
:Entity_EDL_0000024	link	NIL000000020
:Entity_EDL_0000025	type	GeopoliticalEntity
:Entity_EDL_0000025	mention	"United Kingdom"	libyawar_cnn__1000-01-01__timeline:6653-6666	1.0
:Entity_EDL_0000025	link	2635167
:Entity_EDL_0000026	type	GeopoliticalEntity
:Entity_EDL_0000026	canonical_mention	"destination"	libyawar_cnn__1000-01-01__timeline:9514-9524	1.0
:Entity_EDL_0000026	nominal_mention	"destination"	libyawar_cnn__1000-01-01__timeline:9514-9524	1.0
:Entity_EDL_0000026	link	NIL000000021
:Entity_EDL_0000027	type	Facility
:Entity_EDL_0000027	canonical_mention	"hotel"	libyawar_cnn__1000-01-01__timeline:5905-5909	1.0
:Entity_EDL_0000027	nominal_mention	"hotel"	libyawar_cnn__1000-01-01__timeline:5905-5909	1.0
:Entity_EDL_0000027	link	NIL000000022
:Entity_EDL_0000028	type	Person
:Entity_EDL_0000028	mention	"Moussa Koussa"	libyawar_cnn__1000-01-01__timeline:6624-6636	1.0
:Entity_EDL_0000028	link	NIL000000023
:Entity_EDL_0000029	type	Person
:Entity_EDL_0000029	canonical_mention	"civilians"	libyawar_cnn__1000-01-01__timeline:2471-2479	1.0
:Entity_EDL_0000029	nominal_mention	"civilians"	libyawar_cnn__1000-01-01__timeline:2471-2479	1.0
:Entity_EDL_0000029	link	NIL000000024
:Entity_EDL_0000030	type	Person
:Entity_EDL_0000030	nominal_mention	"forces"	libyawar_cnn__1000-01-01__timeline:2124-2129	0.000
:Entity_EDL_0000030	link	NIL000000025
:Entity_EDL_0000031	type	Person
:Entity_EDL_0000031	canonical_mention	"demonstrators"	libyawar_cnn__1000-01-01__timeline:362-374	1.0
:Entity_EDL_0000031	nominal_mention	"demonstrators"	libyawar_cnn__1000-01-01__timeline:362-374	1.0
:Entity_EDL_0000031	link	NIL000000026
:Entity_EDL_0000032	type	GeopoliticalEntity
:Entity_EDL_0000032	mention	"Libya"	libyawar_cnn__1000-01-01__timeline:131-135	1.0
:Entity_EDL_0000032	link	2215636
:Entity_EDL_0000033	type	Person
:Entity_EDL_0000033	pronominal_mention	"Several"	libyawar_cnn__1000-01-01__timeline:489-495	1.0
:Entity_EDL_0000033	link	NIL000000027
:Entity_EDL_0000034	type	GeopoliticalEntity
:Entity_EDL_0000034	nominal_mention	"city"	libyawar_cnn__1000-01-01__timeline:8319-8322	1.0
:Entity_EDL_0000034	link	NIL000000028
:Entity_EDL_0000035	type	GeopoliticalEntity
:Entity_EDL_0000035	canonical_mention	"New York"	libyawar_cnn__1000-01-01__timeline:9475-9482	1.0
:Entity_EDL_0000035	mention	"New York"	libyawar_cnn__1000-01-01__timeline:9475-9482	1.0
:Entity_EDL_0000035	link	5128638
:Entity_EDL_0000036	type	GeopoliticalEntity
:Entity_EDL_0000036	canonical_mention	"Libyans"	libyawar_cnn__1000-01-01__timeline:10167-10173	1.0
:Entity_EDL_0000036	mention	"Libyans"	libyawar_cnn__1000-01-01__timeline:10167-10173	1.0
:Entity_EDL_0000036	link	NIL000000029
:Entity_EDL_0000037	type	GeopoliticalEntity
:Entity_EDL_0000037	mention	"United States"	libyawar_cnn__1000-01-01__timeline:9438-9450	1.0
:Entity_EDL_0000037	link	6252001
:Entity_EDL_0000038	type	Person
:Entity_EDL_0000038	mention	"Moammar Gadhafi"	libyawar_cnn__1000-01-01__timeline:8991-9005	1.0
:Entity_EDL_0000038	link	NIL000000030
:Entity_EDL_0000039	type	Vehicle
:Entity_EDL_0000039	canonical_mention	"limousine"	libyawar_cnn__1000-01-01__timeline:881-889	1.0
:Entity_EDL_0000039	nominal_mention	"limousine"	libyawar_cnn__1000-01-01__timeline:881-889	1.0
:Entity_EDL_0000039	link	NIL000000031
:Entity_EDL_0000040	type	Organization
:Entity_EDL_0000040	canonical_mention	"Justice"	libyawar_cnn__1000-01-01__timeline:3412-3418	1.0
:Entity_EDL_0000040	mention	"Justice"	libyawar_cnn__1000-01-01__timeline:3412-3418	1.0
:Entity_EDL_0000040	link	NIL000000032
:Entity_EDL_0000041	type	Person
:Entity_EDL_0000041	canonical_mention	"each other"	libyawar_cnn__1000-01-01__timeline:692-701	1.0
:Entity_EDL_0000041	pronominal_mention	"each other"	libyawar_cnn__1000-01-01__timeline:692-701	1.0
:Entity_EDL_0000041	link	NIL000000033
:Entity_EDL_0000042	type	Person
:Entity_EDL_0000042	canonical_mention	"minister"	libyawar_cnn__1000-01-01__timeline:2013-2020	1.0
:Entity_EDL_0000042	nominal_mention	"minister"	libyawar_cnn__1000-01-01__timeline:2013-2020	1.0
:Entity_EDL_0000042	link	NIL000000034
:Entity_EDL_0000043	type	Person
:Entity_EDL_0000043	mention	"al-Obeidy"	libyawar_cnn__1000-01-01__timeline:9454-9462	1.0
:Entity_EDL_0000043	link	NIL000000035
:Entity_EDL_0000044	type	Person
:Entity_EDL_0000044	nominal_mention	"people"	libyawar_cnn__1000-01-01__timeline:1117-1122	1.0
:Entity_EDL_0000044	link	NIL000000036
:Entity_EDL_0000045	type	Person
:Entity_EDL_0000045	nominal_mention	"people"	libyawar_cnn__1000-01-01__timeline:7215-7220	1.0
:Entity_EDL_0000045	link	NIL000000037
:Entity_EDL_0000046	type	Person
:Entity_EDL_0000046	pronominal_mention	"she"	libyawar_cnn__1000-01-01__timeline:8137-8139	1.0
:Entity_EDL_0000046	link	NIL000000038
:Entity_EDL_0000047	type	Person
:Entity_EDL_0000047	nominal_mention	"brother"	libyawar_cnn__1000-01-01__timeline:11237-11243	1.0
:Entity_EDL_0000047	link	NIL000000039
:Entity_EDL_0000048	type	Person
:Entity_EDL_0000048	canonical_mention	"staff"	libyawar_cnn__1000-01-01__timeline:6180-6184	1.0
:Entity_EDL_0000048	nominal_mention	"staff"	libyawar_cnn__1000-01-01__timeline:6180-6184	1.0
:Entity_EDL_0000048	link	NIL000000040
:Entity_EDL_0000049	type	GeopoliticalEntity
:Entity_EDL_0000049	canonical_mention	"Italy"	libyawar_cnn__1000-01-01__timeline:8488-8492	1.0
:Entity_EDL_0000049	mention	"Italy"	libyawar_cnn__1000-01-01__timeline:8488-8492	1.0
:Entity_EDL_0000049	link	3175395
:Entity_EDL_0000050	type	Person
:Entity_EDL_0000050	nominal_mention	"forces"	libyawar_cnn__1000-01-01__timeline:1027-1032	0.000
:Entity_EDL_0000050	link	NIL000000041
:Entity_EDL_0000051	type	Person
:Entity_EDL_0000051	canonical_mention	"wife"	libyawar_cnn__1000-01-01__timeline:12028-12031	1.0
:Entity_EDL_0000051	nominal_mention	"wife"	libyawar_cnn__1000-01-01__timeline:12028-12031	1.0
:Entity_EDL_0000051	link	NIL000000042
:Entity_EDL_0000052	type	Person
:Entity_EDL_0000052	canonical_mention	"protesters"	libyawar_cnn__1000-01-01__timeline:961-970	1.0
:Entity_EDL_0000052	nominal_mention	"protesters"	libyawar_cnn__1000-01-01__timeline:961-970	1.0
:Entity_EDL_0000052	link	NIL000000043
:Entity_EDL_0000053	type	Person
:Entity_EDL_0000053	canonical_mention	"they"	libyawar_cnn__1000-01-01__timeline:978-981	1.0
:Entity_EDL_0000053	nominal_mention	"they"	libyawar_cnn__1000-01-01__timeline:978-981	1.0
:Entity_EDL_0000053	link	NIL000000044
:Entity_EDL_0000054	type	GeopoliticalEntity
:Entity_EDL_0000054	mention	"Libya"	libyawar_cnn__1000-01-01__timeline:9205-9209	1.0
:Entity_EDL_0000054	link	2215636
:Entity_EDL_0000055	type	Organization
:Entity_EDL_0000055	mention	"NATO"	libyawar_cnn__1000-01-01__timeline:7043-7046	1.0
:Entity_EDL_0000055	link	20000153
:Entity_EDL_0000056	type	Person
:Entity_EDL_0000056	pronominal_mention	"her"	libyawar_cnn__1000-01-01__timeline:6064-6066	1.0
:Entity_EDL_0000056	link	NIL000000045
:Entity_EDL_0000057	type	GeopoliticalEntity
:Entity_EDL_0000057	canonical_mention	"Tunisia"	libyawar_cnn__1000-01-01__timeline:8049-8055	1.0
:Entity_EDL_0000057	mention	"Tunisia"	libyawar_cnn__1000-01-01__timeline:8049-8055	1.0
:Entity_EDL_0000057	link	2464461
:Entity_EDL_0000058	type	GeopoliticalEntity
:Entity_EDL_0000058	canonical_mention	"cities"	libyawar_cnn__1000-01-01__timeline:1447-1452	1.0
:Entity_EDL_0000058	nominal_mention	"cities"	libyawar_cnn__1000-01-01__timeline:1447-1452	1.0
:Entity_EDL_0000058	link	NIL000000046
:Entity_EDL_0000059	type	Person
:Entity_EDL_0000059	canonical_mention	"Saif al-Islam Gadhafi"	libyawar_cnn__1000-01-01__timeline:1754-1774	1.0
:Entity_EDL_0000059	mention	"Saif al-Islam Gadhafi"	libyawar_cnn__1000-01-01__timeline:1754-1774	1.0
:Entity_EDL_0000059	link	NIL000000047
:Entity_EDL_0000060	type	GeopoliticalEntity
:Entity_EDL_0000060	canonical_mention	"nation"	libyawar_cnn__1000-01-01__timeline:7539-7544	1.0
:Entity_EDL_0000060	nominal_mention	"nation"	libyawar_cnn__1000-01-01__timeline:7539-7544	1.0
:Entity_EDL_0000060	link	NIL000000048
:Entity_EDL_0000061	type	Person
:Entity_EDL_0000061	pronominal_mention	"he"	libyawar_cnn__1000-01-01__timeline:6704-6705	1.0
:Entity_EDL_0000061	link	NIL000000049
:Entity_EDL_0000062	type	Person
:Entity_EDL_0000062	canonical_mention	"associates"	libyawar_cnn__1000-01-01__timeline:3229-3238	1.0
:Entity_EDL_0000062	nominal_mention	"associates"	libyawar_cnn__1000-01-01__timeline:3229-3238	1.0
:Entity_EDL_0000062	link	NIL000000050
:Entity_EDL_0000063	type	Vehicle
:Entity_EDL_0000063	canonical_mention	"submarines"	libyawar_cnn__1000-01-01__timeline:5041-5050	1.0
:Entity_EDL_0000063	nominal_mention	"submarines"	libyawar_cnn__1000-01-01__timeline:5041-5050	1.0
:Entity_EDL_0000063	link	NIL000000051
:Entity_EDL_0000064	type	Person
:Entity_EDL_0000064	nominal_mention	"protesters"	libyawar_cnn__1000-01-01__timeline:2139-2148	1.0
:Entity_EDL_0000064	link	NIL000000052
:Entity_EDL_0000065	type	GeopoliticalEntity
:Entity_EDL_0000065	mention	"Benghazi"	libyawar_cnn__1000-01-01__timeline:926-933	1.0
:Entity_EDL_0000065	link	88319
:Entity_EDL_0000066	type	Person
:Entity_EDL_0000066	pronominal_mention	"he"	libyawar_cnn__1000-01-01__timeline:8508-8509	1.0
:Entity_EDL_0000066	link	NIL000000053
:Entity_EDL_0000067	type	Person
:Entity_EDL_0000067	nominal_mention	"forces"	libyawar_cnn__1000-01-01__timeline:10195-10200	1.0
:Entity_EDL_0000067	link	NIL000000054
:Entity_EDL_0000068	type	Facility
:Entity_EDL_0000068	nominal_mention	"streets"	libyawar_cnn__1000-01-01__timeline:1095-1101	0.000
:Entity_EDL_0000068	link	NIL000000055
:Entity_EDL_0000069	type	GeopoliticalEntity
:Entity_EDL_0000069	mention	"European Union"	libyawar_cnn__1000-01-01__timeline:8263-8276	1.0
:Entity_EDL_0000069	link	6695072
:Entity_EDL_0000070	type	GeopoliticalEntity
:Entity_EDL_0000070	nominal_mention	"country"	libyawar_cnn__1000-01-01__timeline:2265-2271	1.0
:Entity_EDL_0000070	link	NIL000000056
:Entity_EDL_0000071	type	Person
:Entity_EDL_0000071	nominal_mention	"civilians"	libyawar_cnn__1000-01-01__timeline:2593-2601	1.0
:Entity_EDL_0000071	link	NIL000000057
:Entity_EDL_0000072	type	Vehicle
:Entity_EDL_0000072	canonical_mention	"aircraft"	libyawar_cnn__1000-01-01__timeline:11345-11352	1.0
:Entity_EDL_0000072	nominal_mention	"aircraft"	libyawar_cnn__1000-01-01__timeline:11345-11352	1.0
:Entity_EDL_0000072	link	NIL000000058
:Entity_EDL_0000073	type	GeopoliticalEntity
:Entity_EDL_0000073	mention	"Tripoli"	libyawar_cnn__1000-01-01__timeline:11691-11697	1.0
:Entity_EDL_0000073	link	2210247
:Entity_EDL_0000074	type	GeopoliticalEntity
:Entity_EDL_0000074	mention	"Libyan"	libyawar_cnn__1000-01-01__timeline:1538-1543	1.0
:Entity_EDL_0000074	link	2215636
:Entity_EDL_0000075	type	Weapon
:Entity_EDL_0000075	nominal_mention	"missiles"	libyawar_cnn__1000-01-01__timeline:4990-4997	1.0
:Entity_EDL_0000075	link	NIL000000059
:Entity_EDL_0000076	type	Person
:Entity_EDL_0000076	pronominal_mention	"Her"	libyawar_cnn__1000-01-01__timeline:9551-9553	1.0
:Entity_EDL_0000076	link	NIL000000060
:Entity_EDL_0000077	type	Person
:Entity_EDL_0000077	canonical_mention	"she"	libyawar_cnn__1000-01-01__timeline:5961-5963	1.0
:Entity_EDL_0000077	pronominal_mention	"she"	libyawar_cnn__1000-01-01__timeline:5961-5963	1.0
:Entity_EDL_0000077	link	NIL000000061
:Entity_EDL_0000078	type	Person
:Entity_EDL_0000078	canonical_mention	"200"	libyawar_cnn__1000-01-01__timeline:1139-1141	1.0
:Entity_EDL_0000078	pronominal_mention	"200"	libyawar_cnn__1000-01-01__timeline:1139-1141	1.0
:Entity_EDL_0000078	link	NIL000000062
:Entity_EDL_0000079	type	GeopoliticalEntity
:Entity_EDL_0000079	mention	"Benghazi"	libyawar_cnn__1000-01-01__timeline:1320-1327	1.0
:Entity_EDL_0000079	link	88319
:Entity_EDL_0000080	type	Person
:Entity_EDL_0000080	canonical_mention	"officer"	libyawar_cnn__1000-01-01__timeline:8095-8101	1.0
:Entity_EDL_0000080	nominal_mention	"officer"	libyawar_cnn__1000-01-01__timeline:8095-8101	1.0
:Entity_EDL_0000080	link	NIL000000063
:Entity_EDL_0000081	type	Person
:Entity_EDL_0000081	pronominal_mention	"he"	libyawar_cnn__1000-01-01__timeline:2249-2250	1.0
:Entity_EDL_0000081	link	NIL000000064
:Entity_EDL_0000082	type	Person
:Entity_EDL_0000082	pronominal_mention	"15"	libyawar_cnn__1000-01-01__timeline:6021-6022	1.0
:Entity_EDL_0000082	link	NIL000000065
:Entity_EDL_0000083	type	Person
:Entity_EDL_0000083	pronominal_mention	"she"	libyawar_cnn__1000-01-01__timeline:7962-7964	1.0
:Entity_EDL_0000083	link	NIL000000066
:Entity_EDL_0000084	type	Person
:Entity_EDL_0000084	canonical_mention	"Mustafa Abdul Jalil"	libyawar_cnn__1000-01-01__timeline:3429-3447	1.0
:Entity_EDL_0000084	mention	"Mustafa Abdul Jalil"	libyawar_cnn__1000-01-01__timeline:3429-3447	1.0
:Entity_EDL_0000084	link	NIL000000067
:Entity_EDL_0000085	type	Person
:Entity_EDL_0000085	canonical_mention	"suspects"	libyawar_cnn__1000-01-01__timeline:6499-6506	1.0
:Entity_EDL_0000085	nominal_mention	"suspects"	libyawar_cnn__1000-01-01__timeline:6499-6506	1.0
:Entity_EDL_0000085	link	NIL000000068
:Entity_EDL_0000086	type	Organization
:Entity_EDL_0000086	mention	"NATO"	libyawar_cnn__1000-01-01__timeline:7652-7655	1.0
:Entity_EDL_0000086	link	20000153
:Entity_EDL_0000087	type	Person
:Entity_EDL_0000087	canonical_mention	"your"	libyawar_cnn__1000-01-01__timeline:10416-10419	1.0
:Entity_EDL_0000087	pronominal_mention	"your"	libyawar_cnn__1000-01-01__timeline:10416-10419	1.0
:Entity_EDL_0000087	link	NIL000000069
:Entity_EDL_0000088	type	Organization
:Entity_EDL_0000088	nominal_mention	"regime"	libyawar_cnn__1000-01-01__timeline:5213-5218	1.0
:Entity_EDL_0000088	link	NIL000000070
:Entity_EDL_0000089	type	Person
:Entity_EDL_0000089	canonical_mention	"their"	libyawar_cnn__1000-01-01__timeline:1872-1876	1.0
:Entity_EDL_0000089	pronominal_mention	"their"	libyawar_cnn__1000-01-01__timeline:1872-1876	1.0
:Entity_EDL_0000089	link	NIL000000071
:Entity_EDL_0000090	type	Person
:Entity_EDL_0000090	nominal_mention	"protesters"	libyawar_cnn__1000-01-01__timeline:1068-1077	1.0
:Entity_EDL_0000090	link	NIL000000072
:Entity_EDL_0000091	type	Person
:Entity_EDL_0000091	pronominal_mention	"her"	libyawar_cnn__1000-01-01__timeline:6192-6194	1.0
:Entity_EDL_0000091	link	NIL000000073
:Entity_EDL_0000092	type	Person
:Entity_EDL_0000092	nominal_mention	"they"	libyawar_cnn__1000-01-01__timeline:10546-10549	1.0
:Entity_EDL_0000092	link	NIL000000074
:Entity_EDL_0000093	type	Facility
:Entity_EDL_0000093	canonical_mention	"house"	libyawar_cnn__1000-01-01__timeline:7688-7692	1.0
:Entity_EDL_0000093	nominal_mention	"house"	libyawar_cnn__1000-01-01__timeline:7688-7692	1.0
:Entity_EDL_0000093	link	NIL000000075
:Entity_EDL_0000094	type	GeopoliticalEntity
:Entity_EDL_0000094	mention	"Libya"	libyawar_cnn__1000-01-01__timeline:2302-2306	1.0
:Entity_EDL_0000094	link	2215636
:Entity_EDL_0000095	type	GeopoliticalEntity
:Entity_EDL_0000095	nominal_mention	"country"	libyawar_cnn__1000-01-01__timeline:12064-12070	1.0
:Entity_EDL_0000095	link	NIL000000076
:Entity_EDL_0000096	type	Person
:Entity_EDL_0000096	mention	"Gadhafi"	libyawar_cnn__1000-01-01__timeline:6990-6996	1.0
:Entity_EDL_0000096	link	NIL000000077
:Entity_EDL_0000097	type	Person
:Entity_EDL_0000097	canonical_mention	"officers"	libyawar_cnn__1000-01-01__timeline:9839-9846	1.0
:Entity_EDL_0000097	nominal_mention	"officers"	libyawar_cnn__1000-01-01__timeline:9839-9846	1.0
:Entity_EDL_0000097	link	NIL000000078
:Entity_EDL_0000098	type	Person
:Entity_EDL_0000098	canonical_mention	"board"	libyawar_cnn__1000-01-01__timeline:10065-10069	1.0
:Entity_EDL_0000098	nominal_mention	"board"	libyawar_cnn__1000-01-01__timeline:10065-10069	1.0
:Entity_EDL_0000098	link	NIL000000079
:Entity_EDL_0000100	type	Weapon
:Entity_EDL_0000100	nominal_mention	"missile"	libyawar_cnn__1000-01-01__timeline:7668-7674	1.0
:Entity_EDL_0000100	link	NIL000000081
:Entity_EDL_0000101	type	Organization
:Entity_EDL_0000101	canonical_mention	"office"	libyawar_cnn__1000-01-01__timeline:8287-8292	1.0
:Entity_EDL_0000101	nominal_mention	"office"	libyawar_cnn__1000-01-01__timeline:8287-8292	1.0
:Entity_EDL_0000101	link	NIL000000082
:Entity_EDL_0000102	type	GeopoliticalEntity
:Entity_EDL_0000102	nominal_mention	"country"	libyawar_cnn__1000-01-01__timeline:1835-1841	1.0
:Entity_EDL_0000102	link	NIL000000083
:Entity_EDL_0000103	type	GeopoliticalEntity
:Entity_EDL_0000103	mention	"Libya"	libyawar_cnn__1000-01-01__timeline:2609-2613	1.0
:Entity_EDL_0000103	link	2215636
:Entity_EDL_0000104	type	GeopoliticalEntity
:Entity_EDL_0000104	mention	"Libya"	libyawar_cnn__1000-01-01__timeline:3555-3559	1.0
:Entity_EDL_0000104	link	2215636
:Entity_EDL_0000105	type	Person
:Entity_EDL_0000105	pronominal_mention	"she"	libyawar_cnn__1000-01-01__timeline:8028-8030	1.0
:Entity_EDL_0000105	link	NIL000000084
:Entity_EDL_0000106	type	Person
:Entity_EDL_0000106	mention	"al-Obeidy"	libyawar_cnn__1000-01-01__timeline:6456-6464	1.0
:Entity_EDL_0000106	link	NIL000000085
:Entity_EDL_0000107	type	Facility
:Entity_EDL_0000107	canonical_mention	"checkpoint"	libyawar_cnn__1000-01-01__timeline:5982-5991	1.0
:Entity_EDL_0000107	nominal_mention	"checkpoint"	libyawar_cnn__1000-01-01__timeline:5982-5991	1.0
:Entity_EDL_0000107	link	NIL000000086
:Entity_EDL_0000108	type	Vehicle
:Entity_EDL_0000108	canonical_mention	"ships"	libyawar_cnn__1000-01-01__timeline:5031-5035	1.0
:Entity_EDL_0000108	nominal_mention	"ships"	libyawar_cnn__1000-01-01__timeline:5031-5035	1.0
:Entity_EDL_0000108	link	NIL000000087
:Entity_EDL_0000109	type	Person
:Entity_EDL_0000109	nominal_mention	"people"	libyawar_cnn__1000-01-01__timeline:5253-5258	1.0
:Entity_EDL_0000109	link	NIL000000088
:Entity_EDL_0000110	type	Person
:Entity_EDL_0000110	nominal_mention	"people"	libyawar_cnn__1000-01-01__timeline:1511-1516	1.0
:Entity_EDL_0000110	link	NIL000000089
:Entity_EDL_0000111	type	Person
:Entity_EDL_0000111	canonical_mention	"children"	libyawar_cnn__1000-01-01__timeline:12037-12044	1.0
:Entity_EDL_0000111	nominal_mention	"children"	libyawar_cnn__1000-01-01__timeline:12037-12044	1.0
:Entity_EDL_0000111	link	NIL000000090
:Entity_EDL_0000112	type	GeopoliticalEntity
:Entity_EDL_0000112	canonical_mention	"coalition"	libyawar_cnn__1000-01-01__timeline:7489-7497	1.0
:Entity_EDL_0000112	nominal_mention	"coalition"	libyawar_cnn__1000-01-01__timeline:7489-7497	1.0
:Entity_EDL_0000112	link	NIL000000091
:Entity_EDL_0000113	type	GeopoliticalEntity
:Entity_EDL_0000113	mention	"Tripoli"	libyawar_cnn__1000-01-01__timeline:11517-11523	1.0
:Entity_EDL_0000113	link	2210247
:Entity_EDL_0000114	type	Weapon
:Entity_EDL_0000114	nominal_mention	"arms and ammunition"	libyawar_cnn__1000-01-01__timeline:3532-3550	0.000
:Entity_EDL_0000114	link	NIL000000092
:Entity_EDL_0000115	type	Person
:Entity_EDL_0000115	canonical_mention	"officials"	libyawar_cnn__1000-01-01__timeline:6160-6168	1.0
:Entity_EDL_0000115	nominal_mention	"officials"	libyawar_cnn__1000-01-01__timeline:6160-6168	1.0
:Entity_EDL_0000115	link	NIL000000093
:Entity_EDL_0000116	type	Organization
:Entity_EDL_0000116	mention	"NATO"	libyawar_cnn__1000-01-01__timeline:11541-11544	1.0
:Entity_EDL_0000116	link	20000153
:Entity_EDL_0000117	type	Person
:Entity_EDL_0000117	canonical_mention	"activist"	libyawar_cnn__1000-01-01__timeline:409-416	1.0
:Entity_EDL_0000117	nominal_mention	"activist"	libyawar_cnn__1000-01-01__timeline:409-416	1.0
:Entity_EDL_0000117	link	NIL000000094
:Entity_EDL_0000118	type	GeopoliticalEntity
:Entity_EDL_0000118	mention	"Benghazi"	libyawar_cnn__1000-01-01__timeline:9808-9815	1.0
:Entity_EDL_0000118	link	88319
:Entity_EDL_0000119	type	Person
:Entity_EDL_0000119	canonical_mention	"people"	libyawar_cnn__1000-01-01__timeline:676-681	1.0
:Entity_EDL_0000119	nominal_mention	"people"	libyawar_cnn__1000-01-01__timeline:676-681	1.0
:Entity_EDL_0000119	link	NIL000000095
:Entity_EDL_0000120	type	Person
:Entity_EDL_0000120	mention	"Gadhafi"	libyawar_cnn__1000-01-01__timeline:3258-3264	1.0
:Entity_EDL_0000120	link	NIL000000096
:Entity_EDL_0000121	type	GeopoliticalEntity
:Entity_EDL_0000121	mention	"Libya"	libyawar_cnn__1000-01-01__timeline:8206-8210	1.0
:Entity_EDL_0000121	link	2215636
