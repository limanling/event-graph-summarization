:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"strikes"	libya_guardian__1000-01-01__timeline:949-955	1.000
:Event_0000000	canonical_mention.actual	"strikes"	libya_guardian__1000-01-01__timeline:949-955	1.000
:Event_0000000	Conflict.Attack_Attacker.actual	:Entity_EDL_0000126	libya_guardian__1000-01-01__timeline:988-993	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"attack"	libya_xinhua__1000-01-01__timeline:2472-2477	1.000
:Event_0000000	canonical_mention.actual	"attack"	libya_xinhua__1000-01-01__timeline:2472-2477	1.000
:Event_0000000	Conflict.Attack_Attacker.actual	:Entity_EDL_0000023	libya_xinhua__1000-01-01__timeline:2459-2462	1.000
:Event_0000000	Conflict.Attack_Instrument.actual	:Entity_EDL_0000014	libya_xinhua__1000-01-01__timeline:2464-2470	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000206	libya_xinhua__1000-01-01__timeline:2484-2488	1.000
:Event_0000000	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_xinhua__1000-01-01__timeline:2493-2499	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000011	libya_xinhua__1000-01-01__timeline:2528-2530	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000007	libya_xinhua__1000-01-01__timeline:2542-2554	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"attack"	libya_reuters__1000-01-01__timeline:1112-1117	1.000
:Event_0000000	canonical_mention.actual	"attack"	libya_reuters__1000-01-01__timeline:1112-1117	1.000
:Event_0000000	Conflict.Attack_Attacker.actual	:Entity_EDL_0000023	libya_reuters__1000-01-01__timeline:1099-1102	1.000
:Event_0000000	Conflict.Attack_Instrument.actual	:Entity_EDL_0000014	libya_reuters__1000-01-01__timeline:1104-1110	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000220	libya_reuters__1000-01-01__timeline:1124-1128	1.000
:Event_0000000	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_reuters__1000-01-01__timeline:1133-1139	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000011	libya_reuters__1000-01-01__timeline:1167-1169	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000007	libya_reuters__1000-01-01__timeline:1181-1193	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"airstrike"	libya_latimes__1000-01-01__timeline:6222-6230	1.000
:Event_0000000	canonical_mention.actual	"airstrike"	libya_latimes__1000-01-01__timeline:6222-6230	1.000
:Event_0000000	Conflict.Attack_Attacker.actual	:Entity_EDL_0000004	libya_latimes__1000-01-01__timeline:6217-6220	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"strike"	libya_latimes__1000-01-01__timeline:8322-8327	1.000
:Event_0000000	canonical_mention.actual	"strike"	libya_latimes__1000-01-01__timeline:8322-8327	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"attack"	libya_guardian__1000-01-01__timeline:1102-1107	1.000
:Event_0000000	canonical_mention.actual	"attack"	libya_guardian__1000-01-01__timeline:1102-1107	1.000
:Event_0000000	Conflict.Attack_Attacker.actual	:Entity_EDL_0000333	libya_guardian__1000-01-01__timeline:1089-1092	1.000
:Event_0000000	Conflict.Attack_Instrument.actual	:Entity_EDL_0000014	libya_guardian__1000-01-01__timeline:1094-1100	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000346	libya_guardian__1000-01-01__timeline:1114-1118	1.000
:Event_0000000	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_guardian__1000-01-01__timeline:1123-1129	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000011	libya_guardian__1000-01-01__timeline:1157-1159	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000007	libya_guardian__1000-01-01__timeline:1171-1183	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"strike"	libya_latimes__1000-01-01__timeline:8226-8231	1.000
:Event_0000000	canonical_mention.actual	"strike"	libya_latimes__1000-01-01__timeline:8226-8231	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000078	libya_latimes__1000-01-01__timeline:8171-8176	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000249	libya_latimes__1000-01-01__timeline:8196-8203	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000100	libya_latimes__1000-01-01__timeline:8255-8258	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"attacked"	libya_latimes__1000-01-01__timeline:10331-10338	1.000
:Event_0000000	canonical_mention.actual	"attacked"	libya_latimes__1000-01-01__timeline:10331-10338	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000256	libya_latimes__1000-01-01__timeline:10245-10249	1.000
:Event_0000000	Conflict.Attack_Attacker.actual	:Entity_EDL_0000320	libya_latimes__1000-01-01__timeline:10270-10275	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:10313-10326	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"strikes"	libya_reuters__1000-01-01__timeline:959-965	1.000
:Event_0000000	canonical_mention.actual	"strikes"	libya_reuters__1000-01-01__timeline:959-965	1.000
:Event_0000000	Conflict.Attack_Attacker.actual	:Entity_EDL_0000304	libya_reuters__1000-01-01__timeline:998-1003	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"attack"	libya_latimes__1000-01-01__timeline:8296-8301	1.000
:Event_0000000	canonical_mention.actual	"attack"	libya_latimes__1000-01-01__timeline:8296-8301	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"airstrike"	libya_latimes__1000-01-01__timeline:7972-7980	1.000
:Event_0000000	canonical_mention.actual	"airstrike"	libya_latimes__1000-01-01__timeline:7972-7980	1.000
:Event_0000000	Conflict.Attack_Place.actual	:Entity_EDL_0000168	libya_latimes__1000-01-01__timeline:8013-8024	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000022	libya_latimes__1000-01-01__timeline:8067-8072	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"airstrike"	libya_latimes__1000-01-01__timeline:5022-5030	1.000
:Event_0000000	canonical_mention.actual	"airstrike"	libya_latimes__1000-01-01__timeline:5022-5030	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000245	libya_latimes__1000-01-01__timeline:5002-5007	1.000
:Event_0000000	Conflict.Attack_Attacker.actual	:Entity_EDL_0000004	libya_latimes__1000-01-01__timeline:5034-5037	1.000
:Event_0000001	type	Conflict.Demonstrate
:Event_0000001	mention.actual	"protesters"	libya_cnn__1000-01-01__timeline:1068-1077	1.000
:Event_0000001	canonical_mention.actual	"protesters"	libya_cnn__1000-01-01__timeline:1068-1077	1.000
:Event_0000001	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000293	libya_cnn__1000-01-01__timeline:1068-1077	1.000
:Event_0000001	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000417	libya_cnn__1000-01-01__timeline:1095-1101	1.000
:Event_0000001	type	Conflict.Demonstrate
:Event_0000001	mention.actual	"demonstrations"	libya_cnn__1000-01-01__timeline:1545-1558	1.000
:Event_0000001	canonical_mention.actual	"demonstrations"	libya_cnn__1000-01-01__timeline:1545-1558	1.000
:Event_0000001	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	libya_cnn__1000-01-01__timeline:1538-1543	1.000
:Event_0000001	type	Conflict.Demonstrate
:Event_0000001	mention.actual	"Protests"	libya_cnn__1000-01-01__timeline:1233-1240	1.000
:Event_0000001	canonical_mention.actual	"Protests"	libya_cnn__1000-01-01__timeline:1233-1240	1.000
:Event_0000001	type	Conflict.Demonstrate
:Event_0000001	mention.actual	"protesters"	libya_cnn__1000-01-01__timeline:2139-2148	1.000
:Event_0000001	canonical_mention.actual	"protesters"	libya_cnn__1000-01-01__timeline:2139-2148	1.000
:Event_0000001	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000427	libya_cnn__1000-01-01__timeline:2139-2148	1.000
:Event_0000001	type	Conflict.Demonstrate
:Event_0000001	mention.actual	"protesting"	libya_cnn__1000-01-01__timeline:376-385	1.000
:Event_0000001	canonical_mention.actual	"protesting"	libya_cnn__1000-01-01__timeline:376-385	1.000
:Event_0000001	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000231	libya_cnn__1000-01-01__timeline:362-374	1.000
:Event_0000001	type	Conflict.Demonstrate
:Event_0000001	mention.actual	"protests"	libya_cnn__1000-01-01__timeline:1878-1885	1.000
:Event_0000001	canonical_mention.actual	"protests"	libya_cnn__1000-01-01__timeline:1878-1885	1.000
:Event_0000001	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000149	libya_cnn__1000-01-01__timeline:1835-1841	1.000
:Event_0000001	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000077	libya_cnn__1000-01-01__timeline:1872-1876	1.000
:Event_0000001	type	Conflict.Demonstrate
:Event_0000001	mention.actual	"protests"	libya_cnn__1000-01-01__timeline:1422-1429	1.000
:Event_0000001	canonical_mention.actual	"protests"	libya_cnn__1000-01-01__timeline:1422-1429	1.000
:Event_0000001	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000228	libya_cnn__1000-01-01__timeline:1447-1452	1.000
:Event_0000002	type	Life.Die
:Event_0000002	mention.actual	"killed"	libya_guardian__1000-01-01__timeline:4513-4518	1.000
:Event_0000002	canonical_mention.actual	"killed"	libya_guardian__1000-01-01__timeline:4513-4518	1.000
:Event_0000002	Life.Die_Victim.actual	:Entity_EDL_0000392	libya_guardian__1000-01-01__timeline:4498-4500	1.000
:Event_0000002	Life.Die_Victim.actual	:Entity_EDL_0000015	libya_guardian__1000-01-01__timeline:4502-4507	1.000
:Event_0000002	Life.Die_Place.actual	:Entity_EDL_0000000	libya_guardian__1000-01-01__timeline:4546-4552	1.000
:Event_0000002	type	Life.Die
:Event_0000002	mention.actual	"assassinated"	libya_cnn__1000-01-01__timeline:9792-9803	1.000
:Event_0000002	canonical_mention.actual	"assassinated"	libya_cnn__1000-01-01__timeline:9792-9803	1.000
:Event_0000002	Life.Die_Victim.actual	:Entity_EDL_0000309	libya_cnn__1000-01-01__timeline:9755-9763	1.000
:Event_0000002	Life.Die_Place.actual	:Entity_EDL_0000002	libya_cnn__1000-01-01__timeline:9808-9815	1.000
:Event_0000002	Life.Die_Victim.actual	:Entity_EDL_0000411	libya_cnn__1000-01-01__timeline:9839-9846	1.000
:Event_0000002	type	Life.Die
:Event_0000002	mention.actual	"killed"	libya_guardian__1000-01-01__timeline:4798-4803	1.000
:Event_0000002	canonical_mention.actual	"killed"	libya_guardian__1000-01-01__timeline:4798-4803	1.000
:Event_0000002	Life.Die_Victim.actual	:Entity_EDL_0000117	libya_guardian__1000-01-01__timeline:4766-4780	1.000
:Event_0000002	Life.Die_Agent.actual	:Entity_EDL_0000122	libya_guardian__1000-01-01__timeline:4812-4819	1.000
:Event_0000002	Life.Die_Place.actual	:Entity_EDL_0000160	libya_guardian__1000-01-01__timeline:4830-4837	1.000
:Event_0000002	type	Life.Die
:Event_0000002	mention.actual	"dead"	libya_guardian__1000-01-01__timeline:4923-4926	1.000
:Event_0000002	canonical_mention.actual	"dead"	libya_guardian__1000-01-01__timeline:4923-4926	1.000
:Event_0000002	Life.Die_Victim.actual	:Entity_EDL_0000071	libya_guardian__1000-01-01__timeline:4907-4909	1.000
:Event_0000002	Life.Die_Victim.actual	:Entity_EDL_0000204	libya_guardian__1000-01-01__timeline:4911-4918	1.000
:Event_0000002	type	Life.Die
:Event_0000002	mention.actual	"killed"	libya_cnn__1000-01-01__timeline:11315-11320	1.000
:Event_0000002	canonical_mention.actual	"killed"	libya_cnn__1000-01-01__timeline:11315-11320	1.000
:Event_0000002	Life.Die_Victim.actual	:Entity_EDL_0000388	libya_cnn__1000-01-01__timeline:11237-11243	1.000
:Event_0000002	Life.Die_Instrument.actual	:Entity_EDL_0000409	libya_cnn__1000-01-01__timeline:11345-11352	1.000
:Event_0000002	type	Life.Die
:Event_0000002	mention.actual	"body"	libya_guardian__1000-01-01__timeline:5562-5565	1.000
:Event_0000002	canonical_mention.actual	"body"	libya_guardian__1000-01-01__timeline:5562-5565	1.000
:Event_0000002	Life.Die_Victim.actual	:Entity_EDL_0000114	libya_guardian__1000-01-01__timeline:5570-5576	1.000
:Event_0000003	type	Life.Die
:Event_0000003	mention.actual	"death"	libya_aljazeera__1000-01-01__timeline:8037-8041	1.000
:Event_0000003	canonical_mention.actual	"death"	libya_aljazeera__1000-01-01__timeline:8037-8041	1.000
:Event_0000003	Life.Die_Victim.actual	:Entity_EDL_0000213	libya_aljazeera__1000-01-01__timeline:8033-8035	1.000
:Event_0000003	type	Life.Die
:Event_0000003	mention.actual	"death"	libya_aljazeera__1000-01-01__timeline:8197-8201	1.000
:Event_0000003	canonical_mention.actual	"death"	libya_aljazeera__1000-01-01__timeline:8197-8201	1.000
:Event_0000003	Life.Die_Victim.actual	:Entity_EDL_0000443	libya_aljazeera__1000-01-01__timeline:8178-8192	1.000
:Event_0000003	type	Life.Die
:Event_0000003	mention.actual	"death"	libya_aljazeera__1000-01-01__timeline:7946-7950	1.000
:Event_0000003	canonical_mention.actual	"death"	libya_aljazeera__1000-01-01__timeline:7946-7950	1.000
:Event_0000003	Life.Die_Victim.actual	:Entity_EDL_0000105	libya_aljazeera__1000-01-01__timeline:7955-7961	1.000
:Event_0000003	type	Life.Die
:Event_0000003	mention.actual	"death"	libya_afp__1000-01-01__timeline:2211-2215	1.000
:Event_0000003	canonical_mention.actual	"death"	libya_afp__1000-01-01__timeline:2211-2215	1.000
:Event_0000003	Life.Die_Victim.actual	:Entity_EDL_0000128	libya_afp__1000-01-01__timeline:2231-2233	1.000
:Event_0000003	Life.Die_Victim.actual	:Entity_EDL_0000015	libya_afp__1000-01-01__timeline:2235-2240	1.000
:Event_0000003	type	Life.Die
:Event_0000003	mention.actual	"died"	libya_aljazeera__1000-01-01__timeline:7067-7070	1.000
:Event_0000003	canonical_mention.actual	"died"	libya_aljazeera__1000-01-01__timeline:7067-7070	1.000
:Event_0000003	Life.Die_Victim.actual	:Entity_EDL_0000048	libya_aljazeera__1000-01-01__timeline:7047-7061	1.000
:Event_0000003	type	Life.Die
:Event_0000003	mention.actual	"killed"	libya_aljazeera__1000-01-01__timeline:2299-2304	1.000
:Event_0000003	canonical_mention.actual	"killed"	libya_aljazeera__1000-01-01__timeline:2299-2304	1.000
:Event_0000003	Life.Die_Victim.actual	:Entity_EDL_0000271	libya_aljazeera__1000-01-01__timeline:2218-2231	1.000
:Event_0000003	Life.Die_Instrument.actual	:Entity_EDL_0000404	libya_aljazeera__1000-01-01__timeline:2329-2338	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"fight"	libya_cnn__1000-01-01__timeline:5617-5621	1.000
:Event_0000004	canonical_mention.actual	"fight"	libya_cnn__1000-01-01__timeline:5617-5621	1.000
:Event_0000004	Conflict.Attack_Attacker.actual	:Entity_EDL_0000063	libya_cnn__1000-01-01__timeline:5613-5615	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"fight"	libya_cnn__1000-01-01__timeline:10178-10182	1.000
:Event_0000004	canonical_mention.actual	"fight"	libya_cnn__1000-01-01__timeline:10178-10182	1.000
:Event_0000004	Conflict.Attack_Attacker.actual	:Entity_EDL_0000032	libya_cnn__1000-01-01__timeline:10167-10173	1.000
:Event_0000004	Conflict.Attack_Target.actual	:Entity_EDL_0000362	libya_cnn__1000-01-01__timeline:10195-10200	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"conflict"	libya_cnn__1000-01-01__timeline:4529-4536	1.000
:Event_0000004	canonical_mention.actual	"conflict"	libya_cnn__1000-01-01__timeline:4529-4536	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"fight"	libya_cnn__1000-01-01__timeline:10441-10445	1.000
:Event_0000004	canonical_mention.actual	"fight"	libya_cnn__1000-01-01__timeline:10441-10445	1.000
:Event_0000004	Conflict.Attack_Attacker.actual	:Entity_EDL_0000361	libya_cnn__1000-01-01__timeline:10416-10419	1.000
:Event_0000004	Conflict.Attack_Target.actual	:Entity_EDL_0000009	libya_cnn__1000-01-01__timeline:10468-10472	1.000
:Event_0000004	Conflict.Attack_Target.actual	:Entity_EDL_0000258	libya_cnn__1000-01-01__timeline:10496-10503	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"fight"	libya_cnn__1000-01-01__timeline:11678-11682	1.000
:Event_0000004	canonical_mention.actual	"fight"	libya_cnn__1000-01-01__timeline:11678-11682	1.000
:Event_0000004	Conflict.Attack_Attacker.actual	:Entity_EDL_0000167	libya_cnn__1000-01-01__timeline:11654-11659	1.000
:Event_0000004	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_cnn__1000-01-01__timeline:11691-11697	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"war"	libya_cnn__1000-01-01__timeline:7195-7197	1.000
:Event_0000005	canonical_mention.actual	"war"	libya_cnn__1000-01-01__timeline:7195-7197	1.000
:Event_0000005	Conflict.Attack_Target.actual	:Entity_EDL_0000254	libya_cnn__1000-01-01__timeline:7215-7220	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"war"	libya_cnn__1000-01-01__timeline:1865-1867	1.000
:Event_0000005	canonical_mention.actual	"war"	libya_cnn__1000-01-01__timeline:1865-1867	1.000
:Event_0000005	Conflict.Attack_Place.actual	:Entity_EDL_0000149	libya_cnn__1000-01-01__timeline:1835-1841	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"bombing"	libya_cnn__1000-01-01__timeline:7048-7054	1.000
:Event_0000005	canonical_mention.actual	"bombing"	libya_cnn__1000-01-01__timeline:7048-7054	1.000
:Event_0000005	Conflict.Attack_Attacker.actual	:Entity_EDL_0000004	libya_cnn__1000-01-01__timeline:7043-7046	1.000
:Event_0000005	Conflict.Attack_Target.actual	:Entity_EDL_0000042	libya_cnn__1000-01-01__timeline:7072-7078	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"war"	libya_cnn__1000-01-01__timeline:7063-7065	1.000
:Event_0000005	canonical_mention.actual	"war"	libya_cnn__1000-01-01__timeline:7063-7065	1.000
:Event_0000005	Conflict.Attack_Place.actual	:Entity_EDL_0000042	libya_cnn__1000-01-01__timeline:7072-7078	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"war"	libya_cnn__1000-01-01__timeline:5440-5442	1.000
:Event_0000005	canonical_mention.actual	"war"	libya_cnn__1000-01-01__timeline:5440-5442	1.000
:Event_0000006	type	Conflict.Attack
:Event_0000006	mention.actual	"offensive"	libya_afp__1000-01-01__timeline:3498-3506	1.000
:Event_0000006	canonical_mention.actual	"offensive"	libya_afp__1000-01-01__timeline:3498-3506	1.000
:Event_0000006	Conflict.Attack_Attacker.actual	:Entity_EDL_0000344	libya_afp__1000-01-01__timeline:3402-3407	1.000
:Event_0000006	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_afp__1000-01-01__timeline:3415-3421	1.000
:Event_0000006	type	Conflict.Attack
:Event_0000006	mention.actual	"offensive"	libya_afp__1000-01-01__timeline:1477-1485	1.000
:Event_0000006	canonical_mention.actual	"offensive"	libya_afp__1000-01-01__timeline:1477-1485	1.000
:Event_0000006	Conflict.Attack_Attacker.actual	:Entity_EDL_0000276	libya_afp__1000-01-01__timeline:1415-1420	1.000
:Event_0000006	Conflict.Attack_Place.actual	:Entity_EDL_0000134	libya_afp__1000-01-01__timeline:1498-1501	1.000
:Event_0000006	type	Conflict.Attack
:Event_0000006	mention.actual	"offensive"	libya_aljazeera__1000-01-01__timeline:3581-3589	1.000
:Event_0000006	canonical_mention.actual	"offensive"	libya_aljazeera__1000-01-01__timeline:3581-3589	1.000
:Event_0000006	Conflict.Attack_Attacker.actual	:Entity_EDL_0000447	libya_aljazeera__1000-01-01__timeline:3559-3564	1.000
:Event_0000006	Conflict.Attack_Target.actual	:Entity_EDL_0000028	libya_aljazeera__1000-01-01__timeline:3605-3612	1.000
:Event_0000006	type	Conflict.Attack
:Event_0000006	mention.actual	"attack"	libya_aljazeera__1000-01-01__timeline:3641-3646	1.000
:Event_0000006	canonical_mention.actual	"attack"	libya_aljazeera__1000-01-01__timeline:3641-3646	1.000
:Event_0000006	Conflict.Attack_Attacker.actual	:Entity_EDL_0000318	libya_aljazeera__1000-01-01__timeline:3623-3630	1.000
:Event_0000006	Conflict.Attack_Instrument.actual	:Entity_EDL_0000111	libya_aljazeera__1000-01-01__timeline:3667-3671	1.000
:Event_0000006	Conflict.Attack_Target.actual	:Entity_EDL_0000352	libya_aljazeera__1000-01-01__timeline:3680-3687	1.000
:Event_0000006	Conflict.Attack_Place.actual	:Entity_EDL_0000397	libya_aljazeera__1000-01-01__timeline:3698-3703	1.000
:Event_0000006	type	Conflict.Attack
:Event_0000006	mention.actual	"attacks"	libya_afp__1000-01-01__timeline:1551-1557	1.000
:Event_0000006	canonical_mention.actual	"attacks"	libya_afp__1000-01-01__timeline:1551-1557	1.000
:Event_0000006	Conflict.Attack_Attacker.actual	:Entity_EDL_0000058	libya_afp__1000-01-01__timeline:1547-1549	1.000
:Event_0000006	Conflict.Attack_Target.actual	:Entity_EDL_0000107	libya_afp__1000-01-01__timeline:1586-1594	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"rape"	libya_cnn__1000-01-01__timeline:7912-7915	1.000
:Event_0000007	canonical_mention.actual	"rape"	libya_cnn__1000-01-01__timeline:7912-7915	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"raping"	libya_cnn__1000-01-01__timeline:6449-6454	1.000
:Event_0000007	canonical_mention.actual	"raping"	libya_cnn__1000-01-01__timeline:6449-6454	1.000
:Event_0000007	Conflict.Attack_Attacker.actual	:Entity_EDL_0000294	libya_cnn__1000-01-01__timeline:6434-6436	1.000
:Event_0000007	Conflict.Attack_Target.actual	:Entity_EDL_0000020	libya_cnn__1000-01-01__timeline:6456-6464	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"raped"	libya_cnn__1000-01-01__timeline:6058-6062	1.000
:Event_0000007	canonical_mention.actual	"raped"	libya_cnn__1000-01-01__timeline:6058-6062	1.000
:Event_0000007	Conflict.Attack_Place.actual	:Entity_EDL_0000171	libya_cnn__1000-01-01__timeline:5982-5991	1.000
:Event_0000007	Conflict.Attack_Attacker.actual	:Entity_EDL_0000064	libya_cnn__1000-01-01__timeline:6021-6022	1.000
:Event_0000007	Conflict.Attack_Target.actual	:Entity_EDL_0000236	libya_cnn__1000-01-01__timeline:6064-6066	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"beat"	libya_cnn__1000-01-01__timeline:6049-6052	1.000
:Event_0000007	canonical_mention.actual	"beat"	libya_cnn__1000-01-01__timeline:6049-6052	1.000
:Event_0000007	Conflict.Attack_Attacker.actual	:Entity_EDL_0000064	libya_cnn__1000-01-01__timeline:6021-6022	1.000
:Event_0000007	Conflict.Attack_Target.actual	:Entity_EDL_0000236	libya_cnn__1000-01-01__timeline:6064-6066	1.000
:Event_0000008	type	Life.Die
:Event_0000008	mention.actual	"killed"	libya_latimes__1000-01-01__timeline:10344-10349	1.000
:Event_0000008	canonical_mention.actual	"killed"	libya_latimes__1000-01-01__timeline:10344-10349	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000256	libya_latimes__1000-01-01__timeline:10245-10249	1.000
:Event_0000008	Life.Die_Agent.actual	:Entity_EDL_0000320	libya_latimes__1000-01-01__timeline:10270-10275	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:10313-10326	1.000
:Event_0000008	type	Life.Die
:Event_0000008	mention.actual	"killed"	libya_latimes__1000-01-01__timeline:10504-10509	1.000
:Event_0000008	canonical_mention.actual	"killed"	libya_latimes__1000-01-01__timeline:10504-10509	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000031	libya_latimes__1000-01-01__timeline:10455-10472	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000238	libya_latimes__1000-01-01__timeline:10488-10497	1.000
:Event_0000008	type	Life.Die
:Event_0000008	mention.actual	"died"	libya_reuters__1000-01-01__timeline:4695-4698	1.000
:Event_0000008	canonical_mention.actual	"died"	libya_reuters__1000-01-01__timeline:4695-4698	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000093	libya_reuters__1000-01-01__timeline:4684-4686	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000061	libya_reuters__1000-01-01__timeline:4688-4693	1.000
:Event_0000008	Life.Die_Place.actual	:Entity_EDL_0000000	libya_reuters__1000-01-01__timeline:4725-4731	1.000
:Event_0000008	type	Life.Die
:Event_0000008	mention.actual	"dead"	libya_latimes__1000-01-01__timeline:12902-12905	1.000
:Event_0000008	canonical_mention.actual	"dead"	libya_latimes__1000-01-01__timeline:12902-12905	1.000
:Event_0000008	Life.Die_Victim.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:12884-12897	1.000
:Event_0000009	type	Personnel.EndPosition
:Event_0000009	mention.actual	"ouster"	libya_latimes__1000-01-01__timeline:36-41	1.000
:Event_0000009	canonical_mention.actual	"ouster"	libya_latimes__1000-01-01__timeline:36-41	1.000
:Event_0000009	Personnel.EndPosition_Person.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:56-69	1.000
:Event_0000009	Personnel.EndPosition_Place.actual	:Entity_EDL_0000002	libya_latimes__1000-01-01__timeline:80-87	1.000
:Event_0000009	type	Personnel.EndPosition
:Event_0000009	mention.actual	"step down"	libya_latimes__1000-01-01__timeline:1272-1280	1.000
:Event_0000009	canonical_mention.actual	"step down"	libya_latimes__1000-01-01__timeline:1272-1280	1.000
:Event_0000009	Personnel.EndPosition_Person.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:1254-1267	1.000
:Event_0000009	type	Personnel.EndPosition
:Event_0000009	mention.actual	"step down"	libya_latimes__1000-01-01__timeline:2149-2157	1.000
:Event_0000009	canonical_mention.actual	"step down"	libya_latimes__1000-01-01__timeline:2149-2157	1.000
:Event_0000009	Personnel.EndPosition_Person.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:2131-2144	1.000
:Event_0000009	type	Personnel.EndPosition
:Event_0000009	mention.actual	"ouster"	libya_latimes__1000-01-01__timeline:12219-12224	1.000
:Event_0000009	canonical_mention.actual	"ouster"	libya_latimes__1000-01-01__timeline:12219-12224	1.000
:Event_0000009	Personnel.EndPosition_Person.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:12245-12258	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"force"	libya_cnn__1000-01-01__timeline:2103-2107	1.000
:Event_0000010	canonical_mention.actual	"force"	libya_cnn__1000-01-01__timeline:2103-2107	1.000
:Event_0000010	Conflict.Attack_Target.actual	:Entity_EDL_0000243	libya_cnn__1000-01-01__timeline:2013-2020	1.000
:Event_0000010	Conflict.Attack_Attacker.actual	:Entity_EDL_0000200	libya_cnn__1000-01-01__timeline:2124-2129	1.000
:Event_0000010	Conflict.Attack_Target.actual	:Entity_EDL_0000427	libya_cnn__1000-01-01__timeline:2139-2148	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"force"	libya_cnn__1000-01-01__timeline:2457-2461	1.000
:Event_0000010	canonical_mention.actual	"force"	libya_cnn__1000-01-01__timeline:2457-2461	1.000
:Event_0000010	Conflict.Attack_Target.actual	:Entity_EDL_0000311	libya_cnn__1000-01-01__timeline:2471-2479	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"force"	libya_cnn__1000-01-01__timeline:5231-5235	1.000
:Event_0000010	canonical_mention.actual	"force"	libya_cnn__1000-01-01__timeline:5231-5235	1.000
:Event_0000010	Conflict.Attack_Attacker.actual	:Entity_EDL_0000106	libya_cnn__1000-01-01__timeline:5213-5218	1.000
:Event_0000010	Conflict.Attack_Target.actual	:Entity_EDL_0000090	libya_cnn__1000-01-01__timeline:5253-5258	1.000
:Event_0000011	type	Transaction.TransferOwnership
:Event_0000011	mention.actual	"seize"	libya_aljazeera__1000-01-01__timeline:1775-1779	1.000
:Event_0000011	canonical_mention.actual	"seize"	libya_aljazeera__1000-01-01__timeline:1775-1779	1.000
:Event_0000011	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000440	libya_aljazeera__1000-01-01__timeline:1768-1773	1.000
:Event_0000011	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000162	libya_aljazeera__1000-01-01__timeline:1791-1798	1.000
:Event_0000011	type	Transaction.TransferOwnership
:Event_0000011	mention.actual	"taken"	libya_aljazeera__1000-01-01__timeline:1853-1857	1.000
:Event_0000011	canonical_mention.actual	"taken"	libya_aljazeera__1000-01-01__timeline:1853-1857	1.000
:Event_0000011	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000132	libya_aljazeera__1000-01-01__timeline:1827-1831	1.000
:Event_0000011	type	Transaction.TransferOwnership
:Event_0000011	mention.actual	"seized"	libya_aljazeera__1000-01-01__timeline:407-412	1.000
:Event_0000011	canonical_mention.actual	"seized"	libya_aljazeera__1000-01-01__timeline:407-412	1.000
:Event_0000011	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000358	libya_aljazeera__1000-01-01__timeline:398-405	1.000
:Event_0000011	Transaction.TransferOwnership_Place.actual	:Entity_EDL_0000330	libya_aljazeera__1000-01-01__timeline:441-444	1.000
:Event_0000012	type	Conflict.Demonstrate
:Event_0000012	mention.actual	"gathered"	libya_aljazeera__1000-01-01__timeline:172-179	1.000
:Event_0000012	canonical_mention.actual	"gathered"	libya_aljazeera__1000-01-01__timeline:172-179	1.000
:Event_0000012	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000137	libya_aljazeera__1000-01-01__timeline:163-170	1.000
:Event_0000012	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000057	libya_aljazeera__1000-01-01__timeline:200-206	1.000
:Event_0000012	type	Conflict.Demonstrate
:Event_0000012	mention.actual	"protests"	libya_aljazeera__1000-01-01__timeline:48-55	1.000
:Event_0000012	canonical_mention.actual	"protests"	libya_aljazeera__1000-01-01__timeline:48-55	1.000
:Event_0000012	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	libya_aljazeera__1000-01-01__timeline:80-84	1.000
:Event_0000012	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000002	libya_aljazeera__1000-01-01__timeline:151-158	1.000
:Event_0000012	type	Conflict.Demonstrate
:Event_0000012	mention.actual	"protesters"	libya_aljazeera__1000-01-01__timeline:226-235	1.000
:Event_0000012	canonical_mention.actual	"protesters"	libya_aljazeera__1000-01-01__timeline:226-235	1.000
:Event_0000012	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000230	libya_aljazeera__1000-01-01__timeline:226-235	1.000
:Event_0000013	type	Life.Die
:Event_0000013	mention.actual	"killed"	libya_latimes__1000-01-01__timeline:8055-8060	1.000
:Event_0000013	canonical_mention.actual	"killed"	libya_latimes__1000-01-01__timeline:8055-8060	1.000
:Event_0000013	Life.Die_Place.actual	:Entity_EDL_0000168	libya_latimes__1000-01-01__timeline:8013-8024	1.000
:Event_0000013	Life.Die_Victim.actual	:Entity_EDL_0000022	libya_latimes__1000-01-01__timeline:8067-8072	1.000
:Event_0000013	type	Life.Die
:Event_0000013	mention.actual	"killed"	libya_latimes__1000-01-01__timeline:8212-8217	1.000
:Event_0000013	canonical_mention.actual	"killed"	libya_latimes__1000-01-01__timeline:8212-8217	1.000
:Event_0000013	Life.Die_Victim.actual	:Entity_EDL_0000078	libya_latimes__1000-01-01__timeline:8171-8176	1.000
:Event_0000013	Life.Die_Victim.actual	:Entity_EDL_0000249	libya_latimes__1000-01-01__timeline:8196-8203	1.000
:Event_0000013	Life.Die_Place.actual	:Entity_EDL_0000100	libya_latimes__1000-01-01__timeline:8255-8258	1.000
:Event_0000014	type	Contact.Meet
:Event_0000014	mention.actual	"conference"	libya_latimes__1000-01-01__timeline:3752-3761	1.000
:Event_0000014	canonical_mention.actual	"conference"	libya_latimes__1000-01-01__timeline:3752-3761	1.000
:Event_0000014	Contact.Meet_Place.actual	:Entity_EDL_0000263	libya_latimes__1000-01-01__timeline:3766-3771	1.000
:Event_0000014	Contact.Meet_Participant.actual	:Entity_EDL_0000372	libya_latimes__1000-01-01__timeline:3779-3782	1.000
:Event_0000014	type	Contact.Meet
:Event_0000014	mention.actual	"conference"	libya_guardian__1000-01-01__timeline:2063-2072	1.000
:Event_0000014	canonical_mention.actual	"conference"	libya_guardian__1000-01-01__timeline:2063-2072	1.000
:Event_0000014	Contact.Meet_Participant.actual	:Entity_EDL_0000225	libya_guardian__1000-01-01__timeline:2032-2037	1.000
:Event_0000014	Contact.Meet_Participant.actual	:Entity_EDL_0000088	libya_guardian__1000-01-01__timeline:2050-2056	1.000
:Event_0000014	Contact.Meet_Place.actual	:Entity_EDL_0000141	libya_guardian__1000-01-01__timeline:2077-2081	1.000
:Event_0000015	type	Movement.TransportArtifact
:Event_0000015	mention.actual	"arrives"	libya_reuters__1000-01-01__timeline:2300-2306	1.000
:Event_0000015	canonical_mention.actual	"arrives"	libya_reuters__1000-01-01__timeline:2300-2306	1.000
:Event_0000015	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000400	libya_reuters__1000-01-01__timeline:2285-2298	1.000
:Event_0000015	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000000	libya_reuters__1000-01-01__timeline:2311-2317	1.000
:Event_0000015	type	Movement.TransportArtifact
:Event_0000015	mention.actual	"arrives"	libya_reuters__1000-01-01__timeline:4832-4838	1.000
:Event_0000015	canonical_mention.actual	"arrives"	libya_reuters__1000-01-01__timeline:4832-4838	1.000
:Event_0000015	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000221	libya_reuters__1000-01-01__timeline:4817-4830	1.000
:Event_0000015	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000005	libya_reuters__1000-01-01__timeline:4843-4847	1.000
:Event_0000016	type	Movement.TransportArtifact
:Event_0000016	mention.actual	"arrives"	libya_aljazeera__1000-01-01__timeline:6708-6714	1.000
:Event_0000016	canonical_mention.actual	"arrives"	libya_aljazeera__1000-01-01__timeline:6708-6714	1.000
:Event_0000016	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000335	libya_aljazeera__1000-01-01__timeline:6663-6676	1.000
:Event_0000016	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000003	libya_aljazeera__1000-01-01__timeline:6719-6723	1.000
:Event_0000016	type	Movement.TransportArtifact
:Event_0000016	mention.actual	"arrives"	libya_aljazeera__1000-01-01__timeline:4250-4256	1.000
:Event_0000016	canonical_mention.actual	"arrives"	libya_aljazeera__1000-01-01__timeline:4250-4256	1.000
:Event_0000016	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000180	libya_aljazeera__1000-01-01__timeline:4206-4219	1.000
:Event_0000016	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000439	libya_aljazeera__1000-01-01__timeline:4241-4248	1.000
:Event_0000016	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000000	libya_aljazeera__1000-01-01__timeline:4261-4267	1.000
:Event_0000017	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000017	mention.actual	"crimes"	libya_cnn__1000-01-01__timeline:9111-9116	1.000
:Event_0000017	canonical_mention.actual	"crimes"	libya_cnn__1000-01-01__timeline:9111-9116	1.000
:Event_0000017	GenericCrime.GenericCrime.GenericCrime_Place.actual	:Entity_EDL_0000003	libya_cnn__1000-01-01__timeline:9205-9209	1.000
:Event_0000017	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000017	mention.actual	"crimes"	libya_cnn__1000-01-01__timeline:3314-3319	1.000
:Event_0000017	canonical_mention.actual	"crimes"	libya_cnn__1000-01-01__timeline:3314-3319	1.000
:Event_0000017	GenericCrime.GenericCrime.GenericCrime_Perpetrator.actual	:Entity_EDL_0000026	libya_cnn__1000-01-01__timeline:3258-3264	1.000
:Event_0000018	type	Contact.Broadcast
:Event_0000018	mention.actual	"speech"	libya_guardian__1000-01-01__timeline:2602-2607	1.000
:Event_0000018	canonical_mention.actual	"speech"	libya_guardian__1000-01-01__timeline:2602-2607	1.000
:Event_0000018	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000021	libya_guardian__1000-01-01__timeline:2566-2584	1.000
:Event_0000018	Contact.Broadcast_Place.actual	:Entity_EDL_0000000	libya_guardian__1000-01-01__timeline:2612-2618	1.000
:Event_0000018	Contact.Broadcast_Audience.actual	:Entity_EDL_0000425	libya_guardian__1000-01-01__timeline:2625-2629	1.000
:Event_0000018	type	Contact.Broadcast
:Event_0000018	mention.actual	"speech"	libya_guardian__1000-01-01__timeline:3330-3335	1.000
:Event_0000018	canonical_mention.actual	"speech"	libya_guardian__1000-01-01__timeline:3330-3335	1.000
:Event_0000018	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000006	libya_guardian__1000-01-01__timeline:3305-3311	1.000
:Event_0000018	Contact.Broadcast_Audience.actual	:Entity_EDL_0000094	libya_guardian__1000-01-01__timeline:3320-3323	1.000
:Event_0000018	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000281	libya_guardian__1000-01-01__timeline:3384-3390	1.000
:Event_0000019	type	Justice.ArrestJail
:Event_0000019	mention.actual	"arrested"	libya_aljazeera__1000-01-01__timeline:8617-8624	1.000
:Event_0000019	canonical_mention.actual	"arrested"	libya_aljazeera__1000-01-01__timeline:8617-8624	1.000
:Event_0000019	Justice.ArrestJail_Person.actual	:Entity_EDL_0000027	libya_aljazeera__1000-01-01__timeline:8586-8606	1.000
:Event_0000019	Justice.ArrestJail_Place.actual	:Entity_EDL_0000234	libya_aljazeera__1000-01-01__timeline:8631-8635	1.000
:Event_0000019	type	Justice.ArrestJail
:Event_0000019	mention.actual	"arrest"	libya_cnn__1000-01-01__timeline:391-396	1.000
:Event_0000019	canonical_mention.actual	"arrest"	libya_cnn__1000-01-01__timeline:391-396	1.000
:Event_0000019	Justice.ArrestJail_Person.actual	:Entity_EDL_0000393	libya_cnn__1000-01-01__timeline:409-416	1.000
:Event_0000020	type	Movement.TransportArtifact
:Event_0000020	mention.actual	"shipped"	libya_reuters__1000-01-01__timeline:3757-3763	1.000
:Event_0000020	canonical_mention.actual	"shipped"	libya_reuters__1000-01-01__timeline:3757-3763	1.000
:Event_0000020	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000051	libya_reuters__1000-01-01__timeline:3798-3801	1.000
:Event_0000020	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000408	libya_reuters__1000-01-01__timeline:3826-3830	1.000
:Event_0000020	type	Movement.TransportArtifact
:Event_0000020	mention.actual	"sails"	libya_reuters__1000-01-01__timeline:3775-3779	1.000
:Event_0000020	canonical_mention.actual	"sails"	libya_reuters__1000-01-01__timeline:3775-3779	1.000
:Event_0000020	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000051	libya_reuters__1000-01-01__timeline:3798-3801	1.000
:Event_0000020	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000408	libya_reuters__1000-01-01__timeline:3826-3830	1.000
:Event_0000021	type	Conflict.Attack
:Event_0000021	mention.actual	"clashes"	libya_xinhua__1000-01-01__timeline:339-345	1.000
:Event_0000021	canonical_mention.actual	"clashes"	libya_xinhua__1000-01-01__timeline:339-345	1.000
:Event_0000021	Conflict.Attack_Place.actual	:Entity_EDL_0000005	libya_xinhua__1000-01-01__timeline:305-309	1.000
:Event_0000021	type	Conflict.Attack
:Event_0000021	mention.actual	"clashes"	libya_xinhua__1000-01-01__timeline:711-717	1.000
:Event_0000021	canonical_mention.actual	"clashes"	libya_xinhua__1000-01-01__timeline:711-717	1.000
:Event_0000021	Conflict.Attack_Attacker.actual	:Entity_EDL_0000252	libya_xinhua__1000-01-01__timeline:738-746	1.000
:Event_0000021	Conflict.Attack_Attacker.actual	:Entity_EDL_0000262	libya_xinhua__1000-01-01__timeline:752-757	1.000
:Event_0000021	Conflict.Attack_Place.actual	:Entity_EDL_0000049	libya_xinhua__1000-01-01__timeline:776-782	1.000
:Event_0000022	type	Movement.TransportPerson
:Event_0000022	mention.actual	"left"	libya_cnn__1000-01-01__timeline:8511-8514	1.000
:Event_0000022	canonical_mention.actual	"left"	libya_cnn__1000-01-01__timeline:8511-8514	1.000
:Event_0000022	Movement.TransportPerson_Person.actual	:Entity_EDL_0000283	libya_cnn__1000-01-01__timeline:8508-8509	1.000
:Event_0000022	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000177	libya_cnn__1000-01-01__timeline:8545-8551	1.000
:Event_0000022	type	Movement.TransportPerson
:Event_0000022	mention.actual	"defects"	libya_cnn__1000-01-01__timeline:8477-8483	1.000
:Event_0000022	canonical_mention.actual	"defects"	libya_cnn__1000-01-01__timeline:8477-8483	1.000
:Event_0000022	Movement.TransportPerson_Person.actual	:Entity_EDL_0000270	libya_cnn__1000-01-01__timeline:8468-8475	1.000
:Event_0000022	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000034	libya_cnn__1000-01-01__timeline:8488-8492	1.000
:Event_0000023	type	Contact.Broadcast
:Event_0000023	mention.actual	"speech"	libya_aljazeera__1000-01-01__timeline:5326-5331	1.000
:Event_0000023	canonical_mention.actual	"speech"	libya_aljazeera__1000-01-01__timeline:5326-5331	1.000
:Event_0000023	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000013	libya_aljazeera__1000-01-01__timeline:5301-5307	1.000
:Event_0000023	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000410	libya_aljazeera__1000-01-01__timeline:5376-5382	1.000
:Event_0000023	type	Contact.Broadcast
:Event_0000023	mention.actual	"speech"	libya_aljazeera__1000-01-01__timeline:4566-4571	1.000
:Event_0000023	canonical_mention.actual	"speech"	libya_aljazeera__1000-01-01__timeline:4566-4571	1.000
:Event_0000023	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000086	libya_aljazeera__1000-01-01__timeline:4556-4558	1.000
:Event_0000023	Contact.Broadcast_Place.actual	:Entity_EDL_0000000	libya_aljazeera__1000-01-01__timeline:4576-4582	1.000
:Event_0000023	Contact.Broadcast_Audience.actual	:Entity_EDL_0000138	libya_aljazeera__1000-01-01__timeline:4589-4593	1.000
:Event_0000023	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000253	libya_aljazeera__1000-01-01__timeline:4604-4609	1.000
:Event_0000024	type	Life.Die
:Event_0000024	mention.actual	"kills"	libya_reuters__1000-01-01__timeline:1141-1145	1.000
:Event_0000024	canonical_mention.actual	"kills"	libya_reuters__1000-01-01__timeline:1141-1145	1.000
:Event_0000024	Life.Die_Agent.actual	:Entity_EDL_0000023	libya_reuters__1000-01-01__timeline:1099-1102	1.000
:Event_0000024	Life.Die_Instrument.actual	:Entity_EDL_0000014	libya_reuters__1000-01-01__timeline:1104-1110	1.000
:Event_0000024	Life.Die_Place.actual	:Entity_EDL_0000220	libya_reuters__1000-01-01__timeline:1124-1128	1.000
:Event_0000024	Life.Die_Victim.actual	:Entity_EDL_0000011	libya_reuters__1000-01-01__timeline:1167-1169	1.000
:Event_0000024	Life.Die_Victim.actual	:Entity_EDL_0000007	libya_reuters__1000-01-01__timeline:1181-1193	1.000
:Event_0000024	type	Life.Die
:Event_0000024	mention.actual	"killed"	libya_xinhua__1000-01-01__timeline:2501-2506	1.000
:Event_0000024	canonical_mention.actual	"killed"	libya_xinhua__1000-01-01__timeline:2501-2506	1.000
:Event_0000024	Life.Die_Agent.actual	:Entity_EDL_0000023	libya_xinhua__1000-01-01__timeline:2459-2462	1.000
:Event_0000024	Life.Die_Instrument.actual	:Entity_EDL_0000014	libya_xinhua__1000-01-01__timeline:2464-2470	1.000
:Event_0000024	Life.Die_Place.actual	:Entity_EDL_0000206	libya_xinhua__1000-01-01__timeline:2484-2488	1.000
:Event_0000024	Life.Die_Victim.actual	:Entity_EDL_0000011	libya_xinhua__1000-01-01__timeline:2528-2530	1.000
:Event_0000024	Life.Die_Victim.actual	:Entity_EDL_0000007	libya_xinhua__1000-01-01__timeline:2542-2554	1.000
:Event_0000025	type	Movement.TransportArtifact
:Event_0000025	mention.actual	"leave"	libya_cnn__1000-01-01__timeline:2296-2300	1.000
:Event_0000025	canonical_mention.actual	"leave"	libya_cnn__1000-01-01__timeline:2296-2300	1.000
:Event_0000025	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000081	libya_cnn__1000-01-01__timeline:2265-2271	1.000
:Event_0000025	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000009	libya_cnn__1000-01-01__timeline:2302-2306	1.000
:Event_0000025	type	Movement.TransportArtifact
:Event_0000025	mention.actual	"fled"	libya_cnn__1000-01-01__timeline:2256-2259	1.000
:Event_0000025	canonical_mention.actual	"fled"	libya_cnn__1000-01-01__timeline:2256-2259	1.000
:Event_0000025	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000449	libya_cnn__1000-01-01__timeline:2249-2250	1.000
:Event_0000025	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000081	libya_cnn__1000-01-01__timeline:2265-2271	1.000
:Event_0000025	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000009	libya_cnn__1000-01-01__timeline:2302-2306	1.000
:Event_0000026	type	Conflict.Attack
:Event_0000026	mention.actual	"war"	libya_aljazeera__1000-01-01__timeline:1460-1462	1.000
:Event_0000026	canonical_mention.actual	"war"	libya_aljazeera__1000-01-01__timeline:1460-1462	1.000
:Event_0000026	type	Conflict.Attack
:Event_0000026	mention.actual	"war"	libya_aljazeera__1000-01-01__timeline:593-595	1.000
:Event_0000026	canonical_mention.actual	"war"	libya_aljazeera__1000-01-01__timeline:593-595	1.000
:Event_0000027	type	Contact.Meet
:Event_0000027	mention.actual	"meet"	libya_guardian__1000-01-01__timeline:2039-2042	1.000
:Event_0000027	canonical_mention.actual	"meet"	libya_guardian__1000-01-01__timeline:2039-2042	1.000
:Event_0000027	Contact.Meet_Participant.actual	:Entity_EDL_0000225	libya_guardian__1000-01-01__timeline:2032-2037	1.000
:Event_0000027	Contact.Meet_Participant.actual	:Entity_EDL_0000088	libya_guardian__1000-01-01__timeline:2050-2056	1.000
:Event_0000027	Contact.Meet_Place.actual	:Entity_EDL_0000141	libya_guardian__1000-01-01__timeline:2077-2081	1.000
:Event_0000027	type	Contact.Meet
:Event_0000027	mention.actual	"meet"	libya_latimes__1000-01-01__timeline:5475-5478	1.000
:Event_0000027	canonical_mention.actual	"meet"	libya_latimes__1000-01-01__timeline:5475-5478	1.000
:Event_0000027	Contact.Meet_Participant.actual	:Entity_EDL_0000035	libya_latimes__1000-01-01__timeline:5421-5430	1.000
:Event_0000027	Contact.Meet_Participant.actual	:Entity_EDL_0000430	libya_latimes__1000-01-01__timeline:5442-5450	1.000
:Event_0000027	Contact.Meet_Participant.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:5485-5498	1.000
:Event_0000027	Contact.Meet_Place.actual	:Entity_EDL_0000000	libya_latimes__1000-01-01__timeline:5503-5509	1.000
:Event_0000028	type	Conflict.Demonstrate
:Event_0000028	mention.actual	"uprising"	libya_latimes__1000-01-01__timeline:7744-7751	1.000
:Event_0000028	canonical_mention.actual	"uprising"	libya_latimes__1000-01-01__timeline:7744-7751	1.000
:Event_0000028	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000203	libya_latimes__1000-01-01__timeline:7785-7791	1.000
:Event_0000028	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000291	libya_latimes__1000-01-01__timeline:7819-7830	1.000
:Event_0000028	type	Conflict.Demonstrate
:Event_0000028	mention.actual	"uprising"	libya_latimes__1000-01-01__timeline:8816-8823	1.000
:Event_0000028	canonical_mention.actual	"uprising"	libya_latimes__1000-01-01__timeline:8816-8823	1.000
:Event_0000028	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000327	libya_latimes__1000-01-01__timeline:8864-8874	1.000
:Event_0000029	type	Movement.TransportArtifact
:Event_0000029	mention.actual	"shipped"	libya_guardian__1000-01-01__timeline:3750-3756	1.000
:Event_0000029	canonical_mention.actual	"shipped"	libya_guardian__1000-01-01__timeline:3750-3756	1.000
:Event_0000029	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000110	libya_guardian__1000-01-01__timeline:3791-3794	1.000
:Event_0000029	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000121	libya_guardian__1000-01-01__timeline:3819-3823	1.000
:Event_0000029	type	Movement.TransportArtifact
:Event_0000029	mention.actual	"sails"	libya_guardian__1000-01-01__timeline:3768-3772	1.000
:Event_0000029	canonical_mention.actual	"sails"	libya_guardian__1000-01-01__timeline:3768-3772	1.000
:Event_0000029	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000110	libya_guardian__1000-01-01__timeline:3791-3794	1.000
:Event_0000029	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000121	libya_guardian__1000-01-01__timeline:3819-3823	1.000
:Event_0000030	type	Movement.TransportArtifact
:Event_0000030	mention.actual	"shipped"	libya_aljazeera__1000-01-01__timeline:5742-5748	1.000
:Event_0000030	canonical_mention.actual	"shipped"	libya_aljazeera__1000-01-01__timeline:5742-5748	1.000
:Event_0000030	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000369	libya_aljazeera__1000-01-01__timeline:5783-5786	1.000
:Event_0000030	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000034	libya_aljazeera__1000-01-01__timeline:5811-5815	1.000
:Event_0000030	type	Movement.TransportArtifact
:Event_0000030	mention.actual	"sails"	libya_aljazeera__1000-01-01__timeline:5760-5764	1.000
:Event_0000030	canonical_mention.actual	"sails"	libya_aljazeera__1000-01-01__timeline:5760-5764	1.000
:Event_0000030	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000369	libya_aljazeera__1000-01-01__timeline:5783-5786	1.000
:Event_0000030	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000034	libya_aljazeera__1000-01-01__timeline:5811-5815	1.000
:Event_0000031	type	Conflict.Attack
:Event_0000031	mention.actual	"attack"	libya_cnn__1000-01-01__timeline:7676-7681	1.000
:Event_0000031	canonical_mention.actual	"attack"	libya_cnn__1000-01-01__timeline:7676-7681	1.000
:Event_0000031	Conflict.Attack_Attacker.actual	:Entity_EDL_0000004	libya_cnn__1000-01-01__timeline:7652-7655	1.000
:Event_0000031	Conflict.Attack_Instrument.actual	:Entity_EDL_0000387	libya_cnn__1000-01-01__timeline:7668-7674	1.000
:Event_0000031	Conflict.Attack_Target.actual	:Entity_EDL_0000277	libya_cnn__1000-01-01__timeline:7688-7692	1.000
:Event_0000031	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_cnn__1000-01-01__timeline:7697-7703	1.000
:Event_0000031	type	Conflict.Attack
:Event_0000031	mention.actual	"attack"	libya_cnn__1000-01-01__timeline:7712-7717	1.000
:Event_0000031	canonical_mention.actual	"attack"	libya_cnn__1000-01-01__timeline:7712-7717	1.000
:Event_0000031	Conflict.Attack_Target.actual	:Entity_EDL_0000353	libya_cnn__1000-01-01__timeline:7725-7727	1.000
:Event_0000032	type	Contact.Broadcast
:Event_0000032	mention.actual	"speech"	libya_reuters__1000-01-01__timeline:2612-2617	1.000
:Event_0000032	canonical_mention.actual	"speech"	libya_reuters__1000-01-01__timeline:2612-2617	1.000
:Event_0000032	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000118	libya_reuters__1000-01-01__timeline:2576-2594	1.000
:Event_0000032	Contact.Broadcast_Place.actual	:Entity_EDL_0000000	libya_reuters__1000-01-01__timeline:2622-2628	1.000
:Event_0000032	Contact.Broadcast_Audience.actual	:Entity_EDL_0000036	libya_reuters__1000-01-01__timeline:2635-2639	1.000
:Event_0000032	type	Contact.Broadcast
:Event_0000032	mention.actual	"speech"	libya_reuters__1000-01-01__timeline:3341-3346	1.000
:Event_0000032	canonical_mention.actual	"speech"	libya_reuters__1000-01-01__timeline:3341-3346	1.000
:Event_0000032	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000008	libya_reuters__1000-01-01__timeline:3316-3322	1.000
:Event_0000032	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000115	libya_reuters__1000-01-01__timeline:3391-3397	1.000
:Event_0000033	type	Movement.TransportArtifact
:Event_0000033	mention.actual	"retreat"	libya_latimes__1000-01-01__timeline:1513-1519	1.000
:Event_0000033	canonical_mention.actual	"retreat"	libya_latimes__1000-01-01__timeline:1513-1519	1.000
:Event_0000033	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000145	libya_latimes__1000-01-01__timeline:1501-1508	1.000
:Event_0000033	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000030	libya_latimes__1000-01-01__timeline:1524-1532	1.000
:Event_0000033	type	Movement.TransportArtifact
:Event_0000033	mention.actual	"retreating"	libya_latimes__1000-01-01__timeline:4009-4018	1.000
:Event_0000033	canonical_mention.actual	"retreating"	libya_latimes__1000-01-01__timeline:4009-4018	1.000
:Event_0000033	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000288	libya_latimes__1000-01-01__timeline:3961-3966	1.000
:Event_0000033	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000154	libya_latimes__1000-01-01__timeline:3994-3997	1.000
:Event_0000034	type	Justice.ArrestJail
:Event_0000034	mention.actual	"arrest"	libya_cnn__1000-01-01__timeline:8957-8962	1.000
:Event_0000034	canonical_mention.actual	"arrest"	libya_cnn__1000-01-01__timeline:8957-8962	1.000
:Event_0000034	Justice.ArrestJail_Person.actual	:Entity_EDL_0000076	libya_cnn__1000-01-01__timeline:8991-9005	1.000
:Event_0000034	type	Justice.ArrestJail
:Event_0000034	mention.actual	"arrest"	libya_guardian__1000-01-01__timeline:1269-1274	1.000
:Event_0000034	canonical_mention.actual	"arrest"	libya_guardian__1000-01-01__timeline:1269-1274	1.000
:Event_0000034	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000241	libya_guardian__1000-01-01__timeline:1258-1260	1.000
:Event_0000034	Justice.ArrestJail_Person.actual	:Entity_EDL_0000006	libya_guardian__1000-01-01__timeline:1289-1295	1.000
:Event_0000034	Justice.ArrestJail_Person.actual	:Entity_EDL_0000025	libya_guardian__1000-01-01__timeline:1307-1319	1.000
:Event_0000034	Justice.ArrestJail_Person.actual	:Entity_EDL_0000010	libya_guardian__1000-01-01__timeline:1344-1362	1.000
:Event_0000035	type	Conflict.Demonstrate
:Event_0000035	mention.actual	"uprising"	libya_aljazeera__1000-01-01__timeline:7269-7276	1.000
:Event_0000035	canonical_mention.actual	"uprising"	libya_aljazeera__1000-01-01__timeline:7269-7276	1.000
:Event_0000035	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	libya_aljazeera__1000-01-01__timeline:7240-7244	1.000
:Event_0000035	type	Conflict.Demonstrate
:Event_0000035	mention.actual	"uprising"	libya_aljazeera__1000-01-01__timeline:2464-2471	1.000
:Event_0000035	canonical_mention.actual	"uprising"	libya_aljazeera__1000-01-01__timeline:2464-2471	1.000
:Event_0000035	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000101	libya_aljazeera__1000-01-01__timeline:2417-2421	1.000
:Event_0000035	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	libya_aljazeera__1000-01-01__timeline:2426-2432	1.000
:Event_0000036	type	Conflict.Attack
:Event_0000036	mention.actual	"bombardments"	libya_latimes__1000-01-01__timeline:7563-7574	1.000
:Event_0000036	canonical_mention.actual	"bombardments"	libya_latimes__1000-01-01__timeline:7563-7574	1.000
:Event_0000036	Conflict.Attack_Place.actual	:Entity_EDL_0000080	libya_latimes__1000-01-01__timeline:7583-7586	1.000
:Event_0000036	Conflict.Attack_Attacker.actual	:Entity_EDL_0000068	libya_latimes__1000-01-01__timeline:7610-7617	1.000
:Event_0000036	type	Conflict.Attack
:Event_0000036	mention.actual	"hit"	libya_latimes__1000-01-01__timeline:7516-7518	1.000
:Event_0000036	canonical_mention.actual	"hit"	libya_latimes__1000-01-01__timeline:7516-7518	1.000
:Event_0000036	Conflict.Attack_Instrument.actual	:Entity_EDL_0000386	libya_latimes__1000-01-01__timeline:7509-7514	1.000
:Event_0000036	Conflict.Attack_Target.actual	:Entity_EDL_0000378	libya_latimes__1000-01-01__timeline:7531-7537	1.000
:Event_0000037	type	Conflict.Attack
:Event_0000037	mention.actual	"violence"	libya_cnn__1000-01-01__timeline:4761-4768	1.000
:Event_0000037	canonical_mention.actual	"violence"	libya_cnn__1000-01-01__timeline:4761-4768	1.000
:Event_0000037	type	Conflict.Attack
:Event_0000037	mention.actual	"violence"	libya_cnn__1000-01-01__timeline:2437-2444	1.000
:Event_0000037	canonical_mention.actual	"violence"	libya_cnn__1000-01-01__timeline:2437-2444	1.000
:Event_0000038	type	Conflict.Demonstrate
:Event_0000038	mention.actual	"protests"	libya_xinhua__1000-01-01__timeline:425-432	1.000
:Event_0000038	canonical_mention.actual	"protests"	libya_xinhua__1000-01-01__timeline:425-432	1.000
:Event_0000038	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000337	libya_xinhua__1000-01-01__timeline:449-452	1.000
:Event_0000038	type	Conflict.Demonstrate
:Event_0000038	mention.actual	"protests"	libya_xinhua__1000-01-01__timeline:19-26	1.000
:Event_0000038	canonical_mention.actual	"protests"	libya_xinhua__1000-01-01__timeline:19-26	1.000
:Event_0000038	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000223	libya_xinhua__1000-01-01__timeline:46-51	1.000
:Event_0000039	type	Movement.TransportArtifact
:Event_0000039	mention.actual	"take"	libya_cnn__1000-01-01__timeline:418-421	1.000
:Event_0000039	canonical_mention.actual	"take"	libya_cnn__1000-01-01__timeline:418-421	1.000
:Event_0000039	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000231	libya_cnn__1000-01-01__timeline:362-374	1.000
:Event_0000039	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000349	libya_cnn__1000-01-01__timeline:430-436	1.000
:Event_0000039	type	Movement.TransportArtifact
:Event_0000039	mention.actual	"take"	libya_cnn__1000-01-01__timeline:1083-1086	1.000
:Event_0000039	canonical_mention.actual	"take"	libya_cnn__1000-01-01__timeline:1083-1086	1.000
:Event_0000039	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000417	libya_cnn__1000-01-01__timeline:1095-1101	1.000
:Event_0000040	type	Conflict.Demonstrate
:Event_0000040	mention.actual	"protests"	libya_latimes__1000-01-01__timeline:4654-4661	1.000
:Event_0000040	canonical_mention.actual	"protests"	libya_latimes__1000-01-01__timeline:4654-4661	1.000
:Event_0000040	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000375	libya_latimes__1000-01-01__timeline:4624-4629	1.000
:Event_0000040	type	Conflict.Demonstrate
:Event_0000040	mention.actual	"Protests"	libya_latimes__1000-01-01__timeline:11-18	1.000
:Event_0000040	canonical_mention.actual	"Protests"	libya_latimes__1000-01-01__timeline:11-18	1.000
:Event_0000040	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000002	libya_latimes__1000-01-01__timeline:80-87	1.000
:Event_0000041	type	Life.Injure
:Event_0000041	mention.actual	"bloodshed"	libya_afp__1000-01-01__timeline:4035-4043	1.000
:Event_0000041	canonical_mention.actual	"bloodshed"	libya_afp__1000-01-01__timeline:4035-4043	1.000
:Event_0000042	type	Contact.Broadcast
:Event_0000042	mention.actual	"calling"	libya_latimes__1000-01-01__timeline:2335-2341	1.000
:Event_0000042	canonical_mention.actual	"calling"	libya_latimes__1000-01-01__timeline:2335-2341	1.000
:Event_0000042	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000091	libya_latimes__1000-01-01__timeline:2295-2305	1.000
:Event_0000042	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000196	libya_latimes__1000-01-01__timeline:2313-2319	1.000
:Event_0000042	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000240	libya_latimes__1000-01-01__timeline:2325-2330	1.000
:Event_0000043	type	Personnel.EndPosition
:Event_0000043	mention.actual	"fall"	libya_cnn__1000-01-01__timeline:32-35	1.000
:Event_0000043	canonical_mention.actual	"fall"	libya_cnn__1000-01-01__timeline:32-35	1.000
:Event_0000043	Personnel.EndPosition_Person.actual	:Entity_EDL_0000148	libya_cnn__1000-01-01__timeline:59-71	1.000
:Event_0000044	type	Movement.TransportArtifact
:Event_0000044	mention.actual	"crossed"	libya_cnn__1000-01-01__timeline:8036-8042	1.000
:Event_0000044	canonical_mention.actual	"crossed"	libya_cnn__1000-01-01__timeline:8036-8042	1.000
:Event_0000044	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000152	libya_cnn__1000-01-01__timeline:8028-8030	1.000
:Event_0000044	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000448	libya_cnn__1000-01-01__timeline:8049-8055	1.000
:Event_0000044	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000363	libya_cnn__1000-01-01__timeline:8095-8101	1.000
:Event_0000045	type	Business.Start
:Event_0000045	mention.actual	"opens"	libya_cnn__1000-01-01__timeline:8278-8282	1.000
:Event_0000045	canonical_mention.actual	"opens"	libya_cnn__1000-01-01__timeline:8278-8282	1.000
:Event_0000045	Business.Start_Agent.actual	:Entity_EDL_0000355	libya_cnn__1000-01-01__timeline:8263-8276	1.000
:Event_0000045	Business.Start_Organization.actual	:Entity_EDL_0000066	libya_cnn__1000-01-01__timeline:8287-8292	1.000
:Event_0000045	Business.Start_Place.actual	:Entity_EDL_0000083	libya_cnn__1000-01-01__timeline:8319-8322	1.000
:Event_0000046	type	Movement.TransportPerson
:Event_0000046	mention.actual	"crossing"	libya_guardian__1000-01-01__timeline:1946-1953	1.000
:Event_0000046	canonical_mention.actual	"crossing"	libya_guardian__1000-01-01__timeline:1946-1953	1.000
:Event_0000046	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000139	libya_guardian__1000-01-01__timeline:1929-1932	1.000
:Event_0000046	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000296	libya_guardian__1000-01-01__timeline:1959-1966	1.000
:Event_0000047	type	Personnel.EndPosition
:Event_0000047	mention.actual	"resigned"	libya_cnn__1000-01-01__timeline:2026-2033	1.000
:Event_0000047	canonical_mention.actual	"resigned"	libya_cnn__1000-01-01__timeline:2026-2033	1.000
:Event_0000047	Personnel.EndPosition_Person.actual	:Entity_EDL_0000243	libya_cnn__1000-01-01__timeline:2013-2020	1.000
:Event_0000048	type	Conflict.Attack
:Event_0000048	mention.actual	"counterattack"	libya_latimes__1000-01-01__timeline:1374-1386	1.000
:Event_0000048	canonical_mention.actual	"counterattack"	libya_latimes__1000-01-01__timeline:1374-1386	1.000
:Event_0000048	Conflict.Attack_Attacker.actual	:Entity_EDL_0000181	libya_latimes__1000-01-01__timeline:1348-1353	1.000
:Event_0000048	Conflict.Attack_Place.actual	:Entity_EDL_0000095	libya_latimes__1000-01-01__timeline:1391-1400	1.000
:Event_0000049	type	Contact.Meet
:Event_0000049	mention.actual	"talks"	libya_afp__1000-01-01__timeline:3079-3083	1.000
:Event_0000049	canonical_mention.actual	"talks"	libya_afp__1000-01-01__timeline:3079-3083	1.000
:Event_0000049	Contact.Meet_Participant.actual	:Entity_EDL_0000356	libya_afp__1000-01-01__timeline:3056-3060	1.000
:Event_0000049	Contact.Meet_Place.actual	:Entity_EDL_0000284	libya_afp__1000-01-01__timeline:3069-3073	1.000
:Event_0000050	type	Movement.TransportArtifact
:Event_0000050	mention.actual	"flee"	libya_latimes__1000-01-01__timeline:6114-6117	1.000
:Event_0000050	canonical_mention.actual	"flee"	libya_latimes__1000-01-01__timeline:6114-6117	1.000
:Event_0000050	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000242	libya_latimes__1000-01-01__timeline:6107-6112	1.000
:Event_0000050	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000024	libya_latimes__1000-01-01__timeline:6119-6126	1.000
:Event_0000051	type	Conflict.Attack
:Event_0000051	mention.actual	"battle"	libya_latimes__1000-01-01__timeline:12745-12750	1.000
:Event_0000051	canonical_mention.actual	"battle"	libya_latimes__1000-01-01__timeline:12745-12750	1.000
:Event_0000051	Conflict.Attack_Attacker.actual	:Entity_EDL_0000244	libya_latimes__1000-01-01__timeline:12689-12696	1.000
:Event_0000051	Conflict.Attack_Target.actual	:Entity_EDL_0000235	libya_latimes__1000-01-01__timeline:12808-12813	1.000
:Event_0000051	Conflict.Attack_Place.actual	:Entity_EDL_0000210	libya_latimes__1000-01-01__timeline:12828-12835	1.000
:Event_0000052	type	Life.Injure
:Event_0000052	mention.actual	"injured"	libya_latimes__1000-01-01__timeline:8078-8084	1.000
:Event_0000052	canonical_mention.actual	"injured"	libya_latimes__1000-01-01__timeline:8078-8084	1.000
:Event_0000052	Life.Injure_Place.actual	:Entity_EDL_0000168	libya_latimes__1000-01-01__timeline:8013-8024	1.000
:Event_0000052	Life.Injure_Victim.actual	:Entity_EDL_0000303	libya_latimes__1000-01-01__timeline:8086-8087	1.000
:Event_0000053	type	Movement.TransportArtifact
:Event_0000053	mention.actual	"returned"	libya_latimes__1000-01-01__timeline:10519-10526	1.000
:Event_0000053	canonical_mention.actual	"returned"	libya_latimes__1000-01-01__timeline:10519-10526	1.000
:Event_0000053	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000031	libya_latimes__1000-01-01__timeline:10455-10472	1.000
:Event_0000053	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000037	libya_latimes__1000-01-01__timeline:10545-10549	1.000
:Event_0000053	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000033	libya_latimes__1000-01-01__timeline:10556-10565	1.000
:Event_0000053	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000002	libya_latimes__1000-01-01__timeline:10570-10577	1.000
:Event_0000054	type	Justice.ArrestJail
:Event_0000054	mention.actual	"arrest"	libya_latimes__1000-01-01__timeline:6593-6598	1.000
:Event_0000054	canonical_mention.actual	"arrest"	libya_latimes__1000-01-01__timeline:6593-6598	1.000
:Event_0000054	Justice.ArrestJail_Person.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:6627-6640	1.000
:Event_0000055	type	Personnel.EndPosition
:Event_0000055	mention.actual	"resigned"	libya_cnn__1000-01-01__timeline:6711-6718	1.000
:Event_0000055	canonical_mention.actual	"resigned"	libya_cnn__1000-01-01__timeline:6711-6718	1.000
:Event_0000055	Personnel.EndPosition_Person.actual	:Entity_EDL_0000313	libya_cnn__1000-01-01__timeline:6704-6705	1.000
:Event_0000056	type	Personnel.StartPosition
:Event_0000056	mention.actual	"coming"	libya_aljazeera__1000-01-01__timeline:4108-4113	1.000
:Event_0000056	canonical_mention.actual	"coming"	libya_aljazeera__1000-01-01__timeline:4108-4113	1.000
:Event_0000056	Personnel.StartPosition_Person.actual	:Entity_EDL_0000150	libya_aljazeera__1000-01-01__timeline:4104-4106	1.000
:Event_0000057	type	Business.End
:Event_0000057	mention.actual	"crumbling"	libya_afp__1000-01-01__timeline:3649-3657	1.000
:Event_0000057	canonical_mention.actual	"crumbling"	libya_afp__1000-01-01__timeline:3649-3657	1.000
:Event_0000057	Business.End_Organization.actual	:Entity_EDL_0000112	libya_afp__1000-01-01__timeline:3636-3641	1.000
:Event_0000058	type	Conflict.Attack
:Event_0000058	mention.actual	"bomb"	libya_latimes__1000-01-01__timeline:5110-5113	1.000
:Event_0000058	canonical_mention.actual	"bomb"	libya_latimes__1000-01-01__timeline:5110-5113	1.000
:Event_0000058	Conflict.Attack_Place.actual	:Entity_EDL_0000174	libya_latimes__1000-01-01__timeline:5074-5083	1.000
:Event_0000058	Conflict.Attack_Instrument.actual	:Entity_EDL_0000087	libya_latimes__1000-01-01__timeline:5092-5097	1.000
:Event_0000058	Conflict.Attack_Target.actual	:Entity_EDL_0000092	libya_latimes__1000-01-01__timeline:5115-5119	1.000
:Event_0000059	type	Contact.Broadcast
:Event_0000059	mention.actual	"announces"	libya_latimes__1000-01-01__timeline:9750-9758	1.000
:Event_0000059	canonical_mention.actual	"announces"	libya_latimes__1000-01-01__timeline:9750-9758	1.000
:Event_0000059	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000193	libya_latimes__1000-01-01__timeline:9727-9748	1.000
:Event_0000059	Contact.Broadcast_Place.actual	:Entity_EDL_0000414	libya_latimes__1000-01-01__timeline:9763-9770	1.000
:Event_0000060	type	Movement.TransportArtifact
:Event_0000060	mention.actual	"taken"	libya_cnn__1000-01-01__timeline:5969-5973	1.000
:Event_0000060	canonical_mention.actual	"taken"	libya_cnn__1000-01-01__timeline:5969-5973	1.000
:Event_0000060	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000402	libya_cnn__1000-01-01__timeline:5961-5963	1.000
:Event_0000060	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000171	libya_cnn__1000-01-01__timeline:5982-5991	1.000
:Event_0000061	type	Movement.TransportPerson
:Event_0000061	mention.actual	"travel"	libya_cnn__1000-01-01__timeline:3197-3202	1.000
:Event_0000061	canonical_mention.actual	"travel"	libya_cnn__1000-01-01__timeline:3197-3202	1.000
:Event_0000061	Movement.TransportPerson_Person.actual	:Entity_EDL_0000312	libya_cnn__1000-01-01__timeline:3229-3238	1.000
:Event_0000062	type	Life.Die
:Event_0000062	mention.actual	"demise"	libya_afp__1000-01-01__timeline:3022-3027	1.000
:Event_0000062	canonical_mention.actual	"demise"	libya_afp__1000-01-01__timeline:3022-3027	1.000
:Event_0000062	Life.Die_Victim.actual	:Entity_EDL_0000067	libya_afp__1000-01-01__timeline:3016-3020	1.000
:Event_0000063	type	Conflict.Attack
:Event_0000063	mention.actual	"violence"	libya_latimes__1000-01-01__timeline:245-252	1.000
:Event_0000063	canonical_mention.actual	"violence"	libya_latimes__1000-01-01__timeline:245-252	1.000
:Event_0000063	Conflict.Attack_Target.actual	:Entity_EDL_0000348	libya_latimes__1000-01-01__timeline:218-230	1.000
:Event_0000063	Conflict.Attack_Place.actual	:Entity_EDL_0000002	libya_latimes__1000-01-01__timeline:257-264	1.000
:Event_0000064	type	Contact.Broadcast
:Event_0000064	mention.actual	"addresses"	libya_reuters__1000-01-01__timeline:1526-1534	1.000
:Event_0000064	canonical_mention.actual	"addresses"	libya_reuters__1000-01-01__timeline:1526-1534	1.000
:Event_0000064	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000008	libya_reuters__1000-01-01__timeline:1506-1512	1.000
:Event_0000065	type	Conflict.Demonstrate
:Event_0000065	mention.actual	"riot"	libya_reuters__1000-01-01__timeline:69-72	1.000
:Event_0000065	canonical_mention.actual	"riot"	libya_reuters__1000-01-01__timeline:69-72	1.000
:Event_0000065	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000018	libya_reuters__1000-01-01__timeline:77-84	1.000
:Event_0000066	type	Justice.ChargeIndict
:Event_0000066	mention.actual	"charges"	libya_latimes__1000-01-01__timeline:9628-9634	1.000
:Event_0000066	canonical_mention.actual	"charges"	libya_latimes__1000-01-01__timeline:9628-9634	1.000
:Event_0000066	Justice.ChargeIndict_Prosecutor.actual	:Entity_EDL_0000188	libya_latimes__1000-01-01__timeline:9603-9608	1.000
:Event_0000066	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000331	libya_latimes__1000-01-01__timeline:9653-9659	1.000
:Event_0000067	type	Conflict.Attack
:Event_0000067	mention.actual	"lobbed"	libya_aljazeera__1000-01-01__timeline:1114-1119	1.000
:Event_0000067	canonical_mention.actual	"lobbed"	libya_aljazeera__1000-01-01__timeline:1114-1119	1.000
:Event_0000067	Conflict.Attack_Attacker.actual	:Entity_EDL_0000326	libya_aljazeera__1000-01-01__timeline:1080-1083	1.000
:Event_0000067	Conflict.Attack_Instrument.actual	:Entity_EDL_0000156	libya_aljazeera__1000-01-01__timeline:1121-1127	1.000
:Event_0000067	Conflict.Attack_Place.actual	:Entity_EDL_0000269	libya_aljazeera__1000-01-01__timeline:1129-1136	1.000
:Event_0000068	type	Conflict.Attack
:Event_0000068	mention.actual	"Battle"	libya_aljazeera__1000-01-01__timeline:3521-3526	1.000
:Event_0000068	canonical_mention.actual	"Battle"	libya_aljazeera__1000-01-01__timeline:3521-3526	1.000
:Event_0000068	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_aljazeera__1000-01-01__timeline:3532-3538	1.000
:Event_0000069	type	Movement.TransportArtifact
:Event_0000069	mention.actual	"escape"	libya_guardian__1000-01-01__timeline:4116-4121	1.000
:Event_0000069	canonical_mention.actual	"escape"	libya_guardian__1000-01-01__timeline:4116-4121	1.000
:Event_0000069	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000224	libya_guardian__1000-01-01__timeline:4104-4105	1.000
:Event_0000069	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000376	libya_guardian__1000-01-01__timeline:4123-4127	1.000
:Event_0000070	type	Life.Injure
:Event_0000070	mention.actual	"injury"	libya_cnn__1000-01-01__timeline:1291-1296	1.000
:Event_0000070	canonical_mention.actual	"injury"	libya_cnn__1000-01-01__timeline:1291-1296	1.000
:Event_0000071	type	Conflict.Attack
:Event_0000071	mention.actual	"airstrikes"	libya_latimes__1000-01-01__timeline:3613-3622	1.000
:Event_0000071	canonical_mention.actual	"airstrikes"	libya_latimes__1000-01-01__timeline:3613-3622	1.000
:Event_0000072	type	Movement.TransportArtifact
:Event_0000072	mention.actual	"withdraw"	libya_aljazeera__1000-01-01__timeline:983-990	1.000
:Event_0000072	canonical_mention.actual	"withdraw"	libya_aljazeera__1000-01-01__timeline:983-990	1.000
:Event_0000072	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000431	libya_aljazeera__1000-01-01__timeline:976-981	1.000
:Event_0000072	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000017	libya_aljazeera__1000-01-01__timeline:997-1003	1.000
:Event_0000073	type	Personnel.Elect
:Event_0000073	mention.actual	"elected"	libya_guardian__1000-01-01__timeline:5898-5904	1.000
:Event_0000073	canonical_mention.actual	"elected"	libya_guardian__1000-01-01__timeline:5898-5904	1.000
:Event_0000073	Personnel.Elect_Elect.actual	:Entity_EDL_0000334	libya_guardian__1000-01-01__timeline:5874-5893	1.000
:Event_0000074	type	Conflict.Attack
:Event_0000074	mention.actual	"pound"	libya_afp__1000-01-01__timeline:2100-2104	1.000
:Event_0000074	canonical_mention.actual	"pound"	libya_afp__1000-01-01__timeline:2100-2104	1.000
:Event_0000074	Conflict.Attack_Attacker.actual	:Entity_EDL_0000172	libya_afp__1000-01-01__timeline:2081-2089	1.000
:Event_0000074	Conflict.Attack_Attacker.actual	:Entity_EDL_0000199	libya_afp__1000-01-01__timeline:2091-2098	1.000
:Event_0000074	Conflict.Attack_Target.actual	:Entity_EDL_0000308	libya_afp__1000-01-01__timeline:2106-2111	1.000
:Event_0000074	Conflict.Attack_Place.actual	:Entity_EDL_0000186	libya_afp__1000-01-01__timeline:2137-2140	1.000
:Event_0000075	type	ArtifactExistence.DamageDestroy.Damage
:Event_0000075	mention.actual	"destroy"	libya_latimes__1000-01-01__timeline:11881-11887	1.000
:Event_0000075	canonical_mention.actual	"destroy"	libya_latimes__1000-01-01__timeline:11881-11887	1.000
:Event_0000075	ArtifactExistence.DamageDestroy.Damage_Artifact.actual	:Entity_EDL_0000239	libya_latimes__1000-01-01__timeline:11889-11895	1.000
:Event_0000076	type	Movement.TransportArtifact
:Event_0000076	mention.actual	"enter"	libya_aljazeera__1000-01-01__timeline:2697-2701	1.000
:Event_0000076	canonical_mention.actual	"enter"	libya_aljazeera__1000-01-01__timeline:2697-2701	1.000
:Event_0000076	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000226	libya_aljazeera__1000-01-01__timeline:2688-2695	1.000
:Event_0000076	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000000	libya_aljazeera__1000-01-01__timeline:2703-2709	1.000
:Event_0000077	type	Conflict.Attack
:Event_0000077	mention.actual	"Gunfights"	libya_reuters__1000-01-01__timeline:4356-4364	1.000
:Event_0000077	canonical_mention.actual	"Gunfights"	libya_reuters__1000-01-01__timeline:4356-4364	1.000
:Event_0000077	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_reuters__1000-01-01__timeline:4379-4385	1.000
:Event_0000077	Conflict.Attack_Attacker.actual	:Entity_EDL_0000368	libya_reuters__1000-01-01__timeline:4403-4412	1.000
:Event_0000077	Conflict.Attack_Attacker.actual	:Entity_EDL_0000123	libya_reuters__1000-01-01__timeline:4422-4427	1.000
:Event_0000078	type	Movement.TransportArtifact
:Event_0000078	mention.actual	"arrives"	libya_guardian__1000-01-01__timeline:4652-4658	1.000
:Event_0000078	canonical_mention.actual	"arrives"	libya_guardian__1000-01-01__timeline:4652-4658	1.000
:Event_0000078	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000279	libya_guardian__1000-01-01__timeline:4636-4650	1.000
:Event_0000078	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000005	libya_guardian__1000-01-01__timeline:4663-4667	1.000
:Event_0000079	type	Movement.TransportArtifact
:Event_0000079	mention.actual	"leave"	libya_cnn__1000-01-01__timeline:12054-12058	1.000
:Event_0000079	canonical_mention.actual	"leave"	libya_cnn__1000-01-01__timeline:12054-12058	1.000
:Event_0000079	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000222	libya_cnn__1000-01-01__timeline:12028-12031	1.000
:Event_0000079	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000444	libya_cnn__1000-01-01__timeline:12037-12044	1.000
:Event_0000079	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000184	libya_cnn__1000-01-01__timeline:12064-12070	1.000
:Event_0000080	type	Movement.TransportArtifact
:Event_0000080	mention.actual	"visits"	libya_afp__1000-01-01__timeline:3062-3067	1.000
:Event_0000080	canonical_mention.actual	"visits"	libya_afp__1000-01-01__timeline:3062-3067	1.000
:Event_0000080	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000356	libya_afp__1000-01-01__timeline:3056-3060	1.000
:Event_0000080	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000284	libya_afp__1000-01-01__timeline:3069-3073	1.000
:Event_0000081	type	Conflict.Attack
:Event_0000081	mention.actual	"airstrikes"	libya_latimes__1000-01-01__timeline:3139-3148	1.000
:Event_0000081	canonical_mention.actual	"airstrikes"	libya_latimes__1000-01-01__timeline:3139-3148	1.000
:Event_0000082	type	Contact.Meet
:Event_0000082	mention.actual	"meets"	libya_afp__1000-01-01__timeline:1028-1032	1.000
:Event_0000082	canonical_mention.actual	"meets"	libya_afp__1000-01-01__timeline:1028-1032	1.000
:Event_0000082	Contact.Meet_Participant.actual	:Entity_EDL_0000119	libya_afp__1000-01-01__timeline:991-1026	1.000
:Event_0000082	Contact.Meet_Place.actual	:Entity_EDL_0000102	libya_afp__1000-01-01__timeline:1037-1045	1.000
:Event_0000083	type	Movement.TransportPerson
:Event_0000083	mention.actual	"arrival"	libya_cnn__1000-01-01__timeline:9555-9561	1.000
:Event_0000083	canonical_mention.actual	"arrival"	libya_cnn__1000-01-01__timeline:9555-9561	1.000
:Event_0000083	Movement.TransportPerson_Person.actual	:Entity_EDL_0000350	libya_cnn__1000-01-01__timeline:9551-9553	1.000
:Event_0000083	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000016	libya_cnn__1000-01-01__timeline:9570-9582	1.000
:Event_0000084	type	Conflict.Attack
:Event_0000084	mention.actual	"airstrikes"	libya_cnn__1000-01-01__timeline:7449-7458	1.000
:Event_0000084	canonical_mention.actual	"airstrikes"	libya_cnn__1000-01-01__timeline:7449-7458	1.000
:Event_0000085	type	Conflict.Attack
:Event_0000085	mention.actual	"airstrikes"	libya_latimes__1000-01-01__timeline:7625-7634	1.000
:Event_0000085	canonical_mention.actual	"airstrikes"	libya_latimes__1000-01-01__timeline:7625-7634	1.000
:Event_0000085	Conflict.Attack_Attacker.actual	:Entity_EDL_0000068	libya_latimes__1000-01-01__timeline:7610-7617	1.000
:Event_0000086	type	Conflict.Attack
:Event_0000086	mention.actual	"repression"	libya_latimes__1000-01-01__timeline:1082-1091	1.000
:Event_0000086	canonical_mention.actual	"repression"	libya_latimes__1000-01-01__timeline:1082-1091	1.000
:Event_0000086	Conflict.Attack_Target.actual	:Entity_EDL_0000173	libya_latimes__1000-01-01__timeline:1105-1117	1.000
:Event_0000086	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_latimes__1000-01-01__timeline:1122-1128	1.000
:Event_0000087	type	Conflict.Attack
:Event_0000087	mention.actual	"siege"	libya_latimes__1000-01-01__timeline:2545-2549	1.000
:Event_0000087	canonical_mention.actual	"siege"	libya_latimes__1000-01-01__timeline:2545-2549	1.000
:Event_0000087	Conflict.Attack_Target.actual	:Entity_EDL_0000072	libya_latimes__1000-01-01__timeline:2504-2509	1.000
:Event_0000087	Conflict.Attack_Place.actual	:Entity_EDL_0000024	libya_latimes__1000-01-01__timeline:2522-2529	1.000
:Event_0000088	type	Transaction.TransferOwnership
:Event_0000088	mention.actual	"retaking"	libya_xinhua__1000-01-01__timeline:1545-1552	1.000
:Event_0000088	canonical_mention.actual	"retaking"	libya_xinhua__1000-01-01__timeline:1545-1552	1.000
:Event_0000088	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000187	libya_xinhua__1000-01-01__timeline:1469-1474	1.000
:Event_0000089	type	Life.Injure
:Event_0000089	mention.actual	"wounded"	libya_cnn__1000-01-01__timeline:1147-1153	1.000
:Event_0000089	canonical_mention.actual	"wounded"	libya_cnn__1000-01-01__timeline:1147-1153	1.000
:Event_0000089	Life.Injure_Victim.actual	:Entity_EDL_0000179	libya_cnn__1000-01-01__timeline:1139-1141	1.000
:Event_0000090	type	Transaction.TransferOwnership
:Event_0000090	mention.actual	"sale"	libya_cnn__1000-01-01__timeline:3524-3527	1.000
:Event_0000090	canonical_mention.actual	"sale"	libya_cnn__1000-01-01__timeline:3524-3527	1.000
:Event_0000090	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000079	libya_cnn__1000-01-01__timeline:3532-3550	1.000
:Event_0000090	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000003	libya_cnn__1000-01-01__timeline:3555-3559	1.000
:Event_0000091	type	Conflict.Attack
:Event_0000091	mention.actual	"fight"	libya_aljazeera__1000-01-01__timeline:2810-2814	1.000
:Event_0000091	canonical_mention.actual	"fight"	libya_aljazeera__1000-01-01__timeline:2810-2814	1.000
:Event_0000091	Conflict.Attack_Attacker.actual	:Entity_EDL_0000032	libya_aljazeera__1000-01-01__timeline:2799-2805	1.000
:Event_0000092	type	Movement.TransportArtifact
:Event_0000092	mention.actual	"arrives"	libya_guardian__1000-01-01__timeline:2290-2296	1.000
:Event_0000092	canonical_mention.actual	"arrives"	libya_guardian__1000-01-01__timeline:2290-2296	1.000
:Event_0000092	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000219	libya_guardian__1000-01-01__timeline:2275-2288	1.000
:Event_0000092	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000000	libya_guardian__1000-01-01__timeline:2301-2307	1.000
:Event_0000093	type	Conflict.Attack
:Event_0000093	mention.actual	"combat"	libya_latimes__1000-01-01__timeline:4879-4884	1.000
:Event_0000093	canonical_mention.actual	"combat"	libya_latimes__1000-01-01__timeline:4879-4884	1.000
:Event_0000093	Conflict.Attack_Attacker.actual	:Entity_EDL_0000062	libya_latimes__1000-01-01__timeline:4853-4855	1.000
:Event_0000093	Conflict.Attack_Instrument.actual	:Entity_EDL_0000147	libya_latimes__1000-01-01__timeline:4857-4865	1.000
:Event_0000094	type	Movement.TransportArtifact
:Event_0000094	mention.actual	"deported"	libya_cnn__1000-01-01__timeline:8189-8196	1.000
:Event_0000094	canonical_mention.actual	"deported"	libya_cnn__1000-01-01__timeline:8189-8196	1.000
:Event_0000094	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000342	libya_cnn__1000-01-01__timeline:8137-8139	1.000
:Event_0000094	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000009	libya_cnn__1000-01-01__timeline:8206-8210	1.000
:Event_0000095	type	Contact.Meet
:Event_0000095	mention.actual	"met"	libya_latimes__1000-01-01__timeline:7402-7404	1.000
:Event_0000095	canonical_mention.actual	"met"	libya_latimes__1000-01-01__timeline:7402-7404	1.000
:Event_0000095	Contact.Meet_Participant.actual	:Entity_EDL_0000035	libya_latimes__1000-01-01__timeline:7397-7400	1.000
:Event_0000095	Contact.Meet_Participant.actual	:Entity_EDL_0000161	libya_latimes__1000-01-01__timeline:7422-7427	1.000
:Event_0000095	Contact.Meet_Place.actual	:Entity_EDL_0000000	libya_latimes__1000-01-01__timeline:7432-7438	1.000
:Event_0000096	type	Conflict.Attack
:Event_0000096	mention.actual	"attacks"	libya_latimes__1000-01-01__timeline:5049-5055	1.000
:Event_0000096	canonical_mention.actual	"attacks"	libya_latimes__1000-01-01__timeline:5049-5055	1.000
:Event_0000096	Conflict.Attack_Attacker.actual	:Entity_EDL_0000004	libya_latimes__1000-01-01__timeline:5034-5037	1.000
:Event_0000096	Conflict.Attack_Target.actual	:Entity_EDL_0000000	libya_latimes__1000-01-01__timeline:5060-5066	1.000
:Event_0000097	type	Conflict.Attack
:Event_0000097	mention.actual	"bombing"	libya_aljazeera__1000-01-01__timeline:687-693	1.000
:Event_0000097	canonical_mention.actual	"bombing"	libya_aljazeera__1000-01-01__timeline:687-693	1.000
:Event_0000097	Conflict.Attack_Attacker.actual	:Entity_EDL_0000004	libya_aljazeera__1000-01-01__timeline:675-678	1.000
:Event_0000097	Conflict.Attack_Target.actual	:Entity_EDL_0000003	libya_aljazeera__1000-01-01__timeline:695-699	1.000
:Event_0000098	type	Personnel.Elect
:Event_0000098	mention.actual	"elections"	libya_latimes__1000-01-01__timeline:13033-13041	1.000
:Event_0000098	canonical_mention.actual	"elections"	libya_latimes__1000-01-01__timeline:13033-13041	1.000
:Event_0000099	type	Movement.TransportArtifact
:Event_0000099	mention.actual	"enter"	libya_guardian__1000-01-01__timeline:1456-1460	1.000
:Event_0000099	canonical_mention.actual	"enter"	libya_guardian__1000-01-01__timeline:1456-1460	1.000
:Event_0000099	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000056	libya_guardian__1000-01-01__timeline:1449-1454	1.000
:Event_0000099	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000000	libya_guardian__1000-01-01__timeline:1462-1468	1.000
:Event_0000100	type	Conflict.Demonstrate
:Event_0000100	mention.actual	"demonstrations"	libya_cnn__1000-01-01__timeline:113-126	1.000
:Event_0000100	canonical_mention.actual	"demonstrations"	libya_cnn__1000-01-01__timeline:113-126	1.000
:Event_0000100	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	libya_cnn__1000-01-01__timeline:131-135	1.000
:Event_0000101	type	Conflict.Yield.Surrender
:Event_0000101	mention.actual	"surrender"	libya_aljazeera__1000-01-01__timeline:5229-5237	1.000
:Event_0000101	canonical_mention.actual	"surrender"	libya_aljazeera__1000-01-01__timeline:5229-5237	1.000
:Event_0000102	type	Movement.TransportArtifact
:Event_0000102	mention.actual	"enter"	libya_guardian__1000-01-01__timeline:1862-1866	1.000
:Event_0000102	canonical_mention.actual	"enter"	libya_guardian__1000-01-01__timeline:1862-1866	1.000
:Event_0000102	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000266	libya_guardian__1000-01-01__timeline:1836-1840	1.000
:Event_0000102	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000299	libya_guardian__1000-01-01__timeline:1846-1848	1.000
:Event_0000102	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000012	libya_guardian__1000-01-01__timeline:1868-1874	1.000
:Event_0000103	type	Conflict.Attack
:Event_0000103	mention.actual	"war"	libya_xinhua__1000-01-01__timeline:328-330	1.000
:Event_0000103	canonical_mention.actual	"war"	libya_xinhua__1000-01-01__timeline:328-330	1.000
:Event_0000103	Conflict.Attack_Place.actual	:Entity_EDL_0000005	libya_xinhua__1000-01-01__timeline:305-309	1.000
:Event_0000104	type	Conflict.Attack
:Event_0000104	mention.actual	"siege"	libya_reuters__1000-01-01__timeline:5016-5020	1.000
:Event_0000104	canonical_mention.actual	"siege"	libya_reuters__1000-01-01__timeline:5016-5020	1.000
:Event_0000104	Conflict.Attack_Attacker.actual	:Entity_EDL_0000190	libya_reuters__1000-01-01__timeline:4950-4957	1.000
:Event_0000105	type	Movement.TransportArtifact
:Event_0000105	mention.actual	"withdraw"	libya_latimes__1000-01-01__timeline:4594-4601	1.000
:Event_0000105	canonical_mention.actual	"withdraw"	libya_latimes__1000-01-01__timeline:4594-4601	1.000
:Event_0000105	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000433	libya_latimes__1000-01-01__timeline:4587-4592	1.000
:Event_0000105	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000375	libya_latimes__1000-01-01__timeline:4624-4629	1.000
:Event_0000106	type	Contact.Broadcast
:Event_0000106	mention.actual	"addresses"	libya_guardian__1000-01-01__timeline:1516-1524	1.000
:Event_0000106	canonical_mention.actual	"addresses"	libya_guardian__1000-01-01__timeline:1516-1524	1.000
:Event_0000106	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000006	libya_guardian__1000-01-01__timeline:1496-1502	1.000
:Event_0000107	type	Justice.ArrestJail
:Event_0000107	mention.actual	"custody"	libya_afp__1000-01-01__timeline:3718-3724	1.000
:Event_0000107	canonical_mention.actual	"custody"	libya_afp__1000-01-01__timeline:3718-3724	1.000
:Event_0000107	Justice.ArrestJail_Person.actual	:Entity_EDL_0000438	libya_afp__1000-01-01__timeline:3694-3696	1.000
:Event_0000107	Justice.ArrestJail_Person.actual	:Entity_EDL_0000424	libya_afp__1000-01-01__timeline:3698-3710	1.000
:Event_0000108	type	Movement.TransportArtifact
:Event_0000108	mention.actual	"advance"	libya_guardian__1000-01-01__timeline:966-972	1.000
:Event_0000108	canonical_mention.actual	"advance"	libya_guardian__1000-01-01__timeline:966-972	1.000
:Event_0000108	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000126	libya_guardian__1000-01-01__timeline:988-993	1.000
:Event_0000108	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000002	libya_guardian__1000-01-01__timeline:998-1005	1.000
:Event_0000109	type	Transaction.TransferOwnership
:Event_0000109	mention.actual	"seizing"	libya_afp__1000-01-01__timeline:3321-3327	1.000
:Event_0000109	canonical_mention.actual	"seizing"	libya_afp__1000-01-01__timeline:3321-3327	1.000
:Event_0000110	type	Movement.TransportArtifact
:Event_0000110	mention.actual	"moved"	libya_aljazeera__1000-01-01__timeline:7750-7754	1.000
:Event_0000110	canonical_mention.actual	"moved"	libya_aljazeera__1000-01-01__timeline:7750-7754	1.000
:Event_0000110	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000278	libya_aljazeera__1000-01-01__timeline:7740-7743	1.000
:Event_0000110	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000434	libya_aljazeera__1000-01-01__timeline:7797-7800	1.000
:Event_0000111	type	Life.BeBorn
:Event_0000111	mention.actual	"birth"	libya_reuters__1000-01-01__timeline:1909-1913	1.000
:Event_0000111	canonical_mention.actual	"birth"	libya_reuters__1000-01-01__timeline:1909-1913	1.000
:Event_0000111	Life.BeBorn_Person.actual	:Entity_EDL_0000406	libya_reuters__1000-01-01__timeline:1889-1901	1.000
:Event_0000111	Life.BeBorn_Place.actual	:Entity_EDL_0000265	libya_reuters__1000-01-01__timeline:1920-1925	1.000
:Event_0000111	Life.BeBorn_Place.actual	:Entity_EDL_0000089	libya_reuters__1000-01-01__timeline:1939-1942	1.000
:Event_0000112	type	Movement.TransportPerson
:Event_0000112	mention.actual	"return"	libya_reuters__1000-01-01__timeline:3272-3277	1.000
:Event_0000112	canonical_mention.actual	"return"	libya_reuters__1000-01-01__timeline:3272-3277	1.000
:Event_0000112	Movement.TransportPerson_Person.actual	:Entity_EDL_0000338	libya_reuters__1000-01-01__timeline:3291-3300	1.000
:Event_0000112	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000000	libya_reuters__1000-01-01__timeline:3305-3311	1.000
:Event_0000113	type	Conflict.Attack
:Event_0000113	mention.actual	"assault"	libya_latimes__1000-01-01__timeline:12382-12388	1.000
:Event_0000113	canonical_mention.actual	"assault"	libya_latimes__1000-01-01__timeline:12382-12388	1.000
:Event_0000113	Conflict.Attack_Attacker.actual	:Entity_EDL_0000157	libya_latimes__1000-01-01__timeline:12321-12326	1.000
:Event_0000113	Conflict.Attack_Place.actual	:Entity_EDL_0000341	libya_latimes__1000-01-01__timeline:12412-12419	1.000
:Event_0000114	type	Conflict.Coup.Coup
:Event_0000114	mention.actual	"force"	libya_latimes__1000-01-01__timeline:7070-7074	1.000
:Event_0000114	canonical_mention.actual	"force"	libya_latimes__1000-01-01__timeline:7070-7074	1.000
:Event_0000114	Conflict.Coup.Coup_DeposedEntity.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:7076-7089	1.000
:Event_0000115	type	Movement.TransportArtifact
:Event_0000115	mention.actual	"leaving"	libya_latimes__1000-01-01__timeline:7321-7327	1.000
:Event_0000115	canonical_mention.actual	"leaving"	libya_latimes__1000-01-01__timeline:7321-7327	1.000
:Event_0000115	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:7286-7299	1.000
:Event_0000115	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000003	libya_latimes__1000-01-01__timeline:7329-7333	1.000
:Event_0000116	type	Conflict.Attack
:Event_0000116	mention.actual	"strike"	libya_xinhua__1000-01-01__timeline:2065-2070	1.000
:Event_0000116	canonical_mention.actual	"strike"	libya_xinhua__1000-01-01__timeline:2065-2070	1.000
:Event_0000116	Conflict.Attack_Attacker.actual	:Entity_EDL_0000317	libya_xinhua__1000-01-01__timeline:1962-1967	1.000
:Event_0000116	Conflict.Attack_Place.actual	:Entity_EDL_0000045	libya_xinhua__1000-01-01__timeline:2083-2087	1.000
:Event_0000116	Conflict.Attack_Instrument.actual	:Entity_EDL_0000436	libya_xinhua__1000-01-01__timeline:2136-2144	1.000
:Event_0000116	Conflict.Attack_Instrument.actual	:Entity_EDL_0000305	libya_xinhua__1000-01-01__timeline:2148-2157	1.000
:Event_0000116	Conflict.Attack_Instrument.actual	:Entity_EDL_0000316	libya_xinhua__1000-01-01__timeline:2163-2179	1.000
:Event_0000117	type	Conflict.Attack
:Event_0000117	mention.actual	"besieged"	libya_aljazeera__1000-01-01__timeline:1040-1047	1.000
:Event_0000117	canonical_mention.actual	"besieged"	libya_aljazeera__1000-01-01__timeline:1040-1047	1.000
:Event_0000117	Conflict.Attack_Target.actual	:Entity_EDL_0000043	libya_aljazeera__1000-01-01__timeline:1020-1023	1.000
:Event_0000117	Conflict.Attack_Attacker.actual	:Entity_EDL_0000364	libya_aljazeera__1000-01-01__timeline:1071-1076	1.000
:Event_0000118	type	Life.Die
:Event_0000118	mention.actual	"death"	libya_latimes__1000-01-01__timeline:660-664	1.000
:Event_0000118	canonical_mention.actual	"death"	libya_latimes__1000-01-01__timeline:660-664	1.000
:Event_0000118	Life.Die_Victim.actual	:Entity_EDL_0000227	libya_latimes__1000-01-01__timeline:677-679	1.000
:Event_0000119	type	Justice.ChargeIndict
:Event_0000119	mention.actual	"charges"	libya_reuters__1000-01-01__timeline:1377-1383	1.000
:Event_0000119	canonical_mention.actual	"charges"	libya_reuters__1000-01-01__timeline:1377-1383	1.000
:Event_0000119	Justice.ChargeIndict_Adjudicator.actual	:Entity_EDL_0000029	libya_reuters__1000-01-01__timeline:1268-1270	1.000
:Event_0000119	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000008	libya_reuters__1000-01-01__timeline:1299-1305	1.000
:Event_0000119	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000321	libya_reuters__1000-01-01__timeline:1317-1329	1.000
:Event_0000119	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000010	libya_reuters__1000-01-01__timeline:1354-1372	1.000
:Event_0000120	type	Conflict.Attack
:Event_0000120	mention.actual	"massacre"	libya_afp__1000-01-01__timeline:2601-2608	1.000
:Event_0000120	canonical_mention.actual	"massacre"	libya_afp__1000-01-01__timeline:2601-2608	1.000
:Event_0000120	Conflict.Attack_Attacker.actual	:Entity_EDL_0000004	libya_afp__1000-01-01__timeline:2588-2591	1.000
:Event_0000120	Conflict.Attack_Target.actual	:Entity_EDL_0000371	libya_afp__1000-01-01__timeline:2619-2627	1.000
:Event_0000120	Conflict.Attack_Place.actual	:Entity_EDL_0000435	libya_afp__1000-01-01__timeline:2653-2658	1.000
:Event_0000121	type	Conflict.Attack
:Event_0000121	mention.actual	"hitting"	libya_afp__1000-01-01__timeline:1872-1878	1.000
:Event_0000121	canonical_mention.actual	"hitting"	libya_afp__1000-01-01__timeline:1872-1878	1.000
:Event_0000121	Conflict.Attack_Attacker.actual	:Entity_EDL_0000351	libya_afp__1000-01-01__timeline:1849-1850	1.000
:Event_0000121	Conflict.Attack_Target.actual	:Entity_EDL_0000109	libya_afp__1000-01-01__timeline:1891-1898	1.000
:Event_0000121	Conflict.Attack_Target.actual	:Entity_EDL_0000131	libya_afp__1000-01-01__timeline:1910-1917	1.000
:Event_0000121	Conflict.Attack_Target.actual	:Entity_EDL_0000125	libya_afp__1000-01-01__timeline:1921-1925	1.000
:Event_0000121	Conflict.Attack_Target.actual	:Entity_EDL_0000395	libya_afp__1000-01-01__timeline:1946-1953	1.000
:Event_0000121	Conflict.Attack_Place.actual	:Entity_EDL_0000120	libya_afp__1000-01-01__timeline:1962-1966	1.000
:Event_0000122	type	Conflict.Attack
:Event_0000122	mention.actual	"fired"	libya_cnn__1000-01-01__timeline:4999-5003	1.000
:Event_0000122	canonical_mention.actual	"fired"	libya_cnn__1000-01-01__timeline:4999-5003	1.000
:Event_0000122	Conflict.Attack_Instrument.actual	:Entity_EDL_0000038	libya_cnn__1000-01-01__timeline:4990-4997	1.000
:Event_0000122	Conflict.Attack_Instrument.actual	:Entity_EDL_0000165	libya_cnn__1000-01-01__timeline:5031-5035	1.000
:Event_0000122	Conflict.Attack_Instrument.actual	:Entity_EDL_0000075	libya_cnn__1000-01-01__timeline:5041-5050	1.000
:Event_0000123	type	Life.Die
:Event_0000123	mention.actual	"killing"	libya_latimes__1000-01-01__timeline:4994-5000	1.000
:Event_0000123	canonical_mention.actual	"killing"	libya_latimes__1000-01-01__timeline:4994-5000	1.000
:Event_0000123	Life.Die_Victim.actual	:Entity_EDL_0000245	libya_latimes__1000-01-01__timeline:5002-5007	1.000
:Event_0000123	Life.Die_Place.actual	:Entity_EDL_0000000	libya_latimes__1000-01-01__timeline:5060-5066	1.000
:Event_0000124	type	Movement.TransportArtifact
:Event_0000124	mention.actual	"driven"	libya_latimes__1000-01-01__timeline:9538-9543	1.000
:Event_0000124	canonical_mention.actual	"driven"	libya_latimes__1000-01-01__timeline:9538-9543	1.000
:Event_0000124	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000198	libya_latimes__1000-01-01__timeline:9528-9531	1.000
:Event_0000124	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000212	libya_latimes__1000-01-01__timeline:9568-9573	1.000
:Event_0000124	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000133	libya_latimes__1000-01-01__timeline:9580-9587	1.000
:Event_0000125	type	Life.Injure
:Event_0000125	mention.actual	"bruises"	libya_cnn__1000-01-01__timeline:5857-5863	1.000
:Event_0000125	canonical_mention.actual	"bruises"	libya_cnn__1000-01-01__timeline:5857-5863	1.000
:Event_0000126	type	Conflict.Attack
:Event_0000126	mention.actual	"fighting"	libya_latimes__1000-01-01__timeline:11745-11752	1.000
:Event_0000126	canonical_mention.actual	"fighting"	libya_latimes__1000-01-01__timeline:11745-11752	1.000
:Event_0000126	Conflict.Attack_Place.actual	:Entity_EDL_0000028	libya_latimes__1000-01-01__timeline:11781-11788	1.000
:Event_0000126	Conflict.Attack_Place.actual	:Entity_EDL_0000405	libya_latimes__1000-01-01__timeline:11800-11806	1.000
:Event_0000127	type	Life.Die
:Event_0000127	mention.actual	"kills"	libya_guardian__1000-01-01__timeline:1131-1135	1.000
:Event_0000127	canonical_mention.actual	"kills"	libya_guardian__1000-01-01__timeline:1131-1135	1.000
:Event_0000127	Life.Die_Agent.actual	:Entity_EDL_0000333	libya_guardian__1000-01-01__timeline:1089-1092	1.000
:Event_0000127	Life.Die_Instrument.actual	:Entity_EDL_0000014	libya_guardian__1000-01-01__timeline:1094-1100	1.000
:Event_0000127	Life.Die_Place.actual	:Entity_EDL_0000346	libya_guardian__1000-01-01__timeline:1114-1118	1.000
:Event_0000127	Life.Die_Victim.actual	:Entity_EDL_0000011	libya_guardian__1000-01-01__timeline:1157-1159	1.000
:Event_0000127	Life.Die_Victim.actual	:Entity_EDL_0000007	libya_guardian__1000-01-01__timeline:1171-1183	1.000
:Event_0000128	type	Life.Injure
:Event_0000128	mention.actual	"wounded"	libya_aljazeera__1000-01-01__timeline:2096-2102	1.000
:Event_0000128	canonical_mention.actual	"wounded"	libya_aljazeera__1000-01-01__timeline:2096-2102	1.000
:Event_0000128	Life.Injure_Victim.actual	:Entity_EDL_0000135	libya_aljazeera__1000-01-01__timeline:2092-2094	1.000
:Event_0000128	Life.Injure_Place.actual	:Entity_EDL_0000183	libya_aljazeera__1000-01-01__timeline:2141-2147	1.000
:Event_0000129	type	Life.Die
:Event_0000129	mention.actual	"burial"	libya_aljazeera__1000-01-01__timeline:7869-7874	1.000
:Event_0000129	canonical_mention.actual	"burial"	libya_aljazeera__1000-01-01__timeline:7869-7874	1.000
:Event_0000130	type	Movement.TransportPerson
:Event_0000130	mention.actual	"fled"	libya_xinhua__1000-01-01__timeline:3720-3723	1.000
:Event_0000130	canonical_mention.actual	"fled"	libya_xinhua__1000-01-01__timeline:3720-3723	1.000
:Event_0000130	Movement.TransportPerson_Person.actual	:Entity_EDL_0000019	libya_xinhua__1000-01-01__timeline:3712-3716	1.000
:Event_0000130	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000127	libya_xinhua__1000-01-01__timeline:3728-3732	1.000
:Event_0000131	type	Movement.TransportArtifact
:Event_0000131	mention.actual	"land"	libya_guardian__1000-01-01__timeline:2749-2752	1.000
:Event_0000131	canonical_mention.actual	"land"	libya_guardian__1000-01-01__timeline:2749-2752	1.000
:Event_0000131	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000359	libya_guardian__1000-01-01__timeline:2704-2718	1.000
:Event_0000131	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000442	libya_guardian__1000-01-01__timeline:2735-2747	1.000
:Event_0000131	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000005	libya_guardian__1000-01-01__timeline:2757-2761	1.000
:Event_0000132	type	Life.Die
:Event_0000132	mention.actual	"die"	libya_cnn__1000-01-01__timeline:2322-2324	1.000
:Event_0000132	canonical_mention.actual	"die"	libya_cnn__1000-01-01__timeline:2322-2324	1.000
:Event_0000133	type	Personnel.EndPosition
:Event_0000133	mention.actual	"sacks"	libya_afp__1000-01-01__timeline:2463-2467	1.000
:Event_0000133	canonical_mention.actual	"sacks"	libya_afp__1000-01-01__timeline:2463-2467	1.000
:Event_0000133	Personnel.EndPosition_Person.actual	:Entity_EDL_0000021	libya_afp__1000-01-01__timeline:2443-2461	1.000
:Event_0000133	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000418	libya_afp__1000-01-01__timeline:2490-2495	1.000
:Event_0000133	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000401	libya_afp__1000-01-01__timeline:2504-2513	1.000
:Event_0000134	type	Contact.Meet
:Event_0000134	mention.actual	"meeting"	libya_xinhua__1000-01-01__timeline:1309-1315	1.000
:Event_0000134	canonical_mention.actual	"meeting"	libya_xinhua__1000-01-01__timeline:1309-1315	1.000
:Event_0000134	Contact.Meet_Participant.actual	:Entity_EDL_0000314	libya_xinhua__1000-01-01__timeline:1276-1284	1.000
:Event_0000135	type	Movement.TransportArtifact
:Event_0000135	mention.actual	"arrived"	libya_reuters__1000-01-01__timeline:2490-2496	1.000
:Event_0000135	canonical_mention.actual	"arrived"	libya_reuters__1000-01-01__timeline:2490-2496	1.000
:Event_0000135	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000170	libya_reuters__1000-01-01__timeline:2476-2478	1.000
:Event_0000135	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000073	libya_reuters__1000-01-01__timeline:2480-2484	1.000
:Event_0000135	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000108	libya_reuters__1000-01-01__timeline:2498-2502	1.000
:Event_0000136	type	Contact.Broadcast
:Event_0000136	mention.actual	"announced"	libya_afp__1000-01-01__timeline:2262-2270	1.000
:Event_0000136	canonical_mention.actual	"announced"	libya_afp__1000-01-01__timeline:2262-2270	1.000
:Event_0000136	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000004	libya_afp__1000-01-01__timeline:2247-2250	1.000
:Event_0000136	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000211	libya_afp__1000-01-01__timeline:2275-2280	1.000
:Event_0000137	type	Movement.TransportArtifact
:Event_0000137	mention.actual	"flies"	libya_afp__1000-01-01__timeline:3143-3147	1.000
:Event_0000137	canonical_mention.actual	"flies"	libya_afp__1000-01-01__timeline:3143-3147	1.000
:Event_0000137	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000285	libya_afp__1000-01-01__timeline:3134-3141	1.000
:Event_0000137	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000343	libya_afp__1000-01-01__timeline:3156-3160	1.000
:Event_0000138	type	Justice.ArrestJail
:Event_0000138	mention.actual	"detained"	libya_guardian__1000-01-01__timeline:6010-6017	1.000
:Event_0000138	canonical_mention.actual	"detained"	libya_guardian__1000-01-01__timeline:6010-6017	1.000
:Event_0000138	Justice.ArrestJail_Person.actual	:Entity_EDL_0000025	libya_guardian__1000-01-01__timeline:5987-5999	1.000
:Event_0000139	type	Conflict.Attack
:Event_0000139	mention.actual	"raid"	libya_afp__1000-01-01__timeline:2252-2255	1.000
:Event_0000139	canonical_mention.actual	"raid"	libya_afp__1000-01-01__timeline:2252-2255	1.000
:Event_0000139	Conflict.Attack_Target.actual	:Entity_EDL_0000128	libya_afp__1000-01-01__timeline:2231-2233	1.000
:Event_0000139	Conflict.Attack_Attacker.actual	:Entity_EDL_0000004	libya_afp__1000-01-01__timeline:2247-2250	1.000
:Event_0000140	type	Conflict.Attack
:Event_0000140	mention.actual	"offensives"	libya_xinhua__1000-01-01__timeline:3908-3917	1.000
:Event_0000140	canonical_mention.actual	"offensives"	libya_xinhua__1000-01-01__timeline:3908-3917	1.000
:Event_0000140	Conflict.Attack_Attacker.actual	:Entity_EDL_0000302	libya_xinhua__1000-01-01__timeline:3882-3887	1.000
:Event_0000141	type	Conflict.Attack
:Event_0000141	mention.actual	"raids"	libya_aljazeera__1000-01-01__timeline:3896-3900	1.000
:Event_0000141	canonical_mention.actual	"raids"	libya_aljazeera__1000-01-01__timeline:3896-3900	1.000
:Event_0000141	Conflict.Attack_Instrument.actual	:Entity_EDL_0000383	libya_aljazeera__1000-01-01__timeline:3841-3844	1.000
:Event_0000142	type	Movement.TransportArtifact
:Event_0000142	mention.actual	"land"	libya_reuters__1000-01-01__timeline:2759-2762	1.000
:Event_0000142	canonical_mention.actual	"land"	libya_reuters__1000-01-01__timeline:2759-2762	1.000
:Event_0000142	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000289	libya_reuters__1000-01-01__timeline:2714-2728	1.000
:Event_0000142	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000060	libya_reuters__1000-01-01__timeline:2745-2757	1.000
:Event_0000142	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000005	libya_reuters__1000-01-01__timeline:2767-2771	1.000
:Event_0000143	type	Conflict.Attack
:Event_0000143	mention.actual	"fight"	libya_latimes__1000-01-01__timeline:560-564	1.000
:Event_0000143	canonical_mention.actual	"fight"	libya_latimes__1000-01-01__timeline:560-564	1.000
:Event_0000143	Conflict.Attack_Attacker.actual	:Entity_EDL_0000097	libya_latimes__1000-01-01__timeline:548-553	1.000
:Event_0000144	type	Conflict.Demonstrate
:Event_0000144	mention.actual	"riot"	libya_guardian__1000-01-01__timeline:69-72	1.000
:Event_0000144	canonical_mention.actual	"riot"	libya_guardian__1000-01-01__timeline:69-72	1.000
:Event_0000144	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000002	libya_guardian__1000-01-01__timeline:77-84	1.000
:Event_0000145	type	Movement.TransportArtifact
:Event_0000145	mention.actual	"arrives"	libya_latimes__1000-01-01__timeline:6429-6435	1.000
:Event_0000145	canonical_mention.actual	"arrives"	libya_latimes__1000-01-01__timeline:6429-6435	1.000
:Event_0000145	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000103	libya_latimes__1000-01-01__timeline:6360-6363	1.000
:Event_0000145	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000085	libya_latimes__1000-01-01__timeline:6382-6388	1.000
:Event_0000145	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000216	libya_latimes__1000-01-01__timeline:6415-6418	1.000
:Event_0000145	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000260	libya_latimes__1000-01-01__timeline:6455-6464	1.000
:Event_0000146	type	Transaction.TransferOwnership
:Event_0000146	mention.actual	"captured"	libya_xinhua__1000-01-01__timeline:4247-4254	1.000
:Event_0000146	canonical_mention.actual	"captured"	libya_xinhua__1000-01-01__timeline:4247-4254	1.000
:Event_0000146	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000136	libya_xinhua__1000-01-01__timeline:4240-4245	1.000
:Event_0000146	Transaction.TransferOwnership_Place.actual	:Entity_EDL_0000208	libya_xinhua__1000-01-01__timeline:4275-4278	1.000
:Event_0000147	type	Life.Die
:Event_0000147	mention.actual	"killed"	libya_afp__1000-01-01__timeline:1564-1569	1.000
:Event_0000147	canonical_mention.actual	"killed"	libya_afp__1000-01-01__timeline:1564-1569	1.000
:Event_0000147	Life.Die_Agent.actual	:Entity_EDL_0000058	libya_afp__1000-01-01__timeline:1547-1549	1.000
:Event_0000147	Life.Die_Victim.actual	:Entity_EDL_0000107	libya_afp__1000-01-01__timeline:1586-1594	1.000
:Event_0000148	type	Movement.TransportArtifact
:Event_0000148	mention.actual	"entered"	libya_xinhua__1000-01-01__timeline:3203-3209	1.000
:Event_0000148	canonical_mention.actual	"entered"	libya_xinhua__1000-01-01__timeline:3203-3209	1.000
:Event_0000148	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000189	libya_xinhua__1000-01-01__timeline:3196-3201	1.000
:Event_0000148	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000328	libya_xinhua__1000-01-01__timeline:3230-3241	1.000
:Event_0000149	type	Life.Die
:Event_0000149	mention.actual	"killed"	libya_aljazeera__1000-01-01__timeline:376-381	1.000
:Event_0000149	canonical_mention.actual	"killed"	libya_aljazeera__1000-01-01__timeline:376-381	1.000
:Event_0000149	Life.Die_Victim.actual	:Entity_EDL_0000022	libya_aljazeera__1000-01-01__timeline:369-374	1.000
:Event_0000150	type	Movement.TransportPerson
:Event_0000150	mention.actual	"fled"	libya_cnn__1000-01-01__timeline:7970-7973	1.000
:Event_0000150	canonical_mention.actual	"fled"	libya_cnn__1000-01-01__timeline:7970-7973	1.000
:Event_0000150	Movement.TransportPerson_Person.actual	:Entity_EDL_0000429	libya_cnn__1000-01-01__timeline:7962-7964	1.000
:Event_0000150	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000009	libya_cnn__1000-01-01__timeline:7975-7979	1.000
:Event_0000151	type	ArtifactExistence.DamageDestroy.Damage
:Event_0000151	mention.actual	"trashing"	libya_guardian__1000-01-01__timeline:1725-1732	1.000
:Event_0000151	canonical_mention.actual	"trashing"	libya_guardian__1000-01-01__timeline:1725-1732	1.000
:Event_0000151	ArtifactExistence.DamageDestroy.Damage_Artifact.actual	:Entity_EDL_0000209	libya_guardian__1000-01-01__timeline:1703-1710	1.000
:Event_0000151	ArtifactExistence.DamageDestroy.Damage_Place.actual	:Entity_EDL_0000000	libya_guardian__1000-01-01__timeline:1715-1721	1.000
:Event_0000151	ArtifactExistence.DamageDestroy.Damage_Artifact.actual	:Entity_EDL_0000247	libya_guardian__1000-01-01__timeline:1738-1744	1.000
:Event_0000152	type	Conflict.Attack
:Event_0000152	mention.actual	"hit"	libya_cnn__1000-01-01__timeline:5052-5054	1.000
:Event_0000152	canonical_mention.actual	"hit"	libya_cnn__1000-01-01__timeline:5052-5054	1.000
:Event_0000152	Conflict.Attack_Instrument.actual	:Entity_EDL_0000038	libya_cnn__1000-01-01__timeline:4990-4997	1.000
:Event_0000153	type	Movement.TransportArtifact
:Event_0000153	mention.actual	"enter"	libya_reuters__1000-01-01__timeline:1872-1876	1.000
:Event_0000153	canonical_mention.actual	"enter"	libya_reuters__1000-01-01__timeline:1872-1876	1.000
:Event_0000153	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000229	libya_reuters__1000-01-01__timeline:1846-1850	1.000
:Event_0000153	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000373	libya_reuters__1000-01-01__timeline:1856-1858	1.000
:Event_0000153	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000012	libya_reuters__1000-01-01__timeline:1878-1884	1.000
:Event_0000154	type	Conflict.Attack
:Event_0000154	mention.actual	"fighting"	libya_xinhua__1000-01-01__timeline:3266-3273	1.000
:Event_0000154	canonical_mention.actual	"fighting"	libya_xinhua__1000-01-01__timeline:3266-3273	1.000
:Event_0000154	Conflict.Attack_Target.actual	:Entity_EDL_0000189	libya_xinhua__1000-01-01__timeline:3196-3201	1.000
:Event_0000154	Conflict.Attack_Place.actual	:Entity_EDL_0000328	libya_xinhua__1000-01-01__timeline:3230-3241	1.000
:Event_0000154	Conflict.Attack_Attacker.actual	:Entity_EDL_0000292	libya_xinhua__1000-01-01__timeline:3291-3296	1.000
:Event_0000155	type	Movement.TransportArtifact
:Event_0000155	mention.actual	"land"	libya_aljazeera__1000-01-01__timeline:4746-4749	1.000
:Event_0000155	canonical_mention.actual	"land"	libya_aljazeera__1000-01-01__timeline:4746-4749	1.000
:Event_0000155	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000389	libya_aljazeera__1000-01-01__timeline:4658-4672	1.000
:Event_0000155	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000286	libya_aljazeera__1000-01-01__timeline:4701-4713	1.000
:Event_0000155	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000003	libya_aljazeera__1000-01-01__timeline:4754-4758	1.000
:Event_0000156	type	Conflict.Yield.Surrender
:Event_0000156	mention.actual	"surrender"	libya_reuters__1000-01-01__timeline:3242-3250	1.000
:Event_0000156	canonical_mention.actual	"surrender"	libya_reuters__1000-01-01__timeline:3242-3250	1.000
:Event_0000157	type	Contact.Meet
:Event_0000157	mention.actual	"conference"	libya_aljazeera__1000-01-01__timeline:4017-4026	1.000
:Event_0000157	canonical_mention.actual	"conference"	libya_aljazeera__1000-01-01__timeline:4017-4026	1.000
:Event_0000157	Contact.Meet_Participant.actual	:Entity_EDL_0000232	libya_aljazeera__1000-01-01__timeline:3986-3991	1.000
:Event_0000157	Contact.Meet_Participant.actual	:Entity_EDL_0000054	libya_aljazeera__1000-01-01__timeline:4004-4010	1.000
:Event_0000157	Contact.Meet_Place.actual	:Entity_EDL_0000059	libya_aljazeera__1000-01-01__timeline:4031-4035	1.000
:Event_0000158	type	Movement.TransportArtifact
:Event_0000158	mention.actual	"enter"	libya_afp__1000-01-01__timeline:3409-3413	1.000
:Event_0000158	canonical_mention.actual	"enter"	libya_afp__1000-01-01__timeline:3409-3413	1.000
:Event_0000158	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000344	libya_afp__1000-01-01__timeline:3402-3407	1.000
:Event_0000158	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000000	libya_afp__1000-01-01__timeline:3415-3421	1.000
:Event_0000159	type	Conflict.Attack
:Event_0000159	mention.actual	"strikes"	libya_cnn__1000-01-01__timeline:10319-10325	1.000
:Event_0000159	canonical_mention.actual	"strikes"	libya_cnn__1000-01-01__timeline:10319-10325	1.000
:Event_0000160	type	Personnel.StartPosition
:Event_0000160	mention.actual	"coming"	libya_guardian__1000-01-01__timeline:2154-2159	1.000
:Event_0000160	canonical_mention.actual	"coming"	libya_guardian__1000-01-01__timeline:2154-2159	1.000
:Event_0000160	Personnel.StartPosition_Person.actual	:Entity_EDL_0000044	libya_guardian__1000-01-01__timeline:2150-2152	1.000
:Event_0000161	type	Movement.TransportArtifact
:Event_0000161	mention.actual	"arrived"	libya_aljazeera__1000-01-01__timeline:4440-4446	1.000
:Event_0000161	canonical_mention.actual	"arrived"	libya_aljazeera__1000-01-01__timeline:4440-4446	1.000
:Event_0000161	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000403	libya_aljazeera__1000-01-01__timeline:4426-4428	1.000
:Event_0000161	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000339	libya_aljazeera__1000-01-01__timeline:4430-4434	1.000
:Event_0000161	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000267	libya_aljazeera__1000-01-01__timeline:4448-4452	1.000
:Event_0000162	type	Conflict.Attack
:Event_0000162	mention.actual	"killing"	libya_cnn__1000-01-01__timeline:7502-7508	1.000
:Event_0000162	canonical_mention.actual	"killing"	libya_cnn__1000-01-01__timeline:7502-7508	1.000
:Event_0000162	Conflict.Attack_Attacker.actual	:Entity_EDL_0000280	libya_cnn__1000-01-01__timeline:7489-7497	1.000
:Event_0000162	Conflict.Attack_Target.actual	:Entity_EDL_0000214	libya_cnn__1000-01-01__timeline:7510-7518	1.000
:Event_0000163	type	Conflict.Attack
:Event_0000163	mention.actual	"battle"	libya_cnn__1000-01-01__timeline:11063-11068	1.000
:Event_0000163	canonical_mention.actual	"battle"	libya_cnn__1000-01-01__timeline:11063-11068	1.000
:Event_0000163	Conflict.Attack_Attacker.actual	:Entity_EDL_0000055	libya_cnn__1000-01-01__timeline:11017-11024	1.000
:Event_0000164	type	Contact.Meet
:Event_0000164	mention.actual	"meetings"	libya_xinhua__1000-01-01__timeline:587-594	1.000
:Event_0000164	canonical_mention.actual	"meetings"	libya_xinhua__1000-01-01__timeline:587-594	1.000
:Event_0000164	Contact.Meet_Participant.actual	:Entity_EDL_0000005	libya_xinhua__1000-01-01__timeline:551-555	1.000
:Event_0000165	type	Movement.TransportArtifact
:Event_0000165	mention.actual	"enter"	libya_reuters__1000-01-01__timeline:1466-1470	1.000
:Event_0000165	canonical_mention.actual	"enter"	libya_reuters__1000-01-01__timeline:1466-1470	1.000
:Event_0000165	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000250	libya_reuters__1000-01-01__timeline:1459-1464	1.000
:Event_0000165	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000000	libya_reuters__1000-01-01__timeline:1472-1478	1.000
:Event_0000166	type	Contact.Meet
:Event_0000166	mention.actual	"conference"	libya_reuters__1000-01-01__timeline:2073-2082	1.000
:Event_0000166	canonical_mention.actual	"conference"	libya_reuters__1000-01-01__timeline:2073-2082	1.000
:Event_0000166	Contact.Meet_Participant.actual	:Entity_EDL_0000420	libya_reuters__1000-01-01__timeline:2042-2047	1.000
:Event_0000166	Contact.Meet_Participant.actual	:Entity_EDL_0000159	libya_reuters__1000-01-01__timeline:2060-2066	1.000
:Event_0000166	Contact.Meet_Place.actual	:Entity_EDL_0000370	libya_reuters__1000-01-01__timeline:2087-2091	1.000
:Event_0000167	type	Conflict.Attack
:Event_0000167	mention.actual	"fighting"	libya_reuters__1000-01-01__timeline:4703-4710	1.000
:Event_0000167	canonical_mention.actual	"fighting"	libya_reuters__1000-01-01__timeline:4703-4710	1.000
:Event_0000167	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_reuters__1000-01-01__timeline:4725-4731	1.000
:Event_0000168	type	Justice.ArrestJail
:Event_0000168	mention.actual	"arrest"	libya_xinhua__1000-01-01__timeline:2643-2648	1.000
:Event_0000168	canonical_mention.actual	"arrest"	libya_xinhua__1000-01-01__timeline:2643-2648	1.000
:Event_0000168	Justice.ArrestJail_Person.actual	:Entity_EDL_0000008	libya_xinhua__1000-01-01__timeline:2663-2669	1.000
:Event_0000168	Justice.ArrestJail_Person.actual	:Entity_EDL_0000354	libya_xinhua__1000-01-01__timeline:2681-2693	1.000
:Event_0000169	type	Movement.TransportArtifact
:Event_0000169	mention.actual	"sent"	libya_aljazeera__1000-01-01__timeline:2573-2576	1.000
:Event_0000169	canonical_mention.actual	"sent"	libya_aljazeera__1000-01-01__timeline:2573-2576	1.000
:Event_0000169	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000069	libya_aljazeera__1000-01-01__timeline:2515-2518	1.000
:Event_0000169	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000000	libya_aljazeera__1000-01-01__timeline:2581-2587	1.000
:Event_0000169	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000264	libya_aljazeera__1000-01-01__timeline:2592-2598	1.000
:Event_0000170	type	Conflict.Attack
:Event_0000170	mention.actual	"fighting"	libya_guardian__1000-01-01__timeline:4523-4530	1.000
:Event_0000170	canonical_mention.actual	"fighting"	libya_guardian__1000-01-01__timeline:4523-4530	1.000
:Event_0000170	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_guardian__1000-01-01__timeline:4546-4552	1.000
:Event_0000171	type	Movement.TransportPerson
:Event_0000171	mention.actual	"evicting"	libya_guardian__1000-01-01__timeline:216-223	1.000
:Event_0000171	canonical_mention.actual	"evicting"	libya_guardian__1000-01-01__timeline:216-223	1.000
:Event_0000171	Movement.TransportPerson_Agent.actual	:Entity_EDL_0000040	libya_guardian__1000-01-01__timeline:149-156	1.000
:Event_0000171	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000261	libya_guardian__1000-01-01__timeline:194-197	1.000
:Event_0000171	Movement.TransportPerson_Person.actual	:Entity_EDL_0000325	libya_guardian__1000-01-01__timeline:225-230	1.000
:Event_0000172	type	Conflict.Attack
:Event_0000172	mention.actual	"gunfire"	libya_aljazeera__1000-01-01__timeline:2309-2315	1.000
:Event_0000172	canonical_mention.actual	"gunfire"	libya_aljazeera__1000-01-01__timeline:2309-2315	1.000
:Event_0000172	Conflict.Attack_Target.actual	:Entity_EDL_0000271	libya_aljazeera__1000-01-01__timeline:2218-2231	1.000
:Event_0000172	Conflict.Attack_Instrument.actual	:Entity_EDL_0000404	libya_aljazeera__1000-01-01__timeline:2329-2338	1.000
:Event_0000173	type	Movement.TransportArtifact
:Event_0000173	mention.actual	"arrives"	libya_cnn__1000-01-01__timeline:6638-6644	1.000
:Event_0000173	canonical_mention.actual	"arrives"	libya_cnn__1000-01-01__timeline:6638-6644	1.000
:Event_0000173	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000306	libya_cnn__1000-01-01__timeline:6624-6636	1.000
:Event_0000173	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000268	libya_cnn__1000-01-01__timeline:6653-6666	1.000
:Event_0000174	type	Conflict.Attack
:Event_0000174	mention.actual	"clashed"	libya_xinhua__1000-01-01__timeline:145-151	1.000
:Event_0000174	canonical_mention.actual	"clashed"	libya_xinhua__1000-01-01__timeline:145-151	1.000
:Event_0000174	Conflict.Attack_Attacker.actual	:Entity_EDL_0000099	libya_xinhua__1000-01-01__timeline:134-143	1.000
:Event_0000174	Conflict.Attack_Target.actual	:Entity_EDL_0000332	libya_xinhua__1000-01-01__timeline:162-167	1.000
:Event_0000175	type	Life.Die
:Event_0000175	mention.actual	"kills"	libya_afp__1000-01-01__timeline:716-720	1.000
:Event_0000175	canonical_mention.actual	"kills"	libya_afp__1000-01-01__timeline:716-720	1.000
:Event_0000175	Life.Die_Victim.actual	:Entity_EDL_0000070	libya_afp__1000-01-01__timeline:735-737	1.000
:Event_0000175	Life.Die_Victim.actual	:Entity_EDL_0000007	libya_afp__1000-01-01__timeline:766-778	1.000
:Event_0000176	type	Contact.Broadcast
:Event_0000176	mention.actual	"addresses"	libya_aljazeera__1000-01-01__timeline:2762-2770	1.000
:Event_0000176	canonical_mention.actual	"addresses"	libya_aljazeera__1000-01-01__timeline:2762-2770	1.000
:Event_0000176	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000013	libya_aljazeera__1000-01-01__timeline:2744-2750	1.000
:Event_0000177	type	Contact.Meet
:Event_0000177	mention.actual	"talks"	libya_xinhua__1000-01-01__timeline:2348-2352	1.000
:Event_0000177	canonical_mention.actual	"talks"	libya_xinhua__1000-01-01__timeline:2348-2352	1.000
:Event_0000177	Contact.Meet_Participant.actual	:Entity_EDL_0000041	libya_xinhua__1000-01-01__timeline:2306-2315	1.000
:Event_0000177	Contact.Meet_Place.actual	:Entity_EDL_0000000	libya_xinhua__1000-01-01__timeline:2357-2363	1.000
:Event_0000178	type	Conflict.Attack
:Event_0000178	mention.actual	"fire"	libya_latimes__1000-01-01__timeline:3231-3234	1.000
:Event_0000178	canonical_mention.actual	"fire"	libya_latimes__1000-01-01__timeline:3231-3234	1.000
:Event_0000178	Conflict.Attack_Instrument.actual	:Entity_EDL_0000039	libya_latimes__1000-01-01__timeline:3222-3229	1.000
:Event_0000178	Conflict.Attack_Instrument.actual	:Entity_EDL_0000146	libya_latimes__1000-01-01__timeline:3257-3264	1.000
:Event_0000179	type	Conflict.Attack
:Event_0000179	mention.actual	"attacked"	libya_latimes__1000-01-01__timeline:11326-11333	1.000
:Event_0000179	canonical_mention.actual	"attacked"	libya_latimes__1000-01-01__timeline:11326-11333	1.000
:Event_0000179	Conflict.Attack_Attacker.actual	:Entity_EDL_0000374	libya_latimes__1000-01-01__timeline:11316-11319	1.000
:Event_0000180	type	Conflict.Attack
:Event_0000180	mention.actual	"fight"	libya_guardian__1000-01-01__timeline:1570-1574	1.000
:Event_0000180	canonical_mention.actual	"fight"	libya_guardian__1000-01-01__timeline:1570-1574	1.000
:Event_0000180	Conflict.Attack_Attacker.actual	:Entity_EDL_0000272	libya_guardian__1000-01-01__timeline:1559-1565	1.000
:Event_0000181	type	Conflict.Attack
:Event_0000181	mention.actual	"battle"	libya_latimes__1000-01-01__timeline:5375-5380	1.000
:Event_0000181	canonical_mention.actual	"battle"	libya_latimes__1000-01-01__timeline:5375-5380	1.000
:Event_0000181	Conflict.Attack_Attacker.actual	:Entity_EDL_0000396	libya_latimes__1000-01-01__timeline:5334-5339	1.000
:Event_0000182	type	Justice.ArrestJail
:Event_0000182	mention.actual	"captured"	libya_latimes__1000-01-01__timeline:11510-11517	1.000
:Event_0000182	canonical_mention.actual	"captured"	libya_latimes__1000-01-01__timeline:11510-11517	1.000
:Event_0000182	Justice.ArrestJail_Person.actual	:Entity_EDL_0000065	libya_latimes__1000-01-01__timeline:11455-11457	1.000
:Event_0000182	Justice.ArrestJail_Person.actual	:Entity_EDL_0000398	libya_latimes__1000-01-01__timeline:11471-11483	1.000
:Event_0000182	Justice.ArrestJail_Person.actual	:Entity_EDL_0000412	libya_latimes__1000-01-01__timeline:11487-11503	1.000
:Event_0000183	type	Contact.Broadcast
:Event_0000183	mention.actual	"warn"	libya_cnn__1000-01-01__timeline:1807-1810	1.000
:Event_0000183	canonical_mention.actual	"warn"	libya_cnn__1000-01-01__timeline:1807-1810	1.000
:Event_0000183	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000027	libya_cnn__1000-01-01__timeline:1754-1774	1.000
:Event_0000183	Contact.Broadcast_Audience.actual	:Entity_EDL_0000182	libya_cnn__1000-01-01__timeline:1812-1824	1.000
:Event_0000184	type	Contact.Meet
:Event_0000184	mention.actual	"converging"	libya_latimes__1000-01-01__timeline:7793-7802	1.000
:Event_0000184	canonical_mention.actual	"converging"	libya_latimes__1000-01-01__timeline:7793-7802	1.000
:Event_0000184	Contact.Meet_Participant.actual	:Entity_EDL_0000203	libya_latimes__1000-01-01__timeline:7785-7791	1.000
:Event_0000184	Contact.Meet_Place.actual	:Entity_EDL_0000291	libya_latimes__1000-01-01__timeline:7819-7830	1.000
:Event_0000185	type	Conflict.Attack
:Event_0000185	mention.actual	"fighting"	libya_aljazeera__1000-01-01__timeline:342-349	1.000
:Event_0000185	canonical_mention.actual	"fighting"	libya_aljazeera__1000-01-01__timeline:342-349	1.000
:Event_0000185	Conflict.Attack_Target.actual	:Entity_EDL_0000022	libya_aljazeera__1000-01-01__timeline:369-374	1.000
:Event_0000186	type	Movement.TransportArtifact
:Event_0000186	mention.actual	"bring"	libya_latimes__1000-01-01__timeline:11094-11098	1.000
:Event_0000186	canonical_mention.actual	"bring"	libya_latimes__1000-01-01__timeline:11094-11098	1.000
:Event_0000186	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000345	libya_latimes__1000-01-01__timeline:11032-11039	1.000
:Event_0000186	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000451	libya_latimes__1000-01-01__timeline:11100-11103	1.000
:Event_0000186	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000301	libya_latimes__1000-01-01__timeline:11129-11135	1.000
:Event_0000187	type	Movement.TransportPerson
:Event_0000187	mention.actual	"sent"	libya_latimes__1000-01-01__timeline:5832-5835	1.000
:Event_0000187	canonical_mention.actual	"sent"	libya_latimes__1000-01-01__timeline:5832-5835	1.000
:Event_0000187	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000287	libya_latimes__1000-01-01__timeline:5783-5786	1.000
:Event_0000187	Movement.TransportPerson_Person.actual	:Entity_EDL_0000297	libya_latimes__1000-01-01__timeline:5822-5827	1.000
:Event_0000188	type	Justice.ArrestJail
:Event_0000188	mention.actual	"arrest"	libya_afp__1000-01-01__timeline:1192-1197	1.000
:Event_0000188	canonical_mention.actual	"arrest"	libya_afp__1000-01-01__timeline:1192-1197	1.000
:Event_0000188	Justice.ArrestJail_Person.actual	:Entity_EDL_0000006	libya_afp__1000-01-01__timeline:1211-1217	1.000
:Event_0000189	type	Personnel.StartPosition
:Event_0000189	mention.actual	"coming"	libya_reuters__1000-01-01__timeline:2164-2169	1.000
:Event_0000189	canonical_mention.actual	"coming"	libya_reuters__1000-01-01__timeline:2164-2169	1.000
:Event_0000189	Personnel.StartPosition_Person.actual	:Entity_EDL_0000074	libya_reuters__1000-01-01__timeline:2160-2162	1.000
:Event_0000190	type	Life.Die
:Event_0000190	mention.actual	"killed"	libya_cnn__1000-01-01__timeline:1528-1533	1.000
:Event_0000190	canonical_mention.actual	"killed"	libya_cnn__1000-01-01__timeline:1528-1533	1.000
:Event_0000190	Life.Die_Victim.actual	:Entity_EDL_0000336	libya_cnn__1000-01-01__timeline:1511-1516	1.000
:Event_0000190	Life.Die_Place.actual	:Entity_EDL_0000003	libya_cnn__1000-01-01__timeline:1538-1543	1.000
:Event_0000191	type	Life.Die
:Event_0000191	mention.actual	"murder"	libya_cnn__1000-01-01__timeline:9150-9155	1.000
:Event_0000191	canonical_mention.actual	"murder"	libya_cnn__1000-01-01__timeline:9150-9155	1.000
:Event_0000191	Life.Die_Place.actual	:Entity_EDL_0000003	libya_cnn__1000-01-01__timeline:9205-9209	1.000
:Event_0000192	type	Life.Die
:Event_0000192	mention.actual	"assassinated"	libya_afp__1000-01-01__timeline:2065-2076	1.000
:Event_0000192	canonical_mention.actual	"assassinated"	libya_afp__1000-01-01__timeline:2065-2076	1.000
:Event_0000192	Life.Die_Victim.actual	:Entity_EDL_0000031	libya_afp__1000-01-01__timeline:2044-2060	1.000
:Event_0000193	type	Conflict.Yield.Surrender
:Event_0000193	mention.actual	"surrender"	libya_guardian__1000-01-01__timeline:3233-3241	1.000
:Event_0000193	canonical_mention.actual	"surrender"	libya_guardian__1000-01-01__timeline:3233-3241	1.000
:Event_0000194	type	Transaction.TransferOwnership
:Event_0000194	mention.actual	"winning"	libya_aljazeera__1000-01-01__timeline:1304-1310	1.000
:Event_0000194	canonical_mention.actual	"winning"	libya_aljazeera__1000-01-01__timeline:1304-1310	1.000
:Event_0000194	Transaction.TransferOwnership_Place.actual	:Entity_EDL_0000017	libya_aljazeera__1000-01-01__timeline:1270-1276	1.000
:Event_0000194	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000340	libya_aljazeera__1000-01-01__timeline:1293-1296	1.000
:Event_0000195	type	Movement.TransportArtifact
:Event_0000195	mention.actual	"advanced"	libya_xinhua__1000-01-01__timeline:1476-1483	1.000
:Event_0000195	canonical_mention.actual	"advanced"	libya_xinhua__1000-01-01__timeline:1476-1483	1.000
:Event_0000195	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000187	libya_xinhua__1000-01-01__timeline:1469-1474	1.000
:Event_0000195	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000002	libya_xinhua__1000-01-01__timeline:1492-1499	1.000
:Event_0000195	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000319	libya_xinhua__1000-01-01__timeline:1577-1580	1.000
:Event_0000196	type	Justice.ArrestJail
:Event_0000196	mention.actual	"arrest"	libya_reuters__1000-01-01__timeline:15-20	1.000
:Event_0000196	canonical_mention.actual	"arrest"	libya_reuters__1000-01-01__timeline:15-20	1.000
:Event_0000196	Justice.ArrestJail_Person.actual	:Entity_EDL_0000385	libya_reuters__1000-01-01__timeline:47-58	1.000
:Event_0000196	Justice.ArrestJail_Place.actual	:Entity_EDL_0000018	libya_reuters__1000-01-01__timeline:77-84	1.000
:Event_0000197	type	Conflict.Attack
:Event_0000197	mention.actual	"attack"	libya_cnn__1000-01-01__timeline:993-998	1.000
:Event_0000197	canonical_mention.actual	"attack"	libya_cnn__1000-01-01__timeline:993-998	1.000
:Event_0000197	Conflict.Attack_Place.actual	:Entity_EDL_0000002	libya_cnn__1000-01-01__timeline:926-933	1.000
:Event_0000197	Conflict.Attack_Target.actual	:Entity_EDL_0000446	libya_cnn__1000-01-01__timeline:961-970	1.000
:Event_0000197	Conflict.Attack_Target.actual	:Entity_EDL_0000324	libya_cnn__1000-01-01__timeline:978-981	1.000
:Event_0000197	Conflict.Attack_Attacker.actual	:Entity_EDL_0000215	libya_cnn__1000-01-01__timeline:1027-1032	1.000
:Event_0000198	type	Conflict.Attack
:Event_0000198	mention.actual	"firing"	libya_cnn__1000-01-01__timeline:1377-1382	1.000
:Event_0000198	canonical_mention.actual	"firing"	libya_cnn__1000-01-01__timeline:1377-1382	1.000
:Event_0000198	Conflict.Attack_Place.actual	:Entity_EDL_0000002	libya_cnn__1000-01-01__timeline:1320-1327	1.000
:Event_0000198	Conflict.Attack_Attacker.actual	:Entity_EDL_0000246	libya_cnn__1000-01-01__timeline:1368-1375	1.000
:Event_0000198	Conflict.Attack_Instrument.actual	:Entity_EDL_0000394	libya_cnn__1000-01-01__timeline:1384-1391	1.000
:Event_0000198	Conflict.Attack_Instrument.actual	:Entity_EDL_0000323	libya_cnn__1000-01-01__timeline:1397-1403	1.000
:Event_0000199	type	Personnel.EndPosition
:Event_0000199	mention.actual	"former"	libya_cnn__1000-01-01__timeline:3405-3410	1.000
:Event_0000199	canonical_mention.actual	"former"	libya_cnn__1000-01-01__timeline:3405-3410	1.000
:Event_0000199	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000259	libya_cnn__1000-01-01__timeline:3412-3418	1.000
:Event_0000199	Personnel.EndPosition_Person.actual	:Entity_EDL_0000142	libya_cnn__1000-01-01__timeline:3429-3447	1.000
:Event_0000200	type	Justice.ArrestJail
:Event_0000200	mention.actual	"arrest"	libya_guardian__1000-01-01__timeline:15-20	1.000
:Event_0000200	canonical_mention.actual	"arrest"	libya_guardian__1000-01-01__timeline:15-20	1.000
:Event_0000200	Justice.ArrestJail_Person.actual	:Entity_EDL_0000217	libya_guardian__1000-01-01__timeline:47-58	1.000
:Event_0000200	Justice.ArrestJail_Place.actual	:Entity_EDL_0000002	libya_guardian__1000-01-01__timeline:77-84	1.000
:Event_0000201	type	Movement.TransportPerson
:Event_0000201	mention.actual	"return"	libya_guardian__1000-01-01__timeline:3263-3268	1.000
:Event_0000201	canonical_mention.actual	"return"	libya_guardian__1000-01-01__timeline:3263-3268	1.000
:Event_0000201	Movement.TransportPerson_Person.actual	:Entity_EDL_0000415	libya_guardian__1000-01-01__timeline:3280-3289	1.000
:Event_0000201	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000000	libya_guardian__1000-01-01__timeline:3294-3300	1.000
:Event_0000202	type	Movement.TransportPerson
:Event_0000202	mention.actual	"crossing"	libya_reuters__1000-01-01__timeline:1956-1963	1.000
:Event_0000202	canonical_mention.actual	"crossing"	libya_reuters__1000-01-01__timeline:1956-1963	1.000
:Event_0000202	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000089	libya_reuters__1000-01-01__timeline:1939-1942	1.000
:Event_0000202	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000197	libya_reuters__1000-01-01__timeline:1969-1976	1.000
:Event_0000203	type	Conflict.Attack
:Event_0000203	mention.actual	"campaign"	libya_cnn__1000-01-01__timeline:11550-11557	1.000
:Event_0000203	canonical_mention.actual	"campaign"	libya_cnn__1000-01-01__timeline:11550-11557	1.000
:Event_0000203	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_cnn__1000-01-01__timeline:11517-11523	1.000
:Event_0000203	Conflict.Attack_Attacker.actual	:Entity_EDL_0000004	libya_cnn__1000-01-01__timeline:11541-11544	1.000
:Event_0000204	type	Conflict.Attack
:Event_0000204	mention.actual	"overrun"	libya_reuters__1000-01-01__timeline:1669-1675	1.000
:Event_0000204	canonical_mention.actual	"overrun"	libya_reuters__1000-01-01__timeline:1669-1675	1.000
:Event_0000204	Conflict.Attack_Attacker.actual	:Entity_EDL_0000390	libya_reuters__1000-01-01__timeline:1662-1667	1.000
:Event_0000204	Conflict.Attack_Target.actual	:Entity_EDL_0000192	libya_reuters__1000-01-01__timeline:1713-1720	1.000
:Event_0000204	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_reuters__1000-01-01__timeline:1725-1731	1.000
:Event_0000205	type	Conflict.Attack
:Event_0000205	mention.actual	"Battles"	libya_aljazeera__1000-01-01__timeline:1909-1915	1.000
:Event_0000205	canonical_mention.actual	"Battles"	libya_aljazeera__1000-01-01__timeline:1909-1915	1.000
:Event_0000205	Conflict.Attack_Place.actual	:Entity_EDL_0000391	libya_aljazeera__1000-01-01__timeline:1943-1948	1.000
:Event_0000206	type	Life.Die
:Event_0000206	mention.actual	"deaths"	libya_afp__1000-01-01__timeline:2728-2733	1.000
:Event_0000206	canonical_mention.actual	"deaths"	libya_afp__1000-01-01__timeline:2728-2733	1.000
:Event_0000206	Life.Die_Victim.actual	:Entity_EDL_0000164	libya_afp__1000-01-01__timeline:2719-2726	1.000
:Event_0000207	type	Movement.TransportArtifact
:Event_0000207	mention.actual	"escape"	libya_reuters__1000-01-01__timeline:4123-4128	1.000
:Event_0000207	canonical_mention.actual	"escape"	libya_reuters__1000-01-01__timeline:4123-4128	1.000
:Event_0000207	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000275	libya_reuters__1000-01-01__timeline:4111-4112	1.000
:Event_0000207	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000441	libya_reuters__1000-01-01__timeline:4130-4134	1.000
:Event_0000208	type	Conflict.Attack
:Event_0000208	mention.actual	"Fighting"	libya_afp__1000-01-01__timeline:3209-3216	1.000
:Event_0000208	canonical_mention.actual	"Fighting"	libya_afp__1000-01-01__timeline:3209-3216	1.000
:Event_0000208	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_afp__1000-01-01__timeline:3228-3234	1.000
:Event_0000208	Conflict.Attack_Attacker.actual	:Entity_EDL_0000175	libya_afp__1000-01-01__timeline:3239-3244	1.000
:Event_0000209	type	Conflict.Attack
:Event_0000209	mention.actual	"assassinations"	libya_cnn__1000-01-01__timeline:8820-8833	1.000
:Event_0000209	canonical_mention.actual	"assassinations"	libya_cnn__1000-01-01__timeline:8820-8833	1.000
:Event_0000210	type	Justice.ArrestJail
:Event_0000210	mention.actual	"arrest"	libya_reuters__1000-01-01__timeline:1279-1284	1.000
:Event_0000210	canonical_mention.actual	"arrest"	libya_reuters__1000-01-01__timeline:1279-1284	1.000
:Event_0000210	Justice.ArrestJail_Agent.actual	:Entity_EDL_0000029	libya_reuters__1000-01-01__timeline:1268-1270	1.000
:Event_0000210	Justice.ArrestJail_Person.actual	:Entity_EDL_0000008	libya_reuters__1000-01-01__timeline:1299-1305	1.000
:Event_0000210	Justice.ArrestJail_Person.actual	:Entity_EDL_0000321	libya_reuters__1000-01-01__timeline:1317-1329	1.000
:Event_0000210	Justice.ArrestJail_Person.actual	:Entity_EDL_0000010	libya_reuters__1000-01-01__timeline:1354-1372	1.000
:Event_0000211	type	Conflict.Attack
:Event_0000211	mention.actual	"clashes"	libya_cnn__1000-01-01__timeline:1355-1361	1.000
:Event_0000211	canonical_mention.actual	"clashes"	libya_cnn__1000-01-01__timeline:1355-1361	1.000
:Event_0000211	Conflict.Attack_Place.actual	:Entity_EDL_0000002	libya_cnn__1000-01-01__timeline:1320-1327	1.000
:Event_0000211	Conflict.Attack_Attacker.actual	:Entity_EDL_0000246	libya_cnn__1000-01-01__timeline:1368-1375	1.000
:Event_0000211	Conflict.Attack_Instrument.actual	:Entity_EDL_0000394	libya_cnn__1000-01-01__timeline:1384-1391	1.000
:Event_0000211	Conflict.Attack_Instrument.actual	:Entity_EDL_0000323	libya_cnn__1000-01-01__timeline:1397-1403	1.000
:Event_0000212	type	Contact.Meet
:Event_0000212	mention.actual	"meet"	libya_reuters__1000-01-01__timeline:2049-2052	1.000
:Event_0000212	canonical_mention.actual	"meet"	libya_reuters__1000-01-01__timeline:2049-2052	1.000
:Event_0000212	Contact.Meet_Participant.actual	:Entity_EDL_0000420	libya_reuters__1000-01-01__timeline:2042-2047	1.000
:Event_0000212	Contact.Meet_Participant.actual	:Entity_EDL_0000159	libya_reuters__1000-01-01__timeline:2060-2066	1.000
:Event_0000212	Contact.Meet_Place.actual	:Entity_EDL_0000370	libya_reuters__1000-01-01__timeline:2087-2091	1.000
:Event_0000213	type	Movement.TransportArtifact
:Event_0000213	mention.actual	"creeps"	libya_cnn__1000-01-01__timeline:897-902	1.000
:Event_0000213	canonical_mention.actual	"creeps"	libya_cnn__1000-01-01__timeline:897-902	1.000
:Event_0000213	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000113	libya_cnn__1000-01-01__timeline:881-889	1.000
:Event_0000213	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000000	libya_cnn__1000-01-01__timeline:912-918	1.000
:Event_0000214	type	Movement.TransportArtifact
:Event_0000214	mention.actual	"arrives"	libya_cnn__1000-01-01__timeline:9464-9470	1.000
:Event_0000214	canonical_mention.actual	"arrives"	libya_cnn__1000-01-01__timeline:9464-9470	1.000
:Event_0000214	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000016	libya_cnn__1000-01-01__timeline:9438-9450	1.000
:Event_0000214	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000020	libya_cnn__1000-01-01__timeline:9454-9462	1.000
:Event_0000214	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000124	libya_cnn__1000-01-01__timeline:9475-9482	1.000
:Event_0000214	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000307	libya_cnn__1000-01-01__timeline:9500-9505	1.000
:Event_0000214	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000191	libya_cnn__1000-01-01__timeline:9514-9524	1.000
:Event_0000215	type	Movement.TransportPerson
:Event_0000215	mention.actual	"evicting"	libya_reuters__1000-01-01__timeline:212-219	1.000
:Event_0000215	canonical_mention.actual	"evicting"	libya_reuters__1000-01-01__timeline:212-219	1.000
:Event_0000215	Movement.TransportPerson_Agent.actual	:Entity_EDL_0000310	libya_reuters__1000-01-01__timeline:149-156	1.000
:Event_0000215	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000421	libya_reuters__1000-01-01__timeline:190-193	1.000
:Event_0000215	Movement.TransportPerson_Person.actual	:Entity_EDL_0000202	libya_reuters__1000-01-01__timeline:221-226	1.000
:Event_0000216	type	Transaction.TransferOwnership
:Event_0000216	mention.actual	"captured"	libya_xinhua__1000-01-01__timeline:3352-3359	1.000
:Event_0000216	canonical_mention.actual	"captured"	libya_xinhua__1000-01-01__timeline:3352-3359	1.000
:Event_0000216	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000274	libya_xinhua__1000-01-01__timeline:3345-3350	1.000
:Event_0000216	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000419	libya_xinhua__1000-01-01__timeline:3379-3386	1.000
:Event_0000216	Transaction.TransferOwnership_Place.actual	:Entity_EDL_0000000	libya_xinhua__1000-01-01__timeline:3391-3397	1.000
:Event_0000217	type	Conflict.Coup.Coup
:Event_0000217	mention.actual	"overthrow"	libya_latimes__1000-01-01__timeline:10289-10297	1.000
:Event_0000217	canonical_mention.actual	"overthrow"	libya_latimes__1000-01-01__timeline:10289-10297	1.000
:Event_0000217	Conflict.Coup.Coup_DeposingEntity.actual	:Entity_EDL_0000320	libya_latimes__1000-01-01__timeline:10270-10275	1.000
:Event_0000217	Conflict.Coup.Coup_DeposedEntity.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:10313-10326	1.000
:Event_0000218	type	Conflict.Attack
:Event_0000218	mention.actual	"fight"	libya_latimes__1000-01-01__timeline:5840-5844	1.000
:Event_0000218	canonical_mention.actual	"fight"	libya_latimes__1000-01-01__timeline:5840-5844	1.000
:Event_0000218	Conflict.Attack_Place.actual	:Entity_EDL_0000287	libya_latimes__1000-01-01__timeline:5783-5786	1.000
:Event_0000218	Conflict.Attack_Attacker.actual	:Entity_EDL_0000297	libya_latimes__1000-01-01__timeline:5822-5827	1.000
:Event_0000218	Conflict.Attack_Attacker.actual	:Entity_EDL_0000194	libya_latimes__1000-01-01__timeline:5860-5865	1.000
:Event_0000219	type	Transaction.TransferMoney
:Event_0000219	mention.actual	"get"	libya_latimes__1000-01-01__timeline:10883-10885	1.000
:Event_0000219	canonical_mention.actual	"get"	libya_latimes__1000-01-01__timeline:10883-10885	1.000
:Event_0000219	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000218	libya_latimes__1000-01-01__timeline:10868-10873	1.000
:Event_0000220	type	Life.Die
:Event_0000220	mention.actual	"kills"	libya_latimes__1000-01-01__timeline:6258-6262	1.000
:Event_0000220	canonical_mention.actual	"kills"	libya_latimes__1000-01-01__timeline:6258-6262	1.000
:Event_0000220	Life.Die_Agent.actual	:Entity_EDL_0000004	libya_latimes__1000-01-01__timeline:6217-6220	1.000
:Event_0000220	Life.Die_Victim.actual	:Entity_EDL_0000423	libya_latimes__1000-01-01__timeline:6264-6266	1.000
:Event_0000220	Life.Die_Victim.actual	:Entity_EDL_0000007	libya_latimes__1000-01-01__timeline:6290-6302	1.000
:Event_0000221	type	Movement.TransportPerson
:Event_0000221	mention.actual	"bursts into"	libya_cnn__1000-01-01__timeline:5883-5893	1.000
:Event_0000221	canonical_mention.actual	"bursts into"	libya_cnn__1000-01-01__timeline:5883-5893	1.000
:Event_0000221	Movement.TransportPerson_Agent.actual	:Entity_EDL_0000428	libya_cnn__1000-01-01__timeline:5846-5850	1.000
:Event_0000221	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000237	libya_cnn__1000-01-01__timeline:5905-5909	1.000
:Event_0000222	type	Justice.ArrestJail
:Event_0000222	mention.actual	"arrest"	libya_latimes__1000-01-01__timeline:9136-9141	1.000
:Event_0000222	canonical_mention.actual	"arrest"	libya_latimes__1000-01-01__timeline:9136-9141	1.000
:Event_0000222	Justice.ArrestJail_Person.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:9155-9168	1.000
:Event_0000223	type	Life.BeBorn
:Event_0000223	mention.actual	"birth"	libya_guardian__1000-01-01__timeline:1899-1903	1.000
:Event_0000223	canonical_mention.actual	"birth"	libya_guardian__1000-01-01__timeline:1899-1903	1.000
:Event_0000223	Life.BeBorn_Person.actual	:Entity_EDL_0000207	libya_guardian__1000-01-01__timeline:1879-1891	1.000
:Event_0000223	Life.BeBorn_Place.actual	:Entity_EDL_0000329	libya_guardian__1000-01-01__timeline:1910-1915	1.000
:Event_0000223	Life.BeBorn_Place.actual	:Entity_EDL_0000139	libya_guardian__1000-01-01__timeline:1929-1932	1.000
:Event_0000224	type	Conflict.Attack
:Event_0000224	mention.actual	"fight"	libya_latimes__1000-01-01__timeline:6088-6092	1.000
:Event_0000224	canonical_mention.actual	"fight"	libya_latimes__1000-01-01__timeline:6088-6092	1.000
:Event_0000224	Conflict.Attack_Attacker.actual	:Entity_EDL_0000242	libya_latimes__1000-01-01__timeline:6107-6112	1.000
:Event_0000224	Conflict.Attack_Place.actual	:Entity_EDL_0000024	libya_latimes__1000-01-01__timeline:6119-6126	1.000
:Event_0000225	type	Conflict.Attack
:Event_0000225	mention.actual	"strike"	libya_afp__1000-01-01__timeline:685-690	1.000
:Event_0000225	canonical_mention.actual	"strike"	libya_afp__1000-01-01__timeline:685-690	1.000
:Event_0000225	Conflict.Attack_Target.actual	:Entity_EDL_0000006	libya_afp__1000-01-01__timeline:658-664	1.000
:Event_0000225	Conflict.Attack_Attacker.actual	:Entity_EDL_0000004	libya_afp__1000-01-01__timeline:676-679	1.000
:Event_0000226	type	Conflict.Attack
:Event_0000226	mention.actual	"airstrikes"	libya_latimes__1000-01-01__timeline:3503-3512	1.000
:Event_0000226	canonical_mention.actual	"airstrikes"	libya_latimes__1000-01-01__timeline:3503-3512	1.000
:Event_0000227	type	Conflict.Attack
:Event_0000227	mention.actual	"Fighting"	libya_latimes__1000-01-01__timeline:10019-10026	1.000
:Event_0000227	canonical_mention.actual	"Fighting"	libya_latimes__1000-01-01__timeline:10019-10026	1.000
:Event_0000227	Conflict.Attack_Place.actual	:Entity_EDL_0000033	libya_latimes__1000-01-01__timeline:10047-10056	1.000
:Event_0000227	Conflict.Attack_Attacker.actual	:Entity_EDL_0000195	libya_latimes__1000-01-01__timeline:10084-10091	1.000
:Event_0000228	type	Movement.TransportArtifact
:Event_0000228	mention.actual	"whisk"	libya_cnn__1000-01-01__timeline:6186-6190	1.000
:Event_0000228	canonical_mention.actual	"whisk"	libya_cnn__1000-01-01__timeline:6186-6190	1.000
:Event_0000228	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000437	libya_cnn__1000-01-01__timeline:6160-6168	1.000
:Event_0000228	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000255	libya_cnn__1000-01-01__timeline:6180-6184	1.000
:Event_0000228	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000166	libya_cnn__1000-01-01__timeline:6192-6194	1.000
:Event_0000228	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000365	libya_cnn__1000-01-01__timeline:6207-6209	1.000
:Event_0000229	type	Justice.ArrestJail
:Event_0000229	mention.actual	"arrested"	libya_guardian__1000-01-01__timeline:5620-5627	1.000
:Event_0000229	canonical_mention.actual	"arrested"	libya_guardian__1000-01-01__timeline:5620-5627	1.000
:Event_0000229	Justice.ArrestJail_Person.actual	:Entity_EDL_0000116	libya_guardian__1000-01-01__timeline:5612-5614	1.000
:Event_0000229	Justice.ArrestJail_Person.actual	:Entity_EDL_0000347	libya_guardian__1000-01-01__timeline:5634-5636	1.000
:Event_0000230	type	Life.Injure
:Event_0000230	mention.actual	"wounded"	libya_guardian__1000-01-01__timeline:6193-6199	1.000
:Event_0000230	canonical_mention.actual	"wounded"	libya_guardian__1000-01-01__timeline:6193-6199	1.000
:Event_0000230	Life.Injure_Victim.actual	:Entity_EDL_0000155	libya_guardian__1000-01-01__timeline:6182-6183	1.000
:Event_0000231	type	Conflict.Attack
:Event_0000231	mention.actual	"bullet"	libya_latimes__1000-01-01__timeline:580-585	1.000
:Event_0000231	canonical_mention.actual	"bullet"	libya_latimes__1000-01-01__timeline:580-585	1.000
:Event_0000231	Conflict.Attack_Attacker.actual	:Entity_EDL_0000097	libya_latimes__1000-01-01__timeline:548-553	1.000
:Event_0000231	Conflict.Attack_Instrument.actual	:Entity_EDL_0000377	libya_latimes__1000-01-01__timeline:580-585	1.000
:Event_0000232	type	Movement.TransportArtifact
:Event_0000232	mention.actual	"evacuate"	libya_xinhua__1000-01-01__timeline:672-679	1.000
:Event_0000232	canonical_mention.actual	"evacuate"	libya_xinhua__1000-01-01__timeline:672-679	1.000
:Event_0000232	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000158	libya_xinhua__1000-01-01__timeline:653-661	1.000
:Event_0000232	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000098	libya_xinhua__1000-01-01__timeline:687-695	1.000
:Event_0000232	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000005	libya_xinhua__1000-01-01__timeline:702-706	1.000
:Event_0000233	type	Contact.Broadcast
:Event_0000233	mention.actual	"announces"	libya_latimes__1000-01-01__timeline:13271-13279	1.000
:Event_0000233	canonical_mention.actual	"announces"	libya_latimes__1000-01-01__timeline:13271-13279	1.000
:Event_0000233	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000140	libya_latimes__1000-01-01__timeline:13252-13267	1.000
:Event_0000234	type	Life.Die
:Event_0000234	mention.actual	"dead"	libya_aljazeera__1000-01-01__timeline:2083-2086	1.000
:Event_0000234	canonical_mention.actual	"dead"	libya_aljazeera__1000-01-01__timeline:2083-2086	1.000
:Event_0000234	Life.Die_Victim.actual	:Entity_EDL_0000169	libya_aljazeera__1000-01-01__timeline:2080-2081	1.000
:Event_0000235	type	Life.Injure
:Event_0000235	mention.actual	"bloodshed"	libya_latimes__1000-01-01__timeline:391-399	1.000
:Event_0000235	canonical_mention.actual	"bloodshed"	libya_latimes__1000-01-01__timeline:391-399	1.000
:Event_0000236	type	Movement.TransportArtifact
:Event_0000236	mention.actual	"reach"	libya_latimes__1000-01-01__timeline:925-929	1.000
:Event_0000236	canonical_mention.actual	"reach"	libya_latimes__1000-01-01__timeline:925-929	1.000
:Event_0000236	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000185	libya_latimes__1000-01-01__timeline:918-923	1.000
:Event_0000236	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000130	libya_latimes__1000-01-01__timeline:931-936	1.000
:Event_0000237	type	Conflict.Attack
:Event_0000237	mention.actual	"siege"	libya_aljazeera__1000-01-01__timeline:6892-6896	1.000
:Event_0000237	canonical_mention.actual	"siege"	libya_aljazeera__1000-01-01__timeline:6892-6896	1.000
:Event_0000237	Conflict.Attack_Attacker.actual	:Entity_EDL_0000382	libya_aljazeera__1000-01-01__timeline:6826-6833	1.000
:Event_0000238	type	Conflict.Attack
:Event_0000238	mention.actual	"attack"	libya_xinhua__1000-01-01__timeline:1893-1898	1.000
:Event_0000238	canonical_mention.actual	"attack"	libya_xinhua__1000-01-01__timeline:1893-1898	1.000
:Event_0000238	Conflict.Attack_Target.actual	:Entity_EDL_0000315	libya_xinhua__1000-01-01__timeline:1867-1875	1.000
:Event_0000238	Conflict.Attack_Place.actual	:Entity_EDL_0000432	libya_xinhua__1000-01-01__timeline:1907-1913	1.000
:Event_0000239	type	Conflict.Attack
:Event_0000239	mention.actual	"strikes"	libya_afp__1000-01-01__timeline:2636-2642	1.000
:Event_0000239	canonical_mention.actual	"strikes"	libya_afp__1000-01-01__timeline:2636-2642	1.000
:Event_0000239	Conflict.Attack_Attacker.actual	:Entity_EDL_0000004	libya_afp__1000-01-01__timeline:2588-2591	1.000
:Event_0000239	Conflict.Attack_Target.actual	:Entity_EDL_0000371	libya_afp__1000-01-01__timeline:2619-2627	1.000
:Event_0000239	Conflict.Attack_Place.actual	:Entity_EDL_0000435	libya_afp__1000-01-01__timeline:2653-2658	1.000
:Event_0000240	type	Life.Die
:Event_0000240	mention.actual	"killed"	libya_xinhua__1000-01-01__timeline:395-400	1.000
:Event_0000240	canonical_mention.actual	"killed"	libya_xinhua__1000-01-01__timeline:395-400	1.000
:Event_0000240	Life.Die_Victim.actual	:Entity_EDL_0000290	libya_xinhua__1000-01-01__timeline:379-384	1.000
:Event_0000240	Life.Die_Place.actual	:Entity_EDL_0000337	libya_xinhua__1000-01-01__timeline:449-452	1.000
:Event_0000241	type	Conflict.Attack
:Event_0000241	mention.actual	"bombs"	libya_aljazeera__1000-01-01__timeline:501-505	1.000
:Event_0000241	canonical_mention.actual	"bombs"	libya_aljazeera__1000-01-01__timeline:501-505	1.000
:Event_0000241	Conflict.Attack_Attacker.actual	:Entity_EDL_0000013	libya_aljazeera__1000-01-01__timeline:493-499	1.000
:Event_0000241	Conflict.Attack_Place.actual	:Entity_EDL_0000445	libya_aljazeera__1000-01-01__timeline:507-511	1.000
:Event_0000242	type	Life.Die
:Event_0000242	mention.actual	"killed"	libya_aljazeera__1000-01-01__timeline:242-247	1.000
:Event_0000242	canonical_mention.actual	"killed"	libya_aljazeera__1000-01-01__timeline:242-247	1.000
:Event_0000242	Life.Die_Place.actual	:Entity_EDL_0000057	libya_aljazeera__1000-01-01__timeline:200-206	1.000
:Event_0000242	Life.Die_Victim.actual	:Entity_EDL_0000230	libya_aljazeera__1000-01-01__timeline:226-235	1.000
:Event_0000243	type	ArtifactExistence.DamageDestroy.Damage
:Event_0000243	mention.actual	"trashing"	libya_reuters__1000-01-01__timeline:1735-1742	1.000
:Event_0000243	canonical_mention.actual	"trashing"	libya_reuters__1000-01-01__timeline:1735-1742	1.000
:Event_0000243	ArtifactExistence.DamageDestroy.Damage_Artifact.actual	:Entity_EDL_0000192	libya_reuters__1000-01-01__timeline:1713-1720	1.000
:Event_0000243	ArtifactExistence.DamageDestroy.Damage_Place.actual	:Entity_EDL_0000000	libya_reuters__1000-01-01__timeline:1725-1731	1.000
:Event_0000243	ArtifactExistence.DamageDestroy.Damage_Artifact.actual	:Entity_EDL_0000178	libya_reuters__1000-01-01__timeline:1748-1754	1.000
:Event_0000244	type	Life.Die
:Event_0000244	mention.actual	"kills"	libya_cnn__1000-01-01__timeline:7719-7723	1.000
:Event_0000244	canonical_mention.actual	"kills"	libya_cnn__1000-01-01__timeline:7719-7723	1.000
:Event_0000244	Life.Die_Victim.actual	:Entity_EDL_0000353	libya_cnn__1000-01-01__timeline:7725-7727	1.000
:Event_0000245	type	Conflict.Attack
:Event_0000245	mention.actual	"killing"	libya_guardian__1000-01-01__timeline:5090-5096	1.000
:Event_0000245	canonical_mention.actual	"killing"	libya_guardian__1000-01-01__timeline:5090-5096	1.000
:Event_0000245	Conflict.Attack_Attacker.actual	:Entity_EDL_0000422	libya_guardian__1000-01-01__timeline:5086-5088	1.000
:Event_0000246	type	Conflict.Attack
:Event_0000246	mention.actual	"Gunfights"	libya_aljazeera__1000-01-01__timeline:6341-6349	1.000
:Event_0000246	canonical_mention.actual	"Gunfights"	libya_aljazeera__1000-01-01__timeline:6341-6349	1.000
:Event_0000246	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_aljazeera__1000-01-01__timeline:6364-6370	1.000
:Event_0000246	Conflict.Attack_Attacker.actual	:Entity_EDL_0000084	libya_aljazeera__1000-01-01__timeline:6388-6397	1.000
:Event_0000246	Conflict.Attack_Attacker.actual	:Entity_EDL_0000298	libya_aljazeera__1000-01-01__timeline:6407-6412	1.000
:Event_0000247	type	Conflict.Demonstrate
:Event_0000247	mention.actual	"protest"	libya_cnn__1000-01-01__timeline:2038-2044	1.000
:Event_0000247	canonical_mention.actual	"protest"	libya_cnn__1000-01-01__timeline:2038-2044	1.000
:Event_0000247	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000427	libya_cnn__1000-01-01__timeline:2139-2148	1.000
:Event_0000248	type	Conflict.Attack
:Event_0000248	mention.actual	"bombing"	libya_latimes__1000-01-01__timeline:2620-2626	1.000
:Event_0000248	canonical_mention.actual	"bombing"	libya_latimes__1000-01-01__timeline:2620-2626	1.000
:Event_0000248	Conflict.Attack_Attacker.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:2598-2611	1.000
:Event_0000248	Conflict.Attack_Place.actual	:Entity_EDL_0000002	libya_latimes__1000-01-01__timeline:2628-2635	1.000
:Event_0000249	type	Business.Start
:Event_0000249	mention.actual	"put in place"	libya_aljazeera__1000-01-01__timeline:8105-8116	1.000
:Event_0000249	canonical_mention.actual	"put in place"	libya_aljazeera__1000-01-01__timeline:8105-8116	1.000
:Event_0000249	Business.Start_Agent.actual	:Entity_EDL_0000205	libya_aljazeera__1000-01-01__timeline:8086-8087	1.000
:Event_0000249	Business.Start_Organization.actual	:Entity_EDL_0000053	libya_aljazeera__1000-01-01__timeline:8120-8129	1.000
:Event_0000250	type	Conflict.Attack
:Event_0000250	mention.actual	"airstrikes"	libya_latimes__1000-01-01__timeline:1816-1825	1.000
:Event_0000250	canonical_mention.actual	"airstrikes"	libya_latimes__1000-01-01__timeline:1816-1825	1.000
:Event_0000250	Conflict.Attack_Attacker.actual	:Entity_EDL_0000001	libya_latimes__1000-01-01__timeline:1794-1807	1.000
:Event_0000250	Conflict.Attack_Target.actual	:Entity_EDL_0000030	libya_latimes__1000-01-01__timeline:1835-1843	1.000
:Event_0000251	type	Movement.TransportArtifact
:Event_0000251	mention.actual	"close in"	libya_afp__1000-01-01__timeline:3246-3253	1.000
:Event_0000251	canonical_mention.actual	"close in"	libya_afp__1000-01-01__timeline:3246-3253	1.000
:Event_0000251	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000175	libya_afp__1000-01-01__timeline:3239-3244	1.000
:Event_0000251	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000201	libya_afp__1000-01-01__timeline:3262-3268	1.000
:Event_0000252	type	Justice.ArrestJail
:Event_0000252	mention.actual	"arrested"	libya_cnn__1000-01-01__timeline:509-516	1.000
:Event_0000252	canonical_mention.actual	"arrested"	libya_cnn__1000-01-01__timeline:509-516	1.000
:Event_0000252	Justice.ArrestJail_Person.actual	:Entity_EDL_0000407	libya_cnn__1000-01-01__timeline:489-495	1.000
:Event_0000253	type	Conflict.Attack
:Event_0000253	mention.actual	"fighting"	libya_latimes__1000-01-01__timeline:10277-10284	1.000
:Event_0000253	canonical_mention.actual	"fighting"	libya_latimes__1000-01-01__timeline:10277-10284	1.000
:Event_0000253	Conflict.Attack_Target.actual	:Entity_EDL_0000256	libya_latimes__1000-01-01__timeline:10245-10249	1.000
:Event_0000253	Conflict.Attack_Attacker.actual	:Entity_EDL_0000320	libya_latimes__1000-01-01__timeline:10270-10275	1.000
:Event_0000254	type	Contact.Meet
:Event_0000254	mention.actual	"meet"	libya_aljazeera__1000-01-01__timeline:3993-3996	1.000
:Event_0000254	canonical_mention.actual	"meet"	libya_aljazeera__1000-01-01__timeline:3993-3996	1.000
:Event_0000254	Contact.Meet_Participant.actual	:Entity_EDL_0000232	libya_aljazeera__1000-01-01__timeline:3986-3991	1.000
:Event_0000254	Contact.Meet_Participant.actual	:Entity_EDL_0000054	libya_aljazeera__1000-01-01__timeline:4004-4010	1.000
:Event_0000254	Contact.Meet_Place.actual	:Entity_EDL_0000059	libya_aljazeera__1000-01-01__timeline:4031-4035	1.000
:Event_0000255	type	Movement.TransportArtifact
:Event_0000255	mention.actual	"crossed"	libya_xinhua__1000-01-01__timeline:3599-3605	1.000
:Event_0000255	canonical_mention.actual	"crossed"	libya_xinhua__1000-01-01__timeline:3599-3605	1.000
:Event_0000255	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000050	libya_xinhua__1000-01-01__timeline:3543-3550	1.000
:Event_0000255	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000046	libya_xinhua__1000-01-01__timeline:3556-3563	1.000
:Event_0000255	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000012	libya_xinhua__1000-01-01__timeline:3623-3629	1.000
:Event_0000256	type	Justice.ChargeIndict
:Event_0000256	mention.actual	"charges"	libya_cnn__1000-01-01__timeline:6533-6539	1.000
:Event_0000256	canonical_mention.actual	"charges"	libya_cnn__1000-01-01__timeline:6533-6539	1.000
:Event_0000256	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000294	libya_cnn__1000-01-01__timeline:6434-6436	1.000
:Event_0000256	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000416	libya_cnn__1000-01-01__timeline:6499-6506	1.000
:Event_0000257	type	Life.Die
:Event_0000257	mention.actual	"die"	libya_latimes__1000-01-01__timeline:5931-5933	1.000
:Event_0000257	canonical_mention.actual	"die"	libya_latimes__1000-01-01__timeline:5931-5933	1.000
:Event_0000257	Life.Die_Victim.actual	:Entity_EDL_0000360	libya_latimes__1000-01-01__timeline:5923-5924	1.000
:Event_0000258	type	Conflict.Attack
:Event_0000258	mention.actual	"overrun"	libya_guardian__1000-01-01__timeline:1659-1665	1.000
:Event_0000258	canonical_mention.actual	"overrun"	libya_guardian__1000-01-01__timeline:1659-1665	1.000
:Event_0000258	Conflict.Attack_Attacker.actual	:Entity_EDL_0000399	libya_guardian__1000-01-01__timeline:1652-1657	1.000
:Event_0000258	Conflict.Attack_Target.actual	:Entity_EDL_0000209	libya_guardian__1000-01-01__timeline:1703-1710	1.000
:Event_0000258	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_guardian__1000-01-01__timeline:1715-1721	1.000
:Event_0000259	type	Personnel.EndPosition
:Event_0000259	mention.actual	"dismissed"	libya_cnn__1000-01-01__timeline:10022-10030	1.000
:Event_0000259	canonical_mention.actual	"dismissed"	libya_cnn__1000-01-01__timeline:10022-10030	1.000
:Event_0000259	Personnel.EndPosition_Person.actual	:Entity_EDL_0000248	libya_cnn__1000-01-01__timeline:10065-10069	1.000
:Event_0000260	type	Conflict.Attack
:Event_0000260	mention.actual	"clash"	libya_aljazeera__1000-01-01__timeline:8210-8214	1.000
:Event_0000260	canonical_mention.actual	"clash"	libya_aljazeera__1000-01-01__timeline:8210-8214	1.000
:Event_0000260	Conflict.Attack_Target.actual	:Entity_EDL_0000443	libya_aljazeera__1000-01-01__timeline:8178-8192	1.000
:Event_0000260	Conflict.Attack_Attacker.actual	:Entity_EDL_0000151	libya_aljazeera__1000-01-01__timeline:8225-8230	1.000
:Event_0000261	type	Life.Die
:Event_0000261	mention.actual	"casualties"	libya_xinhua__1000-01-01__timeline:184-193	1.000
:Event_0000261	canonical_mention.actual	"casualties"	libya_xinhua__1000-01-01__timeline:184-193	1.000
:Event_0000261	Life.Die_Victim.actual	:Entity_EDL_0000099	libya_xinhua__1000-01-01__timeline:134-143	1.000
:Event_0000261	Life.Die_Agent.actual	:Entity_EDL_0000332	libya_xinhua__1000-01-01__timeline:162-167	1.000
:Event_0000262	type	Conflict.Attack
:Event_0000262	mention.actual	"clashes"	libya_aljazeera__1000-01-01__timeline:69-75	1.000
:Event_0000262	canonical_mention.actual	"clashes"	libya_aljazeera__1000-01-01__timeline:69-75	1.000
:Event_0000262	Conflict.Attack_Place.actual	:Entity_EDL_0000003	libya_aljazeera__1000-01-01__timeline:80-84	1.000
:Event_0000262	Conflict.Attack_Place.actual	:Entity_EDL_0000002	libya_aljazeera__1000-01-01__timeline:151-158	1.000
:Event_0000263	type	Movement.TransportArtifact
:Event_0000263	mention.actual	"arrived"	libya_guardian__1000-01-01__timeline:2480-2486	1.000
:Event_0000263	canonical_mention.actual	"arrived"	libya_guardian__1000-01-01__timeline:2480-2486	1.000
:Event_0000263	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000143	libya_guardian__1000-01-01__timeline:2466-2468	1.000
:Event_0000263	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000019	libya_guardian__1000-01-01__timeline:2470-2474	1.000
:Event_0000263	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000282	libya_guardian__1000-01-01__timeline:2488-2492	1.000
:Event_0000264	type	Life.Die
:Event_0000264	mention.actual	"killed"	libya_cnn__1000-01-01__timeline:1128-1133	1.000
:Event_0000264	canonical_mention.actual	"killed"	libya_cnn__1000-01-01__timeline:1128-1133	1.000
:Event_0000264	Life.Die_Victim.actual	:Entity_EDL_0000293	libya_cnn__1000-01-01__timeline:1068-1077	1.000
:Event_0000264	Life.Die_Victim.actual	:Entity_EDL_0000426	libya_cnn__1000-01-01__timeline:1117-1122	1.000
:Event_0000265	type	Conflict.Attack
:Event_0000265	mention.actual	"fighting"	libya_cnn__1000-01-01__timeline:683-690	1.000
:Event_0000265	canonical_mention.actual	"fighting"	libya_cnn__1000-01-01__timeline:683-690	1.000
:Event_0000265	Conflict.Attack_Attacker.actual	:Entity_EDL_0000176	libya_cnn__1000-01-01__timeline:676-681	1.000
:Event_0000265	Conflict.Attack_Target.actual	:Entity_EDL_0000082	libya_cnn__1000-01-01__timeline:692-701	1.000
:Event_0000266	type	Movement.TransportArtifact
:Event_0000266	mention.actual	"escape"	libya_aljazeera__1000-01-01__timeline:6108-6113	1.000
:Event_0000266	canonical_mention.actual	"escape"	libya_aljazeera__1000-01-01__timeline:6108-6113	1.000
:Event_0000266	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000257	libya_aljazeera__1000-01-01__timeline:6096-6097	1.000
:Event_0000266	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000450	libya_aljazeera__1000-01-01__timeline:6115-6119	1.000
:Event_0000267	type	Conflict.Attack
:Event_0000267	mention.actual	"destroying"	libya_cnn__1000-01-01__timeline:7524-7533	1.000
:Event_0000267	canonical_mention.actual	"destroying"	libya_cnn__1000-01-01__timeline:7524-7533	1.000
:Event_0000267	Conflict.Attack_Attacker.actual	:Entity_EDL_0000280	libya_cnn__1000-01-01__timeline:7489-7497	1.000
:Event_0000267	Conflict.Attack_Place.actual	:Entity_EDL_0000251	libya_cnn__1000-01-01__timeline:7539-7544	1.000
:Event_0000268	type	Conflict.Attack
:Event_0000268	mention.actual	"besieged"	libya_latimes__1000-01-01__timeline:6399-6406	1.000
:Event_0000268	canonical_mention.actual	"besieged"	libya_latimes__1000-01-01__timeline:6399-6406	1.000
:Event_0000269	type	Justice.ChargeIndict
:Event_0000269	mention.actual	"charged"	libya_xinhua__1000-01-01__timeline:2740-2746	1.000
:Event_0000269	canonical_mention.actual	"charged"	libya_xinhua__1000-01-01__timeline:2740-2746	1.000
:Event_0000269	Justice.ChargeIndict_Adjudicator.actual	:Entity_EDL_0000029	libya_xinhua__1000-01-01__timeline:2607-2634	1.000
:Event_0000269	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000008	libya_xinhua__1000-01-01__timeline:2663-2669	1.000
:Event_0000269	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000010	libya_xinhua__1000-01-01__timeline:2718-2736	1.000
:Event_0000270	type	Conflict.Attack
:Event_0000270	mention.actual	"fight"	libya_latimes__1000-01-01__timeline:11275-11279	1.000
:Event_0000270	canonical_mention.actual	"fight"	libya_latimes__1000-01-01__timeline:11275-11279	1.000
:Event_0000270	Conflict.Attack_Place.actual	:Entity_EDL_0000000	libya_latimes__1000-01-01__timeline:11285-11291	1.000
:Event_0000271	type	Conflict.Attack
:Event_0000271	mention.actual	"pound"	libya_latimes__1000-01-01__timeline:6144-6148	1.000
:Event_0000271	canonical_mention.actual	"pound"	libya_latimes__1000-01-01__timeline:6144-6148	1.000
:Event_0000271	Conflict.Attack_Attacker.actual	:Entity_EDL_0000242	libya_latimes__1000-01-01__timeline:6107-6112	1.000
:Event_0000271	Conflict.Attack_Place.actual	:Entity_EDL_0000384	libya_latimes__1000-01-01__timeline:6150-6151	1.000
:Event_0000271	Conflict.Attack_Instrument.actual	:Entity_EDL_0000047	libya_latimes__1000-01-01__timeline:6158-6166	1.000
:Event_0000272	type	Life.Die
:Event_0000272	mention.actual	"death"	libya_cnn__1000-01-01__timeline:1281-1285	1.000
:Event_0000272	canonical_mention.actual	"death"	libya_cnn__1000-01-01__timeline:1281-1285	1.000
:Event_0000273	type	Movement.TransportPerson
:Event_0000273	mention.actual	"return"	libya_aljazeera__1000-01-01__timeline:5259-5264	1.000
:Event_0000273	canonical_mention.actual	"return"	libya_aljazeera__1000-01-01__timeline:5259-5264	1.000
:Event_0000273	Movement.TransportPerson_Person.actual	:Entity_EDL_0000233	libya_aljazeera__1000-01-01__timeline:5276-5285	1.000
:Event_0000273	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000000	libya_aljazeera__1000-01-01__timeline:5290-5296	1.000
:Event_0000274	type	Life.Die
:Event_0000274	mention.actual	"deaths"	libya_cnn__1000-01-01__timeline:2571-2576	1.000
:Event_0000274	canonical_mention.actual	"deaths"	libya_cnn__1000-01-01__timeline:2571-2576	1.000
:Event_0000274	Life.Die_Victim.actual	:Entity_EDL_0000104	libya_cnn__1000-01-01__timeline:2593-2601	1.000
:Event_0000274	Life.Die_Place.actual	:Entity_EDL_0000003	libya_cnn__1000-01-01__timeline:2609-2613	1.000
:Event_0000275	type	Movement.TransportArtifact
:Event_0000275	mention.actual	"reach"	libya_aljazeera__1000-01-01__timeline:2926-2930	1.000
:Event_0000275	canonical_mention.actual	"reach"	libya_aljazeera__1000-01-01__timeline:2926-2930	1.000
:Event_0000275	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000322	libya_aljazeera__1000-01-01__timeline:2919-2924	1.000
:Event_0000275	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000300	libya_aljazeera__1000-01-01__timeline:2932-2943	1.000
:Event_0000276	type	Conflict.Attack
:Event_0000276	mention.actual	"fighting"	libya_xinhua__1000-01-01__timeline:4317-4324	1.000
:Event_0000276	canonical_mention.actual	"fighting"	libya_xinhua__1000-01-01__timeline:4317-4324	1.000
:Event_0000277	type	Movement.TransportArtifact
:Event_0000277	mention.actual	"advance"	libya_reuters__1000-01-01__timeline:976-982	1.000
:Event_0000277	canonical_mention.actual	"advance"	libya_reuters__1000-01-01__timeline:976-982	1.000
:Event_0000277	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000304	libya_reuters__1000-01-01__timeline:998-1003	1.000
:Event_0000277	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000018	libya_reuters__1000-01-01__timeline:1008-1015	1.000
:Event_0000278	type	Contact.Meet
:Event_0000278	mention.actual	"talks"	libya_latimes__1000-01-01__timeline:8469-8473	1.000
:Event_0000278	canonical_mention.actual	"talks"	libya_latimes__1000-01-01__timeline:8469-8473	1.000
:Event_0000278	Contact.Meet_Participant.actual	:Entity_EDL_0000379	libya_latimes__1000-01-01__timeline:8529-8543	1.000
:Event_0000278	Contact.Meet_Participant.actual	:Entity_EDL_0000381	libya_latimes__1000-01-01__timeline:8582-8587	1.000
:Event_0000279	type	Contact.Correspondence
:Event_0000279	mention.actual	"letter"	libya_cnn__1000-01-01__timeline:7104-7109	1.000
:Event_0000279	canonical_mention.actual	"letter"	libya_cnn__1000-01-01__timeline:7104-7109	1.000
:Event_0000279	Contact.Correspondence_Participant.actual	:Entity_EDL_0000026	libya_cnn__1000-01-01__timeline:6990-6996	1.000
:Event_0000280	type	Conflict.Attack
:Event_0000280	mention.actual	"fight"	libya_cnn__1000-01-01__timeline:10537-10541	1.000
:Event_0000280	canonical_mention.actual	"fight"	libya_cnn__1000-01-01__timeline:10537-10541	1.000
:Event_0000280	Conflict.Attack_Attacker.actual	:Entity_EDL_0000367	libya_cnn__1000-01-01__timeline:10546-10549	1.000
:Event_0000281	type	Conflict.Attack
:Event_0000281	mention.actual	"battle"	libya_afp__1000-01-01__timeline:3596-3601	1.000
:Event_0000281	canonical_mention.actual	"battle"	libya_afp__1000-01-01__timeline:3596-3601	1.000
:Event_0000281	Conflict.Attack_Place.actual	:Entity_EDL_0000052	libya_afp__1000-01-01__timeline:3611-3617	1.000
:Event_0000282	type	Conflict.Attack
:Event_0000282	mention.actual	"attacks"	libya_afp__1000-01-01__timeline:150-156	1.000
:Event_0000282	canonical_mention.actual	"attacks"	libya_afp__1000-01-01__timeline:150-156	1.000
:Event_0000282	Conflict.Attack_Place.actual	:Entity_EDL_0000002	libya_afp__1000-01-01__timeline:85-92	1.000
:Event_0000282	Conflict.Attack_Attacker.actual	:Entity_EDL_0000413	libya_afp__1000-01-01__timeline:120-125	1.000
:Event_0000283	type	Conflict.Attack
:Event_0000283	mention.actual	"action"	libya_latimes__1000-01-01__timeline:6786-6791	1.000
:Event_0000283	canonical_mention.actual	"action"	libya_latimes__1000-01-01__timeline:6786-6791	1.000
:Event_0000283	Conflict.Attack_Attacker.actual	:Entity_EDL_0000096	libya_latimes__1000-01-01__timeline:6777-6784	1.000
:Event_0000283	Conflict.Attack_Place.actual	:Entity_EDL_0000003	libya_latimes__1000-01-01__timeline:6796-6800	1.000
:Event_0000284	type	Justice.ChargeIndict
:Event_0000284	mention.actual	"charges"	libya_guardian__1000-01-01__timeline:1367-1373	1.000
:Event_0000284	canonical_mention.actual	"charges"	libya_guardian__1000-01-01__timeline:1367-1373	1.000
:Event_0000284	Justice.ChargeIndict_Adjudicator.actual	:Entity_EDL_0000241	libya_guardian__1000-01-01__timeline:1258-1260	1.000
:Event_0000284	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000006	libya_guardian__1000-01-01__timeline:1289-1295	1.000
:Event_0000284	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000025	libya_guardian__1000-01-01__timeline:1307-1319	1.000
:Event_0000284	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000010	libya_guardian__1000-01-01__timeline:1344-1362	1.000
:Event_0000285	type	Conflict.Demonstrate
:Event_0000285	mention.actual	"uprisings"	libya_latimes__1000-01-01__timeline:11573-11581	1.000
:Event_0000285	canonical_mention.actual	"uprisings"	libya_latimes__1000-01-01__timeline:11573-11581	1.000
:Event_0000285	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000000	libya_latimes__1000-01-01__timeline:11603-11609	1.000
:Event_0000286	type	Conflict.Attack
:Event_0000286	mention.actual	"battle"	libya_latimes__1000-01-01__timeline:10961-10966	1.000
:Event_0000286	canonical_mention.actual	"battle"	libya_latimes__1000-01-01__timeline:10961-10966	1.000
:Event_0000286	Conflict.Attack_Attacker.actual	:Entity_EDL_0000357	libya_latimes__1000-01-01__timeline:10954-10959	1.000
:Event_0000286	Conflict.Attack_Place.actual	:Entity_EDL_0000295	libya_latimes__1000-01-01__timeline:10978-10981	1.000
:Event_0000287	type	Conflict.Attack
:Event_0000287	mention.actual	"fight"	libya_reuters__1000-01-01__timeline:1580-1584	1.000
:Event_0000287	canonical_mention.actual	"fight"	libya_reuters__1000-01-01__timeline:1580-1584	1.000
:Event_0000287	Conflict.Attack_Attacker.actual	:Entity_EDL_0000163	libya_reuters__1000-01-01__timeline:1569-1575	1.000
:Event_0000288	type	Life.Injure
:Event_0000288	mention.actual	"casualties"	libya_latimes__1000-01-01__timeline:11724-11733	1.000
:Event_0000288	canonical_mention.actual	"casualties"	libya_latimes__1000-01-01__timeline:11724-11733	1.000
:Event_0000288	Life.Injure_Place.actual	:Entity_EDL_0000028	libya_latimes__1000-01-01__timeline:11781-11788	1.000
