:Event_0000000	type	Life.Injure
:Event_0000000	mention.actual	"injury"	bpoil_reuters__1000-01-01__timeline:1439-1444	1.000
:Event_0000000	canonical_mention.actual	"injury"	bpoil_reuters__1000-01-01__timeline:1439-1444	1.000
:Event_0000000	Life.Injure_Victim.actual	:Entity_EDL_0000001	bpoil_reuters__1000-01-01__timeline:1456-1464	1.000
:Event_0000001	type	Justice.ChargeIndict
:Event_0000001	mention.actual	"charged"	bpoil_reuters__1000-01-01__timeline:4309-4315	1.000
:Event_0000001	canonical_mention.actual	"charged"	bpoil_reuters__1000-01-01__timeline:4309-4315	1.000
:Event_0000001	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000017	bpoil_reuters__1000-01-01__timeline:4296-4304	1.000
:Event_0000002	type	Personnel.StartPosition
:Event_0000002	mention.actual	"succeeded"	bpoil_reuters__1000-01-01__timeline:2286-2294	1.000
:Event_0000002	canonical_mention.actual	"succeeded"	bpoil_reuters__1000-01-01__timeline:2286-2294	1.000
:Event_0000002	Personnel.StartPosition_Person.actual	:Entity_EDL_0000007	bpoil_reuters__1000-01-01__timeline:2308-2320	1.000
:Event_0000003	type	Transaction.TransferMoney
:Event_0000003	mention.actual	"payments"	bpoil_reuters__1000-01-01__timeline:4183-4190	1.000
:Event_0000003	canonical_mention.actual	"payments"	bpoil_reuters__1000-01-01__timeline:4183-4190	1.000
:Event_0000003	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000014	bpoil_reuters__1000-01-01__timeline:4214-4221	1.000
:Event_0000004	type	Justice.Sentence
:Event_0000004	mention.actual	"penalty"	bpoil_reuters__1000-01-01__timeline:4154-4160	1.000
:Event_0000004	canonical_mention.actual	"penalty"	bpoil_reuters__1000-01-01__timeline:4154-4160	1.000
:Event_0000004	Justice.Sentence_Defendant.actual	:Entity_EDL_0000014	bpoil_reuters__1000-01-01__timeline:4214-4221	1.000
:Event_0000005	type	Justice.TrialHearing
:Event_0000005	mention.actual	"trial"	bpoil_reuters__1000-01-01__timeline:3427-3431	1.000
:Event_0000005	canonical_mention.actual	"trial"	bpoil_reuters__1000-01-01__timeline:3427-3431	1.000
:Event_0000005	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000012	bpoil_reuters__1000-01-01__timeline:3448-3449	1.000
:Event_0000006	type	Life.Die
:Event_0000006	mention.actual	"kills"	bpoil_reuters__1000-01-01__timeline:83-87	1.000
:Event_0000006	canonical_mention.actual	"kills"	bpoil_reuters__1000-01-01__timeline:83-87	1.000
:Event_0000006	Life.Die_Victim.actual	:Entity_EDL_0000015	bpoil_reuters__1000-01-01__timeline:92-98	1.000
:Event_0000007	type	Disaster.FireExplosion.FireExplosion
:Event_0000007	mention.actual	"explosion"	bpoil_reuters__1000-01-01__timeline:14-22	1.000
:Event_0000007	canonical_mention.actual	"explosion"	bpoil_reuters__1000-01-01__timeline:14-22	1.000
:Event_0000007	mention.actual	"explosion"	bpoil_reuters__1000-01-01__timeline:14-22	1.000
:Event_0000007	canonical_mention.actual	"explosion"	bpoil_reuters__1000-01-01__timeline:14-22	1.000
:Event_0000008	type	Justice.Sue
:Event_0000008	mention.actual	"sue"	bpoil_reuters__1000-01-01__timeline:3771-3773	1.000
:Event_0000008	canonical_mention.actual	"sue"	bpoil_reuters__1000-01-01__timeline:3771-3773	1.000
:Event_0000008	Justice.Sue_Plaintiff.actual	:Entity_EDL_0000011	bpoil_reuters__1000-01-01__timeline:3762-3765	1.000
:Event_0000009	type	Life.Die
:Event_0000009	mention.actual	"deaths"	bpoil_reuters__1000-01-01__timeline:4027-4032	1.000
:Event_0000009	canonical_mention.actual	"deaths"	bpoil_reuters__1000-01-01__timeline:4027-4032	1.000
:Event_0000009	Life.Die_Victim.actual	:Entity_EDL_0000005	bpoil_reuters__1000-01-01__timeline:4040-4046	1.000
:Event_0000010	type	Transaction.TransferMoney
:Event_0000010	mention.actual	"pay"	bpoil_reuters__1000-01-01__timeline:3884-3886	1.000
:Event_0000010	canonical_mention.actual	"pay"	bpoil_reuters__1000-01-01__timeline:3884-3886	1.000
:Event_0000010	Transaction.TransferMoney_Giver.actual	:Entity_EDL_0000000	bpoil_reuters__1000-01-01__timeline:3871-3872	1.000
:Event_0000010	Transaction.TransferMoney_Recipient.actual	:Entity_EDL_0000003	bpoil_reuters__1000-01-01__timeline:3932-3941	1.000
:Event_0000011	type	Justice.TrialHearing
:Event_0000011	mention.actual	"plead"	bpoil_reuters__1000-01-01__timeline:3982-3986	1.000
:Event_0000011	canonical_mention.actual	"plead"	bpoil_reuters__1000-01-01__timeline:3982-3986	1.000
:Event_0000011	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000000	bpoil_reuters__1000-01-01__timeline:3871-3872	1.000
:Event_0000012	type	Justice.Sue
:Event_0000012	mention.actual	"suit"	bpoil_reuters__1000-01-01__timeline:2951-2954	1.000
:Event_0000012	canonical_mention.actual	"suit"	bpoil_reuters__1000-01-01__timeline:2951-2954	1.000
:Event_0000012	Justice.Sue_Plaintiff.actual	:Entity_EDL_0000013	bpoil_reuters__1000-01-01__timeline:2926-2943	1.000
:Event_0000012	Justice.Sue_Defendant.actual	:Entity_EDL_0000004	bpoil_reuters__1000-01-01__timeline:2964-2965	1.000
:Event_0000012	Justice.Sue_Defendant.actual	:Entity_EDL_0000006	bpoil_reuters__1000-01-01__timeline:2983-2991	1.000
:Event_0000013	type	Conflict.Attack
:Event_0000013	mention.actual	"explosion"	bpoil_reuters__1000-01-01__timeline:3348-3356	1.000
:Event_0000013	canonical_mention.actual	"explosion"	bpoil_reuters__1000-01-01__timeline:3348-3356	1.000
:Event_0000013	Conflict.Attack_Place.actual	:Entity_EDL_0000010	bpoil_reuters__1000-01-01__timeline:3330-3346	1.000
:Event_0000014	type	Contact.Broadcast
:Event_0000014	mention.actual	"announces"	bpoil_reuters__1000-01-01__timeline:1047-1055	1.000
:Event_0000014	canonical_mention.actual	"announces"	bpoil_reuters__1000-01-01__timeline:1047-1055	1.000
:Event_0000014	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000009	bpoil_reuters__1000-01-01__timeline:1039-1045	1.000
:Event_0000015	type	Personnel.EndPosition
:Event_0000015	mention.actual	"step down"	bpoil_reuters__1000-01-01__timeline:2259-2267	1.000
:Event_0000015	canonical_mention.actual	"step down"	bpoil_reuters__1000-01-01__timeline:2259-2267	1.000
:Event_0000015	Personnel.EndPosition_Person.actual	:Entity_EDL_0000002	bpoil_reuters__1000-01-01__timeline:2246-2252	1.000
:Event_0000016	type	Justice.ChargeIndict
:Event_0000016	mention.actual	"charged"	bpoil_reuters__1000-01-01__timeline:4255-4261	1.000
:Event_0000016	canonical_mention.actual	"charged"	bpoil_reuters__1000-01-01__timeline:4255-4261	1.000
:Event_0000016	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000008	bpoil_reuters__1000-01-01__timeline:4243-4249	1.000
:Event_0000017	type	Justice.Fine
:Event_0000017	mention.actual	"fines"	bpoil_reuters__1000-01-01__timeline:4126-4130	1.000
:Event_0000017	canonical_mention.actual	"fines"	bpoil_reuters__1000-01-01__timeline:4126-4130	1.000
:Event_0000018	type	Justice.TrialHearing
:Event_0000018	mention.actual	"trial"	bpoil_reuters__1000-01-01__timeline:3487-3491	1.000
:Event_0000018	canonical_mention.actual	"trial"	bpoil_reuters__1000-01-01__timeline:3487-3491	1.000
:Event_0000018	Justice.TrialHearing_Defendant.actual	:Entity_EDL_0000016	bpoil_reuters__1000-01-01__timeline:3455-3461	1.000
