:Event_0000000	type	Movement.TransportArtifact
:Event_0000000	mention.actual	"tour"	bpoil_foxnews__1000-01-01__timeline:4573-4576	1.000
:Event_0000000	canonical_mention.actual	"tour"	bpoil_foxnews__1000-01-01__timeline:4573-4576	1.000
:Event_0000000	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000011	bpoil_foxnews__1000-01-01__timeline:4552-4556	1.000
:Event_0000000	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000025	bpoil_foxnews__1000-01-01__timeline:4601-4605	1.000
:Event_0000001	type	Movement.TransportArtifact
:Event_0000001	mention.actual	"visits"	bpoil_foxnews__1000-01-01__timeline:4580-4585	1.000
:Event_0000001	canonical_mention.actual	"visits"	bpoil_foxnews__1000-01-01__timeline:4580-4585	1.000
:Event_0000001	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000011	bpoil_foxnews__1000-01-01__timeline:4552-4556	1.000
:Event_0000001	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000025	bpoil_foxnews__1000-01-01__timeline:4601-4605	1.000
:Event_0000002	type	Movement.TransportArtifact
:Event_0000002	mention.actual	"deployed"	bpoil_foxnews__1000-01-01__timeline:6671-6678	1.000
:Event_0000002	canonical_mention.actual	"deployed"	bpoil_foxnews__1000-01-01__timeline:6671-6678	1.000
:Event_0000002	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000024	bpoil_foxnews__1000-01-01__timeline:6638-6644	1.000
:Event_0000002	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000020	bpoil_foxnews__1000-01-01__timeline:6656-6665	1.000
:Event_0000002	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000014	bpoil_foxnews__1000-01-01__timeline:6683-6692	1.000
:Event_0000003	type	ArtifactExistence.DamageDestroy.Destroy
:Event_0000003	mention.actual	"sinks"	bpoil_foxnews__1000-01-01__timeline:641-645	1.000
:Event_0000003	canonical_mention.actual	"sinks"	bpoil_foxnews__1000-01-01__timeline:641-645	1.000
:Event_0000004	type	Movement.TransportArtifact
:Event_0000004	mention.actual	"goes"	bpoil_foxnews__1000-01-01__timeline:429-432	1.000
:Event_0000004	canonical_mention.actual	"goes"	bpoil_foxnews__1000-01-01__timeline:429-432	1.000
:Event_0000004	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000022	bpoil_foxnews__1000-01-01__timeline:415-425	1.000
:Event_0000004	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000019	bpoil_foxnews__1000-01-01__timeline:442-452	1.000
:Event_0000005	type	Contact.Meet
:Event_0000005	mention.actual	"meet"	bpoil_foxnews__1000-01-01__timeline:4067-4070	1.000
:Event_0000005	canonical_mention.actual	"meet"	bpoil_foxnews__1000-01-01__timeline:4067-4070	1.000
:Event_0000005	Contact.Meet_Participant.actual	:Entity_EDL_0000007	bpoil_foxnews__1000-01-01__timeline:3892-3900	1.000
:Event_0000005	Contact.Meet_Participant.actual	:Entity_EDL_0000008	bpoil_foxnews__1000-01-01__timeline:3945-3960	1.000
:Event_0000005	Contact.Meet_Participant.actual	:Entity_EDL_0000027	bpoil_foxnews__1000-01-01__timeline:3964-3970	1.000
:Event_0000005	Contact.Meet_Participant.actual	:Entity_EDL_0000016	bpoil_foxnews__1000-01-01__timeline:4001-4015	1.000
:Event_0000005	Contact.Meet_Participant.actual	:Entity_EDL_0000021	bpoil_foxnews__1000-01-01__timeline:4048-4060	1.000
:Event_0000005	Contact.Meet_Participant.actual	:Entity_EDL_0000002	bpoil_foxnews__1000-01-01__timeline:4089-4097	1.000
:Event_0000005	Contact.Meet_Participant.actual	:Entity_EDL_0000028	bpoil_foxnews__1000-01-01__timeline:4101-4112	1.000
:Event_0000005	Contact.Meet_Participant.actual	:Entity_EDL_0000004	bpoil_foxnews__1000-01-01__timeline:4134-4143	1.000
:Event_0000006	type	Contact.Meet
:Event_0000006	mention.actual	"meeting"	bpoil_foxnews__1000-01-01__timeline:1036-1042	1.000
:Event_0000006	canonical_mention.actual	"meeting"	bpoil_foxnews__1000-01-01__timeline:1036-1042	1.000
:Event_0000006	Contact.Meet_Participant.actual	:Entity_EDL_0000003	bpoil_foxnews__1000-01-01__timeline:999-1010	1.000
:Event_0000006	Contact.Meet_Place.actual	:Entity_EDL_0000018	bpoil_foxnews__1000-01-01__timeline:1024-1034	1.000
:Event_0000007	type	Contact.Meet
:Event_0000007	mention.actual	"convenes"	bpoil_foxnews__1000-01-01__timeline:1012-1019	1.000
:Event_0000007	canonical_mention.actual	"convenes"	bpoil_foxnews__1000-01-01__timeline:1012-1019	1.000
:Event_0000007	Contact.Meet_Participant.actual	:Entity_EDL_0000003	bpoil_foxnews__1000-01-01__timeline:999-1010	1.000
:Event_0000007	Contact.Meet_Place.actual	:Entity_EDL_0000018	bpoil_foxnews__1000-01-01__timeline:1024-1034	1.000
:Event_0000008	type	Movement.TransportArtifact
:Event_0000008	mention.actual	"visits"	bpoil_foxnews__1000-01-01__timeline:6574-6579	1.000
:Event_0000008	canonical_mention.actual	"visits"	bpoil_foxnews__1000-01-01__timeline:6574-6579	1.000
:Event_0000008	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000005	bpoil_foxnews__1000-01-01__timeline:6568-6572	1.000
:Event_0000008	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000001	bpoil_foxnews__1000-01-01__timeline:6585-6588	1.000
:Event_0000009	type	Contact.Meet
:Event_0000009	mention.actual	"meets"	bpoil_foxnews__1000-01-01__timeline:6136-6140	1.000
:Event_0000009	canonical_mention.actual	"meets"	bpoil_foxnews__1000-01-01__timeline:6136-6140	1.000
:Event_0000009	Contact.Meet_Participant.actual	:Entity_EDL_0000026	bpoil_foxnews__1000-01-01__timeline:6128-6134	1.000
:Event_0000009	Contact.Meet_Participant.actual	:Entity_EDL_0000013	bpoil_foxnews__1000-01-01__timeline:6159-6168	1.000
:Event_0000010	type	Movement.TransportArtifact
:Event_0000010	mention.actual	"reach"	bpoil_foxnews__1000-01-01__timeline:4933-4937	1.000
:Event_0000010	canonical_mention.actual	"reach"	bpoil_foxnews__1000-01-01__timeline:4933-4937	1.000
:Event_0000010	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000023	bpoil_foxnews__1000-01-01__timeline:4939-4947	1.000
:Event_0000011	type	Contact.Meet
:Event_0000011	mention.actual	"meeting"	bpoil_foxnews__1000-01-01__timeline:5261-5267	1.000
:Event_0000011	canonical_mention.actual	"meeting"	bpoil_foxnews__1000-01-01__timeline:5261-5267	1.000
:Event_0000011	Contact.Meet_Place.actual	:Entity_EDL_0000000	bpoil_foxnews__1000-01-01__timeline:5201-5211	1.000
:Event_0000011	Contact.Meet_Place.actual	:Entity_EDL_0000006	bpoil_foxnews__1000-01-01__timeline:5276-5289	1.000
:Event_0000012	type	Movement.TransportArtifact
:Event_0000012	mention.actual	"sends"	bpoil_foxnews__1000-01-01__timeline:6223-6227	1.000
:Event_0000012	canonical_mention.actual	"sends"	bpoil_foxnews__1000-01-01__timeline:6223-6227	1.000
:Event_0000012	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000015	bpoil_foxnews__1000-01-01__timeline:6217-6221	1.000
:Event_0000012	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000012	bpoil_foxnews__1000-01-01__timeline:6229-6238	1.000
:Event_0000012	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000010	bpoil_foxnews__1000-01-01__timeline:6242-6248	1.000
:Event_0000012	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000029	bpoil_foxnews__1000-01-01__timeline:6264-6272	1.000
:Event_0000012	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000017	bpoil_foxnews__1000-01-01__timeline:6277-6286	1.000
:Event_0000013	type	Conflict.Attack
:Event_0000013	mention.actual	"explosion"	bpoil_foxnews__1000-01-01__timeline:558-566	1.000
:Event_0000013	canonical_mention.actual	"explosion"	bpoil_foxnews__1000-01-01__timeline:558-566	1.000
:Event_0000013	Conflict.Attack_Place.actual	:Entity_EDL_0000009	bpoil_foxnews__1000-01-01__timeline:550-553	1.000
