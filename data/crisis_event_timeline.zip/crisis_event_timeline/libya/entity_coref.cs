:Entity_EDL_0000000	type	GeopoliticalEntity
:Entity_EDL_0000000	mention	"Tripoli"	libya_reuters__1000-01-01__timeline:2311-2317	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_cnn__1000-01-01__timeline:11691-11697	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_reuters__1000-01-01__timeline:4725-4731	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_reuters__1000-01-01__timeline:3305-3311	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_latimes__1000-01-01__timeline:11603-11609	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_reuters__1000-01-01__timeline:1472-1478	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_xinhua__1000-01-01__timeline:2357-2363	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_latimes__1000-01-01__timeline:5060-5066	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_cnn__1000-01-01__timeline:7697-7703	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_reuters__1000-01-01__timeline:2622-2628	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_xinhua__1000-01-01__timeline:2493-2499	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_guardian__1000-01-01__timeline:1715-1721	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_latimes__1000-01-01__timeline:7432-7438	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_latimes__1000-01-01__timeline:5503-5509	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_aljazeera__1000-01-01__timeline:2703-2709	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_aljazeera__1000-01-01__timeline:2581-2587	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_guardian__1000-01-01__timeline:2612-2618	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_aljazeera__1000-01-01__timeline:2426-2432	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_afp__1000-01-01__timeline:3228-3234	1.0
:Entity_EDL_0000000	canonical_mention	"Tripoli"	libya_cnn__1000-01-01__timeline:912-918	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_cnn__1000-01-01__timeline:912-918	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_guardian__1000-01-01__timeline:1462-1468	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_aljazeera__1000-01-01__timeline:4576-4582	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_latimes__1000-01-01__timeline:11285-11291	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_xinhua__1000-01-01__timeline:3391-3397	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_aljazeera__1000-01-01__timeline:6364-6370	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_aljazeera__1000-01-01__timeline:3532-3538	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_aljazeera__1000-01-01__timeline:5290-5296	1.0
:Entity_EDL_0000000	canonical_mention	"Tripoli"	libya_reuters__1000-01-01__timeline:1133-1139	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_reuters__1000-01-01__timeline:1133-1139	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_reuters__1000-01-01__timeline:4379-4385	1.0
:Entity_EDL_0000000	canonical_mention	"Tripoli"	libya_guardian__1000-01-01__timeline:1123-1129	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_guardian__1000-01-01__timeline:1123-1129	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_aljazeera__1000-01-01__timeline:4261-4267	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_reuters__1000-01-01__timeline:1725-1731	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_guardian__1000-01-01__timeline:3294-3300	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_afp__1000-01-01__timeline:3415-3421	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_cnn__1000-01-01__timeline:11517-11523	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_guardian__1000-01-01__timeline:4546-4552	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_latimes__1000-01-01__timeline:1122-1128	1.0
:Entity_EDL_0000000	mention	"Tripoli"	libya_guardian__1000-01-01__timeline:2301-2307	1.0
:Entity_EDL_0000000	link	2210247
:Entity_EDL_0000001	type	Person
:Entity_EDL_0000001	mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:7076-7089	1.0
:Entity_EDL_0000001	mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:7286-7299	1.0
:Entity_EDL_0000001	mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:2131-2144	1.0
:Entity_EDL_0000001	mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:6627-6640	1.0
:Entity_EDL_0000001	mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:1794-1807	1.0
:Entity_EDL_0000001	mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:9155-9168	1.0
:Entity_EDL_0000001	canonical_mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:56-69	1.0
:Entity_EDL_0000001	mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:56-69	1.0
:Entity_EDL_0000001	mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:2598-2611	1.0
:Entity_EDL_0000001	mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:12245-12258	1.0
:Entity_EDL_0000001	mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:5485-5498	1.0
:Entity_EDL_0000001	mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:12884-12897	1.0
:Entity_EDL_0000001	mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:1254-1267	1.0
:Entity_EDL_0000001	mention	"Moammar Kadafi"	libya_latimes__1000-01-01__timeline:10313-10326	1.0
:Entity_EDL_0000001	link	NIL000000001
:Entity_EDL_0000002	type	GeopoliticalEntity
:Entity_EDL_0000002	mention	"Benghazi"	libya_cnn__1000-01-01__timeline:1320-1327	1.0
:Entity_EDL_0000002	mention	"Benghazi"	libya_cnn__1000-01-01__timeline:926-933	1.0
:Entity_EDL_0000002	mention	"Benghazi"	libya_latimes__1000-01-01__timeline:10570-10577	1.0
:Entity_EDL_0000002	mention	"Benghazi"	libya_cnn__1000-01-01__timeline:9808-9815	1.0
:Entity_EDL_0000002	mention	"Benghazi"	libya_guardian__1000-01-01__timeline:998-1005	1.0
:Entity_EDL_0000002	mention	"Benghazi"	libya_latimes__1000-01-01__timeline:2628-2635	1.0
:Entity_EDL_0000002	canonical_mention	"Benghazi"	libya_guardian__1000-01-01__timeline:77-84	1.0
:Entity_EDL_0000002	mention	"Benghazi"	libya_guardian__1000-01-01__timeline:77-84	1.0
:Entity_EDL_0000002	canonical_mention	"Benghazi"	libya_latimes__1000-01-01__timeline:80-87	1.0
:Entity_EDL_0000002	mention	"Benghazi"	libya_latimes__1000-01-01__timeline:80-87	1.0
:Entity_EDL_0000002	canonical_mention	"Benghazi"	libya_aljazeera__1000-01-01__timeline:151-158	1.0
:Entity_EDL_0000002	mention	"Benghazi"	libya_aljazeera__1000-01-01__timeline:151-158	1.0
:Entity_EDL_0000002	canonical_mention	"Benghazi"	libya_afp__1000-01-01__timeline:85-92	1.0
:Entity_EDL_0000002	mention	"Benghazi"	libya_afp__1000-01-01__timeline:85-92	1.0
:Entity_EDL_0000002	mention	"Benghazi"	libya_xinhua__1000-01-01__timeline:1492-1499	1.0
:Entity_EDL_0000002	mention	"Benghazi"	libya_latimes__1000-01-01__timeline:257-264	1.0
:Entity_EDL_0000002	link	88319
:Entity_EDL_0000003	type	GeopoliticalEntity
:Entity_EDL_0000003	mention	"Libya"	libya_aljazeera__1000-01-01__timeline:7240-7244	1.0
:Entity_EDL_0000003	mention	"Libyan"	libya_cnn__1000-01-01__timeline:1538-1543	1.0
:Entity_EDL_0000003	mention	"Libya"	libya_latimes__1000-01-01__timeline:7329-7333	1.0
:Entity_EDL_0000003	mention	"Libya"	libya_cnn__1000-01-01__timeline:2609-2613	1.0
:Entity_EDL_0000003	mention	"Libya"	libya_latimes__1000-01-01__timeline:6796-6800	1.0
:Entity_EDL_0000003	mention	"Libya"	libya_aljazeera__1000-01-01__timeline:80-84	1.0
:Entity_EDL_0000003	mention	"Libya"	libya_cnn__1000-01-01__timeline:3555-3559	1.0
:Entity_EDL_0000003	mention	"Libya"	libya_aljazeera__1000-01-01__timeline:695-699	1.0
:Entity_EDL_0000003	mention	"Libya"	libya_aljazeera__1000-01-01__timeline:4754-4758	1.0
:Entity_EDL_0000003	mention	"Libya"	libya_cnn__1000-01-01__timeline:9205-9209	1.0
:Entity_EDL_0000003	mention	"Libya"	libya_cnn__1000-01-01__timeline:131-135	1.0
:Entity_EDL_0000003	mention	"Libya"	libya_aljazeera__1000-01-01__timeline:6719-6723	1.0
:Entity_EDL_0000003	link	2215636
:Entity_EDL_0000004	type	Organization
:Entity_EDL_0000004	mention	"NATO"	libya_latimes__1000-01-01__timeline:5034-5037	1.0
:Entity_EDL_0000004	mention	"NATO"	libya_latimes__1000-01-01__timeline:6217-6220	1.0
:Entity_EDL_0000004	mention	"NATO"	libya_afp__1000-01-01__timeline:676-679	1.0
:Entity_EDL_0000004	mention	"NATO"	libya_cnn__1000-01-01__timeline:11541-11544	1.0
:Entity_EDL_0000004	mention	"NATO"	libya_cnn__1000-01-01__timeline:7652-7655	1.0
:Entity_EDL_0000004	mention	"NATO"	libya_afp__1000-01-01__timeline:2588-2591	1.0
:Entity_EDL_0000004	mention	"NATO"	libya_afp__1000-01-01__timeline:2247-2250	1.0
:Entity_EDL_0000004	mention	"NATO"	libya_cnn__1000-01-01__timeline:7043-7046	1.0
:Entity_EDL_0000004	canonical_mention	"NATO"	libya_aljazeera__1000-01-01__timeline:675-678	1.0
:Entity_EDL_0000004	mention	"NATO"	libya_aljazeera__1000-01-01__timeline:675-678	1.0
:Entity_EDL_0000004	link	20000153
:Entity_EDL_0000005	type	GeopoliticalEntity
:Entity_EDL_0000005	mention	"Libya"	libya_reuters__1000-01-01__timeline:4843-4847	1.0
:Entity_EDL_0000005	mention	"Libya"	libya_xinhua__1000-01-01__timeline:551-555	1.0
:Entity_EDL_0000005	mention	"Libya"	libya_guardian__1000-01-01__timeline:2757-2761	1.0
:Entity_EDL_0000005	mention	"Libya"	libya_reuters__1000-01-01__timeline:2767-2771	1.0
:Entity_EDL_0000005	mention	"Libya"	libya_guardian__1000-01-01__timeline:4663-4667	1.0
:Entity_EDL_0000005	mention	"Libya"	libya_xinhua__1000-01-01__timeline:305-309	1.0
:Entity_EDL_0000005	mention	"Libya"	libya_xinhua__1000-01-01__timeline:702-706	1.0
:Entity_EDL_0000005	link	2215636
:Entity_EDL_0000006	type	Person
:Entity_EDL_0000006	mention	"Gaddafi"	libya_guardian__1000-01-01__timeline:1289-1295	1.0
:Entity_EDL_0000006	mention	"Gaddafi"	libya_afp__1000-01-01__timeline:1211-1217	1.0
:Entity_EDL_0000006	canonical_mention	"Gaddafi"	libya_afp__1000-01-01__timeline:658-664	1.0
:Entity_EDL_0000006	mention	"Gaddafi"	libya_afp__1000-01-01__timeline:658-664	1.0
:Entity_EDL_0000006	mention	"Gaddafi"	libya_guardian__1000-01-01__timeline:3305-3311	1.0
:Entity_EDL_0000006	mention	"Gaddafi"	libya_guardian__1000-01-01__timeline:1496-1502	1.0
:Entity_EDL_0000006	link	NIL000000002
:Entity_EDL_0000007	type	Person
:Entity_EDL_0000007	canonical_mention	"grandchildren"	libya_xinhua__1000-01-01__timeline:2542-2554	1.0
:Entity_EDL_0000007	nominal_mention	"grandchildren"	libya_xinhua__1000-01-01__timeline:2542-2554	1.0
:Entity_EDL_0000007	canonical_mention	"grandchildren"	libya_reuters__1000-01-01__timeline:1181-1193	1.0
:Entity_EDL_0000007	nominal_mention	"grandchildren"	libya_reuters__1000-01-01__timeline:1181-1193	1.0
:Entity_EDL_0000007	canonical_mention	"grandchildren"	libya_guardian__1000-01-01__timeline:1171-1183	1.0
:Entity_EDL_0000007	nominal_mention	"grandchildren"	libya_guardian__1000-01-01__timeline:1171-1183	1.0
:Entity_EDL_0000007	canonical_mention	"grandchildren"	libya_afp__1000-01-01__timeline:766-778	1.0
:Entity_EDL_0000007	nominal_mention	"grandchildren"	libya_afp__1000-01-01__timeline:766-778	1.0
:Entity_EDL_0000007	canonical_mention	"grandchildren"	libya_latimes__1000-01-01__timeline:6290-6302	1.0
:Entity_EDL_0000007	nominal_mention	"grandchildren"	libya_latimes__1000-01-01__timeline:6290-6302	1.0
:Entity_EDL_0000007	link	NIL000000003
:Entity_EDL_0000008	type	Person
:Entity_EDL_0000008	mention	"Gaddafi"	libya_reuters__1000-01-01__timeline:1299-1305	1.0
:Entity_EDL_0000008	mention	"Gaddafi"	libya_xinhua__1000-01-01__timeline:2663-2669	1.0
:Entity_EDL_0000008	mention	"Gaddafi"	libya_reuters__1000-01-01__timeline:3316-3322	1.0
:Entity_EDL_0000008	mention	"Gaddafi"	libya_reuters__1000-01-01__timeline:1506-1512	1.0
:Entity_EDL_0000008	link	NIL000000004
:Entity_EDL_0000009	type	GeopoliticalEntity
:Entity_EDL_0000009	mention	"Libya"	libya_cnn__1000-01-01__timeline:10468-10472	1.0
:Entity_EDL_0000009	mention	"Libya"	libya_cnn__1000-01-01__timeline:8206-8210	1.0
:Entity_EDL_0000009	mention	"Libya"	libya_cnn__1000-01-01__timeline:2302-2306	1.0
:Entity_EDL_0000009	mention	"Libya"	libya_cnn__1000-01-01__timeline:7975-7979	1.0
:Entity_EDL_0000009	link	2215636
:Entity_EDL_0000010	type	Person
:Entity_EDL_0000010	canonical_mention	"Abdullah al-Senussi"	libya_guardian__1000-01-01__timeline:1344-1362	1.0
:Entity_EDL_0000010	mention	"Abdullah al-Senussi"	libya_guardian__1000-01-01__timeline:1344-1362	1.0
:Entity_EDL_0000010	canonical_mention	"Abdullah al-Senussi"	libya_xinhua__1000-01-01__timeline:2718-2736	1.0
:Entity_EDL_0000010	mention	"Abdullah al-Senussi"	libya_xinhua__1000-01-01__timeline:2718-2736	1.0
:Entity_EDL_0000010	canonical_mention	"Abdullah al-Senussi"	libya_reuters__1000-01-01__timeline:1354-1372	1.0
:Entity_EDL_0000010	mention	"Abdullah al-Senussi"	libya_reuters__1000-01-01__timeline:1354-1372	1.0
:Entity_EDL_0000010	link	NIL000000005
:Entity_EDL_0000011	type	Person
:Entity_EDL_0000011	canonical_mention	"son"	libya_reuters__1000-01-01__timeline:1167-1169	1.0
:Entity_EDL_0000011	nominal_mention	"son"	libya_reuters__1000-01-01__timeline:1167-1169	1.0
:Entity_EDL_0000011	canonical_mention	"son"	libya_guardian__1000-01-01__timeline:1157-1159	1.0
:Entity_EDL_0000011	nominal_mention	"son"	libya_guardian__1000-01-01__timeline:1157-1159	1.0
:Entity_EDL_0000011	canonical_mention	"son"	libya_xinhua__1000-01-01__timeline:2528-2530	1.0
:Entity_EDL_0000011	nominal_mention	"son"	libya_xinhua__1000-01-01__timeline:2528-2530	1.0
:Entity_EDL_0000011	link	NIL000000006
:Entity_EDL_0000012	type	GeopoliticalEntity
:Entity_EDL_0000012	canonical_mention	"Algeria"	libya_xinhua__1000-01-01__timeline:3623-3629	1.0
:Entity_EDL_0000012	mention	"Algeria"	libya_xinhua__1000-01-01__timeline:3623-3629	1.0
:Entity_EDL_0000012	canonical_mention	"Algeria"	libya_reuters__1000-01-01__timeline:1878-1884	1.0
:Entity_EDL_0000012	mention	"Algeria"	libya_reuters__1000-01-01__timeline:1878-1884	1.0
:Entity_EDL_0000012	canonical_mention	"Algeria"	libya_guardian__1000-01-01__timeline:1868-1874	1.0
:Entity_EDL_0000012	mention	"Algeria"	libya_guardian__1000-01-01__timeline:1868-1874	1.0
:Entity_EDL_0000012	link	2589581
:Entity_EDL_0000013	type	Person
:Entity_EDL_0000013	mention	"Gaddafi"	libya_aljazeera__1000-01-01__timeline:5301-5307	1.0
:Entity_EDL_0000013	mention	"Gaddafi"	libya_aljazeera__1000-01-01__timeline:2744-2750	1.0
:Entity_EDL_0000013	mention	"Gaddafi"	libya_aljazeera__1000-01-01__timeline:493-499	1.0
:Entity_EDL_0000013	link	NIL000000007
:Entity_EDL_0000014	type	Weapon
:Entity_EDL_0000014	canonical_mention	"missile"	libya_xinhua__1000-01-01__timeline:2464-2470	1.0
:Entity_EDL_0000014	nominal_mention	"missile"	libya_xinhua__1000-01-01__timeline:2464-2470	1.0
:Entity_EDL_0000014	canonical_mention	"missile"	libya_guardian__1000-01-01__timeline:1094-1100	1.0
:Entity_EDL_0000014	nominal_mention	"missile"	libya_guardian__1000-01-01__timeline:1094-1100	1.0
:Entity_EDL_0000014	canonical_mention	"missile"	libya_reuters__1000-01-01__timeline:1104-1110	1.0
:Entity_EDL_0000014	nominal_mention	"missile"	libya_reuters__1000-01-01__timeline:1104-1110	1.0
:Entity_EDL_0000014	link	NIL000000008
:Entity_EDL_0000015	type	Person
:Entity_EDL_0000015	canonical_mention	"Khamis"	libya_guardian__1000-01-01__timeline:4502-4507	1.0
:Entity_EDL_0000015	mention	"Khamis"	libya_guardian__1000-01-01__timeline:4502-4507	1.0
:Entity_EDL_0000015	canonical_mention	"Khamis"	libya_afp__1000-01-01__timeline:2235-2240	1.0
:Entity_EDL_0000015	mention	"Khamis"	libya_afp__1000-01-01__timeline:2235-2240	1.0
:Entity_EDL_0000015	link	30004519
:Entity_EDL_0000016	type	GeopoliticalEntity
:Entity_EDL_0000016	mention	"United States"	libya_cnn__1000-01-01__timeline:9570-9582	1.0
:Entity_EDL_0000016	mention	"United States"	libya_cnn__1000-01-01__timeline:9438-9450	1.0
:Entity_EDL_0000016	link	6252001
:Entity_EDL_0000017	type	GeopoliticalEntity
:Entity_EDL_0000017	mention	"Misrata"	libya_aljazeera__1000-01-01__timeline:1270-1276	1.0
:Entity_EDL_0000017	canonical_mention	"Misrata"	libya_aljazeera__1000-01-01__timeline:997-1003	1.0
:Entity_EDL_0000017	mention	"Misrata"	libya_aljazeera__1000-01-01__timeline:997-1003	1.0
:Entity_EDL_0000017	link	2214845
:Entity_EDL_0000018	type	GeopoliticalEntity
:Entity_EDL_0000018	canonical_mention	"Benghazi"	libya_reuters__1000-01-01__timeline:77-84	1.0
:Entity_EDL_0000018	mention	"Benghazi"	libya_reuters__1000-01-01__timeline:77-84	1.0
:Entity_EDL_0000018	mention	"Benghazi"	libya_reuters__1000-01-01__timeline:1008-1015	1.0
:Entity_EDL_0000018	link	88319
:Entity_EDL_0000019	type	Person
:Entity_EDL_0000019	canonical_mention	"Saadi"	libya_xinhua__1000-01-01__timeline:3712-3716	1.0
:Entity_EDL_0000019	mention	"Saadi"	libya_xinhua__1000-01-01__timeline:3712-3716	1.0
:Entity_EDL_0000019	canonical_mention	"Saadi"	libya_guardian__1000-01-01__timeline:2470-2474	1.0
:Entity_EDL_0000019	mention	"Saadi"	libya_guardian__1000-01-01__timeline:2470-2474	1.0
:Entity_EDL_0000019	link	NIL000000009
:Entity_EDL_0000020	type	Person
:Entity_EDL_0000020	mention	"al-Obeidy"	libya_cnn__1000-01-01__timeline:9454-9462	1.0
:Entity_EDL_0000020	mention	"al-Obeidy"	libya_cnn__1000-01-01__timeline:6456-6464	1.0
:Entity_EDL_0000020	link	NIL000000010
:Entity_EDL_0000021	type	Person
:Entity_EDL_0000021	canonical_mention	"Mustafa Abdel Jalil"	libya_guardian__1000-01-01__timeline:2566-2584	1.0
:Entity_EDL_0000021	mention	"Mustafa Abdel Jalil"	libya_guardian__1000-01-01__timeline:2566-2584	1.0
:Entity_EDL_0000021	canonical_mention	"Mustafa Abdel Jalil"	libya_afp__1000-01-01__timeline:2443-2461	1.0
:Entity_EDL_0000021	mention	"Mustafa Abdel Jalil"	libya_afp__1000-01-01__timeline:2443-2461	1.0
:Entity_EDL_0000021	link	NIL000000011
:Entity_EDL_0000022	type	Person
:Entity_EDL_0000022	canonical_mention	"people"	libya_latimes__1000-01-01__timeline:8067-8072	1.0
:Entity_EDL_0000022	nominal_mention	"people"	libya_latimes__1000-01-01__timeline:8067-8072	1.0
:Entity_EDL_0000022	canonical_mention	"people"	libya_aljazeera__1000-01-01__timeline:369-374	1.0
:Entity_EDL_0000022	nominal_mention	"people"	libya_aljazeera__1000-01-01__timeline:369-374	1.0
:Entity_EDL_0000022	link	NIL000000012
:Entity_EDL_0000023	type	Organization
:Entity_EDL_0000023	canonical_mention	"NATO"	libya_reuters__1000-01-01__timeline:1099-1102	1.0
:Entity_EDL_0000023	mention	"NATO"	libya_reuters__1000-01-01__timeline:1099-1102	1.0
:Entity_EDL_0000023	canonical_mention	"NATO"	libya_xinhua__1000-01-01__timeline:2459-2462	1.0
:Entity_EDL_0000023	mention	"NATO"	libya_xinhua__1000-01-01__timeline:2459-2462	1.0
:Entity_EDL_0000023	link	20000153
:Entity_EDL_0000024	type	GeopoliticalEntity
:Entity_EDL_0000024	mention	"Misurata"	libya_latimes__1000-01-01__timeline:6119-6126	1.0
:Entity_EDL_0000024	mention	"Misurata"	libya_latimes__1000-01-01__timeline:2522-2529	1.0
:Entity_EDL_0000024	link	2214846
:Entity_EDL_0000025	type	Person
:Entity_EDL_0000025	mention	"Saif al-Islam"	libya_guardian__1000-01-01__timeline:5987-5999	1.0
:Entity_EDL_0000025	canonical_mention	"Saif al-Islam"	libya_guardian__1000-01-01__timeline:1307-1319	1.0
:Entity_EDL_0000025	mention	"Saif al-Islam"	libya_guardian__1000-01-01__timeline:1307-1319	1.0
:Entity_EDL_0000025	link	NIL000000013
:Entity_EDL_0000026	type	Person
:Entity_EDL_0000026	mention	"Gadhafi"	libya_cnn__1000-01-01__timeline:3258-3264	1.0
:Entity_EDL_0000026	mention	"Gadhafi"	libya_cnn__1000-01-01__timeline:6990-6996	1.0
:Entity_EDL_0000026	link	NIL000000014
:Entity_EDL_0000027	type	Person
:Entity_EDL_0000027	canonical_mention	"Saif al-Islam Gadhafi"	libya_cnn__1000-01-01__timeline:1754-1774	1.0
:Entity_EDL_0000027	mention	"Saif al-Islam Gadhafi"	libya_cnn__1000-01-01__timeline:1754-1774	1.0
:Entity_EDL_0000027	mention	"Saif al Islam Gaddafi"	libya_aljazeera__1000-01-01__timeline:8586-8606	1.0
:Entity_EDL_0000027	link	NIL000000015
:Entity_EDL_0000028	type	Facility
:Entity_EDL_0000028	canonical_mention	"compound"	libya_aljazeera__1000-01-01__timeline:3605-3612	1.0
:Entity_EDL_0000028	nominal_mention	"compound"	libya_aljazeera__1000-01-01__timeline:3605-3612	1.0
:Entity_EDL_0000028	canonical_mention	"compound"	libya_latimes__1000-01-01__timeline:11781-11788	1.0
:Entity_EDL_0000028	nominal_mention	"compound"	libya_latimes__1000-01-01__timeline:11781-11788	1.0
:Entity_EDL_0000028	link	NIL000000016
:Entity_EDL_0000029	type	Organization
:Entity_EDL_0000029	canonical_mention	"International Criminal Court"	libya_xinhua__1000-01-01__timeline:2607-2634	1.0
:Entity_EDL_0000029	mention	"International Criminal Court"	libya_xinhua__1000-01-01__timeline:2607-2634	1.0
:Entity_EDL_0000029	mention	"ICC"	libya_reuters__1000-01-01__timeline:1268-1270	1.0
:Entity_EDL_0000029	link	20000115
:Entity_EDL_0000030	type	GeopoliticalEntity
:Entity_EDL_0000030	canonical_mention	"Ras Lanuf"	libya_latimes__1000-01-01__timeline:1524-1532	1.0
:Entity_EDL_0000030	mention	"Ras Lanuf"	libya_latimes__1000-01-01__timeline:1524-1532	1.0
:Entity_EDL_0000030	mention	"Ras Lanuf"	libya_latimes__1000-01-01__timeline:1835-1843	1.0
:Entity_EDL_0000030	link	2212984
:Entity_EDL_0000031	type	Person
:Entity_EDL_0000031	canonical_mention	"Abdul Fatah Younis"	libya_latimes__1000-01-01__timeline:10455-10472	1.0
:Entity_EDL_0000031	mention	"Abdul Fatah Younis"	libya_latimes__1000-01-01__timeline:10455-10472	1.0
:Entity_EDL_0000031	canonical_mention	"Abdel Fatah Yunis"	libya_afp__1000-01-01__timeline:2044-2060	1.0
:Entity_EDL_0000031	mention	"Abdel Fatah Yunis"	libya_afp__1000-01-01__timeline:2044-2060	1.0
:Entity_EDL_0000031	link	NIL000000017
:Entity_EDL_0000032	type	GeopoliticalEntity
:Entity_EDL_0000032	canonical_mention	"Libyans"	libya_aljazeera__1000-01-01__timeline:2799-2805	1.0
:Entity_EDL_0000032	nominal_mention	"Libyans"	libya_aljazeera__1000-01-01__timeline:2799-2805	1.0
:Entity_EDL_0000032	canonical_mention	"Libyans"	libya_cnn__1000-01-01__timeline:10167-10173	1.0
:Entity_EDL_0000032	mention	"Libyans"	libya_cnn__1000-01-01__timeline:10167-10173	1.0
:Entity_EDL_0000032	link	NIL000000018
:Entity_EDL_0000033	type	GeopoliticalEntity
:Entity_EDL_0000033	mention	"Port Brega"	libya_latimes__1000-01-01__timeline:10556-10565	1.0
:Entity_EDL_0000033	mention	"Port Brega"	libya_latimes__1000-01-01__timeline:10047-10056	1.0
:Entity_EDL_0000033	link	2215208
:Entity_EDL_0000034	type	GeopoliticalEntity
:Entity_EDL_0000034	canonical_mention	"Italy"	libya_aljazeera__1000-01-01__timeline:5811-5815	1.0
:Entity_EDL_0000034	mention	"Italy"	libya_aljazeera__1000-01-01__timeline:5811-5815	1.0
:Entity_EDL_0000034	canonical_mention	"Italy"	libya_cnn__1000-01-01__timeline:8488-8492	1.0
:Entity_EDL_0000034	mention	"Italy"	libya_cnn__1000-01-01__timeline:8488-8492	1.0
:Entity_EDL_0000034	link	3175395
:Entity_EDL_0000035	type	Person
:Entity_EDL_0000035	mention	"Zuma"	libya_latimes__1000-01-01__timeline:7397-7400	1.0
:Entity_EDL_0000035	canonical_mention	"Jacob Zuma"	libya_latimes__1000-01-01__timeline:5421-5430	1.0
:Entity_EDL_0000035	mention	"Jacob Zuma"	libya_latimes__1000-01-01__timeline:5421-5430	1.0
:Entity_EDL_0000035	link	30004268
:Entity_EDL_0000036	type	Person
:Entity_EDL_0000036	canonical_mention	"crowd"	libya_reuters__1000-01-01__timeline:2635-2639	1.0
:Entity_EDL_0000036	nominal_mention	"crowd"	libya_reuters__1000-01-01__timeline:2635-2639	1.0
:Entity_EDL_0000036	link	NIL000000019
:Entity_EDL_0000037	type	Location
:Entity_EDL_0000037	canonical_mention	"front"	libya_latimes__1000-01-01__timeline:10545-10549	1.0
:Entity_EDL_0000037	nominal_mention	"front"	libya_latimes__1000-01-01__timeline:10545-10549	1.0
:Entity_EDL_0000037	link	NIL000000020
:Entity_EDL_0000038	type	Weapon
:Entity_EDL_0000038	nominal_mention	"missiles"	libya_cnn__1000-01-01__timeline:4990-4997	1.0
:Entity_EDL_0000038	link	NIL000000021
:Entity_EDL_0000039	type	Vehicle
:Entity_EDL_0000039	canonical_mention	"warships"	libya_latimes__1000-01-01__timeline:3222-3229	1.0
:Entity_EDL_0000039	nominal_mention	"warships"	libya_latimes__1000-01-01__timeline:3222-3229	1.0
:Entity_EDL_0000039	link	NIL000000022
:Entity_EDL_0000040	type	Person
:Entity_EDL_0000040	canonical_mention	"militias"	libya_guardian__1000-01-01__timeline:149-156	1.0
:Entity_EDL_0000040	nominal_mention	"militias"	libya_guardian__1000-01-01__timeline:149-156	1.0
:Entity_EDL_0000040	link	NIL000000023
:Entity_EDL_0000041	type	Person
:Entity_EDL_0000041	canonical_mention	"delegation"	libya_xinhua__1000-01-01__timeline:2306-2315	1.0
:Entity_EDL_0000041	nominal_mention	"delegation"	libya_xinhua__1000-01-01__timeline:2306-2315	1.0
:Entity_EDL_0000041	link	NIL000000024
:Entity_EDL_0000042	type	GeopoliticalEntity
:Entity_EDL_0000042	nominal_mention	"country"	libya_cnn__1000-01-01__timeline:7072-7078	1.0
:Entity_EDL_0000042	link	NIL000000025
:Entity_EDL_0000043	type	GeopoliticalEntity
:Entity_EDL_0000043	nominal_mention	"city"	libya_aljazeera__1000-01-01__timeline:1020-1023	1.0
:Entity_EDL_0000043	link	NIL000000026
:Entity_EDL_0000044	type	Person
:Entity_EDL_0000044	pronominal_mention	"his"	libya_guardian__1000-01-01__timeline:2150-2152	1.0
:Entity_EDL_0000044	link	NIL000000027
:Entity_EDL_0000045	type	Location
:Entity_EDL_0000045	canonical_mention	"areas"	libya_xinhua__1000-01-01__timeline:2083-2087	1.0
:Entity_EDL_0000045	nominal_mention	"areas"	libya_xinhua__1000-01-01__timeline:2083-2087	1.0
:Entity_EDL_0000045	link	NIL000000028
:Entity_EDL_0000046	type	Person
:Entity_EDL_0000046	canonical_mention	"Mohammed"	libya_xinhua__1000-01-01__timeline:3556-3563	1.0
:Entity_EDL_0000046	mention	"Mohammed"	libya_xinhua__1000-01-01__timeline:3556-3563	1.0
:Entity_EDL_0000046	link	30003253
:Entity_EDL_0000047	type	Weapon
:Entity_EDL_0000047	canonical_mention	"artillery"	libya_latimes__1000-01-01__timeline:6158-6166	1.0
:Entity_EDL_0000047	nominal_mention	"artillery"	libya_latimes__1000-01-01__timeline:6158-6166	1.0
:Entity_EDL_0000047	link	NIL000000029
:Entity_EDL_0000048	type	Person
:Entity_EDL_0000048	canonical_mention	"Muammar Gaddafi"	libya_aljazeera__1000-01-01__timeline:7047-7061	1.0
:Entity_EDL_0000048	mention	"Muammar Gaddafi"	libya_aljazeera__1000-01-01__timeline:7047-7061	1.0
:Entity_EDL_0000048	link	NIL000000030
:Entity_EDL_0000049	type	GeopoliticalEntity
:Entity_EDL_0000049	canonical_mention	"country"	libya_xinhua__1000-01-01__timeline:776-782	1.0
:Entity_EDL_0000049	nominal_mention	"country"	libya_xinhua__1000-01-01__timeline:776-782	1.0
:Entity_EDL_0000049	link	NIL000000031
:Entity_EDL_0000050	type	Person
:Entity_EDL_0000050	canonical_mention	"Hannibal"	libya_xinhua__1000-01-01__timeline:3543-3550	1.0
:Entity_EDL_0000050	mention	"Hannibal"	libya_xinhua__1000-01-01__timeline:3543-3550	1.0
:Entity_EDL_0000050	link	NIL000000032
:Entity_EDL_0000051	type	Facility
:Entity_EDL_0000051	canonical_mention	"port"	libya_reuters__1000-01-01__timeline:3798-3801	1.0
:Entity_EDL_0000051	nominal_mention	"port"	libya_reuters__1000-01-01__timeline:3798-3801	1.0
:Entity_EDL_0000051	link	NIL000000033
:Entity_EDL_0000052	type	GeopoliticalEntity
:Entity_EDL_0000052	nominal_mention	"capital"	libya_afp__1000-01-01__timeline:3611-3617	1.0
:Entity_EDL_0000052	link	NIL000000034
:Entity_EDL_0000053	type	Organization
:Entity_EDL_0000053	canonical_mention	"commission"	libya_aljazeera__1000-01-01__timeline:8120-8129	1.0
:Entity_EDL_0000053	nominal_mention	"commission"	libya_aljazeera__1000-01-01__timeline:8120-8129	1.0
:Entity_EDL_0000053	link	NIL000000035
:Entity_EDL_0000054	type	Person
:Entity_EDL_0000054	canonical_mention	"leaders"	libya_aljazeera__1000-01-01__timeline:4004-4010	1.0
:Entity_EDL_0000054	nominal_mention	"leaders"	libya_aljazeera__1000-01-01__timeline:4004-4010	1.0
:Entity_EDL_0000054	link	NIL000000036
:Entity_EDL_0000055	type	Organization
:Entity_EDL_0000055	nominal_mention	"military"	libya_cnn__1000-01-01__timeline:11017-11024	0.000
:Entity_EDL_0000055	link	NIL000000037
:Entity_EDL_0000056	type	Person
:Entity_EDL_0000056	nominal_mention	"Rebels"	libya_guardian__1000-01-01__timeline:1449-1454	1.0
:Entity_EDL_0000056	link	NIL000000038
:Entity_EDL_0000057	type	Facility
:Entity_EDL_0000057	canonical_mention	"station"	libya_aljazeera__1000-01-01__timeline:200-206	1.0
:Entity_EDL_0000057	nominal_mention	"station"	libya_aljazeera__1000-01-01__timeline:200-206	1.0
:Entity_EDL_0000057	link	NIL000000039
:Entity_EDL_0000058	type	Organization
:Entity_EDL_0000058	canonical_mention	"its"	libya_afp__1000-01-01__timeline:1547-1549	1.0
:Entity_EDL_0000058	pronominal_mention	"its"	libya_afp__1000-01-01__timeline:1547-1549	1.0
:Entity_EDL_0000058	link	NIL000000040
:Entity_EDL_0000059	type	GeopoliticalEntity
:Entity_EDL_0000059	canonical_mention	"Paris"	libya_aljazeera__1000-01-01__timeline:4031-4035	1.0
:Entity_EDL_0000059	mention	"Paris"	libya_aljazeera__1000-01-01__timeline:4031-4035	1.0
:Entity_EDL_0000059	link	2988507
:Entity_EDL_0000060	type	Person
:Entity_EDL_0000060	canonical_mention	"David Cameron"	libya_reuters__1000-01-01__timeline:2745-2757	1.0
:Entity_EDL_0000060	mention	"David Cameron"	libya_reuters__1000-01-01__timeline:2745-2757	1.0
:Entity_EDL_0000060	link	30005047
:Entity_EDL_0000061	type	Person
:Entity_EDL_0000061	canonical_mention	"Khamis"	libya_reuters__1000-01-01__timeline:4688-4693	1.0
:Entity_EDL_0000061	mention	"Khamis"	libya_reuters__1000-01-01__timeline:4688-4693	1.0
:Entity_EDL_0000061	link	30004519
:Entity_EDL_0000062	type	GeopoliticalEntity
:Entity_EDL_0000062	canonical_mention	"its"	libya_latimes__1000-01-01__timeline:4853-4855	1.0
:Entity_EDL_0000062	pronominal_mention	"its"	libya_latimes__1000-01-01__timeline:4853-4855	1.0
:Entity_EDL_0000062	link	NIL000000041
:Entity_EDL_0000063	type	GeopoliticalEntity
:Entity_EDL_0000063	pronominal_mention	"its"	libya_cnn__1000-01-01__timeline:5613-5615	1.0
:Entity_EDL_0000063	link	NIL000000042
:Entity_EDL_0000064	type	Person
:Entity_EDL_0000064	pronominal_mention	"15"	libya_cnn__1000-01-01__timeline:6021-6022	1.0
:Entity_EDL_0000064	link	NIL000000043
:Entity_EDL_0000065	type	Person
:Entity_EDL_0000065	nominal_mention	"son"	libya_latimes__1000-01-01__timeline:11455-11457	1.0
:Entity_EDL_0000065	link	NIL000000044
:Entity_EDL_0000066	type	Organization
:Entity_EDL_0000066	canonical_mention	"office"	libya_cnn__1000-01-01__timeline:8287-8292	1.0
:Entity_EDL_0000066	nominal_mention	"office"	libya_cnn__1000-01-01__timeline:8287-8292	1.0
:Entity_EDL_0000066	link	NIL000000045
:Entity_EDL_0000067	type	Person
:Entity_EDL_0000067	pronominal_mention	"their"	libya_afp__1000-01-01__timeline:3016-3020	1.0
:Entity_EDL_0000067	link	NIL000000046
:Entity_EDL_0000068	type	GeopoliticalEntity
:Entity_EDL_0000068	canonical_mention	"alliance"	libya_latimes__1000-01-01__timeline:7610-7617	1.0
:Entity_EDL_0000068	nominal_mention	"alliance"	libya_latimes__1000-01-01__timeline:7610-7617	1.0
:Entity_EDL_0000068	link	NIL000000047
:Entity_EDL_0000069	type	Weapon
:Entity_EDL_0000069	pronominal_mention	"Many"	libya_aljazeera__1000-01-01__timeline:2515-2518	1.0
:Entity_EDL_0000069	link	NIL000000048
:Entity_EDL_0000070	type	Person
:Entity_EDL_0000070	nominal_mention	"son"	libya_afp__1000-01-01__timeline:735-737	1.0
:Entity_EDL_0000070	link	NIL000000049
:Entity_EDL_0000071	type	Person
:Entity_EDL_0000071	nominal_mention	"son"	libya_guardian__1000-01-01__timeline:4907-4909	1.0
:Entity_EDL_0000071	link	NIL000000050
:Entity_EDL_0000072	type	Person
:Entity_EDL_0000072	nominal_mention	"Rebels"	libya_latimes__1000-01-01__timeline:2504-2509	1.0
:Entity_EDL_0000072	link	NIL000000051
:Entity_EDL_0000073	type	Person
:Entity_EDL_0000073	canonical_mention	"Saadi"	libya_reuters__1000-01-01__timeline:2480-2484	1.0
:Entity_EDL_0000073	mention	"Saadi"	libya_reuters__1000-01-01__timeline:2480-2484	1.0
:Entity_EDL_0000073	link	NIL000000052
:Entity_EDL_0000074	type	Person
:Entity_EDL_0000074	pronominal_mention	"his"	libya_reuters__1000-01-01__timeline:2160-2162	1.0
:Entity_EDL_0000074	link	NIL000000053
:Entity_EDL_0000075	type	Vehicle
:Entity_EDL_0000075	canonical_mention	"submarines"	libya_cnn__1000-01-01__timeline:5041-5050	1.0
:Entity_EDL_0000075	nominal_mention	"submarines"	libya_cnn__1000-01-01__timeline:5041-5050	1.0
:Entity_EDL_0000075	link	NIL000000054
:Entity_EDL_0000076	type	Person
:Entity_EDL_0000076	mention	"Moammar Gadhafi"	libya_cnn__1000-01-01__timeline:8991-9005	1.0
:Entity_EDL_0000076	link	NIL000000055
:Entity_EDL_0000077	type	Person
:Entity_EDL_0000077	canonical_mention	"their"	libya_cnn__1000-01-01__timeline:1872-1876	1.0
:Entity_EDL_0000077	pronominal_mention	"their"	libya_cnn__1000-01-01__timeline:1872-1876	1.0
:Entity_EDL_0000077	link	NIL000000056
:Entity_EDL_0000078	type	Person
:Entity_EDL_0000078	nominal_mention	"people"	libya_latimes__1000-01-01__timeline:8171-8176	1.0
:Entity_EDL_0000078	link	NIL000000057
:Entity_EDL_0000079	type	Weapon
:Entity_EDL_0000079	nominal_mention	"arms and ammunition"	libya_cnn__1000-01-01__timeline:3532-3550	0.000
:Entity_EDL_0000079	link	NIL000000058
:Entity_EDL_0000080	type	GeopoliticalEntity
:Entity_EDL_0000080	nominal_mention	"city"	libya_latimes__1000-01-01__timeline:7583-7586	0.000
:Entity_EDL_0000080	link	NIL000000059
:Entity_EDL_0000081	type	GeopoliticalEntity
:Entity_EDL_0000081	nominal_mention	"country"	libya_cnn__1000-01-01__timeline:2265-2271	1.0
:Entity_EDL_0000081	link	NIL000000060
:Entity_EDL_0000082	type	Person
:Entity_EDL_0000082	canonical_mention	"each other"	libya_cnn__1000-01-01__timeline:692-701	1.0
:Entity_EDL_0000082	pronominal_mention	"each other"	libya_cnn__1000-01-01__timeline:692-701	1.0
:Entity_EDL_0000082	link	NIL000000061
:Entity_EDL_0000083	type	GeopoliticalEntity
:Entity_EDL_0000083	nominal_mention	"city"	libya_cnn__1000-01-01__timeline:8319-8322	1.0
:Entity_EDL_0000083	link	NIL000000062
:Entity_EDL_0000084	type	Person
:Entity_EDL_0000084	nominal_mention	"supporters"	libya_aljazeera__1000-01-01__timeline:6388-6397	1.0
:Entity_EDL_0000084	link	NIL000000063
:Entity_EDL_0000085	type	Person
:Entity_EDL_0000085	canonical_mention	"workers"	libya_latimes__1000-01-01__timeline:6382-6388	1.0
:Entity_EDL_0000085	nominal_mention	"workers"	libya_latimes__1000-01-01__timeline:6382-6388	1.0
:Entity_EDL_0000085	link	NIL000000064
:Entity_EDL_0000086	type	Person
:Entity_EDL_0000086	pronominal_mention	"his"	libya_aljazeera__1000-01-01__timeline:4556-4558	1.0
:Entity_EDL_0000086	link	NIL000000065
:Entity_EDL_0000087	type	Vehicle
:Entity_EDL_0000087	canonical_mention	"planes"	libya_latimes__1000-01-01__timeline:5092-5097	1.0
:Entity_EDL_0000087	nominal_mention	"planes"	libya_latimes__1000-01-01__timeline:5092-5097	1.0
:Entity_EDL_0000087	link	NIL000000066
:Entity_EDL_0000088	type	Person
:Entity_EDL_0000088	canonical_mention	"leaders"	libya_guardian__1000-01-01__timeline:2050-2056	1.0
:Entity_EDL_0000088	nominal_mention	"leaders"	libya_guardian__1000-01-01__timeline:2050-2056	1.0
:Entity_EDL_0000088	link	NIL000000067
:Entity_EDL_0000089	type	GeopoliticalEntity
:Entity_EDL_0000089	canonical_mention	"town"	libya_reuters__1000-01-01__timeline:1939-1942	1.0
:Entity_EDL_0000089	nominal_mention	"town"	libya_reuters__1000-01-01__timeline:1939-1942	1.0
:Entity_EDL_0000089	link	NIL000000068
:Entity_EDL_0000090	type	Person
:Entity_EDL_0000090	nominal_mention	"people"	libya_cnn__1000-01-01__timeline:5253-5258	1.0
:Entity_EDL_0000090	link	NIL000000069
:Entity_EDL_0000091	type	Organization
:Entity_EDL_0000091	canonical_mention	"Arab League"	libya_latimes__1000-01-01__timeline:2295-2305	1.0
:Entity_EDL_0000091	mention	"Arab League"	libya_latimes__1000-01-01__timeline:2295-2305	1.0
:Entity_EDL_0000091	link	20000138
:Entity_EDL_0000092	type	Vehicle
:Entity_EDL_0000092	canonical_mention	"tanks"	libya_latimes__1000-01-01__timeline:5115-5119	1.0
:Entity_EDL_0000092	nominal_mention	"tanks"	libya_latimes__1000-01-01__timeline:5115-5119	1.0
:Entity_EDL_0000092	link	NIL000000070
:Entity_EDL_0000093	type	Person
:Entity_EDL_0000093	nominal_mention	"son"	libya_reuters__1000-01-01__timeline:4684-4686	1.0
:Entity_EDL_0000093	link	NIL000000071
:Entity_EDL_0000094	type	Person
:Entity_EDL_0000094	mention	"Nato"	libya_guardian__1000-01-01__timeline:3320-3323	1.0
:Entity_EDL_0000094	link	20000153
:Entity_EDL_0000095	type	Facility
:Entity_EDL_0000095	canonical_mention	"Port Brega"	libya_latimes__1000-01-01__timeline:1391-1400	1.0
:Entity_EDL_0000095	mention	"Port Brega"	libya_latimes__1000-01-01__timeline:1391-1400	1.0
:Entity_EDL_0000095	link	2215208
:Entity_EDL_0000096	type	Organization
:Entity_EDL_0000096	nominal_mention	"military"	libya_latimes__1000-01-01__timeline:6777-6784	1.0
:Entity_EDL_0000096	link	NIL000000072
:Entity_EDL_0000097	type	Person
:Entity_EDL_0000097	nominal_mention	"forces"	libya_latimes__1000-01-01__timeline:548-553	0.000
:Entity_EDL_0000097	link	NIL000000073
:Entity_EDL_0000098	type	Person
:Entity_EDL_0000098	canonical_mention	"nationals"	libya_xinhua__1000-01-01__timeline:687-695	1.0
:Entity_EDL_0000098	nominal_mention	"nationals"	libya_xinhua__1000-01-01__timeline:687-695	1.0
:Entity_EDL_0000098	link	NIL000000074
:Entity_EDL_0000099	type	Person
:Entity_EDL_0000099	nominal_mention	"Protesters"	libya_xinhua__1000-01-01__timeline:134-143	1.0
:Entity_EDL_0000099	link	NIL000000075
:Entity_EDL_0000100	type	Facility
:Entity_EDL_0000100	canonical_mention	"home"	libya_latimes__1000-01-01__timeline:8255-8258	1.0
:Entity_EDL_0000100	nominal_mention	"home"	libya_latimes__1000-01-01__timeline:8255-8258	1.0
:Entity_EDL_0000100	link	NIL000000076
:Entity_EDL_0000101	type	Organization
:Entity_EDL_0000101	canonical_mention	"cells"	libya_aljazeera__1000-01-01__timeline:2417-2421	1.0
:Entity_EDL_0000101	nominal_mention	"cells"	libya_aljazeera__1000-01-01__timeline:2417-2421	1.0
:Entity_EDL_0000101	link	NIL000000077
:Entity_EDL_0000102	type	GeopoliticalEntity
:Entity_EDL_0000102	canonical_mention	"Abu Dhabi"	libya_afp__1000-01-01__timeline:1037-1045	1.0
:Entity_EDL_0000102	mention	"Abu Dhabi"	libya_afp__1000-01-01__timeline:1037-1045	1.0
:Entity_EDL_0000102	link	292968
:Entity_EDL_0000103	type	Vehicle
:Entity_EDL_0000103	nominal_mention	"ship"	libya_latimes__1000-01-01__timeline:6360-6363	1.0
:Entity_EDL_0000103	link	NIL000000078
:Entity_EDL_0000104	type	Person
:Entity_EDL_0000104	nominal_mention	"civilians"	libya_cnn__1000-01-01__timeline:2593-2601	1.0
:Entity_EDL_0000104	link	NIL000000079
:Entity_EDL_0000105	type	Person
:Entity_EDL_0000105	mention	"Gaddafi"	libya_aljazeera__1000-01-01__timeline:7955-7961	1.0
:Entity_EDL_0000105	link	NIL000000080
:Entity_EDL_0000106	type	Organization
:Entity_EDL_0000106	nominal_mention	"regime"	libya_cnn__1000-01-01__timeline:5213-5218	1.0
:Entity_EDL_0000106	link	NIL000000081
:Entity_EDL_0000107	type	Person
:Entity_EDL_0000107	canonical_mention	"civilians"	libya_afp__1000-01-01__timeline:1586-1594	1.0
:Entity_EDL_0000107	nominal_mention	"civilians"	libya_afp__1000-01-01__timeline:1586-1594	1.0
:Entity_EDL_0000107	link	NIL000000082
:Entity_EDL_0000108	type	GeopoliticalEntity
:Entity_EDL_0000108	canonical_mention	"there"	libya_reuters__1000-01-01__timeline:2498-2502	1.0
:Entity_EDL_0000108	nominal_mention	"there"	libya_reuters__1000-01-01__timeline:2498-2502	1.0
:Entity_EDL_0000108	link	NIL000000083
:Entity_EDL_0000109	type	Facility
:Entity_EDL_0000109	canonical_mention	"facility"	libya_afp__1000-01-01__timeline:1891-1898	1.0
:Entity_EDL_0000109	nominal_mention	"facility"	libya_afp__1000-01-01__timeline:1891-1898	1.0
:Entity_EDL_0000109	link	NIL000000084
:Entity_EDL_0000110	type	Facility
:Entity_EDL_0000110	canonical_mention	"port"	libya_guardian__1000-01-01__timeline:3791-3794	1.0
:Entity_EDL_0000110	nominal_mention	"port"	libya_guardian__1000-01-01__timeline:3791-3794	1.0
:Entity_EDL_0000110	link	NIL000000085
:Entity_EDL_0000111	type	Vehicle
:Entity_EDL_0000111	canonical_mention	"tanks"	libya_aljazeera__1000-01-01__timeline:3667-3671	1.0
:Entity_EDL_0000111	nominal_mention	"tanks"	libya_aljazeera__1000-01-01__timeline:3667-3671	1.0
:Entity_EDL_0000111	link	NIL000000086
:Entity_EDL_0000112	type	Organization
:Entity_EDL_0000112	nominal_mention	"regime"	libya_afp__1000-01-01__timeline:3636-3641	1.0
:Entity_EDL_0000112	link	NIL000000087
:Entity_EDL_0000113	type	Vehicle
:Entity_EDL_0000113	canonical_mention	"limousine"	libya_cnn__1000-01-01__timeline:881-889	1.0
:Entity_EDL_0000113	nominal_mention	"limousine"	libya_cnn__1000-01-01__timeline:881-889	1.0
:Entity_EDL_0000113	link	NIL000000088
:Entity_EDL_0000114	type	Person
:Entity_EDL_0000114	mention	"Gaddafi"	libya_guardian__1000-01-01__timeline:5570-5576	1.0
:Entity_EDL_0000114	link	NIL000000089
:Entity_EDL_0000115	type	Organization
:Entity_EDL_0000115	canonical_mention	"station"	libya_reuters__1000-01-01__timeline:3391-3397	1.0
:Entity_EDL_0000115	nominal_mention	"station"	libya_reuters__1000-01-01__timeline:3391-3397	1.0
:Entity_EDL_0000115	link	NIL000000090
:Entity_EDL_0000116	type	Person
:Entity_EDL_0000116	pronominal_mention	"who"	libya_guardian__1000-01-01__timeline:5612-5614	1.0
:Entity_EDL_0000116	link	NIL000000091
:Entity_EDL_0000117	type	Person
:Entity_EDL_0000117	canonical_mention	"Muammar Gaddafi"	libya_guardian__1000-01-01__timeline:4766-4780	1.0
:Entity_EDL_0000117	mention	"Muammar Gaddafi"	libya_guardian__1000-01-01__timeline:4766-4780	1.0
:Entity_EDL_0000117	link	NIL000000092
:Entity_EDL_0000118	type	Person
:Entity_EDL_0000118	canonical_mention	"Mustafa Abdel Jalil"	libya_reuters__1000-01-01__timeline:2576-2594	1.0
:Entity_EDL_0000118	mention	"Mustafa Abdel Jalil"	libya_reuters__1000-01-01__timeline:2576-2594	1.0
:Entity_EDL_0000118	link	NIL000000093
:Entity_EDL_0000119	type	Organization
:Entity_EDL_0000119	canonical_mention	"International Contact Group on Libya"	libya_afp__1000-01-01__timeline:991-1026	1.0
:Entity_EDL_0000119	mention	"International Contact Group on Libya"	libya_afp__1000-01-01__timeline:991-1026	1.0
:Entity_EDL_0000119	link	NIL000000094
:Entity_EDL_0000120	type	GeopoliticalEntity
:Entity_EDL_0000120	mention	"Brega"	libya_afp__1000-01-01__timeline:1962-1966	1.0
:Entity_EDL_0000120	link	2215210
:Entity_EDL_0000121	type	GeopoliticalEntity
:Entity_EDL_0000121	canonical_mention	"Italy"	libya_guardian__1000-01-01__timeline:3819-3823	1.0
:Entity_EDL_0000121	mention	"Italy"	libya_guardian__1000-01-01__timeline:3819-3823	1.0
:Entity_EDL_0000121	link	3175395
:Entity_EDL_0000122	type	Person
:Entity_EDL_0000122	nominal_mention	"fighters"	libya_guardian__1000-01-01__timeline:4812-4819	1.0
:Entity_EDL_0000122	link	NIL000000095
:Entity_EDL_0000123	type	Person
:Entity_EDL_0000123	nominal_mention	"forces"	libya_reuters__1000-01-01__timeline:4422-4427	1.0
:Entity_EDL_0000123	link	NIL000000096
:Entity_EDL_0000124	type	GeopoliticalEntity
:Entity_EDL_0000124	canonical_mention	"New York"	libya_cnn__1000-01-01__timeline:9475-9482	1.0
:Entity_EDL_0000124	mention	"New York"	libya_cnn__1000-01-01__timeline:9475-9482	1.0
:Entity_EDL_0000124	link	5128638
:Entity_EDL_0000125	type	Vehicle
:Entity_EDL_0000125	canonical_mention	"tanks"	libya_afp__1000-01-01__timeline:1921-1925	1.0
:Entity_EDL_0000125	nominal_mention	"tanks"	libya_afp__1000-01-01__timeline:1921-1925	1.0
:Entity_EDL_0000125	link	NIL000000097
:Entity_EDL_0000126	type	Person
:Entity_EDL_0000126	nominal_mention	"forces"	libya_guardian__1000-01-01__timeline:988-993	1.0
:Entity_EDL_0000126	link	NIL000000098
:Entity_EDL_0000127	type	GeopoliticalEntity
:Entity_EDL_0000127	canonical_mention	"Niger"	libya_xinhua__1000-01-01__timeline:3728-3732	1.0
:Entity_EDL_0000127	mention	"Niger"	libya_xinhua__1000-01-01__timeline:3728-3732	1.0
:Entity_EDL_0000127	link	2440476
:Entity_EDL_0000128	type	Person
:Entity_EDL_0000128	nominal_mention	"son"	libya_afp__1000-01-01__timeline:2231-2233	1.0
:Entity_EDL_0000128	link	NIL000000099
:Entity_EDL_0000130	type	GeopoliticalEntity
:Entity_EDL_0000130	canonical_mention	"Zawiya"	libya_latimes__1000-01-01__timeline:931-936	1.0
:Entity_EDL_0000130	mention	"Zawiya"	libya_latimes__1000-01-01__timeline:931-936	1.0
:Entity_EDL_0000130	link	2216885
:Entity_EDL_0000131	type	Vehicle
:Entity_EDL_0000131	canonical_mention	"vehicles"	libya_afp__1000-01-01__timeline:1910-1917	1.0
:Entity_EDL_0000131	nominal_mention	"vehicles"	libya_afp__1000-01-01__timeline:1910-1917	1.0
:Entity_EDL_0000131	link	NIL000000101
:Entity_EDL_0000132	type	Facility
:Entity_EDL_0000132	canonical_mention	"plant"	libya_aljazeera__1000-01-01__timeline:1827-1831	1.0
:Entity_EDL_0000132	nominal_mention	"plant"	libya_aljazeera__1000-01-01__timeline:1827-1831	1.0
:Entity_EDL_0000132	link	NIL000000102
:Entity_EDL_0000133	type	GeopoliticalEntity
:Entity_EDL_0000133	canonical_mention	"Qawalish"	libya_latimes__1000-01-01__timeline:9580-9587	1.0
:Entity_EDL_0000133	mention	"Qawalish"	libya_latimes__1000-01-01__timeline:9580-9587	1.0
:Entity_EDL_0000133	link	NIL000000103
:Entity_EDL_0000134	type	GeopoliticalEntity
:Entity_EDL_0000134	nominal_mention	"town"	libya_afp__1000-01-01__timeline:1498-1501	1.0
:Entity_EDL_0000134	link	NIL000000104
:Entity_EDL_0000135	type	Person
:Entity_EDL_0000135	canonical_mention	"120"	libya_aljazeera__1000-01-01__timeline:2092-2094	1.0
:Entity_EDL_0000135	pronominal_mention	"120"	libya_aljazeera__1000-01-01__timeline:2092-2094	1.0
:Entity_EDL_0000135	link	NIL000000105
:Entity_EDL_0000136	type	Person
:Entity_EDL_0000136	nominal_mention	"forces"	libya_xinhua__1000-01-01__timeline:4240-4245	1.0
:Entity_EDL_0000136	link	NIL000000106
:Entity_EDL_0000137	type	Person
:Entity_EDL_0000137	canonical_mention	"Hundreds"	libya_aljazeera__1000-01-01__timeline:163-170	1.0
:Entity_EDL_0000137	pronominal_mention	"Hundreds"	libya_aljazeera__1000-01-01__timeline:163-170	1.0
:Entity_EDL_0000137	link	NIL000000107
:Entity_EDL_0000138	type	Person
:Entity_EDL_0000138	canonical_mention	"crowd"	libya_aljazeera__1000-01-01__timeline:4589-4593	1.0
:Entity_EDL_0000138	nominal_mention	"crowd"	libya_aljazeera__1000-01-01__timeline:4589-4593	1.0
:Entity_EDL_0000138	link	NIL000000108
:Entity_EDL_0000139	type	GeopoliticalEntity
:Entity_EDL_0000139	canonical_mention	"town"	libya_guardian__1000-01-01__timeline:1929-1932	1.0
:Entity_EDL_0000139	nominal_mention	"town"	libya_guardian__1000-01-01__timeline:1929-1932	1.0
:Entity_EDL_0000139	link	NIL000000109
:Entity_EDL_0000140	type	Person
:Entity_EDL_0000140	canonical_mention	"Abdel-Rahim Keeb"	libya_latimes__1000-01-01__timeline:13252-13267	1.0
:Entity_EDL_0000140	mention	"Abdel-Rahim Keeb"	libya_latimes__1000-01-01__timeline:13252-13267	1.0
:Entity_EDL_0000140	link	NIL000000110
:Entity_EDL_0000141	type	GeopoliticalEntity
:Entity_EDL_0000141	canonical_mention	"Paris"	libya_guardian__1000-01-01__timeline:2077-2081	1.0
:Entity_EDL_0000141	mention	"Paris"	libya_guardian__1000-01-01__timeline:2077-2081	1.0
:Entity_EDL_0000141	link	2988507
:Entity_EDL_0000142	type	Person
:Entity_EDL_0000142	canonical_mention	"Mustafa Abdul Jalil"	libya_cnn__1000-01-01__timeline:3429-3447	1.0
:Entity_EDL_0000142	mention	"Mustafa Abdul Jalil"	libya_cnn__1000-01-01__timeline:3429-3447	1.0
:Entity_EDL_0000142	link	NIL000000111
:Entity_EDL_0000143	type	Person
:Entity_EDL_0000143	nominal_mention	"son"	libya_guardian__1000-01-01__timeline:2466-2468	1.0
:Entity_EDL_0000143	link	NIL000000112
:Entity_EDL_0000145	type	Organization
:Entity_EDL_0000145	nominal_mention	"military"	libya_latimes__1000-01-01__timeline:1501-1508	0.000
:Entity_EDL_0000145	link	NIL000000114
:Entity_EDL_0000146	type	Weapon
:Entity_EDL_0000146	nominal_mention	"missiles"	libya_latimes__1000-01-01__timeline:3257-3264	1.0
:Entity_EDL_0000146	link	NIL000000115
:Entity_EDL_0000147	type	Vehicle
:Entity_EDL_0000147	canonical_mention	"warplanes"	libya_latimes__1000-01-01__timeline:4857-4865	1.0
:Entity_EDL_0000147	nominal_mention	"warplanes"	libya_latimes__1000-01-01__timeline:4857-4865	1.0
:Entity_EDL_0000147	link	NIL000000116
:Entity_EDL_0000148	type	Person
:Entity_EDL_0000148	canonical_mention	"Hosni Mubarak"	libya_cnn__1000-01-01__timeline:59-71	1.0
:Entity_EDL_0000148	mention	"Hosni Mubarak"	libya_cnn__1000-01-01__timeline:59-71	1.0
:Entity_EDL_0000148	link	NIL000000117
:Entity_EDL_0000149	type	GeopoliticalEntity
:Entity_EDL_0000149	nominal_mention	"country"	libya_cnn__1000-01-01__timeline:1835-1841	1.0
:Entity_EDL_0000149	link	NIL000000118
:Entity_EDL_0000150	type	Person
:Entity_EDL_0000150	pronominal_mention	"his"	libya_aljazeera__1000-01-01__timeline:4104-4106	1.0
:Entity_EDL_0000150	link	NIL000000119
:Entity_EDL_0000151	type	Person
:Entity_EDL_0000151	canonical_mention	"circle"	libya_aljazeera__1000-01-01__timeline:8225-8230	1.0
:Entity_EDL_0000151	nominal_mention	"circle"	libya_aljazeera__1000-01-01__timeline:8225-8230	1.0
:Entity_EDL_0000151	link	NIL000000120
:Entity_EDL_0000152	type	Person
:Entity_EDL_0000152	pronominal_mention	"she"	libya_cnn__1000-01-01__timeline:8028-8030	1.0
:Entity_EDL_0000152	link	NIL000000121
:Entity_EDL_0000154	type	GeopoliticalEntity
:Entity_EDL_0000154	nominal_mention	"city"	libya_latimes__1000-01-01__timeline:3994-3997	1.0
:Entity_EDL_0000154	link	NIL000000123
:Entity_EDL_0000155	type	Person
:Entity_EDL_0000155	pronominal_mention	"He"	libya_guardian__1000-01-01__timeline:6182-6183	1.0
:Entity_EDL_0000155	link	NIL000000124
:Entity_EDL_0000156	type	Weapon
:Entity_EDL_0000156	canonical_mention	"mortars"	libya_aljazeera__1000-01-01__timeline:1121-1127	1.0
:Entity_EDL_0000156	nominal_mention	"mortars"	libya_aljazeera__1000-01-01__timeline:1121-1127	1.0
:Entity_EDL_0000156	link	NIL000000125
:Entity_EDL_0000157	type	Person
:Entity_EDL_0000157	nominal_mention	"forces"	libya_latimes__1000-01-01__timeline:12321-12326	1.0
:Entity_EDL_0000157	link	NIL000000126
:Entity_EDL_0000158	type	GeopoliticalEntity
:Entity_EDL_0000158	canonical_mention	"countries"	libya_xinhua__1000-01-01__timeline:653-661	1.0
:Entity_EDL_0000158	nominal_mention	"countries"	libya_xinhua__1000-01-01__timeline:653-661	1.0
:Entity_EDL_0000158	link	NIL000000127
:Entity_EDL_0000159	type	Person
:Entity_EDL_0000159	canonical_mention	"leaders"	libya_reuters__1000-01-01__timeline:2060-2066	1.0
:Entity_EDL_0000159	nominal_mention	"leaders"	libya_reuters__1000-01-01__timeline:2060-2066	1.0
:Entity_EDL_0000159	link	NIL000000128
:Entity_EDL_0000160	type	GeopoliticalEntity
:Entity_EDL_0000160	nominal_mention	"hometown"	libya_guardian__1000-01-01__timeline:4830-4837	1.0
:Entity_EDL_0000160	link	NIL000000129
:Entity_EDL_0000161	type	Person
:Entity_EDL_0000161	nominal_mention	"leader"	libya_latimes__1000-01-01__timeline:7422-7427	1.0
:Entity_EDL_0000161	link	NIL000000130
:Entity_EDL_0000162	type	Facility
:Entity_EDL_0000162	canonical_mention	"refinery"	libya_aljazeera__1000-01-01__timeline:1791-1798	1.0
:Entity_EDL_0000162	nominal_mention	"refinery"	libya_aljazeera__1000-01-01__timeline:1791-1798	1.0
:Entity_EDL_0000162	link	NIL000000131
:Entity_EDL_0000163	type	GeopoliticalEntity
:Entity_EDL_0000163	canonical_mention	"Libyans"	libya_reuters__1000-01-01__timeline:1569-1575	1.0
:Entity_EDL_0000163	nominal_mention	"Libyans"	libya_reuters__1000-01-01__timeline:1569-1575	1.0
:Entity_EDL_0000163	link	NIL000000132
:Entity_EDL_0000164	type	Person
:Entity_EDL_0000164	nominal_mention	"civilian"	libya_afp__1000-01-01__timeline:2719-2726	1.0
:Entity_EDL_0000164	link	NIL000000133
:Entity_EDL_0000165	type	Vehicle
:Entity_EDL_0000165	canonical_mention	"ships"	libya_cnn__1000-01-01__timeline:5031-5035	1.0
:Entity_EDL_0000165	nominal_mention	"ships"	libya_cnn__1000-01-01__timeline:5031-5035	1.0
:Entity_EDL_0000165	link	NIL000000134
:Entity_EDL_0000166	type	Person
:Entity_EDL_0000166	pronominal_mention	"her"	libya_cnn__1000-01-01__timeline:6192-6194	1.0
:Entity_EDL_0000166	link	NIL000000135
:Entity_EDL_0000167	type	Person
:Entity_EDL_0000167	nominal_mention	"rebels"	libya_cnn__1000-01-01__timeline:11654-11659	1.0
:Entity_EDL_0000167	link	NIL000000136
:Entity_EDL_0000168	type	GeopoliticalEntity
:Entity_EDL_0000168	nominal_mention	"neighborhood"	libya_latimes__1000-01-01__timeline:8013-8024	1.0
:Entity_EDL_0000168	link	NIL000000137
:Entity_EDL_0000169	type	Person
:Entity_EDL_0000169	canonical_mention	"30"	libya_aljazeera__1000-01-01__timeline:2080-2081	1.0
:Entity_EDL_0000169	pronominal_mention	"30"	libya_aljazeera__1000-01-01__timeline:2080-2081	1.0
:Entity_EDL_0000169	link	NIL000000138
:Entity_EDL_0000170	type	Person
:Entity_EDL_0000170	nominal_mention	"son"	libya_reuters__1000-01-01__timeline:2476-2478	1.0
:Entity_EDL_0000170	link	NIL000000139
:Entity_EDL_0000171	type	Facility
:Entity_EDL_0000171	canonical_mention	"checkpoint"	libya_cnn__1000-01-01__timeline:5982-5991	1.0
:Entity_EDL_0000171	nominal_mention	"checkpoint"	libya_cnn__1000-01-01__timeline:5982-5991	1.0
:Entity_EDL_0000171	link	NIL000000140
:Entity_EDL_0000172	type	Person
:Entity_EDL_0000172	nominal_mention	"insurgent"	libya_afp__1000-01-01__timeline:2081-2089	1.0
:Entity_EDL_0000172	link	NIL000000141
:Entity_EDL_0000173	type	Person
:Entity_EDL_0000173	nominal_mention	"demonstrators"	libya_latimes__1000-01-01__timeline:1105-1117	1.0
:Entity_EDL_0000173	link	NIL000000142
:Entity_EDL_0000174	type	GeopoliticalEntity
:Entity_EDL_0000174	mention	"Port Brega"	libya_latimes__1000-01-01__timeline:5074-5083	1.0
:Entity_EDL_0000174	link	2215208
:Entity_EDL_0000175	type	Person
:Entity_EDL_0000175	nominal_mention	"rebels"	libya_afp__1000-01-01__timeline:3239-3244	1.0
:Entity_EDL_0000175	link	NIL000000143
:Entity_EDL_0000176	type	Person
:Entity_EDL_0000176	canonical_mention	"people"	libya_cnn__1000-01-01__timeline:676-681	1.0
:Entity_EDL_0000176	nominal_mention	"people"	libya_cnn__1000-01-01__timeline:676-681	1.0
:Entity_EDL_0000176	link	NIL000000144
:Entity_EDL_0000177	type	GeopoliticalEntity
:Entity_EDL_0000177	nominal_mention	"country"	libya_cnn__1000-01-01__timeline:8545-8551	1.0
:Entity_EDL_0000177	link	NIL000000145
:Entity_EDL_0000178	type	FAC
:Entity_EDL_0000178	canonical_mention	"symbols"	libya_reuters__1000-01-01__timeline:1748-1754	1.0
:Entity_EDL_0000178	nominal_mention	"symbols"	libya_reuters__1000-01-01__timeline:1748-1754	1.0
:Entity_EDL_0000178	link	NIL000000146
:Entity_EDL_0000179	type	Person
:Entity_EDL_0000179	canonical_mention	"200"	libya_cnn__1000-01-01__timeline:1139-1141	1.0
:Entity_EDL_0000179	pronominal_mention	"200"	libya_cnn__1000-01-01__timeline:1139-1141	1.0
:Entity_EDL_0000179	link	NIL000000147
:Entity_EDL_0000180	type	Person
:Entity_EDL_0000180	canonical_mention	"Mahmoud Jibril"	libya_aljazeera__1000-01-01__timeline:4206-4219	1.0
:Entity_EDL_0000180	mention	"Mahmoud Jibril"	libya_aljazeera__1000-01-01__timeline:4206-4219	1.0
:Entity_EDL_0000180	link	NIL000000148
:Entity_EDL_0000181	type	Person
:Entity_EDL_0000181	nominal_mention	"forces"	libya_latimes__1000-01-01__timeline:1348-1353	1.0
:Entity_EDL_0000181	link	NIL000000149
:Entity_EDL_0000182	type	Person
:Entity_EDL_0000182	nominal_mention	"demonstrators"	libya_cnn__1000-01-01__timeline:1812-1824	1.0
:Entity_EDL_0000182	link	NIL000000150
:Entity_EDL_0000183	type	GeopoliticalEntity
:Entity_EDL_0000183	nominal_mention	"capital"	libya_aljazeera__1000-01-01__timeline:2141-2147	1.0
:Entity_EDL_0000183	link	NIL000000151
:Entity_EDL_0000184	type	GeopoliticalEntity
:Entity_EDL_0000184	nominal_mention	"country"	libya_cnn__1000-01-01__timeline:12064-12070	1.0
:Entity_EDL_0000184	link	NIL000000152
:Entity_EDL_0000185	type	Person
:Entity_EDL_0000185	nominal_mention	"Rebels"	libya_latimes__1000-01-01__timeline:918-923	1.0
:Entity_EDL_0000185	link	NIL000000153
:Entity_EDL_0000186	type	Location
:Entity_EDL_0000186	canonical_mention	"West"	libya_afp__1000-01-01__timeline:2137-2140	1.0
:Entity_EDL_0000186	mention	"West"	libya_afp__1000-01-01__timeline:2137-2140	1.0
:Entity_EDL_0000186	link	9408659
:Entity_EDL_0000187	type	Person
:Entity_EDL_0000187	nominal_mention	"troops"	libya_xinhua__1000-01-01__timeline:1469-1474	0.000
:Entity_EDL_0000187	link	NIL000000154
:Entity_EDL_0000188	type	Organization
:Entity_EDL_0000188	nominal_mention	"regime"	libya_latimes__1000-01-01__timeline:9603-9608	1.0
:Entity_EDL_0000188	link	NIL000000155
:Entity_EDL_0000189	type	Person
:Entity_EDL_0000189	nominal_mention	"Rebels"	libya_xinhua__1000-01-01__timeline:3196-3201	1.0
:Entity_EDL_0000189	link	NIL000000156
:Entity_EDL_0000190	type	Person
:Entity_EDL_0000190	nominal_mention	"fighters"	libya_reuters__1000-01-01__timeline:4950-4957	1.0
:Entity_EDL_0000190	link	NIL000000157
:Entity_EDL_0000191	type	GeopoliticalEntity
:Entity_EDL_0000191	canonical_mention	"destination"	libya_cnn__1000-01-01__timeline:9514-9524	1.0
:Entity_EDL_0000191	nominal_mention	"destination"	libya_cnn__1000-01-01__timeline:9514-9524	1.0
:Entity_EDL_0000191	link	NIL000000158
:Entity_EDL_0000192	type	Facility
:Entity_EDL_0000192	nominal_mention	"compound"	libya_reuters__1000-01-01__timeline:1713-1720	1.0
:Entity_EDL_0000192	link	NIL000000159
:Entity_EDL_0000193	type	Person
:Entity_EDL_0000193	mention	"Hillary Rodham Clinton"	libya_latimes__1000-01-01__timeline:9727-9748	1.0
:Entity_EDL_0000193	link	NIL000000160
:Entity_EDL_0000194	type	Person
:Entity_EDL_0000194	nominal_mention	"rebels"	libya_latimes__1000-01-01__timeline:5860-5865	0.000
:Entity_EDL_0000194	link	NIL000000161
:Entity_EDL_0000195	type	Person
:Entity_EDL_0000195	nominal_mention	"fighters"	libya_latimes__1000-01-01__timeline:10084-10091	0.000
:Entity_EDL_0000195	link	NIL000000162
:Entity_EDL_0000196	type	GeopoliticalEntity
:Entity_EDL_0000196	canonical_mention	"Britain"	libya_latimes__1000-01-01__timeline:2313-2319	1.0
:Entity_EDL_0000196	mention	"Britain"	libya_latimes__1000-01-01__timeline:2313-2319	1.0
:Entity_EDL_0000196	link	2635167
:Entity_EDL_0000197	type	Location
:Entity_EDL_0000197	canonical_mention	"frontier"	libya_reuters__1000-01-01__timeline:1969-1976	1.0
:Entity_EDL_0000197	nominal_mention	"frontier"	libya_reuters__1000-01-01__timeline:1969-1976	1.0
:Entity_EDL_0000197	link	NIL000000163
:Entity_EDL_0000198	type	Person
:Entity_EDL_0000198	nominal_mention	"they"	libya_latimes__1000-01-01__timeline:9528-9531	1.0
:Entity_EDL_0000198	link	NIL000000164
:Entity_EDL_0000199	type	Person
:Entity_EDL_0000199	canonical_mention	"fighters"	libya_afp__1000-01-01__timeline:2091-2098	1.0
:Entity_EDL_0000199	nominal_mention	"fighters"	libya_afp__1000-01-01__timeline:2091-2098	1.0
:Entity_EDL_0000199	link	NIL000000165
:Entity_EDL_0000200	type	Person
:Entity_EDL_0000200	nominal_mention	"forces"	libya_cnn__1000-01-01__timeline:2124-2129	0.000
:Entity_EDL_0000200	link	NIL000000166
:Entity_EDL_0000201	type	GeopoliticalEntity
:Entity_EDL_0000201	canonical_mention	"capital"	libya_afp__1000-01-01__timeline:3262-3268	1.0
:Entity_EDL_0000201	nominal_mention	"capital"	libya_afp__1000-01-01__timeline:3262-3268	1.0
:Entity_EDL_0000201	link	NIL000000167
:Entity_EDL_0000202	type	Person
:Entity_EDL_0000202	canonical_mention	"forces"	libya_reuters__1000-01-01__timeline:221-226	1.0
:Entity_EDL_0000202	nominal_mention	"forces"	libya_reuters__1000-01-01__timeline:221-226	1.0
:Entity_EDL_0000202	link	NIL000000168
:Entity_EDL_0000203	type	Person
:Entity_EDL_0000203	canonical_mention	"throngs"	libya_latimes__1000-01-01__timeline:7785-7791	1.0
:Entity_EDL_0000203	nominal_mention	"throngs"	libya_latimes__1000-01-01__timeline:7785-7791	1.0
:Entity_EDL_0000203	link	NIL000000169
:Entity_EDL_0000204	type	Person
:Entity_EDL_0000204	mention	"Mutassim"	libya_guardian__1000-01-01__timeline:4911-4918	1.0
:Entity_EDL_0000204	link	NIL000000170
:Entity_EDL_0000205	type	GeopoliticalEntity
:Entity_EDL_0000205	pronominal_mention	"we"	libya_aljazeera__1000-01-01__timeline:8086-8087	1.0
:Entity_EDL_0000205	link	NIL000000171
:Entity_EDL_0000206	type	Facility
:Entity_EDL_0000206	canonical_mention	"house"	libya_xinhua__1000-01-01__timeline:2484-2488	1.0
:Entity_EDL_0000206	nominal_mention	"house"	libya_xinhua__1000-01-01__timeline:2484-2488	1.0
:Entity_EDL_0000206	link	NIL000000172
:Entity_EDL_0000207	type	Person
:Entity_EDL_0000207	canonical_mention	"Aisha Gaddafi"	libya_guardian__1000-01-01__timeline:1879-1891	1.0
:Entity_EDL_0000207	mention	"Aisha Gaddafi"	libya_guardian__1000-01-01__timeline:1879-1891	1.0
:Entity_EDL_0000207	link	NIL000000173
:Entity_EDL_0000208	type	GeopoliticalEntity
:Entity_EDL_0000208	nominal_mention	"town"	libya_xinhua__1000-01-01__timeline:4275-4278	1.0
:Entity_EDL_0000208	link	NIL000000174
:Entity_EDL_0000209	type	Facility
:Entity_EDL_0000209	nominal_mention	"compound"	libya_guardian__1000-01-01__timeline:1703-1710	1.0
:Entity_EDL_0000209	link	NIL000000175
:Entity_EDL_0000210	type	GeopoliticalEntity
:Entity_EDL_0000210	nominal_mention	"hometown"	libya_latimes__1000-01-01__timeline:12828-12835	1.0
:Entity_EDL_0000210	link	NIL000000176
:Entity_EDL_0000211	type	Person
:Entity_EDL_0000211	nominal_mention	"rebels"	libya_afp__1000-01-01__timeline:2275-2280	1.0
:Entity_EDL_0000211	link	NIL000000177
:Entity_EDL_0000212	type	Person
:Entity_EDL_0000212	nominal_mention	"forces"	libya_latimes__1000-01-01__timeline:9568-9573	1.0
:Entity_EDL_0000212	link	NIL000000178
:Entity_EDL_0000213	type	Person
:Entity_EDL_0000213	pronominal_mention	"his"	libya_aljazeera__1000-01-01__timeline:8033-8035	1.0
:Entity_EDL_0000213	link	NIL000000179
:Entity_EDL_0000214	type	Person
:Entity_EDL_0000214	nominal_mention	"civilians"	libya_cnn__1000-01-01__timeline:7510-7518	1.0
:Entity_EDL_0000214	link	NIL000000180
:Entity_EDL_0000215	type	Person
:Entity_EDL_0000215	nominal_mention	"forces"	libya_cnn__1000-01-01__timeline:1027-1032	0.000
:Entity_EDL_0000215	link	NIL000000181
:Entity_EDL_0000216	type	GeopoliticalEntity
:Entity_EDL_0000216	nominal_mention	"city"	libya_latimes__1000-01-01__timeline:6415-6418	1.0
:Entity_EDL_0000216	link	NIL000000182
:Entity_EDL_0000217	type	Person
:Entity_EDL_0000217	canonical_mention	"Fethi Tarbel"	libya_guardian__1000-01-01__timeline:47-58	1.0
:Entity_EDL_0000217	mention	"Fethi Tarbel"	libya_guardian__1000-01-01__timeline:47-58	1.0
:Entity_EDL_0000217	link	NIL000000183
:Entity_EDL_0000218	type	Organization
:Entity_EDL_0000218	nominal_mention	"regime"	libya_latimes__1000-01-01__timeline:10868-10873	1.0
:Entity_EDL_0000218	link	NIL000000184
:Entity_EDL_0000219	type	Person
:Entity_EDL_0000219	canonical_mention	"Mahmoud Jibril"	libya_guardian__1000-01-01__timeline:2275-2288	1.0
:Entity_EDL_0000219	mention	"Mahmoud Jibril"	libya_guardian__1000-01-01__timeline:2275-2288	1.0
:Entity_EDL_0000219	link	NIL000000185
:Entity_EDL_0000220	type	Facility
:Entity_EDL_0000220	canonical_mention	"house"	libya_reuters__1000-01-01__timeline:1124-1128	1.0
:Entity_EDL_0000220	nominal_mention	"house"	libya_reuters__1000-01-01__timeline:1124-1128	1.0
:Entity_EDL_0000220	link	NIL000000186
:Entity_EDL_0000221	type	Person
:Entity_EDL_0000221	canonical_mention	"Hilary Clinton"	libya_reuters__1000-01-01__timeline:4817-4830	1.0
:Entity_EDL_0000221	mention	"Hilary Clinton"	libya_reuters__1000-01-01__timeline:4817-4830	1.0
:Entity_EDL_0000221	link	NIL000000187
:Entity_EDL_0000222	type	Person
:Entity_EDL_0000222	canonical_mention	"wife"	libya_cnn__1000-01-01__timeline:12028-12031	1.0
:Entity_EDL_0000222	nominal_mention	"wife"	libya_cnn__1000-01-01__timeline:12028-12031	1.0
:Entity_EDL_0000222	link	NIL000000188
:Entity_EDL_0000223	type	GeopoliticalEntity
:Entity_EDL_0000223	nominal_mention	"cities"	libya_xinhua__1000-01-01__timeline:46-51	1.0
:Entity_EDL_0000223	link	NIL000000189
:Entity_EDL_0000224	type	Person
:Entity_EDL_0000224	pronominal_mention	"he"	libya_guardian__1000-01-01__timeline:4104-4105	1.0
:Entity_EDL_0000224	link	NIL000000190
:Entity_EDL_0000225	type	Person
:Entity_EDL_0000225	canonical_mention	"rulers"	libya_guardian__1000-01-01__timeline:2032-2037	1.0
:Entity_EDL_0000225	nominal_mention	"rulers"	libya_guardian__1000-01-01__timeline:2032-2037	1.0
:Entity_EDL_0000225	link	NIL000000191
:Entity_EDL_0000226	type	Person
:Entity_EDL_0000226	canonical_mention	"fighters"	libya_aljazeera__1000-01-01__timeline:2688-2695	1.0
:Entity_EDL_0000226	nominal_mention	"fighters"	libya_aljazeera__1000-01-01__timeline:2688-2695	1.0
:Entity_EDL_0000226	link	NIL000000192
:Entity_EDL_0000227	type	Person
:Entity_EDL_0000227	canonical_mention	"230"	libya_latimes__1000-01-01__timeline:677-679	1.0
:Entity_EDL_0000227	nominal_mention	"230"	libya_latimes__1000-01-01__timeline:677-679	1.0
:Entity_EDL_0000227	link	NIL000000193
:Entity_EDL_0000228	type	GeopoliticalEntity
:Entity_EDL_0000228	canonical_mention	"cities"	libya_cnn__1000-01-01__timeline:1447-1452	1.0
:Entity_EDL_0000228	nominal_mention	"cities"	libya_cnn__1000-01-01__timeline:1447-1452	1.0
:Entity_EDL_0000228	link	NIL000000194
:Entity_EDL_0000229	type	Person
:Entity_EDL_0000229	canonical_mention	"Aisha"	libya_reuters__1000-01-01__timeline:1846-1850	1.0
:Entity_EDL_0000229	mention	"Aisha"	libya_reuters__1000-01-01__timeline:1846-1850	1.0
:Entity_EDL_0000229	link	NIL000000195
:Entity_EDL_0000230	type	Person
:Entity_EDL_0000230	canonical_mention	"protesters"	libya_aljazeera__1000-01-01__timeline:226-235	1.0
:Entity_EDL_0000230	nominal_mention	"protesters"	libya_aljazeera__1000-01-01__timeline:226-235	1.0
:Entity_EDL_0000230	link	NIL000000196
:Entity_EDL_0000231	type	Person
:Entity_EDL_0000231	canonical_mention	"demonstrators"	libya_cnn__1000-01-01__timeline:362-374	1.0
:Entity_EDL_0000231	nominal_mention	"demonstrators"	libya_cnn__1000-01-01__timeline:362-374	1.0
:Entity_EDL_0000231	link	NIL000000197
:Entity_EDL_0000232	type	Person
:Entity_EDL_0000232	canonical_mention	"rulers"	libya_aljazeera__1000-01-01__timeline:3986-3991	1.0
:Entity_EDL_0000232	nominal_mention	"rulers"	libya_aljazeera__1000-01-01__timeline:3986-3991	1.0
:Entity_EDL_0000232	link	NIL000000198
:Entity_EDL_0000233	type	Person
:Entity_EDL_0000233	canonical_mention	"ambassador"	libya_aljazeera__1000-01-01__timeline:5276-5285	1.0
:Entity_EDL_0000233	nominal_mention	"ambassador"	libya_aljazeera__1000-01-01__timeline:5276-5285	1.0
:Entity_EDL_0000233	link	NIL000000199
:Entity_EDL_0000234	type	GeopoliticalEntity
:Entity_EDL_0000234	canonical_mention	"Ubari"	libya_aljazeera__1000-01-01__timeline:8631-8635	1.0
:Entity_EDL_0000234	mention	"Ubari"	libya_aljazeera__1000-01-01__timeline:8631-8635	1.0
:Entity_EDL_0000234	link	2219235
:Entity_EDL_0000235	type	Person
:Entity_EDL_0000235	nominal_mention	"leader"	libya_latimes__1000-01-01__timeline:12808-12813	1.0
:Entity_EDL_0000235	link	NIL000000200
:Entity_EDL_0000236	type	Person
:Entity_EDL_0000236	pronominal_mention	"her"	libya_cnn__1000-01-01__timeline:6064-6066	1.0
:Entity_EDL_0000236	link	NIL000000201
:Entity_EDL_0000237	type	Facility
:Entity_EDL_0000237	canonical_mention	"hotel"	libya_cnn__1000-01-01__timeline:5905-5909	1.0
:Entity_EDL_0000237	nominal_mention	"hotel"	libya_cnn__1000-01-01__timeline:5905-5909	1.0
:Entity_EDL_0000237	link	NIL000000202
:Entity_EDL_0000238	type	Person
:Entity_EDL_0000238	canonical_mention	"commanders"	libya_latimes__1000-01-01__timeline:10488-10497	1.0
:Entity_EDL_0000238	nominal_mention	"commanders"	libya_latimes__1000-01-01__timeline:10488-10497	1.0
:Entity_EDL_0000238	link	NIL000000203
:Entity_EDL_0000239	type	FAC
:Entity_EDL_0000239	canonical_mention	"symbols"	libya_latimes__1000-01-01__timeline:11889-11895	1.0
:Entity_EDL_0000239	nominal_mention	"symbols"	libya_latimes__1000-01-01__timeline:11889-11895	1.0
:Entity_EDL_0000239	link	NIL000000204
:Entity_EDL_0000240	type	GeopoliticalEntity
:Entity_EDL_0000240	mention	"France"	libya_latimes__1000-01-01__timeline:2325-2330	1.0
:Entity_EDL_0000240	link	3017382
:Entity_EDL_0000241	type	Organization
:Entity_EDL_0000241	canonical_mention	"ICC"	libya_guardian__1000-01-01__timeline:1258-1260	1.0
:Entity_EDL_0000241	mention	"ICC"	libya_guardian__1000-01-01__timeline:1258-1260	1.0
:Entity_EDL_0000241	link	20000115
:Entity_EDL_0000242	type	Person
:Entity_EDL_0000242	nominal_mention	"forces"	libya_latimes__1000-01-01__timeline:6107-6112	1.0
:Entity_EDL_0000242	link	NIL000000205
:Entity_EDL_0000243	type	Person
:Entity_EDL_0000243	canonical_mention	"minister"	libya_cnn__1000-01-01__timeline:2013-2020	1.0
:Entity_EDL_0000243	nominal_mention	"minister"	libya_cnn__1000-01-01__timeline:2013-2020	1.0
:Entity_EDL_0000243	link	NIL000000206
:Entity_EDL_0000244	type	Person
:Entity_EDL_0000244	nominal_mention	"Fighters"	libya_latimes__1000-01-01__timeline:12689-12696	1.0
:Entity_EDL_0000244	link	NIL000000207
:Entity_EDL_0000245	type	Person
:Entity_EDL_0000245	nominal_mention	"rebels"	libya_latimes__1000-01-01__timeline:5002-5007	1.0
:Entity_EDL_0000245	link	NIL000000208
:Entity_EDL_0000246	type	Person
:Entity_EDL_0000246	canonical_mention	"soldiers"	libya_cnn__1000-01-01__timeline:1368-1375	1.0
:Entity_EDL_0000246	nominal_mention	"soldiers"	libya_cnn__1000-01-01__timeline:1368-1375	1.0
:Entity_EDL_0000246	link	NIL000000209
:Entity_EDL_0000247	type	FAC
:Entity_EDL_0000247	canonical_mention	"symbols"	libya_guardian__1000-01-01__timeline:1738-1744	1.0
:Entity_EDL_0000247	nominal_mention	"symbols"	libya_guardian__1000-01-01__timeline:1738-1744	1.0
:Entity_EDL_0000247	link	NIL000000210
:Entity_EDL_0000248	type	Person
:Entity_EDL_0000248	canonical_mention	"board"	libya_cnn__1000-01-01__timeline:10065-10069	1.0
:Entity_EDL_0000248	nominal_mention	"board"	libya_cnn__1000-01-01__timeline:10065-10069	1.0
:Entity_EDL_0000248	link	NIL000000211
:Entity_EDL_0000249	type	Person
:Entity_EDL_0000249	canonical_mention	"children"	libya_latimes__1000-01-01__timeline:8196-8203	1.0
:Entity_EDL_0000249	nominal_mention	"children"	libya_latimes__1000-01-01__timeline:8196-8203	1.0
:Entity_EDL_0000249	link	NIL000000212
:Entity_EDL_0000250	type	Person
:Entity_EDL_0000250	nominal_mention	"Rebels"	libya_reuters__1000-01-01__timeline:1459-1464	1.0
:Entity_EDL_0000250	link	NIL000000213
:Entity_EDL_0000251	type	GeopoliticalEntity
:Entity_EDL_0000251	canonical_mention	"nation"	libya_cnn__1000-01-01__timeline:7539-7544	1.0
:Entity_EDL_0000251	nominal_mention	"nation"	libya_cnn__1000-01-01__timeline:7539-7544	1.0
:Entity_EDL_0000251	link	NIL000000214
:Entity_EDL_0000252	type	Person
:Entity_EDL_0000252	nominal_mention	"loyalists"	libya_xinhua__1000-01-01__timeline:738-746	1.0
:Entity_EDL_0000252	link	NIL000000215
:Entity_EDL_0000253	type	Person
:Entity_EDL_0000253	canonical_mention	"10,000"	libya_aljazeera__1000-01-01__timeline:4604-4609	1.0
:Entity_EDL_0000253	pronominal_mention	"10,000"	libya_aljazeera__1000-01-01__timeline:4604-4609	1.0
:Entity_EDL_0000253	link	NIL000000216
:Entity_EDL_0000254	type	Person
:Entity_EDL_0000254	nominal_mention	"people"	libya_cnn__1000-01-01__timeline:7215-7220	1.0
:Entity_EDL_0000254	link	NIL000000217
:Entity_EDL_0000255	type	Person
:Entity_EDL_0000255	canonical_mention	"staff"	libya_cnn__1000-01-01__timeline:6180-6184	1.0
:Entity_EDL_0000255	nominal_mention	"staff"	libya_cnn__1000-01-01__timeline:6180-6184	1.0
:Entity_EDL_0000255	link	NIL000000218
:Entity_EDL_0000256	type	Person
:Entity_EDL_0000256	canonical_mention	"chief"	libya_latimes__1000-01-01__timeline:10245-10249	1.0
:Entity_EDL_0000256	nominal_mention	"chief"	libya_latimes__1000-01-01__timeline:10245-10249	1.0
:Entity_EDL_0000256	link	NIL000000219
:Entity_EDL_0000257	type	Person
:Entity_EDL_0000257	pronominal_mention	"he"	libya_aljazeera__1000-01-01__timeline:6096-6097	1.0
:Entity_EDL_0000257	link	NIL000000220
:Entity_EDL_0000258	type	Person
:Entity_EDL_0000258	canonical_mention	"traitors"	libya_cnn__1000-01-01__timeline:10496-10503	1.0
:Entity_EDL_0000258	nominal_mention	"traitors"	libya_cnn__1000-01-01__timeline:10496-10503	1.0
:Entity_EDL_0000258	link	NIL000000221
:Entity_EDL_0000259	type	Organization
:Entity_EDL_0000259	canonical_mention	"Justice"	libya_cnn__1000-01-01__timeline:3412-3418	1.0
:Entity_EDL_0000259	mention	"Justice"	libya_cnn__1000-01-01__timeline:3412-3418	1.0
:Entity_EDL_0000259	link	NIL000000222
:Entity_EDL_0000260	type	GeopoliticalEntity
:Entity_EDL_0000260	nominal_mention	"stronghold"	libya_latimes__1000-01-01__timeline:6455-6464	1.0
:Entity_EDL_0000260	link	NIL000000223
:Entity_EDL_0000261	type	GeopoliticalEntity
:Entity_EDL_0000261	nominal_mention	"city"	libya_guardian__1000-01-01__timeline:194-197	1.0
:Entity_EDL_0000261	link	NIL000000224
:Entity_EDL_0000262	type	Person
:Entity_EDL_0000262	nominal_mention	"rebels"	libya_xinhua__1000-01-01__timeline:752-757	1.0
:Entity_EDL_0000262	link	NIL000000225
:Entity_EDL_0000263	type	GeopoliticalEntity
:Entity_EDL_0000263	canonical_mention	"London"	libya_latimes__1000-01-01__timeline:3766-3771	1.0
:Entity_EDL_0000263	mention	"London"	libya_latimes__1000-01-01__timeline:3766-3771	1.0
:Entity_EDL_0000263	link	2643743
:Entity_EDL_0000264	type	Vehicle
:Entity_EDL_0000264	canonical_mention	"tugboat"	libya_aljazeera__1000-01-01__timeline:2592-2598	1.0
:Entity_EDL_0000264	nominal_mention	"tugboat"	libya_aljazeera__1000-01-01__timeline:2592-2598	1.0
:Entity_EDL_0000264	link	NIL000000226
:Entity_EDL_0000265	type	Facility
:Entity_EDL_0000265	canonical_mention	"clinic"	libya_reuters__1000-01-01__timeline:1920-1925	1.0
:Entity_EDL_0000265	nominal_mention	"clinic"	libya_reuters__1000-01-01__timeline:1920-1925	1.0
:Entity_EDL_0000265	link	NIL000000227
:Entity_EDL_0000266	type	Person
:Entity_EDL_0000266	canonical_mention	"Aisha"	libya_guardian__1000-01-01__timeline:1836-1840	1.0
:Entity_EDL_0000266	mention	"Aisha"	libya_guardian__1000-01-01__timeline:1836-1840	1.0
:Entity_EDL_0000266	link	NIL000000228
:Entity_EDL_0000267	type	GeopoliticalEntity
:Entity_EDL_0000267	nominal_mention	"there"	libya_aljazeera__1000-01-01__timeline:4448-4452	1.0
:Entity_EDL_0000267	link	NIL000000229
:Entity_EDL_0000268	type	GeopoliticalEntity
:Entity_EDL_0000268	mention	"United Kingdom"	libya_cnn__1000-01-01__timeline:6653-6666	1.0
:Entity_EDL_0000268	link	2635167
:Entity_EDL_0000269	type	Location
:Entity_EDL_0000269	canonical_mention	"downtown"	libya_aljazeera__1000-01-01__timeline:1129-1136	1.0
:Entity_EDL_0000269	nominal_mention	"downtown"	libya_aljazeera__1000-01-01__timeline:1129-1136	1.0
:Entity_EDL_0000269	link	NIL000000230
:Entity_EDL_0000270	type	Person
:Entity_EDL_0000270	nominal_mention	"minister"	libya_cnn__1000-01-01__timeline:8468-8475	1.0
:Entity_EDL_0000270	link	NIL000000231
:Entity_EDL_0000271	type	Person
:Entity_EDL_0000271	canonical_mention	"Hassan Ibrahim"	libya_aljazeera__1000-01-01__timeline:2218-2231	1.0
:Entity_EDL_0000271	mention	"Hassan Ibrahim"	libya_aljazeera__1000-01-01__timeline:2218-2231	1.0
:Entity_EDL_0000271	link	NIL000000232
:Entity_EDL_0000272	type	GeopoliticalEntity
:Entity_EDL_0000272	canonical_mention	"Libyans"	libya_guardian__1000-01-01__timeline:1559-1565	1.0
:Entity_EDL_0000272	mention	"Libyans"	libya_guardian__1000-01-01__timeline:1559-1565	1.0
:Entity_EDL_0000272	link	NIL000000233
:Entity_EDL_0000274	type	Person
:Entity_EDL_0000274	nominal_mention	"Rebels"	libya_xinhua__1000-01-01__timeline:3345-3350	1.0
:Entity_EDL_0000274	link	NIL000000234
:Entity_EDL_0000275	type	Person
:Entity_EDL_0000275	pronominal_mention	"he"	libya_reuters__1000-01-01__timeline:4111-4112	1.0
:Entity_EDL_0000275	link	NIL000000235
:Entity_EDL_0000276	type	Person
:Entity_EDL_0000276	nominal_mention	"rebels"	libya_afp__1000-01-01__timeline:1415-1420	0.000
:Entity_EDL_0000276	link	NIL000000236
:Entity_EDL_0000277	type	Facility
:Entity_EDL_0000277	canonical_mention	"house"	libya_cnn__1000-01-01__timeline:7688-7692	1.0
:Entity_EDL_0000277	nominal_mention	"house"	libya_cnn__1000-01-01__timeline:7688-7692	1.0
:Entity_EDL_0000277	link	NIL000000237
:Entity_EDL_0000278	type	Person
:Entity_EDL_0000278	canonical_mention	"aide"	libya_aljazeera__1000-01-01__timeline:7740-7743	1.0
:Entity_EDL_0000278	nominal_mention	"aide"	libya_aljazeera__1000-01-01__timeline:7740-7743	1.0
:Entity_EDL_0000278	link	NIL000000238
:Entity_EDL_0000279	type	Person
:Entity_EDL_0000279	canonical_mention	"Hillary Clinton"	libya_guardian__1000-01-01__timeline:4636-4650	1.0
:Entity_EDL_0000279	mention	"Hillary Clinton"	libya_guardian__1000-01-01__timeline:4636-4650	1.0
:Entity_EDL_0000279	link	NIL000000239
:Entity_EDL_0000280	type	GeopoliticalEntity
:Entity_EDL_0000280	canonical_mention	"coalition"	libya_cnn__1000-01-01__timeline:7489-7497	1.0
:Entity_EDL_0000280	nominal_mention	"coalition"	libya_cnn__1000-01-01__timeline:7489-7497	1.0
:Entity_EDL_0000280	link	NIL000000240
:Entity_EDL_0000281	type	Organization
:Entity_EDL_0000281	canonical_mention	"station"	libya_guardian__1000-01-01__timeline:3384-3390	1.0
:Entity_EDL_0000281	nominal_mention	"station"	libya_guardian__1000-01-01__timeline:3384-3390	1.0
:Entity_EDL_0000281	link	NIL000000241
:Entity_EDL_0000282	type	GeopoliticalEntity
:Entity_EDL_0000282	canonical_mention	"there"	libya_guardian__1000-01-01__timeline:2488-2492	1.0
:Entity_EDL_0000282	nominal_mention	"there"	libya_guardian__1000-01-01__timeline:2488-2492	1.0
:Entity_EDL_0000282	link	NIL000000242
:Entity_EDL_0000283	type	Person
:Entity_EDL_0000283	pronominal_mention	"he"	libya_cnn__1000-01-01__timeline:8508-8509	1.0
:Entity_EDL_0000283	link	NIL000000243
:Entity_EDL_0000284	type	GeopoliticalEntity
:Entity_EDL_0000284	canonical_mention	"Tunis"	libya_afp__1000-01-01__timeline:3069-3073	1.0
:Entity_EDL_0000284	mention	"Tunis"	libya_afp__1000-01-01__timeline:3069-3073	1.0
:Entity_EDL_0000284	link	2464470
:Entity_EDL_0000285	type	Person
:Entity_EDL_0000285	canonical_mention	"minister"	libya_afp__1000-01-01__timeline:3134-3141	1.0
:Entity_EDL_0000285	nominal_mention	"minister"	libya_afp__1000-01-01__timeline:3134-3141	1.0
:Entity_EDL_0000285	link	NIL000000244
:Entity_EDL_0000286	type	Person
:Entity_EDL_0000286	canonical_mention	"David Cameron"	libya_aljazeera__1000-01-01__timeline:4701-4713	1.0
:Entity_EDL_0000286	mention	"David Cameron"	libya_aljazeera__1000-01-01__timeline:4701-4713	1.0
:Entity_EDL_0000286	link	30005047
:Entity_EDL_0000287	type	GeopoliticalEntity
:Entity_EDL_0000287	nominal_mention	"city"	libya_latimes__1000-01-01__timeline:5783-5786	1.0
:Entity_EDL_0000287	link	NIL000000245
:Entity_EDL_0000288	type	Person
:Entity_EDL_0000288	nominal_mention	"forces"	libya_latimes__1000-01-01__timeline:3961-3966	0.000
:Entity_EDL_0000288	link	NIL000000246
:Entity_EDL_0000289	type	Person
:Entity_EDL_0000289	canonical_mention	"Nicolas Sarkozy"	libya_reuters__1000-01-01__timeline:2714-2728	1.0
:Entity_EDL_0000289	mention	"Nicolas Sarkozy"	libya_reuters__1000-01-01__timeline:2714-2728	1.0
:Entity_EDL_0000289	link	NIL000000247
:Entity_EDL_0000290	type	Person
:Entity_EDL_0000290	canonical_mention	"people"	libya_xinhua__1000-01-01__timeline:379-384	1.0
:Entity_EDL_0000290	nominal_mention	"people"	libya_xinhua__1000-01-01__timeline:379-384	1.0
:Entity_EDL_0000290	link	NIL000000248
:Entity_EDL_0000291	type	Facility
:Entity_EDL_0000291	canonical_mention	"Green Square"	libya_latimes__1000-01-01__timeline:7819-7830	1.0
:Entity_EDL_0000291	mention	"Green Square"	libya_latimes__1000-01-01__timeline:7819-7830	1.0
:Entity_EDL_0000291	link	NIL000000249
:Entity_EDL_0000292	type	Person
:Entity_EDL_0000292	nominal_mention	"forces"	libya_xinhua__1000-01-01__timeline:3291-3296	1.0
:Entity_EDL_0000292	link	NIL000000250
:Entity_EDL_0000293	type	Person
:Entity_EDL_0000293	nominal_mention	"protesters"	libya_cnn__1000-01-01__timeline:1068-1077	1.0
:Entity_EDL_0000293	link	NIL000000251
:Entity_EDL_0000294	type	Person
:Entity_EDL_0000294	nominal_mention	"men"	libya_cnn__1000-01-01__timeline:6434-6436	1.0
:Entity_EDL_0000294	link	NIL000000252
:Entity_EDL_0000295	type	GeopoliticalEntity
:Entity_EDL_0000295	nominal_mention	"city"	libya_latimes__1000-01-01__timeline:10978-10981	1.0
:Entity_EDL_0000295	link	NIL000000253
:Entity_EDL_0000296	type	Location
:Entity_EDL_0000296	canonical_mention	"frontier"	libya_guardian__1000-01-01__timeline:1959-1966	1.0
:Entity_EDL_0000296	nominal_mention	"frontier"	libya_guardian__1000-01-01__timeline:1959-1966	1.0
:Entity_EDL_0000296	link	NIL000000254
:Entity_EDL_0000297	type	Person
:Entity_EDL_0000297	canonical_mention	"troops"	libya_latimes__1000-01-01__timeline:5822-5827	1.0
:Entity_EDL_0000297	nominal_mention	"troops"	libya_latimes__1000-01-01__timeline:5822-5827	1.0
:Entity_EDL_0000297	link	NIL000000255
:Entity_EDL_0000298	type	Person
:Entity_EDL_0000298	nominal_mention	"forces"	libya_aljazeera__1000-01-01__timeline:6407-6412	1.0
:Entity_EDL_0000298	link	NIL000000256
:Entity_EDL_0000299	type	Person
:Entity_EDL_0000299	nominal_mention	"two"	libya_guardian__1000-01-01__timeline:1846-1848	1.0
:Entity_EDL_0000299	pronominal_mention	"two"	libya_guardian__1000-01-01__timeline:1846-1848	1.0
:Entity_EDL_0000299	link	NIL000000257
:Entity_EDL_0000300	type	Facility
:Entity_EDL_0000300	canonical_mention	"Green Square"	libya_aljazeera__1000-01-01__timeline:2932-2943	1.0
:Entity_EDL_0000300	mention	"Green Square"	libya_aljazeera__1000-01-01__timeline:2932-2943	1.0
:Entity_EDL_0000300	link	NIL000000258
:Entity_EDL_0000301	type	GeopoliticalEntity
:Entity_EDL_0000301	nominal_mention	"capital"	libya_latimes__1000-01-01__timeline:11129-11135	1.0
:Entity_EDL_0000301	link	NIL000000259
:Entity_EDL_0000302	type	Person
:Entity_EDL_0000302	nominal_mention	"Rebels"	libya_xinhua__1000-01-01__timeline:3882-3887	1.0
:Entity_EDL_0000302	link	NIL000000260
:Entity_EDL_0000303	type	Person
:Entity_EDL_0000303	canonical_mention	"18"	libya_latimes__1000-01-01__timeline:8086-8087	1.0
:Entity_EDL_0000303	pronominal_mention	"18"	libya_latimes__1000-01-01__timeline:8086-8087	1.0
:Entity_EDL_0000303	link	NIL000000261
:Entity_EDL_0000304	type	Person
:Entity_EDL_0000304	nominal_mention	"forces"	libya_reuters__1000-01-01__timeline:998-1003	1.0
:Entity_EDL_0000304	link	NIL000000262
:Entity_EDL_0000305	type	Vehicle
:Entity_EDL_0000305	canonical_mention	"submarines"	libya_xinhua__1000-01-01__timeline:2148-2157	1.0
:Entity_EDL_0000305	nominal_mention	"submarines"	libya_xinhua__1000-01-01__timeline:2148-2157	1.0
:Entity_EDL_0000305	link	NIL000000263
:Entity_EDL_0000306	type	Person
:Entity_EDL_0000306	mention	"Moussa Koussa"	libya_cnn__1000-01-01__timeline:6624-6636	1.0
:Entity_EDL_0000306	link	NIL000000264
:Entity_EDL_0000307	type	Vehicle
:Entity_EDL_0000307	canonical_mention	"flight"	libya_cnn__1000-01-01__timeline:9500-9505	1.0
:Entity_EDL_0000307	nominal_mention	"flight"	libya_cnn__1000-01-01__timeline:9500-9505	1.0
:Entity_EDL_0000307	link	NIL000000265
:Entity_EDL_0000308	type	Person
:Entity_EDL_0000308	nominal_mention	"forces"	libya_afp__1000-01-01__timeline:2106-2111	1.0
:Entity_EDL_0000308	link	NIL000000266
:Entity_EDL_0000309	type	Person
:Entity_EDL_0000309	canonical_mention	"commander"	libya_cnn__1000-01-01__timeline:9755-9763	1.0
:Entity_EDL_0000309	nominal_mention	"commander"	libya_cnn__1000-01-01__timeline:9755-9763	1.0
:Entity_EDL_0000309	link	NIL000000267
:Entity_EDL_0000310	type	Person
:Entity_EDL_0000310	canonical_mention	"militias"	libya_reuters__1000-01-01__timeline:149-156	1.0
:Entity_EDL_0000310	nominal_mention	"militias"	libya_reuters__1000-01-01__timeline:149-156	1.0
:Entity_EDL_0000310	link	NIL000000268
:Entity_EDL_0000311	type	Person
:Entity_EDL_0000311	canonical_mention	"civilians"	libya_cnn__1000-01-01__timeline:2471-2479	1.0
:Entity_EDL_0000311	nominal_mention	"civilians"	libya_cnn__1000-01-01__timeline:2471-2479	1.0
:Entity_EDL_0000311	link	NIL000000269
:Entity_EDL_0000312	type	Person
:Entity_EDL_0000312	canonical_mention	"associates"	libya_cnn__1000-01-01__timeline:3229-3238	1.0
:Entity_EDL_0000312	nominal_mention	"associates"	libya_cnn__1000-01-01__timeline:3229-3238	1.0
:Entity_EDL_0000312	link	NIL000000270
:Entity_EDL_0000313	type	Person
:Entity_EDL_0000313	pronominal_mention	"he"	libya_cnn__1000-01-01__timeline:6704-6705	1.0
:Entity_EDL_0000313	link	NIL000000271
:Entity_EDL_0000314	type	Person
:Entity_EDL_0000314	canonical_mention	"ministers"	libya_xinhua__1000-01-01__timeline:1276-1284	1.0
:Entity_EDL_0000314	nominal_mention	"ministers"	libya_xinhua__1000-01-01__timeline:1276-1284	1.0
:Entity_EDL_0000314	link	NIL000000272
:Entity_EDL_0000315	type	Person
:Entity_EDL_0000315	canonical_mention	"civilians"	libya_xinhua__1000-01-01__timeline:1867-1875	1.0
:Entity_EDL_0000315	nominal_mention	"civilians"	libya_xinhua__1000-01-01__timeline:1867-1875	1.0
:Entity_EDL_0000315	link	NIL000000273
:Entity_EDL_0000316	type	Vehicle
:Entity_EDL_0000316	nominal_mention	"aircraft carriers"	libya_xinhua__1000-01-01__timeline:2163-2179	0.000
:Entity_EDL_0000316	link	NIL000000274
:Entity_EDL_0000317	type	Person
:Entity_EDL_0000317	canonical_mention	"Forces"	libya_xinhua__1000-01-01__timeline:1962-1967	1.0
:Entity_EDL_0000317	nominal_mention	"Forces"	libya_xinhua__1000-01-01__timeline:1962-1967	1.0
:Entity_EDL_0000317	link	NIL000000275
:Entity_EDL_0000318	type	Person
:Entity_EDL_0000318	nominal_mention	"fighters"	libya_aljazeera__1000-01-01__timeline:3623-3630	1.0
:Entity_EDL_0000318	link	NIL000000276
:Entity_EDL_0000319	type	GeopoliticalEntity
:Entity_EDL_0000319	nominal_mention	"city"	libya_xinhua__1000-01-01__timeline:1577-1580	1.0
:Entity_EDL_0000319	link	NIL000000277
:Entity_EDL_0000320	type	Person
:Entity_EDL_0000320	nominal_mention	"forces"	libya_latimes__1000-01-01__timeline:10270-10275	0.000
:Entity_EDL_0000320	link	NIL000000278
:Entity_EDL_0000321	type	Person
:Entity_EDL_0000321	canonical_mention	"Saif al-Islam"	libya_reuters__1000-01-01__timeline:1317-1329	1.0
:Entity_EDL_0000321	mention	"Saif al-Islam"	libya_reuters__1000-01-01__timeline:1317-1329	1.0
:Entity_EDL_0000321	link	NIL000000279
:Entity_EDL_0000322	type	Person
:Entity_EDL_0000322	nominal_mention	"Rebels"	libya_aljazeera__1000-01-01__timeline:2919-2924	1.0
:Entity_EDL_0000322	link	NIL000000280
:Entity_EDL_0000323	type	Weapon
:Entity_EDL_0000323	canonical_mention	"bullets"	libya_cnn__1000-01-01__timeline:1397-1403	1.0
:Entity_EDL_0000323	nominal_mention	"bullets"	libya_cnn__1000-01-01__timeline:1397-1403	1.0
:Entity_EDL_0000323	link	NIL000000281
:Entity_EDL_0000324	type	Person
:Entity_EDL_0000324	canonical_mention	"they"	libya_cnn__1000-01-01__timeline:978-981	1.0
:Entity_EDL_0000324	nominal_mention	"they"	libya_cnn__1000-01-01__timeline:978-981	1.0
:Entity_EDL_0000324	link	NIL000000282
:Entity_EDL_0000325	type	Person
:Entity_EDL_0000325	canonical_mention	"forces"	libya_guardian__1000-01-01__timeline:225-230	1.0
:Entity_EDL_0000325	nominal_mention	"forces"	libya_guardian__1000-01-01__timeline:225-230	1.0
:Entity_EDL_0000325	link	NIL000000283
:Entity_EDL_0000326	type	Person
:Entity_EDL_0000326	canonical_mention	"they"	libya_aljazeera__1000-01-01__timeline:1080-1083	1.0
:Entity_EDL_0000326	nominal_mention	"they"	libya_aljazeera__1000-01-01__timeline:1080-1083	1.0
:Entity_EDL_0000326	link	NIL000000284
:Entity_EDL_0000327	type	GeopoliticalEntity
:Entity_EDL_0000327	canonical_mention	"communities"	libya_latimes__1000-01-01__timeline:8864-8874	1.0
:Entity_EDL_0000327	nominal_mention	"communities"	libya_latimes__1000-01-01__timeline:8864-8874	1.0
:Entity_EDL_0000327	link	NIL000000285
:Entity_EDL_0000328	type	Facility
:Entity_EDL_0000328	canonical_mention	"Green Square"	libya_xinhua__1000-01-01__timeline:3230-3241	1.0
:Entity_EDL_0000328	mention	"Green Square"	libya_xinhua__1000-01-01__timeline:3230-3241	1.0
:Entity_EDL_0000328	link	NIL000000286
:Entity_EDL_0000329	type	Facility
:Entity_EDL_0000329	canonical_mention	"clinic"	libya_guardian__1000-01-01__timeline:1910-1915	1.0
:Entity_EDL_0000329	nominal_mention	"clinic"	libya_guardian__1000-01-01__timeline:1910-1915	1.0
:Entity_EDL_0000329	link	NIL000000287
:Entity_EDL_0000330	type	GeopoliticalEntity
:Entity_EDL_0000330	canonical_mention	"city"	libya_aljazeera__1000-01-01__timeline:441-444	1.0
:Entity_EDL_0000330	nominal_mention	"city"	libya_aljazeera__1000-01-01__timeline:441-444	1.0
:Entity_EDL_0000330	link	NIL000000288
:Entity_EDL_0000331	type	Person
:Entity_EDL_0000331	nominal_mention	"leaders"	libya_latimes__1000-01-01__timeline:9653-9659	1.0
:Entity_EDL_0000331	link	NIL000000289
:Entity_EDL_0000332	type	Person
:Entity_EDL_0000332	nominal_mention	"police"	libya_xinhua__1000-01-01__timeline:162-167	0.000
:Entity_EDL_0000332	link	NIL000000290
:Entity_EDL_0000333	type	Organization
:Entity_EDL_0000333	canonical_mention	"Nato"	libya_guardian__1000-01-01__timeline:1089-1092	1.0
:Entity_EDL_0000333	mention	"Nato"	libya_guardian__1000-01-01__timeline:1089-1092	1.0
:Entity_EDL_0000333	link	20000153
:Entity_EDL_0000334	type	Person
:Entity_EDL_0000334	canonical_mention	"Abdul Raheem al-Keeb"	libya_guardian__1000-01-01__timeline:5874-5893	1.0
:Entity_EDL_0000334	mention	"Abdul Raheem al-Keeb"	libya_guardian__1000-01-01__timeline:5874-5893	1.0
:Entity_EDL_0000334	link	NIL000000291
:Entity_EDL_0000335	type	Person
:Entity_EDL_0000335	canonical_mention	"Hilary Clinton"	libya_aljazeera__1000-01-01__timeline:6663-6676	1.0
:Entity_EDL_0000335	mention	"Hilary Clinton"	libya_aljazeera__1000-01-01__timeline:6663-6676	1.0
:Entity_EDL_0000335	link	NIL000000292
:Entity_EDL_0000336	type	Person
:Entity_EDL_0000336	nominal_mention	"people"	libya_cnn__1000-01-01__timeline:1511-1516	1.0
:Entity_EDL_0000336	link	NIL000000293
:Entity_EDL_0000337	type	GeopoliticalEntity
:Entity_EDL_0000337	nominal_mention	"city"	libya_xinhua__1000-01-01__timeline:449-452	1.0
:Entity_EDL_0000337	link	NIL000000294
:Entity_EDL_0000338	type	Person
:Entity_EDL_0000338	canonical_mention	"ambassador"	libya_reuters__1000-01-01__timeline:3291-3300	1.0
:Entity_EDL_0000338	nominal_mention	"ambassador"	libya_reuters__1000-01-01__timeline:3291-3300	1.0
:Entity_EDL_0000338	link	NIL000000295
:Entity_EDL_0000339	type	Person
:Entity_EDL_0000339	canonical_mention	"Saadi"	libya_aljazeera__1000-01-01__timeline:4430-4434	1.0
:Entity_EDL_0000339	mention	"Saadi"	libya_aljazeera__1000-01-01__timeline:4430-4434	1.0
:Entity_EDL_0000339	link	NIL000000296
:Entity_EDL_0000340	type	Person
:Entity_EDL_0000340	nominal_mention	"they"	libya_aljazeera__1000-01-01__timeline:1293-1296	1.0
:Entity_EDL_0000340	link	NIL000000297
:Entity_EDL_0000341	type	GeopoliticalEntity
:Entity_EDL_0000341	canonical_mention	"hometown"	libya_latimes__1000-01-01__timeline:12412-12419	1.0
:Entity_EDL_0000341	nominal_mention	"hometown"	libya_latimes__1000-01-01__timeline:12412-12419	1.0
:Entity_EDL_0000341	link	NIL000000298
:Entity_EDL_0000342	type	Person
:Entity_EDL_0000342	pronominal_mention	"she"	libya_cnn__1000-01-01__timeline:8137-8139	1.0
:Entity_EDL_0000342	link	NIL000000299
:Entity_EDL_0000343	type	GeopoliticalEntity
:Entity_EDL_0000343	canonical_mention	"Cairo"	libya_afp__1000-01-01__timeline:3156-3160	1.0
:Entity_EDL_0000343	mention	"Cairo"	libya_afp__1000-01-01__timeline:3156-3160	1.0
:Entity_EDL_0000343	link	360630
:Entity_EDL_0000344	type	Person
:Entity_EDL_0000344	nominal_mention	"rebels"	libya_afp__1000-01-01__timeline:3402-3407	1.0
:Entity_EDL_0000344	link	NIL000000300
:Entity_EDL_0000345	type	Person
:Entity_EDL_0000345	nominal_mention	"fighters"	libya_latimes__1000-01-01__timeline:11032-11039	1.0
:Entity_EDL_0000345	link	NIL000000301
:Entity_EDL_0000346	type	Facility
:Entity_EDL_0000346	canonical_mention	"house"	libya_guardian__1000-01-01__timeline:1114-1118	1.0
:Entity_EDL_0000346	nominal_mention	"house"	libya_guardian__1000-01-01__timeline:1114-1118	1.0
:Entity_EDL_0000346	link	NIL000000302
:Entity_EDL_0000347	type	Person
:Entity_EDL_0000347	canonical_mention	"him"	libya_guardian__1000-01-01__timeline:5634-5636	1.0
:Entity_EDL_0000347	pronominal_mention	"him"	libya_guardian__1000-01-01__timeline:5634-5636	1.0
:Entity_EDL_0000347	link	NIL000000303
:Entity_EDL_0000348	type	Person
:Entity_EDL_0000348	canonical_mention	"Demonstrators"	libya_latimes__1000-01-01__timeline:218-230	1.0
:Entity_EDL_0000348	nominal_mention	"Demonstrators"	libya_latimes__1000-01-01__timeline:218-230	1.0
:Entity_EDL_0000348	link	NIL000000304
:Entity_EDL_0000349	type	Facility
:Entity_EDL_0000349	nominal_mention	"streets"	libya_cnn__1000-01-01__timeline:430-436	0.000
:Entity_EDL_0000349	link	NIL000000305
:Entity_EDL_0000350	type	Person
:Entity_EDL_0000350	pronominal_mention	"Her"	libya_cnn__1000-01-01__timeline:9551-9553	1.0
:Entity_EDL_0000350	link	NIL000000306
:Entity_EDL_0000351	type	Organization
:Entity_EDL_0000351	pronominal_mention	"it"	libya_afp__1000-01-01__timeline:1849-1850	1.0
:Entity_EDL_0000351	link	NIL000000307
:Entity_EDL_0000352	type	Facility
:Entity_EDL_0000352	nominal_mention	"compound"	libya_aljazeera__1000-01-01__timeline:3680-3687	1.0
:Entity_EDL_0000352	link	NIL000000308
:Entity_EDL_0000353	type	Person
:Entity_EDL_0000353	pronominal_mention	"one"	libya_cnn__1000-01-01__timeline:7725-7727	1.0
:Entity_EDL_0000353	link	NIL000000309
:Entity_EDL_0000354	type	Person
:Entity_EDL_0000354	mention	"Seif al-Islam"	libya_xinhua__1000-01-01__timeline:2681-2693	1.0
:Entity_EDL_0000354	link	NIL000000310
:Entity_EDL_0000355	type	GeopoliticalEntity
:Entity_EDL_0000355	mention	"European Union"	libya_cnn__1000-01-01__timeline:8263-8276	1.0
:Entity_EDL_0000355	link	6695072
:Entity_EDL_0000356	type	Person
:Entity_EDL_0000356	canonical_mention	"envoy"	libya_afp__1000-01-01__timeline:3056-3060	1.0
:Entity_EDL_0000356	nominal_mention	"envoy"	libya_afp__1000-01-01__timeline:3056-3060	1.0
:Entity_EDL_0000356	link	NIL000000311
:Entity_EDL_0000357	type	Person
:Entity_EDL_0000357	nominal_mention	"rebels"	libya_latimes__1000-01-01__timeline:10954-10959	1.0
:Entity_EDL_0000357	link	NIL000000312
:Entity_EDL_0000358	type	Person
:Entity_EDL_0000358	nominal_mention	"fighters"	libya_aljazeera__1000-01-01__timeline:398-405	1.0
:Entity_EDL_0000358	link	NIL000000313
:Entity_EDL_0000359	type	Person
:Entity_EDL_0000359	canonical_mention	"Nicolas Sarkozy"	libya_guardian__1000-01-01__timeline:2704-2718	1.0
:Entity_EDL_0000359	mention	"Nicolas Sarkozy"	libya_guardian__1000-01-01__timeline:2704-2718	1.0
:Entity_EDL_0000359	link	NIL000000314
:Entity_EDL_0000360	type	Person
:Entity_EDL_0000360	canonical_mention	"we"	libya_latimes__1000-01-01__timeline:5923-5924	1.0
:Entity_EDL_0000360	pronominal_mention	"we"	libya_latimes__1000-01-01__timeline:5923-5924	1.0
:Entity_EDL_0000360	link	NIL000000315
:Entity_EDL_0000361	type	Person
:Entity_EDL_0000361	canonical_mention	"your"	libya_cnn__1000-01-01__timeline:10416-10419	1.0
:Entity_EDL_0000361	pronominal_mention	"your"	libya_cnn__1000-01-01__timeline:10416-10419	1.0
:Entity_EDL_0000361	link	NIL000000316
:Entity_EDL_0000362	type	Person
:Entity_EDL_0000362	nominal_mention	"forces"	libya_cnn__1000-01-01__timeline:10195-10200	1.0
:Entity_EDL_0000362	link	NIL000000317
:Entity_EDL_0000363	type	Person
:Entity_EDL_0000363	canonical_mention	"officer"	libya_cnn__1000-01-01__timeline:8095-8101	1.0
:Entity_EDL_0000363	nominal_mention	"officer"	libya_cnn__1000-01-01__timeline:8095-8101	1.0
:Entity_EDL_0000363	link	NIL000000318
:Entity_EDL_0000364	type	Person
:Entity_EDL_0000364	nominal_mention	"forces"	libya_aljazeera__1000-01-01__timeline:1071-1076	1.0
:Entity_EDL_0000364	link	NIL000000319
:Entity_EDL_0000365	type	Vehicle
:Entity_EDL_0000365	canonical_mention	"car"	libya_cnn__1000-01-01__timeline:6207-6209	1.0
:Entity_EDL_0000365	nominal_mention	"car"	libya_cnn__1000-01-01__timeline:6207-6209	1.0
:Entity_EDL_0000365	link	NIL000000320
:Entity_EDL_0000367	type	Person
:Entity_EDL_0000367	nominal_mention	"they"	libya_cnn__1000-01-01__timeline:10546-10549	1.0
:Entity_EDL_0000367	link	NIL000000322
:Entity_EDL_0000368	type	Person
:Entity_EDL_0000368	nominal_mention	"supporters"	libya_reuters__1000-01-01__timeline:4403-4412	1.0
:Entity_EDL_0000368	link	NIL000000323
:Entity_EDL_0000369	type	Facility
:Entity_EDL_0000369	canonical_mention	"port"	libya_aljazeera__1000-01-01__timeline:5783-5786	1.0
:Entity_EDL_0000369	nominal_mention	"port"	libya_aljazeera__1000-01-01__timeline:5783-5786	1.0
:Entity_EDL_0000369	link	NIL000000324
:Entity_EDL_0000370	type	GeopoliticalEntity
:Entity_EDL_0000370	canonical_mention	"Paris"	libya_reuters__1000-01-01__timeline:2087-2091	1.0
:Entity_EDL_0000370	mention	"Paris"	libya_reuters__1000-01-01__timeline:2087-2091	1.0
:Entity_EDL_0000370	link	2988507
:Entity_EDL_0000371	type	Person
:Entity_EDL_0000371	canonical_mention	"villagers"	libya_afp__1000-01-01__timeline:2619-2627	1.0
:Entity_EDL_0000371	nominal_mention	"villagers"	libya_afp__1000-01-01__timeline:2619-2627	1.0
:Entity_EDL_0000371	link	NIL000000325
:Entity_EDL_0000372	type	GeopoliticalEntity
:Entity_EDL_0000372	mention	"U.S."	libya_latimes__1000-01-01__timeline:3779-3782	1.0
:Entity_EDL_0000372	link	6252001
:Entity_EDL_0000373	type	Person
:Entity_EDL_0000373	nominal_mention	"two"	libya_reuters__1000-01-01__timeline:1856-1858	1.0
:Entity_EDL_0000373	pronominal_mention	"two"	libya_reuters__1000-01-01__timeline:1856-1858	1.0
:Entity_EDL_0000373	link	NIL000000326
:Entity_EDL_0000374	type	Person
:Entity_EDL_0000374	nominal_mention	"they"	libya_latimes__1000-01-01__timeline:11316-11319	1.0
:Entity_EDL_0000374	link	NIL000000327
:Entity_EDL_0000375	type	GeopoliticalEntity
:Entity_EDL_0000375	nominal_mention	"cities"	libya_latimes__1000-01-01__timeline:4624-4629	1.0
:Entity_EDL_0000375	link	NIL000000328
:Entity_EDL_0000376	type	GeopoliticalEntity
:Entity_EDL_0000376	mention	"Sirte"	libya_guardian__1000-01-01__timeline:4123-4127	1.0
:Entity_EDL_0000376	link	2210554
:Entity_EDL_0000377	type	Weapon
:Entity_EDL_0000377	canonical_mention	"bullet"	libya_latimes__1000-01-01__timeline:580-585	1.0
:Entity_EDL_0000377	nominal_mention	"bullet"	libya_latimes__1000-01-01__timeline:580-585	1.0
:Entity_EDL_0000377	link	NIL000000329
:Entity_EDL_0000378	type	GeopoliticalEntity
:Entity_EDL_0000378	nominal_mention	"capital"	libya_latimes__1000-01-01__timeline:7531-7537	1.0
:Entity_EDL_0000378	link	NIL000000330
:Entity_EDL_0000379	type	Person
:Entity_EDL_0000379	nominal_mention	"representatives"	libya_latimes__1000-01-01__timeline:8529-8543	1.0
:Entity_EDL_0000379	link	NIL000000331
:Entity_EDL_0000381	type	Person
:Entity_EDL_0000381	nominal_mention	"rebels"	libya_latimes__1000-01-01__timeline:8582-8587	1.0
:Entity_EDL_0000381	link	NIL000000333
:Entity_EDL_0000382	type	Person
:Entity_EDL_0000382	nominal_mention	"fighters"	libya_aljazeera__1000-01-01__timeline:6826-6833	1.0
:Entity_EDL_0000382	link	NIL000000334
:Entity_EDL_0000383	type	Vehicle
:Entity_EDL_0000383	canonical_mention	"jets"	libya_aljazeera__1000-01-01__timeline:3841-3844	1.0
:Entity_EDL_0000383	nominal_mention	"jets"	libya_aljazeera__1000-01-01__timeline:3841-3844	1.0
:Entity_EDL_0000383	link	NIL000000335
:Entity_EDL_0000384	type	GeopoliticalEntity
:Entity_EDL_0000384	canonical_mention	"it"	libya_latimes__1000-01-01__timeline:6150-6151	1.0
:Entity_EDL_0000384	pronominal_mention	"it"	libya_latimes__1000-01-01__timeline:6150-6151	1.0
:Entity_EDL_0000384	link	NIL000000336
:Entity_EDL_0000385	type	Person
:Entity_EDL_0000385	canonical_mention	"Fethi Tarbel"	libya_reuters__1000-01-01__timeline:47-58	1.0
:Entity_EDL_0000385	mention	"Fethi Tarbel"	libya_reuters__1000-01-01__timeline:47-58	1.0
:Entity_EDL_0000385	link	NIL000000337
:Entity_EDL_0000386	type	Vehicle
:Entity_EDL_0000386	nominal_mention	"planes"	libya_latimes__1000-01-01__timeline:7509-7514	1.0
:Entity_EDL_0000386	link	NIL000000338
:Entity_EDL_0000387	type	Weapon
:Entity_EDL_0000387	nominal_mention	"missile"	libya_cnn__1000-01-01__timeline:7668-7674	1.0
:Entity_EDL_0000387	link	NIL000000339
:Entity_EDL_0000388	type	Person
:Entity_EDL_0000388	nominal_mention	"brother"	libya_cnn__1000-01-01__timeline:11237-11243	1.0
:Entity_EDL_0000388	link	NIL000000340
:Entity_EDL_0000389	type	Person
:Entity_EDL_0000389	canonical_mention	"Nicolas Sarkozy"	libya_aljazeera__1000-01-01__timeline:4658-4672	1.0
:Entity_EDL_0000389	mention	"Nicolas Sarkozy"	libya_aljazeera__1000-01-01__timeline:4658-4672	1.0
:Entity_EDL_0000389	link	NIL000000341
:Entity_EDL_0000390	type	Person
:Entity_EDL_0000390	nominal_mention	"rebels"	libya_reuters__1000-01-01__timeline:1662-1667	0.000
:Entity_EDL_0000390	link	NIL000000342
:Entity_EDL_0000391	type	Location
:Entity_EDL_0000391	canonical_mention	"center"	libya_aljazeera__1000-01-01__timeline:1943-1948	1.0
:Entity_EDL_0000391	nominal_mention	"center"	libya_aljazeera__1000-01-01__timeline:1943-1948	1.0
:Entity_EDL_0000391	link	NIL000000343
:Entity_EDL_0000392	type	Person
:Entity_EDL_0000392	nominal_mention	"son"	libya_guardian__1000-01-01__timeline:4498-4500	1.0
:Entity_EDL_0000392	link	NIL000000344
:Entity_EDL_0000393	type	Person
:Entity_EDL_0000393	canonical_mention	"activist"	libya_cnn__1000-01-01__timeline:409-416	1.0
:Entity_EDL_0000393	nominal_mention	"activist"	libya_cnn__1000-01-01__timeline:409-416	1.0
:Entity_EDL_0000393	link	NIL000000345
:Entity_EDL_0000394	type	Weapon
:Entity_EDL_0000394	canonical_mention	"tear gas"	libya_cnn__1000-01-01__timeline:1384-1391	1.0
:Entity_EDL_0000394	nominal_mention	"tear gas"	libya_cnn__1000-01-01__timeline:1384-1391	1.0
:Entity_EDL_0000394	link	NIL000000346
:Entity_EDL_0000395	type	Vehicle
:Entity_EDL_0000395	nominal_mention	"vehicles"	libya_afp__1000-01-01__timeline:1946-1953	1.0
:Entity_EDL_0000395	link	NIL000000347
:Entity_EDL_0000396	type	Person
:Entity_EDL_0000396	nominal_mention	"forces"	libya_latimes__1000-01-01__timeline:5334-5339	0.000
:Entity_EDL_0000396	link	NIL000000348
:Entity_EDL_0000397	type	Location
:Entity_EDL_0000397	nominal_mention	"center"	libya_aljazeera__1000-01-01__timeline:3698-3703	1.0
:Entity_EDL_0000397	link	NIL000000349
:Entity_EDL_0000398	type	Person
:Entity_EDL_0000398	nominal_mention	"heir apparent"	libya_latimes__1000-01-01__timeline:11471-11483	1.0
:Entity_EDL_0000398	link	NIL000000350
:Entity_EDL_0000399	type	Person
:Entity_EDL_0000399	nominal_mention	"rebels"	libya_guardian__1000-01-01__timeline:1652-1657	0.000
:Entity_EDL_0000399	link	NIL000000351
:Entity_EDL_0000400	type	Person
:Entity_EDL_0000400	canonical_mention	"Mahmoud Jibril"	libya_reuters__1000-01-01__timeline:2285-2298	1.0
:Entity_EDL_0000400	mention	"Mahmoud Jibril"	libya_reuters__1000-01-01__timeline:2285-2298	1.0
:Entity_EDL_0000400	link	NIL000000352
:Entity_EDL_0000401	type	Organization
:Entity_EDL_0000401	nominal_mention	"government"	libya_afp__1000-01-01__timeline:2504-2513	0.000
:Entity_EDL_0000401	link	NIL000000353
:Entity_EDL_0000402	type	Person
:Entity_EDL_0000402	canonical_mention	"she"	libya_cnn__1000-01-01__timeline:5961-5963	1.0
:Entity_EDL_0000402	pronominal_mention	"she"	libya_cnn__1000-01-01__timeline:5961-5963	1.0
:Entity_EDL_0000402	link	NIL000000354
:Entity_EDL_0000403	type	Person
:Entity_EDL_0000403	nominal_mention	"son"	libya_aljazeera__1000-01-01__timeline:4426-4428	1.0
:Entity_EDL_0000403	link	NIL000000355
:Entity_EDL_0000404	type	Vehicle
:Entity_EDL_0000404	canonical_mention	"helicopter"	libya_aljazeera__1000-01-01__timeline:2329-2338	1.0
:Entity_EDL_0000404	nominal_mention	"helicopter"	libya_aljazeera__1000-01-01__timeline:2329-2338	1.0
:Entity_EDL_0000404	link	NIL000000356
:Entity_EDL_0000405	type	Location
:Entity_EDL_0000405	canonical_mention	"pockets"	libya_latimes__1000-01-01__timeline:11800-11806	1.0
:Entity_EDL_0000405	pronominal_mention	"pockets"	libya_latimes__1000-01-01__timeline:11800-11806	1.0
:Entity_EDL_0000405	link	NIL000000357
:Entity_EDL_0000406	type	Person
:Entity_EDL_0000406	canonical_mention	"Aisha Gaddafi"	libya_reuters__1000-01-01__timeline:1889-1901	1.0
:Entity_EDL_0000406	mention	"Aisha Gaddafi"	libya_reuters__1000-01-01__timeline:1889-1901	1.0
:Entity_EDL_0000406	link	NIL000000358
:Entity_EDL_0000407	type	Person
:Entity_EDL_0000407	pronominal_mention	"Several"	libya_cnn__1000-01-01__timeline:489-495	1.0
:Entity_EDL_0000407	link	NIL000000359
:Entity_EDL_0000408	type	GeopoliticalEntity
:Entity_EDL_0000408	canonical_mention	"Italy"	libya_reuters__1000-01-01__timeline:3826-3830	1.0
:Entity_EDL_0000408	mention	"Italy"	libya_reuters__1000-01-01__timeline:3826-3830	1.0
:Entity_EDL_0000408	link	3175395
:Entity_EDL_0000409	type	Vehicle
:Entity_EDL_0000409	canonical_mention	"aircraft"	libya_cnn__1000-01-01__timeline:11345-11352	1.0
:Entity_EDL_0000409	nominal_mention	"aircraft"	libya_cnn__1000-01-01__timeline:11345-11352	1.0
:Entity_EDL_0000409	link	NIL000000360
:Entity_EDL_0000410	type	Organization
:Entity_EDL_0000410	nominal_mention	"station"	libya_aljazeera__1000-01-01__timeline:5376-5382	1.0
:Entity_EDL_0000410	link	NIL000000361
:Entity_EDL_0000411	type	Person
:Entity_EDL_0000411	canonical_mention	"officers"	libya_cnn__1000-01-01__timeline:9839-9846	1.0
:Entity_EDL_0000411	nominal_mention	"officers"	libya_cnn__1000-01-01__timeline:9839-9846	1.0
:Entity_EDL_0000411	link	NIL000000362
:Entity_EDL_0000412	type	Person
:Entity_EDL_0000412	canonical_mention	"Seif Islam Kadafi"	libya_latimes__1000-01-01__timeline:11487-11503	1.0
:Entity_EDL_0000412	mention	"Seif Islam Kadafi"	libya_latimes__1000-01-01__timeline:11487-11503	1.0
:Entity_EDL_0000412	link	NIL000000363
:Entity_EDL_0000413	type	Person
:Entity_EDL_0000413	canonical_mention	"forces"	libya_afp__1000-01-01__timeline:120-125	1.0
:Entity_EDL_0000413	nominal_mention	"forces"	libya_afp__1000-01-01__timeline:120-125	1.0
:Entity_EDL_0000413	link	NIL000000364
:Entity_EDL_0000414	type	GeopoliticalEntity
:Entity_EDL_0000414	canonical_mention	"Istanbul"	libya_latimes__1000-01-01__timeline:9763-9770	1.0
:Entity_EDL_0000414	mention	"Istanbul"	libya_latimes__1000-01-01__timeline:9763-9770	1.0
:Entity_EDL_0000414	link	745044
:Entity_EDL_0000415	type	Person
:Entity_EDL_0000415	canonical_mention	"ambassador"	libya_guardian__1000-01-01__timeline:3280-3289	1.0
:Entity_EDL_0000415	nominal_mention	"ambassador"	libya_guardian__1000-01-01__timeline:3280-3289	1.0
:Entity_EDL_0000415	link	NIL000000365
:Entity_EDL_0000416	type	Person
:Entity_EDL_0000416	canonical_mention	"suspects"	libya_cnn__1000-01-01__timeline:6499-6506	1.0
:Entity_EDL_0000416	nominal_mention	"suspects"	libya_cnn__1000-01-01__timeline:6499-6506	1.0
:Entity_EDL_0000416	link	NIL000000366
:Entity_EDL_0000417	type	Facility
:Entity_EDL_0000417	nominal_mention	"streets"	libya_cnn__1000-01-01__timeline:1095-1101	0.000
:Entity_EDL_0000417	link	NIL000000367
:Entity_EDL_0000418	type	Organization
:Entity_EDL_0000418	canonical_mention	"office"	libya_afp__1000-01-01__timeline:2490-2495	1.0
:Entity_EDL_0000418	nominal_mention	"office"	libya_afp__1000-01-01__timeline:2490-2495	1.0
:Entity_EDL_0000418	link	NIL000000368
:Entity_EDL_0000419	type	Facility
:Entity_EDL_0000419	nominal_mention	"compound"	libya_xinhua__1000-01-01__timeline:3379-3386	1.0
:Entity_EDL_0000419	link	NIL000000369
:Entity_EDL_0000420	type	Person
:Entity_EDL_0000420	canonical_mention	"rulers"	libya_reuters__1000-01-01__timeline:2042-2047	1.0
:Entity_EDL_0000420	nominal_mention	"rulers"	libya_reuters__1000-01-01__timeline:2042-2047	1.0
:Entity_EDL_0000420	link	NIL000000370
:Entity_EDL_0000421	type	GeopoliticalEntity
:Entity_EDL_0000421	nominal_mention	"city"	libya_reuters__1000-01-01__timeline:190-193	1.0
:Entity_EDL_0000421	link	NIL000000371
:Entity_EDL_0000422	type	Person
:Entity_EDL_0000422	pronominal_mention	"his"	libya_guardian__1000-01-01__timeline:5086-5088	1.0
:Entity_EDL_0000422	link	NIL000000372
:Entity_EDL_0000423	type	Person
:Entity_EDL_0000423	pronominal_mention	"one"	libya_latimes__1000-01-01__timeline:6264-6266	1.0
:Entity_EDL_0000423	link	NIL000000373
:Entity_EDL_0000424	type	Person
:Entity_EDL_0000424	canonical_mention	"Seif al-Islam"	libya_afp__1000-01-01__timeline:3698-3710	1.0
:Entity_EDL_0000424	mention	"Seif al-Islam"	libya_afp__1000-01-01__timeline:3698-3710	1.0
:Entity_EDL_0000424	link	NIL000000374
:Entity_EDL_0000425	type	Person
:Entity_EDL_0000425	canonical_mention	"crowd"	libya_guardian__1000-01-01__timeline:2625-2629	1.0
:Entity_EDL_0000425	nominal_mention	"crowd"	libya_guardian__1000-01-01__timeline:2625-2629	1.0
:Entity_EDL_0000425	link	NIL000000375
:Entity_EDL_0000426	type	Person
:Entity_EDL_0000426	nominal_mention	"people"	libya_cnn__1000-01-01__timeline:1117-1122	1.0
:Entity_EDL_0000426	link	NIL000000376
:Entity_EDL_0000427	type	Person
:Entity_EDL_0000427	nominal_mention	"protesters"	libya_cnn__1000-01-01__timeline:2139-2148	1.0
:Entity_EDL_0000427	link	NIL000000377
:Entity_EDL_0000428	type	Person
:Entity_EDL_0000428	canonical_mention	"woman"	libya_cnn__1000-01-01__timeline:5846-5850	1.0
:Entity_EDL_0000428	nominal_mention	"woman"	libya_cnn__1000-01-01__timeline:5846-5850	1.0
:Entity_EDL_0000428	link	NIL000000378
:Entity_EDL_0000429	type	Person
:Entity_EDL_0000429	pronominal_mention	"she"	libya_cnn__1000-01-01__timeline:7962-7964	1.0
:Entity_EDL_0000429	link	NIL000000379
:Entity_EDL_0000430	type	Person
:Entity_EDL_0000430	canonical_mention	"delegates"	libya_latimes__1000-01-01__timeline:5442-5450	1.0
:Entity_EDL_0000430	nominal_mention	"delegates"	libya_latimes__1000-01-01__timeline:5442-5450	1.0
:Entity_EDL_0000430	link	NIL000000380
:Entity_EDL_0000431	type	Person
:Entity_EDL_0000431	nominal_mention	"forces"	libya_aljazeera__1000-01-01__timeline:976-981	1.0
:Entity_EDL_0000431	link	NIL000000381
:Entity_EDL_0000432	type	GeopoliticalEntity
:Entity_EDL_0000432	nominal_mention	"country"	libya_xinhua__1000-01-01__timeline:1907-1913	1.0
:Entity_EDL_0000432	link	NIL000000382
:Entity_EDL_0000433	type	Person
:Entity_EDL_0000433	nominal_mention	"forces"	libya_latimes__1000-01-01__timeline:4587-4592	1.0
:Entity_EDL_0000433	link	NIL000000383
:Entity_EDL_0000434	type	Location
:Entity_EDL_0000434	canonical_mention	"area"	libya_aljazeera__1000-01-01__timeline:7797-7800	1.0
:Entity_EDL_0000434	nominal_mention	"area"	libya_aljazeera__1000-01-01__timeline:7797-7800	1.0
:Entity_EDL_0000434	link	NIL000000384
:Entity_EDL_0000435	type	GeopoliticalEntity
:Entity_EDL_0000435	canonical_mention	"Zliten"	libya_afp__1000-01-01__timeline:2653-2658	1.0
:Entity_EDL_0000435	mention	"Zliten"	libya_afp__1000-01-01__timeline:2653-2658	1.0
:Entity_EDL_0000435	link	2208485
:Entity_EDL_0000436	type	Vehicle
:Entity_EDL_0000436	canonical_mention	"warplanes"	libya_xinhua__1000-01-01__timeline:2136-2144	1.0
:Entity_EDL_0000436	nominal_mention	"warplanes"	libya_xinhua__1000-01-01__timeline:2136-2144	1.0
:Entity_EDL_0000436	link	NIL000000385
:Entity_EDL_0000437	type	Person
:Entity_EDL_0000437	canonical_mention	"officials"	libya_cnn__1000-01-01__timeline:6160-6168	1.0
:Entity_EDL_0000437	nominal_mention	"officials"	libya_cnn__1000-01-01__timeline:6160-6168	1.0
:Entity_EDL_0000437	link	NIL000000386
:Entity_EDL_0000438	type	Person
:Entity_EDL_0000438	nominal_mention	"son"	libya_afp__1000-01-01__timeline:3694-3696	1.0
:Entity_EDL_0000438	link	NIL000000387
:Entity_EDL_0000439	type	Person
:Entity_EDL_0000439	canonical_mention	"minister"	libya_aljazeera__1000-01-01__timeline:4241-4248	1.0
:Entity_EDL_0000439	nominal_mention	"minister"	libya_aljazeera__1000-01-01__timeline:4241-4248	1.0
:Entity_EDL_0000439	link	NIL000000388
:Entity_EDL_0000440	type	Person
:Entity_EDL_0000440	canonical_mention	"forces"	libya_aljazeera__1000-01-01__timeline:1768-1773	1.0
:Entity_EDL_0000440	nominal_mention	"forces"	libya_aljazeera__1000-01-01__timeline:1768-1773	1.0
:Entity_EDL_0000440	link	NIL000000389
:Entity_EDL_0000441	type	GeopoliticalEntity
:Entity_EDL_0000441	mention	"Sirte"	libya_reuters__1000-01-01__timeline:4130-4134	1.0
:Entity_EDL_0000441	link	2210554
:Entity_EDL_0000442	type	Person
:Entity_EDL_0000442	canonical_mention	"David Cameron"	libya_guardian__1000-01-01__timeline:2735-2747	1.0
:Entity_EDL_0000442	mention	"David Cameron"	libya_guardian__1000-01-01__timeline:2735-2747	1.0
:Entity_EDL_0000442	link	30005047
:Entity_EDL_0000443	type	Person
:Entity_EDL_0000443	mention	"Muammar Gaddafi"	libya_aljazeera__1000-01-01__timeline:8178-8192	1.0
:Entity_EDL_0000443	link	NIL000000390
:Entity_EDL_0000444	type	Person
:Entity_EDL_0000444	canonical_mention	"children"	libya_cnn__1000-01-01__timeline:12037-12044	1.0
:Entity_EDL_0000444	nominal_mention	"children"	libya_cnn__1000-01-01__timeline:12037-12044	1.0
:Entity_EDL_0000444	link	NIL000000391
:Entity_EDL_0000445	type	GeopoliticalEntity
:Entity_EDL_0000445	canonical_mention	"Brega"	libya_aljazeera__1000-01-01__timeline:507-511	1.0
:Entity_EDL_0000445	mention	"Brega"	libya_aljazeera__1000-01-01__timeline:507-511	1.0
:Entity_EDL_0000445	link	2215210
:Entity_EDL_0000446	type	Person
:Entity_EDL_0000446	canonical_mention	"protesters"	libya_cnn__1000-01-01__timeline:961-970	1.0
:Entity_EDL_0000446	nominal_mention	"protesters"	libya_cnn__1000-01-01__timeline:961-970	1.0
:Entity_EDL_0000446	link	NIL000000392
:Entity_EDL_0000447	type	Person
:Entity_EDL_0000447	nominal_mention	"rebels"	libya_aljazeera__1000-01-01__timeline:3559-3564	1.0
:Entity_EDL_0000447	link	NIL000000393
:Entity_EDL_0000448	type	GeopoliticalEntity
:Entity_EDL_0000448	canonical_mention	"Tunisia"	libya_cnn__1000-01-01__timeline:8049-8055	1.0
:Entity_EDL_0000448	mention	"Tunisia"	libya_cnn__1000-01-01__timeline:8049-8055	1.0
:Entity_EDL_0000448	link	2464461
:Entity_EDL_0000449	type	Person
:Entity_EDL_0000449	pronominal_mention	"he"	libya_cnn__1000-01-01__timeline:2249-2250	1.0
:Entity_EDL_0000449	link	NIL000000394
:Entity_EDL_0000450	type	GeopoliticalEntity
:Entity_EDL_0000450	mention	"Sirte"	libya_aljazeera__1000-01-01__timeline:6115-6119	1.0
:Entity_EDL_0000450	link	2210554
:Entity_EDL_0000451	type	Person
:Entity_EDL_0000451	pronominal_mention	"them"	libya_latimes__1000-01-01__timeline:11100-11103	1.0
:Entity_EDL_0000451	link	NIL000000395
