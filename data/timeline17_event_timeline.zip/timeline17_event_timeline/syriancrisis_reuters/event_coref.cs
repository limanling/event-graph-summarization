:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2945-2954	1.000
:Event_0000000	canonical_mention.actual	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2945-2954	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000157	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2920-2923	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000094	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2945-2954	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:887-894	1.000
:Event_0000000	canonical_mention.actual	"protests"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:887-894	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"demonstration"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:230-242	1.000
:Event_0000000	canonical_mention.actual	"demonstration"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:230-242	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000110	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:256-260	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2248-2255	1.000
:Event_0000000	canonical_mention.actual	"protests"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2248-2255	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6011-6020	1.000
:Event_0000000	canonical_mention.actual	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6011-6020	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000166	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6011-6020	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000088	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6059-6064	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protest"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:654-660	1.000
:Event_0000000	canonical_mention.actual	"protest"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:654-660	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000010	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:640-652	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000001	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:669-673	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protests"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2133-2140	1.000
:Event_0000000	canonical_mention.actual	"protests"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2133-2140	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"march"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:400-404	1.000
:Event_0000000	canonical_mention.actual	"march"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:400-404	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000084	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:393-398	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000118	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:409-413	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000057	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:419-422	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"gathering"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:40-48	1.000
:Event_0000000	canonical_mention.actual	"gathering"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:40-48	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000109	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:53-65	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000058	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:86-95	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"demonstrations"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:471-484	1.000
:Event_0000000	canonical_mention.actual	"demonstrations"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:471-484	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000118	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:409-413	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protest"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:36-42	1.000
:Event_0000000	canonical_mention.actual	"protest"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:36-42	1.000
:Event_0000000	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000111	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:22-27	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000133	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:47-58	1.000
:Event_0000000	type	Conflict.Demonstrate
:Event_0000000	mention.actual	"protest"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3755-3761	1.000
:Event_0000000	canonical_mention.actual	"protest"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3755-3761	1.000
:Event_0000000	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000139	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3724-3727	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"quit"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4666-4669	1.000
:Event_0000001	canonical_mention.actual	"quit"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4666-4669	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4657-4661	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1663-1671	1.000
:Event_0000001	canonical_mention.actual	"step down"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1663-1671	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1654-1658	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4947-4955	1.000
:Event_0000001	canonical_mention.actual	"step down"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4947-4955	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4938-4942	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2363-2371	1.000
:Event_0000001	canonical_mention.actual	"step down"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2363-2371	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2354-2358	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4361-4369	1.000
:Event_0000001	canonical_mention.actual	"step down"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4361-4369	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4352-4356	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"removal"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5326-5332	1.000
:Event_0000001	canonical_mention.actual	"removal"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5326-5332	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000159	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5322-5324	1.000
:Event_0000001	type	Personnel.EndPosition
:Event_0000001	mention.actual	"step down"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4529-4537	1.000
:Event_0000001	canonical_mention.actual	"step down"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4529-4537	1.000
:Event_0000001	Personnel.EndPosition_Person.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4520-4524	1.000
:Event_0000002	type	Conflict.Demonstrate
:Event_0000002	mention.actual	"protesters"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4326-4335	1.000
:Event_0000002	canonical_mention.actual	"protesters"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4326-4335	1.000
:Event_0000002	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000062	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4326-4335	1.000
:Event_0000002	type	Conflict.Demonstrate
:Event_0000002	mention.actual	"protesters"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1771-1780	1.000
:Event_0000002	canonical_mention.actual	"protesters"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1771-1780	1.000
:Event_0000002	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000160	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1746-1749	1.000
:Event_0000002	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000153	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1771-1780	1.000
:Event_0000002	type	Conflict.Demonstrate
:Event_0000002	mention.actual	"protests"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:887-894	1.000
:Event_0000002	canonical_mention.actual	"protests"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:887-894	1.000
:Event_0000002	type	Conflict.Demonstrate
:Event_0000002	mention.actual	"protesters"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1100-1109	1.000
:Event_0000002	canonical_mention.actual	"protesters"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1100-1109	1.000
:Event_0000002	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000073	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1100-1109	1.000
:Event_0000002	type	Conflict.Demonstrate
:Event_0000002	mention.actual	"protests"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5303-5310	1.000
:Event_0000002	canonical_mention.actual	"protests"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5303-5310	1.000
:Event_0000002	type	Conflict.Demonstrate
:Event_0000002	mention.actual	"protests"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1347-1354	1.000
:Event_0000002	canonical_mention.actual	"protests"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1347-1354	1.000
:Event_0000002	type	Conflict.Demonstrate
:Event_0000002	mention.actual	"protest"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:654-660	1.000
:Event_0000002	canonical_mention.actual	"protest"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:654-660	1.000
:Event_0000002	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000010	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:640-652	1.000
:Event_0000002	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000001	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:669-673	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"attack"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5235-5240	1.000
:Event_0000003	canonical_mention.actual	"attack"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5235-5240	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000046	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5266-5274	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000044	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5280-5288	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"Clashes"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6171-6177	1.000
:Event_0000003	canonical_mention.actual	"Clashes"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6171-6177	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000135	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6201-6212	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"massacre"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3619-3626	1.000
:Event_0000003	canonical_mention.actual	"massacre"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3619-3626	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000099	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3631-3635	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"explode"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1387-1393	1.000
:Event_0000003	canonical_mention.actual	"explode"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1387-1393	1.000
:Event_0000003	Conflict.Attack_Instrument.actual	:Entity_EDL_0000144	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1381-1385	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000134	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1407-1415	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000002	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1420-1427	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"attack"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5678-5683	1.000
:Event_0000003	canonical_mention.actual	"attack"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5678-5683	1.000
:Event_0000003	Conflict.Attack_Instrument.actual	:Entity_EDL_0000071	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5673-5676	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000096	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5701-5709	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000038	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5731-5739	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000002	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5744-5751	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"attacks"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3486-3492	1.000
:Event_0000003	canonical_mention.actual	"attacks"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3486-3492	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000156	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3437-3442	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000115	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3472-3479	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000079	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3501-3506	1.000
:Event_0000004	type	Business.Start
:Event_0000004	mention.actual	"formation"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:264-272	1.000
:Event_0000004	canonical_mention.actual	"formation"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:264-272	1.000
:Event_0000004	Business.Start_Organization.actual	:Entity_EDL_0000005	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:279-287	1.000
:Event_0000004	type	Business.Start
:Event_0000004	mention.actual	"formation"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:572-580	1.000
:Event_0000004	canonical_mention.actual	"formation"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:572-580	1.000
:Event_0000004	Business.Start_Organization.actual	:Entity_EDL_0000005	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:587-595	1.000
:Event_0000004	type	Business.Start
:Event_0000004	mention.actual	"formation"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:264-272	1.000
:Event_0000004	canonical_mention.actual	"formation"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:264-272	1.000
:Event_0000004	Business.Start_Organization.actual	:Entity_EDL_0000005	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:279-287	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"storm"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1995-1999	1.000
:Event_0000005	canonical_mention.actual	"storm"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1995-1999	1.000
:Event_0000005	Conflict.Attack_Instrument.actual	:Entity_EDL_0000004	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1989-1993	1.000
:Event_0000005	Conflict.Attack_Place.actual	:Entity_EDL_0000003	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2001-2004	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"storm"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:920-924	1.000
:Event_0000005	canonical_mention.actual	"storm"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:920-924	1.000
:Event_0000005	Conflict.Attack_Instrument.actual	:Entity_EDL_0000004	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:914-918	1.000
:Event_0000005	Conflict.Attack_Place.actual	:Entity_EDL_0000003	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:926-929	1.000
:Event_0000005	type	Conflict.Attack
:Event_0000005	mention.actual	"storm"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3319-3323	1.000
:Event_0000005	canonical_mention.actual	"storm"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3319-3323	1.000
:Event_0000005	Conflict.Attack_Instrument.actual	:Entity_EDL_0000004	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3313-3317	1.000
:Event_0000005	Conflict.Attack_Place.actual	:Entity_EDL_0000003	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3325-3328	1.000
:Event_0000006	type	Contact.Meet
:Event_0000006	mention.actual	"meeting"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2182-2188	1.000
:Event_0000006	canonical_mention.actual	"meeting"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2182-2188	1.000
:Event_0000006	Contact.Meet_Participant.actual	:Entity_EDL_0000121	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2089-2097	1.000
:Event_0000006	Contact.Meet_Place.actual	:Entity_EDL_0000095	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2135-2139	1.000
:Event_0000006	type	Contact.Meet
:Event_0000006	mention.actual	"meet"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4618-4621	1.000
:Event_0000006	canonical_mention.actual	"meet"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4618-4621	1.000
:Event_0000006	Contact.Meet_Participant.actual	:Entity_EDL_0000137	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4598-4613	1.000
:Event_0000006	Contact.Meet_Place.actual	:Entity_EDL_0000119	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4626-4630	1.000
:Event_0000006	type	Contact.Meet
:Event_0000006	mention.actual	"meet"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2127-2130	1.000
:Event_0000006	canonical_mention.actual	"meet"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2127-2130	1.000
:Event_0000006	Contact.Meet_Participant.actual	:Entity_EDL_0000121	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2089-2097	1.000
:Event_0000006	Contact.Meet_Place.actual	:Entity_EDL_0000095	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2135-2139	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"war"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4158-4160	1.000
:Event_0000007	canonical_mention.actual	"war"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4158-4160	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"violence"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4230-4237	1.000
:Event_0000007	canonical_mention.actual	"violence"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4230-4237	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"bloodshed"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5138-5146	1.000
:Event_0000007	canonical_mention.actual	"bloodshed"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5138-5146	1.000
:Event_0000008	type	Contact.Meet
:Event_0000008	mention.actual	"talks"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3669-3673	1.000
:Event_0000008	canonical_mention.actual	"talks"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3669-3673	1.000
:Event_0000008	Contact.Meet_Participant.actual	:Entity_EDL_0000060	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3647-3661	1.000
:Event_0000008	Contact.Meet_Participant.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3680-3684	1.000
:Event_0000008	type	Contact.Meet
:Event_0000008	mention.actual	"talks"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3031-3035	1.000
:Event_0000008	canonical_mention.actual	"talks"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3031-3035	1.000
:Event_0000008	Contact.Meet_Participant.actual	:Entity_EDL_0000018	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3016-3021	1.000
:Event_0000008	Contact.Meet_Participant.actual	:Entity_EDL_0000029	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3046-3055	1.000
:Event_0000008	type	Contact.Meet
:Event_0000008	mention.actual	"talks"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2550-2554	1.000
:Event_0000008	canonical_mention.actual	"talks"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2550-2554	1.000
:Event_0000008	Contact.Meet_Participant.actual	:Entity_EDL_0000070	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2531-2537	1.000
:Event_0000009	type	Conflict.Demonstrate
:Event_0000009	mention.actual	"uprising"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3366-3373	1.000
:Event_0000009	canonical_mention.actual	"uprising"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3366-3373	1.000
:Event_0000009	type	Conflict.Demonstrate
:Event_0000009	mention.actual	"uprising"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4115-4122	1.000
:Event_0000009	canonical_mention.actual	"uprising"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4115-4122	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"crackdown"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3797-3805	1.000
:Event_0000010	canonical_mention.actual	"crackdown"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3797-3805	1.000
:Event_0000010	Conflict.Attack_Attacker.actual	:Entity_EDL_0000014	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3788-3795	1.000
:Event_0000010	type	Conflict.Attack
:Event_0000010	mention.actual	"crackdown"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1923-1931	1.000
:Event_0000010	canonical_mention.actual	"crackdown"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1923-1931	1.000
:Event_0000010	Conflict.Attack_Attacker.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1912-1916	1.000
:Event_0000011	type	Life.Die
:Event_0000011	mention.actual	"killings"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3821-3828	1.000
:Event_0000011	canonical_mention.actual	"killings"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3821-3828	1.000
:Event_0000011	type	Life.Die
:Event_0000011	mention.actual	"kill"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3737-3740	1.000
:Event_0000011	canonical_mention.actual	"kill"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3737-3740	1.000
:Event_0000011	Life.Die_Agent.actual	:Entity_EDL_0000030	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3700-3705	1.000
:Event_0000011	Life.Die_Agent.actual	:Entity_EDL_0000131	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3711-3720	1.000
:Event_0000011	Life.Die_Victim.actual	:Entity_EDL_0000093	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3754-3759	1.000
:Event_0000011	Life.Die_Place.actual	:Entity_EDL_0000151	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3764-3780	1.000
:Event_0000012	type	Contact.Meet
:Event_0000012	mention.actual	"session"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5390-5396	1.000
:Event_0000012	canonical_mention.actual	"session"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5390-5396	1.000
:Event_0000012	Contact.Meet_Participant.actual	:Entity_EDL_0000089	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5410-5429	1.000
:Event_0000012	Contact.Meet_Place.actual	:Entity_EDL_0000050	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5457-5462	1.000
:Event_0000012	type	Contact.Meet
:Event_0000012	mention.actual	"forum"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5448-5452	1.000
:Event_0000012	canonical_mention.actual	"forum"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5448-5452	1.000
:Event_0000012	Contact.Meet_Participant.actual	:Entity_EDL_0000089	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5410-5429	1.000
:Event_0000012	Contact.Meet_Place.actual	:Entity_EDL_0000050	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5457-5462	1.000
:Event_0000013	type	Contact.Meet
:Event_0000013	mention.actual	"meeting"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6144-6150	1.000
:Event_0000013	canonical_mention.actual	"meeting"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6144-6150	1.000
:Event_0000013	Contact.Meet_Place.actual	:Entity_EDL_0000036	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6155-6159	1.000
:Event_0000013	Contact.Meet_Participant.actual	:Entity_EDL_0000136	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6176-6184	1.000
:Event_0000013	type	Contact.Meet
:Event_0000013	mention.actual	"meeting"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5690-5696	1.000
:Event_0000013	canonical_mention.actual	"meeting"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5690-5696	1.000
:Event_0000013	Contact.Meet_Participant.actual	:Entity_EDL_0000096	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5701-5709	1.000
:Event_0000013	Contact.Meet_Participant.actual	:Entity_EDL_0000038	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5731-5739	1.000
:Event_0000013	Contact.Meet_Place.actual	:Entity_EDL_0000002	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5744-5751	1.000
:Event_0000014	type	Contact.Meet
:Event_0000014	mention.actual	"talks"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4115-4119	1.000
:Event_0000014	canonical_mention.actual	"talks"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4115-4119	1.000
:Event_0000014	Contact.Meet_Participant.actual	:Entity_EDL_0000145	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4130-4139	1.000
:Event_0000015	type	Life.Die
:Event_0000015	mention.actual	"killed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3448-3453	1.000
:Event_0000015	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3448-3453	1.000
:Event_0000015	Life.Die_Victim.actual	:Entity_EDL_0000156	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3437-3442	1.000
:Event_0000015	Life.Die_Victim.actual	:Entity_EDL_0000115	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3472-3479	1.000
:Event_0000015	Life.Die_Place.actual	:Entity_EDL_0000079	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3501-3506	1.000
:Event_0000016	type	Life.Die
:Event_0000016	mention.actual	"killed"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2088-2093	1.000
:Event_0000016	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2088-2093	1.000
:Event_0000016	Life.Die_Victim.actual	:Entity_EDL_0000033	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2077-2082	1.000
:Event_0000017	type	Movement.TransportArtifact
:Event_0000017	mention.actual	"flee"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1998-2001	1.000
:Event_0000017	canonical_mention.actual	"flee"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1998-2001	1.000
:Event_0000017	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000024	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1955-1970	1.000
:Event_0000017	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000167	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1988-1996	1.000
:Event_0000017	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000019	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2006-2011	1.000
:Event_0000018	type	Life.Die
:Event_0000018	mention.actual	"kill"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1082-1085	1.000
:Event_0000018	canonical_mention.actual	"kill"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1082-1085	1.000
:Event_0000018	Life.Die_Agent.actual	:Entity_EDL_0000104	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1049-1054	1.000
:Event_0000018	Life.Die_Agent.actual	:Entity_EDL_0000015	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1060-1065	1.000
:Event_0000018	Life.Die_Victim.actual	:Entity_EDL_0000073	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1100-1109	1.000
:Event_0000019	type	Life.Die
:Event_0000019	mention.actual	"killed"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5503-5508	1.000
:Event_0000019	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5503-5508	1.000
:Event_0000019	Life.Die_Victim.actual	:Entity_EDL_0000103	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5486-5491	1.000
:Event_0000019	Life.Die_Agent.actual	:Entity_EDL_0000001	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5513-5517	1.000
:Event_0000020	type	Conflict.Attack
:Event_0000020	mention.actual	"using"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6136-6140	1.000
:Event_0000020	canonical_mention.actual	"using"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6136-6140	1.000
:Event_0000020	Conflict.Attack_Attacker.actual	:Entity_EDL_0000039	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6119-6120	1.000
:Event_0000020	Conflict.Attack_Instrument.actual	:Entity_EDL_0000064	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6148-6154	1.000
:Event_0000020	Conflict.Attack_Place.actual	:Entity_EDL_0000056	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6159-6163	1.000
:Event_0000021	type	Movement.TransportArtifact
:Event_0000021	mention.actual	"visit"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2910-2914	1.000
:Event_0000021	canonical_mention.actual	"visit"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2910-2914	1.000
:Event_0000021	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000016	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2860-2870	1.000
:Event_0000021	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000020	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2894-2908	1.000
:Event_0000021	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000157	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2920-2923	1.000
:Event_0000022	type	Justice.ArrestJail
:Event_0000022	mention.actual	"arrested"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:860-867	1.000
:Event_0000022	canonical_mention.actual	"arrested"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:860-867	1.000
:Event_0000022	Justice.ArrestJail_Person.actual	:Entity_EDL_0000013	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:850-858	1.000
:Event_0000023	type	Life.Die
:Event_0000023	mention.actual	"killed"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1846-1851	1.000
:Event_0000023	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1846-1851	1.000
:Event_0000023	Life.Die_Place.actual	:Entity_EDL_0000077	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1722-1725	1.000
:Event_0000023	Life.Die_Victim.actual	:Entity_EDL_0000173	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1811-1817	1.000
:Event_0000024	type	Business.Start
:Event_0000024	mention.actual	"form"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:569-572	1.000
:Event_0000024	canonical_mention.actual	"form"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:569-572	1.000
:Event_0000024	Business.Start_Agent.actual	:Entity_EDL_0000009	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:521-530	1.000
:Event_0000024	Business.Start_Organization.actual	:Entity_EDL_0000061	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:580-589	1.000
:Event_0000025	type	Conflict.Yield.Retreat
:Event_0000025	mention.actual	"withdrawn"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3787-3795	1.000
:Event_0000025	canonical_mention.actual	"withdrawn"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3787-3795	1.000
:Event_0000026	type	Conflict.Attack
:Event_0000026	mention.actual	"shoot"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6513-6517	1.000
:Event_0000026	canonical_mention.actual	"shoot"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6513-6517	1.000
:Event_0000026	Conflict.Attack_Attacker.actual	:Entity_EDL_0000128	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6390-6395	1.000
:Event_0000026	Conflict.Attack_Target.actual	:Entity_EDL_0000069	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6524-6528	1.000
:Event_0000026	Conflict.Attack_Place.actual	:Entity_EDL_0000034	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6565-6570	1.000
:Event_0000027	type	Conflict.Attack
:Event_0000027	mention.actual	"strike"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3745-3750	1.000
:Event_0000027	canonical_mention.actual	"strike"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3745-3750	1.000
:Event_0000027	Conflict.Attack_Place.actual	:Entity_EDL_0000139	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3724-3727	1.000
:Event_0000028	type	Movement.TransportArtifact
:Event_0000028	mention.actual	"visit"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1736-1740	1.000
:Event_0000028	canonical_mention.actual	"visit"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1736-1740	1.000
:Event_0000028	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000016	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1686-1696	1.000
:Event_0000028	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000020	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1720-1734	1.000
:Event_0000028	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000160	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1746-1749	1.000
:Event_0000029	type	Life.Die
:Event_0000029	mention.actual	"kill"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1120-1123	1.000
:Event_0000029	canonical_mention.actual	"kill"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1120-1123	1.000
:Event_0000029	Life.Die_Agent.actual	:Entity_EDL_0000076	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1087-1092	1.000
:Event_0000029	Life.Die_Agent.actual	:Entity_EDL_0000015	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1098-1103	1.000
:Event_0000029	Life.Die_Victim.actual	:Entity_EDL_0000150	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1138-1147	1.000
:Event_0000030	type	Life.Die
:Event_0000030	mention.actual	"killed"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3845-3850	1.000
:Event_0000030	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3845-3850	1.000
:Event_0000030	Life.Die_Victim.actual	:Entity_EDL_0000102	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3828-3833	1.000
:Event_0000030	Life.Die_Place.actual	:Entity_EDL_0000003	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3855-3858	1.000
:Event_0000031	type	Life.Die
:Event_0000031	mention.actual	"killed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1000-1005	1.000
:Event_0000031	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1000-1005	1.000
:Event_0000031	Life.Die_Victim.actual	:Entity_EDL_0000127	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:989-994	1.000
:Event_0000032	type	Conflict.Attack
:Event_0000032	mention.actual	"hit"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5633-5635	1.000
:Event_0000032	canonical_mention.actual	"hit"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5633-5635	1.000
:Event_0000032	Conflict.Attack_Instrument.actual	:Entity_EDL_0000041	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5624-5631	1.000
:Event_0000032	Conflict.Attack_Target.actual	:Entity_EDL_0000068	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5651-5658	1.000
:Event_0000032	Conflict.Attack_Place.actual	:Entity_EDL_0000002	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5663-5670	1.000
:Event_0000033	type	Conflict.Demonstrate
:Event_0000033	mention.actual	"gathering"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:40-48	1.000
:Event_0000033	canonical_mention.actual	"gathering"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:40-48	1.000
:Event_0000033	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000126	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:53-65	1.000
:Event_0000033	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000112	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:86-95	1.000
:Event_0000034	type	Conflict.Attack
:Event_0000034	mention.actual	"war"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4539-4541	1.000
:Event_0000034	canonical_mention.actual	"war"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4539-4541	1.000
:Event_0000034	Conflict.Attack_Attacker.actual	:Entity_EDL_0000028	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4522-4528	1.000
:Event_0000035	type	Conflict.Attack
:Event_0000035	mention.actual	"attack"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4890-4895	1.000
:Event_0000035	canonical_mention.actual	"attack"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4890-4895	1.000
:Event_0000035	Conflict.Attack_Attacker.actual	:Entity_EDL_0000158	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4880-4888	1.000
:Event_0000035	Conflict.Attack_Target.actual	:Entity_EDL_0000154	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4923-4929	1.000
:Event_0000035	Conflict.Attack_Place.actual	:Entity_EDL_0000065	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4938-4941	1.000
:Event_0000036	type	Life.Injure
:Event_0000036	mention.actual	"wounded"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5971-5977	1.000
:Event_0000036	canonical_mention.actual	"wounded"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5971-5977	1.000
:Event_0000036	Life.Injure_Victim.actual	:Entity_EDL_0000083	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5932-5956	1.000
:Event_0000037	type	Justice.ArrestJail
:Event_0000037	mention.actual	"arrested"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:169-176	1.000
:Event_0000037	canonical_mention.actual	"arrested"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:169-176	1.000
:Event_0000037	Justice.ArrestJail_Person.actual	:Entity_EDL_0000043	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:158-163	1.000
:Event_0000038	type	Life.Die
:Event_0000038	mention.actual	"killed"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4187-4192	1.000
:Event_0000038	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4187-4192	1.000
:Event_0000038	Life.Die_Agent.actual	:Entity_EDL_0000025	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4180-4185	1.000
:Event_0000038	Life.Die_Victim.actual	:Entity_EDL_0000138	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4197-4202	1.000
:Event_0000038	Life.Die_Place.actual	:Entity_EDL_0000011	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4207-4210	1.000
:Event_0000039	type	Life.Die
:Event_0000039	mention.actual	"kills"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5753-5757	1.000
:Event_0000039	canonical_mention.actual	"kills"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5753-5757	1.000
:Event_0000039	Life.Die_Instrument.actual	:Entity_EDL_0000071	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5673-5676	1.000
:Event_0000039	Life.Die_Place.actual	:Entity_EDL_0000002	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5744-5751	1.000
:Event_0000039	Life.Die_Victim.actual	:Entity_EDL_0000045	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5776-5786	1.000
:Event_0000040	type	Contact.Meet
:Event_0000040	mention.actual	"talks"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1857-1861	1.000
:Event_0000040	canonical_mention.actual	"talks"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1857-1861	1.000
:Event_0000040	Contact.Meet_Participant.actual	:Entity_EDL_0000018	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1842-1847	1.000
:Event_0000040	Contact.Meet_Participant.actual	:Entity_EDL_0000040	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1872-1881	1.000
:Event_0000041	type	Business.Start
:Event_0000041	mention.actual	"form"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:569-572	1.000
:Event_0000041	canonical_mention.actual	"form"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:569-572	1.000
:Event_0000041	Business.Start_Agent.actual	:Entity_EDL_0000009	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:521-530	1.000
:Event_0000041	Business.Start_Organization.actual	:Entity_EDL_0000141	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:580-589	1.000
:Event_0000042	type	Conflict.Attack
:Event_0000042	mention.actual	"attack"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4453-4458	1.000
:Event_0000042	canonical_mention.actual	"attack"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4453-4458	1.000
:Event_0000042	Conflict.Attack_Attacker.actual	:Entity_EDL_0000098	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4446-4451	1.000
:Event_0000042	Conflict.Attack_Target.actual	:Entity_EDL_0000142	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4478-4484	1.000
:Event_0000042	Conflict.Attack_Place.actual	:Entity_EDL_0000002	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4489-4496	1.000
:Event_0000042	Conflict.Attack_Target.actual	:Entity_EDL_0000091	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4521-4530	1.000
:Event_0000043	type	Life.Injure
:Event_0000043	mention.actual	"wound"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3133-3137	1.000
:Event_0000043	canonical_mention.actual	"wound"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3133-3137	1.000
:Event_0000043	Life.Injure_Agent.actual	:Entity_EDL_0000162	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3106-3112	1.000
:Event_0000043	Life.Injure_Victim.actual	:Entity_EDL_0000148	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3149-3151	1.000
:Event_0000043	Life.Injure_Place.actual	:Entity_EDL_0000002	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3156-3163	1.000
:Event_0000044	type	Life.Die
:Event_0000044	mention.actual	"killed"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4294-4299	1.000
:Event_0000044	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4294-4299	1.000
:Event_0000044	Life.Die_Victim.actual	:Entity_EDL_0000067	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4277-4282	1.000
:Event_0000044	Life.Die_Agent.actual	:Entity_EDL_0000001	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4304-4308	1.000
:Event_0000045	type	Life.Die
:Event_0000045	mention.actual	"deaths"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:781-786	1.000
:Event_0000045	canonical_mention.actual	"deaths"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:781-786	1.000
:Event_0000046	type	Justice.ArrestJail
:Event_0000046	mention.actual	"arrested"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:169-176	1.000
:Event_0000046	canonical_mention.actual	"arrested"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:169-176	1.000
:Event_0000046	Justice.ArrestJail_Person.actual	:Entity_EDL_0000026	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:158-163	1.000
:Event_0000047	type	Personnel.StartPosition
:Event_0000047	mention.actual	"headed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4727-4732	1.000
:Event_0000047	canonical_mention.actual	"headed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4727-4732	1.000
:Event_0000047	Personnel.StartPosition_Person.actual	:Entity_EDL_0000163	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4710-4719	1.000
:Event_0000047	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000031	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4736-4739	1.000
:Event_0000048	type	Conflict.Attack
:Event_0000048	mention.actual	"fire"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5662-5665	1.000
:Event_0000048	canonical_mention.actual	"fire"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5662-5665	1.000
:Event_0000048	Conflict.Attack_Target.actual	:Entity_EDL_0000035	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5525-5532	1.000
:Event_0000048	Conflict.Attack_Place.actual	:Entity_EDL_0000132	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5624-5631	1.000
:Event_0000048	Conflict.Attack_Attacker.actual	:Entity_EDL_0000037	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5656-5660	1.000
:Event_0000049	type	Life.Die
:Event_0000049	mention.actual	"kill"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:207-210	1.000
:Event_0000049	canonical_mention.actual	"kill"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:207-210	1.000
:Event_0000049	Life.Die_Agent.actual	:Entity_EDL_0000080	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:200-205	1.000
:Event_0000049	Life.Die_Victim.actual	:Entity_EDL_0000051	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:218-223	1.000
:Event_0000050	type	Life.Die
:Event_0000050	mention.actual	"killed"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:687-692	1.000
:Event_0000050	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:687-692	1.000
:Event_0000050	Life.Die_Victim.actual	:Entity_EDL_0000107	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:680-685	1.000
:Event_0000050	Life.Die_Place.actual	:Entity_EDL_0000008	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:697-701	1.000
:Event_0000050	Life.Die_Victim.actual	:Entity_EDL_0000006	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:713-714	1.000
:Event_0000050	Life.Die_Place.actual	:Entity_EDL_0000007	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:716-724	1.000
:Event_0000051	type	Personnel.StartPosition
:Event_0000051	mention.actual	"appointed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1980-1988	1.000
:Event_0000051	canonical_mention.actual	"appointed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1980-1988	1.000
:Event_0000051	Personnel.StartPosition_Person.actual	:Entity_EDL_0000085	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1966-1975	1.000
:Event_0000051	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000021	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1990-2003	1.000
:Event_0000051	Personnel.StartPosition_Organization.actual	:Entity_EDL_0000012	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2005-2015	1.000
:Event_0000052	type	Contact.Meet
:Event_0000052	mention.actual	"conference"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2434-2443	1.000
:Event_0000052	canonical_mention.actual	"conference"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2434-2443	1.000
:Event_0000052	Contact.Meet_Participant.actual	:Entity_EDL_0000017	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2375-2387	1.000
:Event_0000053	type	Conflict.Attack
:Event_0000053	mention.actual	"bombardment"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2616-2626	1.000
:Event_0000053	canonical_mention.actual	"bombardment"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2616-2626	1.000
:Event_0000054	type	Conflict.Demonstrate
:Event_0000054	mention.actual	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1591-1600	1.000
:Event_0000054	canonical_mention.actual	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1591-1600	1.000
:Event_0000054	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000075	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1591-1600	1.000
:Event_0000054	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000001	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1609-1613	1.000
:Event_0000054	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1633-1636	1.000
:Event_0000055	type	Conflict.Attack
:Event_0000055	mention.actual	"fighting"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5424-5431	1.000
:Event_0000055	canonical_mention.actual	"fighting"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5424-5431	1.000
:Event_0000055	Conflict.Attack_Place.actual	:Entity_EDL_0000072	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5440-5446	1.000
:Event_0000056	type	Movement.TransportArtifact
:Event_0000056	mention.actual	"send"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6271-6274	1.000
:Event_0000056	canonical_mention.actual	"send"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6271-6274	1.000
:Event_0000056	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000055	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6263-6264	1.000
:Event_0000056	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000143	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6306-6318	1.000
:Event_0000056	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000002	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6323-6330	1.000
:Event_0000057	type	Contact.Broadcast
:Event_0000057	mention.actual	"announce"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1077-1084	1.000
:Event_0000057	canonical_mention.actual	"announce"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1077-1084	1.000
:Event_0000057	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000082	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1067-1075	1.000
:Event_0000058	type	Conflict.Attack
:Event_0000058	mention.actual	"crackdown"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1420-1428	1.000
:Event_0000058	canonical_mention.actual	"crackdown"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1420-1428	1.000
:Event_0000059	type	Life.Die
:Event_0000059	mention.actual	"killed"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3412-3417	1.000
:Event_0000059	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3412-3417	1.000
:Event_0000059	Life.Die_Victim.actual	:Entity_EDL_0000048	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3401-3406	1.000
:Event_0000060	type	Transaction.TransferMoney
:Event_0000060	mention.actual	"aid"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4652-4654	1.000
:Event_0000060	canonical_mention.actual	"aid"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4652-4654	1.000
:Event_0000060	Transaction.TransferMoney_Beneficiary.actual	:Entity_EDL_0000116	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4666-4671	1.000
:Event_0000061	type	Personnel.EndPosition
:Event_0000061	mention.actual	"quitting"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2155-2162	1.000
:Event_0000061	canonical_mention.actual	"quitting"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2155-2162	1.000
:Event_0000061	Personnel.EndPosition_Person.actual	:Entity_EDL_0000146	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2149-2150	1.000
:Event_0000062	type	Conflict.Coup.Coup
:Event_0000062	mention.actual	"challenge"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3241-3249	1.000
:Event_0000062	canonical_mention.actual	"challenge"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3241-3249	1.000
:Event_0000062	Conflict.Coup.Coup_DeposingEntity.actual	:Entity_EDL_0000113	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3169-3178	1.000
:Event_0000062	Conflict.Coup.Coup_DeposedEntity.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3251-3255	1.000
:Event_0000063	type	Conflict.Attack
:Event_0000063	mention.actual	"bloodshed"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6222-6230	1.000
:Event_0000063	canonical_mention.actual	"bloodshed"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6222-6230	1.000
:Event_0000063	Conflict.Attack_Place.actual	:Entity_EDL_0000001	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6191-6195	1.000
:Event_0000064	type	Conflict.Attack
:Event_0000064	mention.actual	"intervention"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3890-3901	1.000
:Event_0000064	canonical_mention.actual	"intervention"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3890-3901	1.000
:Event_0000065	type	Conflict.Demonstrate
:Event_0000065	mention.actual	"turn out"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2945-2952	1.000
:Event_0000065	canonical_mention.actual	"turn out"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2945-2952	1.000
:Event_0000065	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000001	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2927-2931	1.000
:Event_0000065	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000105	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2938-2943	1.000
:Event_0000066	type	Life.Die
:Event_0000066	mention.actual	"killed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1746-1751	1.000
:Event_0000066	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1746-1751	1.000
:Event_0000066	Life.Die_Victim.actual	:Entity_EDL_0000097	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1735-1740	1.000
:Event_0000066	Life.Die_Place.actual	:Entity_EDL_0000011	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1756-1759	1.000
:Event_0000066	Life.Die_Victim.actual	:Entity_EDL_0000120	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1783-1793	1.000
:Event_0000067	type	Personnel.Elect
:Event_0000067	mention.actual	"election"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2991-2998	1.000
:Event_0000067	canonical_mention.actual	"election"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2991-2998	1.000
:Event_0000067	Personnel.Elect_Place.actual	:Entity_EDL_0000001	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2927-2931	1.000
:Event_0000067	Personnel.Elect_Elector.actual	:Entity_EDL_0000105	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2938-2943	1.000
:Event_0000068	type	Contact.Meet
:Event_0000068	mention.actual	"meeting"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3182-3188	1.000
:Event_0000068	canonical_mention.actual	"meeting"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3182-3188	1.000
:Event_0000068	Contact.Meet_Participant.actual	:Entity_EDL_0000113	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3169-3178	1.000
:Event_0000068	Contact.Meet_Place.actual	:Entity_EDL_0000019	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3193-3198	1.000
:Event_0000069	type	Life.Die
:Event_0000069	mention.actual	"killed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3352-3357	1.000
:Event_0000069	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3352-3357	1.000
:Event_0000069	Life.Die_Victim.actual	:Entity_EDL_0000052	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3335-3340	1.000
:Event_0000070	type	Conflict.Attack
:Event_0000070	mention.actual	"shoot down"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4346-4355	1.000
:Event_0000070	canonical_mention.actual	"shoot down"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4346-4355	1.000
:Event_0000070	Conflict.Attack_Attacker.actual	:Entity_EDL_0000129	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4339-4344	1.000
:Event_0000070	Conflict.Attack_Target.actual	:Entity_EDL_0000164	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4367-4374	1.000
:Event_0000071	type	Personnel.EndPosition
:Event_0000071	mention.actual	"former"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:536-541	1.000
:Event_0000071	canonical_mention.actual	"former"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:536-541	1.000
:Event_0000071	Personnel.EndPosition_Person.actual	:Entity_EDL_0000090	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:555-562	1.000
:Event_0000071	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000061	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:580-589	1.000
:Event_0000072	type	Conflict.Attack
:Event_0000072	mention.actual	"assault"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3986-3992	1.000
:Event_0000072	canonical_mention.actual	"assault"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3986-3992	1.000
:Event_0000072	Conflict.Attack_Attacker.actual	:Entity_EDL_0000014	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3977-3984	1.000
:Event_0000072	Conflict.Attack_Place.actual	:Entity_EDL_0000161	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4001-4004	1.000
:Event_0000073	type	Justice.ArrestJail
:Event_0000073	mention.actual	"imprisoned"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:117-126	1.000
:Event_0000073	canonical_mention.actual	"imprisoned"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:117-126	1.000
:Event_0000073	Justice.ArrestJail_Person.actual	:Entity_EDL_0000058	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:86-95	1.000
:Event_0000073	Justice.ArrestJail_Person.actual	:Entity_EDL_0000023	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:128-136	1.000
:Event_0000074	type	Life.Die
:Event_0000074	mention.actual	"killing"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1431-1437	1.000
:Event_0000074	canonical_mention.actual	"killing"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1431-1437	1.000
:Event_0000074	Life.Die_Instrument.actual	:Entity_EDL_0000144	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1381-1385	1.000
:Event_0000074	Life.Die_Place.actual	:Entity_EDL_0000134	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1407-1415	1.000
:Event_0000074	Life.Die_Victim.actual	:Entity_EDL_0000086	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1442-1447	1.000
:Event_0000075	type	Contact.Meet
:Event_0000075	mention.actual	"conference"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1533-1542	1.000
:Event_0000075	canonical_mention.actual	"conference"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1533-1542	1.000
:Event_0000075	Contact.Meet_Participant.actual	:Entity_EDL_0000017	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1474-1486	1.000
:Event_0000076	type	Movement.TransportArtifact
:Event_0000076	mention.actual	"pull out"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2534-2541	1.000
:Event_0000076	canonical_mention.actual	"pull out"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2534-2541	1.000
:Event_0000076	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000078	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2527-2532	1.000
:Event_0000076	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000053	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2568-2575	1.000
:Event_0000077	type	Justice.ArrestJail
:Event_0000077	mention.actual	"imprisoned"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:117-126	1.000
:Event_0000077	canonical_mention.actual	"imprisoned"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:117-126	1.000
:Event_0000077	Justice.ArrestJail_Person.actual	:Entity_EDL_0000112	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:86-95	1.000
:Event_0000077	Justice.ArrestJail_Person.actual	:Entity_EDL_0000023	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:128-136	1.000
:Event_0000078	type	Personnel.EndPosition
:Event_0000078	mention.actual	"Former"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1936-1941	1.000
:Event_0000078	canonical_mention.actual	"Former"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1936-1941	1.000
:Event_0000078	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000021	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1943-1945	1.000
:Event_0000078	Personnel.EndPosition_Person.actual	:Entity_EDL_0000085	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1966-1975	1.000
:Event_0000079	type	Conflict.Attack
:Event_0000079	mention.actual	"bombardments"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1843-1854	1.000
:Event_0000079	canonical_mention.actual	"bombardments"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1843-1854	1.000
:Event_0000079	Conflict.Attack_Target.actual	:Entity_EDL_0000170	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1810-1815	1.000
:Event_0000079	Conflict.Attack_Place.actual	:Entity_EDL_0000063	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1863-1866	1.000
:Event_0000079	Conflict.Attack_Attacker.actual	:Entity_EDL_0000081	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1880-1885	1.000
:Event_0000080	type	Life.Die
:Event_0000080	mention.actual	"kill"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1574-1577	1.000
:Event_0000080	canonical_mention.actual	"kill"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1574-1577	1.000
:Event_0000080	Life.Die_Agent.actual	:Entity_EDL_0000087	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1567-1572	1.000
:Event_0000080	Life.Die_Victim.actual	:Entity_EDL_0000075	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1591-1600	1.000
:Event_0000080	Life.Die_Place.actual	:Entity_EDL_0000003	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1633-1636	1.000
:Event_0000081	type	Conflict.Demonstrate
:Event_0000081	mention.actual	"marches"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:791-797	1.000
:Event_0000081	canonical_mention.actual	"marches"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:791-797	1.000
:Event_0000081	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000001	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:806-810	1.000
:Event_0000082	type	Life.Die
:Event_0000082	mention.actual	"suicide"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3094-3100	1.000
:Event_0000082	canonical_mention.actual	"suicide"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3094-3100	1.000
:Event_0000082	Life.Die_Victim.actual	:Entity_EDL_0000162	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3106-3112	1.000
:Event_0000082	Life.Die_Place.actual	:Entity_EDL_0000002	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3156-3163	1.000
:Event_0000083	type	Conflict.Attack
:Event_0000083	mention.actual	"fire"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3920-3923	1.000
:Event_0000083	canonical_mention.actual	"fire"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3920-3923	1.000
:Event_0000083	Conflict.Attack_Instrument.actual	:Entity_EDL_0000122	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3909-3913	1.000
:Event_0000083	Conflict.Attack_Place.actual	:Entity_EDL_0000054	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3928-3934	1.000
:Event_0000084	type	Contact.Correspondence
:Event_0000084	mention.actual	"call"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4099-4102	1.000
:Event_0000084	canonical_mention.actual	"call"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4099-4102	1.000
:Event_0000084	Contact.Correspondence_Participant.actual	:Entity_EDL_0000123	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4080-4090	1.000
:Event_0000084	Contact.Correspondence_Participant.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4109-4113	1.000
:Event_0000085	type	Movement.TransportArtifact
:Event_0000085	mention.actual	"visits"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3737-3742	1.000
:Event_0000085	canonical_mention.actual	"visits"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3737-3742	1.000
:Event_0000085	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000124	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3722-3726	1.000
:Event_0000085	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000003	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3744-3747	1.000
:Event_0000086	type	Justice.ReleaseParole
:Event_0000086	mention.actual	"release"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:839-845	1.000
:Event_0000086	canonical_mention.actual	"release"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:839-845	1.000
:Event_0000086	Justice.ReleaseParole_Agent.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:795-799	1.000
:Event_0000086	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000013	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:850-858	1.000
:Event_0000087	type	Conflict.Demonstrate
:Event_0000087	mention.actual	"rally"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1630-1634	1.000
:Event_0000087	canonical_mention.actual	"rally"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1630-1634	1.000
:Event_0000087	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000022	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1620-1628	1.000
:Event_0000087	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1639-1642	1.000
:Event_0000088	type	Life.Die
:Event_0000088	mention.actual	"killings"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3485-3492	1.000
:Event_0000088	canonical_mention.actual	"killings"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3485-3492	1.000
:Event_0000088	Life.Die_Victim.actual	:Entity_EDL_0000047	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3530-3535	1.000
:Event_0000089	type	Personnel.Elect
:Event_0000089	mention.actual	"elections"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5142-5150	1.000
:Event_0000089	canonical_mention.actual	"elections"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5142-5150	1.000
:Event_0000090	type	Personnel.EndPosition
:Event_0000090	mention.actual	"recall"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5193-5198	1.000
:Event_0000090	canonical_mention.actual	"recall"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5193-5198	1.000
:Event_0000090	Personnel.EndPosition_Person.actual	:Entity_EDL_0000168	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5206-5216	1.000
:Event_0000091	type	Life.Die
:Event_0000091	mention.actual	"kill"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3114-3117	1.000
:Event_0000091	canonical_mention.actual	"kill"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3114-3117	1.000
:Event_0000091	Life.Die_Agent.actual	:Entity_EDL_0000162	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3106-3112	1.000
:Event_0000091	Life.Die_Victim.actual	:Entity_EDL_0000171	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3122-3127	1.000
:Event_0000091	Life.Die_Place.actual	:Entity_EDL_0000002	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3156-3163	1.000
:Event_0000092	type	Contact.Contact
:Event_0000092	mention.actual	"negotiate"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3070-3078	1.000
:Event_0000092	canonical_mention.actual	"negotiate"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3070-3078	1.000
:Event_0000092	Contact.Contact_Participant.actual	:Entity_EDL_0000018	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3016-3021	1.000
:Event_0000092	Contact.Contact_Participant.actual	:Entity_EDL_0000029	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3046-3055	1.000
:Event_0000093	type	Contact.Contact
:Event_0000093	mention.actual	"interview"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5074-5082	1.000
:Event_0000093	canonical_mention.actual	"interview"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5074-5082	1.000
:Event_0000093	Contact.Contact_Participant.actual	:Entity_EDL_0000049	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5093-5102	1.000
:Event_0000093	Contact.Contact_Participant.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5106-5110	1.000
:Event_0000094	type	Life.Die
:Event_0000094	mention.actual	"kill"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5112-5115	1.000
:Event_0000094	canonical_mention.actual	"kill"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5112-5115	1.000
:Event_0000094	Life.Die_Agent.actual	:Entity_EDL_0000140	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5080-5085	1.000
:Event_0000094	Life.Die_Agent.actual	:Entity_EDL_0000117	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5101-5110	1.000
:Event_0000094	Life.Die_Victim.actual	:Entity_EDL_0000100	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5127-5132	1.000
:Event_0000094	Life.Die_Place.actual	:Entity_EDL_0000152	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5154-5160	1.000
:Event_0000095	type	Personnel.Nominate
:Event_0000095	mention.actual	"names"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3964-3968	1.000
:Event_0000095	canonical_mention.actual	"names"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3964-3968	1.000
:Event_0000095	Personnel.Nominate_Nominator.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3958-3962	1.000
:Event_0000095	Personnel.Nominate_Nominee.actual	:Entity_EDL_0000066	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3985-3995	1.000
:Event_0000096	type	Conflict.Attack
:Event_0000096	mention.actual	"siege"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:968-972	1.000
:Event_0000096	canonical_mention.actual	"siege"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:968-972	1.000
:Event_0000096	Conflict.Attack_Place.actual	:Entity_EDL_0000003	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:926-929	1.000
:Event_0000097	type	Justice.ArrestJail
:Event_0000097	mention.actual	"arrested"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:860-867	1.000
:Event_0000097	canonical_mention.actual	"arrested"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:860-867	1.000
:Event_0000097	Justice.ArrestJail_Person.actual	:Entity_EDL_0000013	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:850-858	1.000
:Event_0000098	type	Contact.Broadcast
:Event_0000098	mention.actual	"address"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3576-3582	1.000
:Event_0000098	canonical_mention.actual	"address"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3576-3582	1.000
:Event_0000098	Contact.Broadcast_Audience.actual	:Entity_EDL_0000130	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3587-3596	1.000
:Event_0000098	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3600-3604	1.000
:Event_0000099	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000099	mention.actual	"crime"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3849-3853	1.000
:Event_0000099	canonical_mention.actual	"crime"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3849-3853	1.000
:Event_0000100	type	Contact.Meet
:Event_0000100	mention.actual	"meets"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4718-4722	1.000
:Event_0000100	canonical_mention.actual	"meets"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4718-4722	1.000
:Event_0000100	Contact.Meet_Participant.actual	:Entity_EDL_0000059	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4710-4716	1.000
:Event_0000100	Contact.Meet_Participant.actual	:Entity_EDL_0000074	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4724-4738	1.000
:Event_0000101	type	Conflict.Demonstrate
:Event_0000101	mention.actual	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1138-1147	1.000
:Event_0000101	canonical_mention.actual	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1138-1147	1.000
:Event_0000101	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000150	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1138-1147	1.000
:Event_0000102	type	Life.Die
:Event_0000102	mention.actual	"killed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1827-1832	1.000
:Event_0000102	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1827-1832	1.000
:Event_0000102	Life.Die_Victim.actual	:Entity_EDL_0000170	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1810-1815	1.000
:Event_0000102	Life.Die_Place.actual	:Entity_EDL_0000063	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1863-1866	1.000
:Event_0000102	Life.Die_Agent.actual	:Entity_EDL_0000081	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1880-1885	1.000
:Event_0000103	type	Conflict.Demonstrate
:Event_0000103	mention.actual	"rally"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2801-2805	1.000
:Event_0000103	canonical_mention.actual	"rally"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2801-2805	1.000
:Event_0000103	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000022	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2791-2799	1.000
:Event_0000103	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000003	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2810-2813	1.000
:Event_0000104	type	Transaction.TransferOwnership
:Event_0000104	mention.actual	"purchases"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2642-2650	1.000
:Event_0000104	canonical_mention.actual	"purchases"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2642-2650	1.000
:Event_0000104	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000001	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2655-2660	1.000
:Event_0000105	type	Justice.ReleaseParole
:Event_0000105	mention.actual	"release"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:839-845	1.000
:Event_0000105	canonical_mention.actual	"release"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:839-845	1.000
:Event_0000105	Justice.ReleaseParole_Agent.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:795-799	1.000
:Event_0000105	Justice.ReleaseParole_Person.actual	:Entity_EDL_0000013	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:850-858	1.000
:Event_0000106	type	Conflict.Attack
:Event_0000106	mention.actual	"battles"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6407-6413	1.000
:Event_0000106	canonical_mention.actual	"battles"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6407-6413	1.000
:Event_0000106	Conflict.Attack_Attacker.actual	:Entity_EDL_0000128	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6390-6395	1.000
:Event_0000106	Conflict.Attack_Instrument.actual	:Entity_EDL_0000125	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6403-6405	1.000
:Event_0000106	Conflict.Attack_Target.actual	:Entity_EDL_0000101	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6420-6427	1.000
:Event_0000106	Conflict.Attack_Place.actual	:Entity_EDL_0000032	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6476-6479	1.000
:Event_0000107	type	Business.Start
:Event_0000107	mention.actual	"form"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4000-4003	1.000
:Event_0000107	canonical_mention.actual	"form"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4000-4003	1.000
:Event_0000107	Business.Start_Agent.actual	:Entity_EDL_0000000	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3958-3962	1.000
:Event_0000107	Business.Start_Agent.actual	:Entity_EDL_0000066	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3985-3995	1.000
:Event_0000107	Business.Start_Organization.actual	:Entity_EDL_0000165	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4011-4020	1.000
:Event_0000108	type	Life.Die
:Event_0000108	mention.actual	"death"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:847-851	1.000
:Event_0000108	canonical_mention.actual	"death"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:847-851	1.000
:Event_0000108	Life.Die_Victim.actual	:Entity_EDL_0000027	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:834-842	1.000
:Event_0000108	Life.Die_Place.actual	:Entity_EDL_0000002	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:856-863	1.000
:Event_0000109	type	Justice.ChargeIndict
:Event_0000109	mention.actual	"prosecuted"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4715-4724	1.000
:Event_0000109	canonical_mention.actual	"prosecuted"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4715-4724	1.000
:Event_0000109	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000092	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4695-4700	1.000
:Event_0000110	type	Contact.Broadcast
:Event_0000110	mention.actual	"request"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5746-5752	1.000
:Event_0000110	canonical_mention.actual	"request"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5746-5752	1.000
:Event_0000110	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000012	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5724-5734	1.000
:Event_0000110	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000002	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5757-5764	1.000
:Event_0000111	type	Movement.TransportArtifact
:Event_0000111	mention.actual	"fled"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6451-6454	1.000
:Event_0000111	canonical_mention.actual	"fled"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6451-6454	1.000
:Event_0000111	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000128	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6390-6395	1.000
:Event_0000111	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000101	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6420-6427	1.000
:Event_0000111	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000106	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6461-6469	1.000
:Event_0000112	type	Conflict.Attack
:Event_0000112	mention.actual	"clash"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5356-5360	1.000
:Event_0000112	canonical_mention.actual	"clash"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5356-5360	1.000
:Event_0000112	Conflict.Attack_Instrument.actual	:Entity_EDL_0000169	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5347-5354	1.000
:Event_0000112	Conflict.Attack_Target.actual	:Entity_EDL_0000149	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5367-5372	1.000
:Event_0000112	Conflict.Attack_Place.actual	:Entity_EDL_0000002	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5377-5384	1.000
:Event_0000113	type	Life.Die
:Event_0000113	mention.actual	"killed"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:687-692	1.000
:Event_0000113	canonical_mention.actual	"killed"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:687-692	1.000
:Event_0000113	Life.Die_Victim.actual	:Entity_EDL_0000147	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:680-685	1.000
:Event_0000113	Life.Die_Place.actual	:Entity_EDL_0000008	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:697-701	1.000
:Event_0000113	Life.Die_Victim.actual	:Entity_EDL_0000006	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:713-714	1.000
:Event_0000113	Life.Die_Place.actual	:Entity_EDL_0000007	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:716-724	1.000
:Event_0000114	type	Personnel.EndPosition
:Event_0000114	mention.actual	"former"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:536-541	1.000
:Event_0000114	canonical_mention.actual	"former"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:536-541	1.000
:Event_0000114	Personnel.EndPosition_Person.actual	:Entity_EDL_0000155	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:555-562	1.000
:Event_0000114	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000141	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:580-589	1.000
:Event_0000115	type	Conflict.Attack
:Event_0000115	mention.actual	"fire"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6003-6006	1.000
:Event_0000115	canonical_mention.actual	"fire"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6003-6006	1.000
:Event_0000115	Conflict.Attack_Attacker.actual	:Entity_EDL_0000114	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5996-6001	1.000
:Event_0000115	Conflict.Attack_Target.actual	:Entity_EDL_0000166	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6011-6020	1.000
:Event_0000115	Conflict.Attack_Place.actual	:Entity_EDL_0000088	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6059-6064	1.000
:Event_0000116	type	Personnel.Elect
:Event_0000116	mention.actual	"elections"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5359-5367	1.000
:Event_0000116	canonical_mention.actual	"elections"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5359-5367	1.000
:Event_0000117	type	Personnel.Elect
:Event_0000117	mention.actual	"elections"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2458-2466	1.000
:Event_0000117	canonical_mention.actual	"elections"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2458-2466	1.000
:Event_0000118	type	Personnel.Elect
:Event_0000118	mention.actual	"elects"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3202-3207	1.000
:Event_0000118	canonical_mention.actual	"elects"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3202-3207	1.000
:Event_0000118	Personnel.Elect_Place.actual	:Entity_EDL_0000019	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3193-3198	1.000
:Event_0000118	Personnel.Elect_Elector.actual	:Entity_EDL_0000042	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3211-3236	1.000
:Event_0000119	type	Conflict.Attack
:Event_0000119	mention.actual	"bombs"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3306-3310	1.000
:Event_0000119	canonical_mention.actual	"bombs"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3306-3310	1.000
:Event_0000119	Conflict.Attack_Attacker.actual	:Entity_EDL_0000108	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3266-3273	1.000
:Event_0000119	Conflict.Attack_Instrument.actual	:Entity_EDL_0000172	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3306-3310	1.000
