:Entity_EDL_0000000	type	Organization
:Entity_EDL_0000000	nominal_mention	"court"	bpoil_guardian__1000-01-01__timeline:19793-19797	1.0
:Entity_EDL_0000000	link	NIL000000001
:Entity_EDL_0000001	type	Organization
:Entity_EDL_0000001	canonical_mention	"The Guardian"	bpoil_guardian__1000-01-01__timeline:18058-18069	1.0
:Entity_EDL_0000001	mention	"The Guardian"	bpoil_guardian__1000-01-01__timeline:18058-18069	1.0
:Entity_EDL_0000001	link	NIL000000002
:Entity_EDL_0000003	type	Facility
:Entity_EDL_0000003	nominal_mention	"rig"	bpoil_guardian__1000-01-01__timeline:6407-6409	1.0
:Entity_EDL_0000003	link	NIL000000004
:Entity_EDL_0000004	type	Facility
:Entity_EDL_0000004	mention	"Deepwater"	bpoil_guardian__1000-01-01__timeline:9445-9453	1.0
:Entity_EDL_0000004	link	4501472
:Entity_EDL_0000005	type	Person
:Entity_EDL_0000005	canonical_mention	"Ken Feinberg"	bpoil_guardian__1000-01-01__timeline:35548-35559	1.0
:Entity_EDL_0000005	mention	"Ken Feinberg"	bpoil_guardian__1000-01-01__timeline:35548-35559	1.0
:Entity_EDL_0000005	link	NIL000000005
:Entity_EDL_0000006	type	Person
:Entity_EDL_0000006	mention	"Bob Dudley"	bpoil_guardian__1000-01-01__timeline:24355-24364	1.0
:Entity_EDL_0000006	link	NIL000000006
:Entity_EDL_0000007	type	Person
:Entity_EDL_0000007	canonical_mention	"David Cameron"	bpoil_guardian__1000-01-01__timeline:14653-14665	1.0
:Entity_EDL_0000007	mention	"David Cameron"	bpoil_guardian__1000-01-01__timeline:14653-14665	1.0
:Entity_EDL_0000007	link	30005047
:Entity_EDL_0000008	type	Person
:Entity_EDL_0000008	canonical_mention	"representatives"	bpoil_guardian__1000-01-01__timeline:8507-8521	1.0
:Entity_EDL_0000008	nominal_mention	"representatives"	bpoil_guardian__1000-01-01__timeline:8507-8521	1.0
:Entity_EDL_0000008	link	NIL000000007
:Entity_EDL_0000009	type	Organization
:Entity_EDL_0000009	pronominal_mention	"it"	bpoil_guardian__1000-01-01__timeline:26757-26758	1.0
:Entity_EDL_0000009	link	NIL000000008
:Entity_EDL_0000010	type	Person
:Entity_EDL_0000010	canonical_mention	"bomber"	bpoil_guardian__1000-01-01__timeline:21087-21092	1.0
:Entity_EDL_0000010	nominal_mention	"bomber"	bpoil_guardian__1000-01-01__timeline:21087-21092	1.0
:Entity_EDL_0000010	link	NIL000000009
:Entity_EDL_0000011	type	Person
:Entity_EDL_0000011	mention	"Obama"	bpoil_guardian__1000-01-01__timeline:14441-14445	1.0
:Entity_EDL_0000011	link	30001628
:Entity_EDL_0000012	type	Person
:Entity_EDL_0000012	canonical_mention	"Barack Obama"	bpoil_guardian__1000-01-01__timeline:4784-4795	1.0
:Entity_EDL_0000012	mention	"Barack Obama"	bpoil_guardian__1000-01-01__timeline:4784-4795	1.0
:Entity_EDL_0000012	link	NIL000000010
:Entity_EDL_0000013	type	Vehicle
:Entity_EDL_0000013	nominal_mention	"rig"	bpoil_guardian__1000-01-01__timeline:69-71	1.0
:Entity_EDL_0000013	link	NIL000000011
:Entity_EDL_0000014	type	Organization
:Entity_EDL_0000014	canonical_mention	"department of justice"	bpoil_guardian__1000-01-01__timeline:6296-6316	1.0
:Entity_EDL_0000014	mention	"department of justice"	bpoil_guardian__1000-01-01__timeline:6296-6316	1.0
:Entity_EDL_0000014	link	NIL000000012
:Entity_EDL_0000015	type	GeopoliticalEntity
:Entity_EDL_0000015	mention	"US"	bpoil_guardian__1000-01-01__timeline:22123-22124	1.0
:Entity_EDL_0000015	link	6252001
:Entity_EDL_0000016	type	GeopoliticalEntity
:Entity_EDL_0000016	canonical_mention	"Greenland"	bpoil_guardian__1000-01-01__timeline:35327-35335	1.0
:Entity_EDL_0000016	mention	"Greenland"	bpoil_guardian__1000-01-01__timeline:35327-35335	1.0
:Entity_EDL_0000016	link	3425505
:Entity_EDL_0000017	type	Organization
:Entity_EDL_0000017	canonical_mention	"ABC television"	bpoil_guardian__1000-01-01__timeline:22994-23007	1.0
:Entity_EDL_0000017	mention	"ABC television"	bpoil_guardian__1000-01-01__timeline:22994-23007	1.0
:Entity_EDL_0000017	link	NIL000000013
:Entity_EDL_0000018	type	Person
:Entity_EDL_0000018	canonical_mention	"senators"	bpoil_guardian__1000-01-01__timeline:21919-21926	1.0
:Entity_EDL_0000018	nominal_mention	"senators"	bpoil_guardian__1000-01-01__timeline:21919-21926	1.0
:Entity_EDL_0000018	link	NIL000000014
:Entity_EDL_0000019	type	GeopoliticalEntity
:Entity_EDL_0000019	canonical_mention	"Texas City"	bpoil_guardian__1000-01-01__timeline:33971-33980	1.0
:Entity_EDL_0000019	mention	"Texas City"	bpoil_guardian__1000-01-01__timeline:33971-33980	1.0
:Entity_EDL_0000019	link	4736134
:Entity_EDL_0000021	type	Person
:Entity_EDL_0000021	mention	"Tony Hayward"	bpoil_guardian__1000-01-01__timeline:33493-33504	1.0
:Entity_EDL_0000021	link	NIL000000015
:Entity_EDL_0000022	type	Organization
:Entity_EDL_0000022	canonical_mention	"NBC"	bpoil_guardian__1000-01-01__timeline:14437-14439	1.0
:Entity_EDL_0000022	mention	"NBC"	bpoil_guardian__1000-01-01__timeline:14437-14439	1.0
:Entity_EDL_0000022	link	NIL000000016
:Entity_EDL_0000023	type	Organization
:Entity_EDL_0000023	mention	"Transocean"	bpoil_guardian__1000-01-01__timeline:6323-6332	1.0
:Entity_EDL_0000023	link	NIL000000017
:Entity_EDL_0000024	type	Location
:Entity_EDL_0000024	canonical_mention	"central London"	bpoil_guardian__1000-01-01__timeline:24870-24883	1.0
:Entity_EDL_0000024	mention	"central London"	bpoil_guardian__1000-01-01__timeline:24870-24883	1.0
:Entity_EDL_0000024	link	2643743
:Entity_EDL_0000025	type	Person
:Entity_EDL_0000025	mention	"Obama"	bpoil_guardian__1000-01-01__timeline:4719-4723	1.0
:Entity_EDL_0000025	link	30001628
:Entity_EDL_0000026	type	Organization
:Entity_EDL_0000026	canonical_mention	"industry"	bpoil_guardian__1000-01-01__timeline:17179-17186	1.0
:Entity_EDL_0000026	nominal_mention	"industry"	bpoil_guardian__1000-01-01__timeline:17179-17186	1.0
:Entity_EDL_0000026	link	NIL000000018
:Entity_EDL_0000027	type	Person
:Entity_EDL_0000027	canonical_mention	"artists"	bpoil_guardian__1000-01-01__timeline:18099-18105	1.0
:Entity_EDL_0000027	nominal_mention	"artists"	bpoil_guardian__1000-01-01__timeline:18099-18105	1.0
:Entity_EDL_0000027	link	NIL000000019
:Entity_EDL_0000028	type	Organization
:Entity_EDL_0000028	mention	"BP"	bpoil_guardian__1000-01-01__timeline:25796-25797	1.0
:Entity_EDL_0000028	link	NIL000000020
:Entity_EDL_0000029	type	Organization
:Entity_EDL_0000029	nominal_mention	"government"	bpoil_guardian__1000-01-01__timeline:27725-27734	1.0
:Entity_EDL_0000029	link	NIL000000021
:Entity_EDL_0000030	type	Person
:Entity_EDL_0000030	mention	"Bob Dudley"	bpoil_guardian__1000-01-01__timeline:33419-33428	1.0
:Entity_EDL_0000030	link	NIL000000022
:Entity_EDL_0000031	type	Organization
:Entity_EDL_0000031	mention	"BP"	bpoil_guardian__1000-01-01__timeline:33463-33464	1.0
:Entity_EDL_0000031	link	NIL000000023
:Entity_EDL_0000032	type	Person
:Entity_EDL_0000032	nominal_mention	"executive"	bpoil_guardian__1000-01-01__timeline:24284-24292	1.0
:Entity_EDL_0000032	link	NIL000000024
:Entity_EDL_0000033	type	Person
:Entity_EDL_0000033	canonical_mention	"scientists"	bpoil_guardian__1000-01-01__timeline:9866-9875	1.0
:Entity_EDL_0000033	nominal_mention	"scientists"	bpoil_guardian__1000-01-01__timeline:9866-9875	1.0
:Entity_EDL_0000033	link	NIL000000025
:Entity_EDL_0000034	type	Facility
:Entity_EDL_0000034	canonical_mention	"chamber"	bpoil_guardian__1000-01-01__timeline:7002-7008	1.0
:Entity_EDL_0000034	nominal_mention	"chamber"	bpoil_guardian__1000-01-01__timeline:7002-7008	1.0
:Entity_EDL_0000034	link	NIL000000026
:Entity_EDL_0000035	type	GeopoliticalEntity
:Entity_EDL_0000035	canonical_mention	"Lockerbie"	bpoil_guardian__1000-01-01__timeline:21077-21085	1.0
:Entity_EDL_0000035	mention	"Lockerbie"	bpoil_guardian__1000-01-01__timeline:21077-21085	1.0
:Entity_EDL_0000035	link	2643791
:Entity_EDL_0000036	type	Person
:Entity_EDL_0000036	mention	"Hayward"	bpoil_guardian__1000-01-01__timeline:17935-17941	1.0
:Entity_EDL_0000036	link	NIL000000027
:Entity_EDL_0000037	type	Organization
:Entity_EDL_0000037	mention	"BP"	bpoil_guardian__1000-01-01__timeline:26806-26807	1.0
:Entity_EDL_0000037	link	NIL000000028
:Entity_EDL_0000038	type	Organization
:Entity_EDL_0000038	mention	"BP"	bpoil_guardian__1000-01-01__timeline:15378-15379	1.0
:Entity_EDL_0000038	link	NIL000000029
:Entity_EDL_0000039	type	Organization
:Entity_EDL_0000039	canonical_mention	"agency"	bpoil_guardian__1000-01-01__timeline:9859-9864	1.0
:Entity_EDL_0000039	nominal_mention	"agency"	bpoil_guardian__1000-01-01__timeline:9859-9864	1.0
:Entity_EDL_0000039	link	NIL000000030
:Entity_EDL_0000040	type	Location
:Entity_EDL_0000040	nominal_mention	"coast"	bpoil_guardian__1000-01-01__timeline:4741-4745	1.0
:Entity_EDL_0000040	link	NIL000000031
:Entity_EDL_0000041	type	Person
:Entity_EDL_0000041	canonical_mention	"Carl-Henric Svanberg"	bpoil_guardian__1000-01-01__timeline:14690-14709	1.0
:Entity_EDL_0000041	mention	"Carl-Henric Svanberg"	bpoil_guardian__1000-01-01__timeline:14690-14709	1.0
:Entity_EDL_0000041	link	NIL000000032
:Entity_EDL_0000042	type	Person
:Entity_EDL_0000042	canonical_mention	"widows"	bpoil_guardian__1000-01-01__timeline:14205-14210	1.0
:Entity_EDL_0000042	nominal_mention	"widows"	bpoil_guardian__1000-01-01__timeline:14205-14210	1.0
:Entity_EDL_0000042	link	NIL000000033
:Entity_EDL_0000043	type	Person
:Entity_EDL_0000043	mention	"Tony Hayward"	bpoil_guardian__1000-01-01__timeline:24408-24419	1.0
:Entity_EDL_0000043	link	NIL000000034
:Entity_EDL_0000044	type	Facility
:Entity_EDL_0000044	canonical_mention	"garages"	bpoil_guardian__1000-01-01__timeline:24859-24865	1.0
:Entity_EDL_0000044	nominal_mention	"garages"	bpoil_guardian__1000-01-01__timeline:24859-24865	1.0
:Entity_EDL_0000044	link	NIL000000035
:Entity_EDL_0000045	type	Vehicle
:Entity_EDL_0000045	nominal_mention	"robots"	bpoil_guardian__1000-01-01__timeline:6971-6976	1.0
:Entity_EDL_0000045	link	NIL000000036
:Entity_EDL_0000046	type	Weapon
:Entity_EDL_0000046	nominal_mention	"rig"	bpoil_guardian__1000-01-01__timeline:29242-29244	1.0
:Entity_EDL_0000046	link	NIL000000037
:Entity_EDL_0000047	type	Person
:Entity_EDL_0000047	nominal_mention	"executive"	bpoil_guardian__1000-01-01__timeline:14485-14493	1.0
:Entity_EDL_0000047	link	NIL000000038
:Entity_EDL_0000048	type	Location
:Entity_EDL_0000048	mention	"Deepwater Horizon"	bpoil_guardian__1000-01-01__timeline:16379-16395	1.0
:Entity_EDL_0000048	link	NIL000000039
:Entity_EDL_0000049	type	Person
:Entity_EDL_0000049	canonical_mention	"replacement"	bpoil_guardian__1000-01-01__timeline:17319-17329	1.0
:Entity_EDL_0000049	nominal_mention	"replacement"	bpoil_guardian__1000-01-01__timeline:17319-17329	1.0
:Entity_EDL_0000049	link	NIL000000040
:Entity_EDL_0000050	type	Location
:Entity_EDL_0000050	mention	"Gulf"	bpoil_guardian__1000-01-01__timeline:26009-26012	1.0
:Entity_EDL_0000050	link	3523271
:Entity_EDL_0000051	type	Organization
:Entity_EDL_0000051	nominal_mention	"government"	bpoil_guardian__1000-01-01__timeline:35989-35998	1.0
:Entity_EDL_0000051	link	NIL000000041
:Entity_EDL_0000052	type	Person
:Entity_EDL_0000052	canonical_mention	"father"	bpoil_guardian__1000-01-01__timeline:14356-14361	1.0
:Entity_EDL_0000052	nominal_mention	"father"	bpoil_guardian__1000-01-01__timeline:14356-14361	1.0
:Entity_EDL_0000052	link	NIL000000042
:Entity_EDL_0000053	type	Facility
:Entity_EDL_0000053	nominal_mention	"site"	bpoil_guardian__1000-01-01__timeline:23581-23584	1.0
:Entity_EDL_0000053	link	NIL000000043
:Entity_EDL_0000054	type	Person
:Entity_EDL_0000054	canonical_mention	"shareholders"	bpoil_guardian__1000-01-01__timeline:13599-13610	1.0
:Entity_EDL_0000054	nominal_mention	"shareholders"	bpoil_guardian__1000-01-01__timeline:13599-13610	1.0
:Entity_EDL_0000054	link	NIL000000044
:Entity_EDL_0000055	type	Organization
:Entity_EDL_0000055	nominal_mention	"committee"	bpoil_guardian__1000-01-01__timeline:14280-14288	1.0
:Entity_EDL_0000055	link	NIL000000045
:Entity_EDL_0000056	type	Facility
:Entity_EDL_0000056	canonical_mention	"steps"	bpoil_guardian__1000-01-01__timeline:18343-18347	1.0
:Entity_EDL_0000056	nominal_mention	"steps"	bpoil_guardian__1000-01-01__timeline:18343-18347	1.0
:Entity_EDL_0000056	link	NIL000000046
:Entity_EDL_0000057	type	Organization
:Entity_EDL_0000057	mention	"Anadarko"	bpoil_guardian__1000-01-01__timeline:26956-26963	1.0
:Entity_EDL_0000057	link	NIL000000047
:Entity_EDL_0000058	type	Person
:Entity_EDL_0000058	canonical_mention	"critics"	bpoil_guardian__1000-01-01__timeline:18109-18115	1.0
:Entity_EDL_0000058	nominal_mention	"critics"	bpoil_guardian__1000-01-01__timeline:18109-18115	1.0
:Entity_EDL_0000058	link	NIL000000048
:Entity_EDL_0000059	type	Person
:Entity_EDL_0000059	canonical_mention	"protesters"	bpoil_guardian__1000-01-01__timeline:17281-17290	1.0
:Entity_EDL_0000059	nominal_mention	"protesters"	bpoil_guardian__1000-01-01__timeline:17281-17290	1.0
:Entity_EDL_0000059	link	NIL000000049
:Entity_EDL_0000060	type	Location
:Entity_EDL_0000060	nominal_mention	"area"	bpoil_guardian__1000-01-01__timeline:23664-23667	1.0
:Entity_EDL_0000060	link	NIL000000050
:Entity_EDL_0000061	type	Person
:Entity_EDL_0000061	canonical_mention	"engineers"	bpoil_guardian__1000-01-01__timeline:6948-6956	1.0
:Entity_EDL_0000061	nominal_mention	"engineers"	bpoil_guardian__1000-01-01__timeline:6948-6956	1.0
:Entity_EDL_0000061	link	NIL000000051
:Entity_EDL_0000062	type	Organization
:Entity_EDL_0000062	mention	"BP"	bpoil_guardian__1000-01-01__timeline:14473-14474	1.0
:Entity_EDL_0000062	link	NIL000000052
:Entity_EDL_0000063	type	Vehicle
:Entity_EDL_0000063	canonical_mention	"ships"	bpoil_guardian__1000-01-01__timeline:23525-23529	1.0
:Entity_EDL_0000063	nominal_mention	"ships"	bpoil_guardian__1000-01-01__timeline:23525-23529	1.0
:Entity_EDL_0000063	link	NIL000000053
:Entity_EDL_0000064	type	Facility
:Entity_EDL_0000064	mention	"Deepwater Horizon"	bpoil_guardian__1000-01-01__timeline:34633-34649	1.0
:Entity_EDL_0000064	link	NIL000000054
:Entity_EDL_0000065	type	Person
:Entity_EDL_0000065	pronominal_mention	"he"	bpoil_guardian__1000-01-01__timeline:23009-23010	1.0
:Entity_EDL_0000065	link	NIL000000055
:Entity_EDL_0000066	type	Person
:Entity_EDL_0000066	canonical_mention	"claimants"	bpoil_guardian__1000-01-01__timeline:25835-25843	1.0
:Entity_EDL_0000066	nominal_mention	"claimants"	bpoil_guardian__1000-01-01__timeline:25835-25843	1.0
:Entity_EDL_0000066	link	NIL000000056
:Entity_EDL_0000067	type	Organization
:Entity_EDL_0000067	mention	"BP"	bpoil_guardian__1000-01-01__timeline:21650-21651	1.0
:Entity_EDL_0000067	link	NIL000000057
:Entity_EDL_0000068	type	Organization
:Entity_EDL_0000068	canonical_mention	"its"	bpoil_guardian__1000-01-01__timeline:13519-13521	1.0
:Entity_EDL_0000068	pronominal_mention	"its"	bpoil_guardian__1000-01-01__timeline:13519-13521	1.0
:Entity_EDL_0000068	link	NIL000000058
:Entity_EDL_0000069	type	Person
:Entity_EDL_0000069	pronominal_mention	"him"	bpoil_guardian__1000-01-01__timeline:14566-14568	1.0
:Entity_EDL_0000069	link	NIL000000059
:Entity_EDL_0000070	type	Facility
:Entity_EDL_0000070	canonical_mention	"rig"	bpoil_guardian__1000-01-01__timeline:292-294	1.0
:Entity_EDL_0000070	nominal_mention	"rig"	bpoil_guardian__1000-01-01__timeline:292-294	1.0
:Entity_EDL_0000070	link	NIL000000060
:Entity_EDL_0000071	type	Person
:Entity_EDL_0000071	canonical_mention	"Lehr"	bpoil_guardian__1000-01-01__timeline:30163-30166	1.0
:Entity_EDL_0000071	mention	"Lehr"	bpoil_guardian__1000-01-01__timeline:30163-30166	1.0
:Entity_EDL_0000071	link	NIL000000061
:Entity_EDL_0000072	type	Organization
:Entity_EDL_0000072	canonical_mention	"commission"	bpoil_guardian__1000-01-01__timeline:11436-11445	1.0
:Entity_EDL_0000072	nominal_mention	"commission"	bpoil_guardian__1000-01-01__timeline:11436-11445	1.0
:Entity_EDL_0000072	link	NIL000000062
:Entity_EDL_0000073	type	Organization
:Entity_EDL_0000073	nominal_mention	"partners"	bpoil_guardian__1000-01-01__timeline:18718-18725	1.0
:Entity_EDL_0000073	link	NIL000000063
:Entity_EDL_0000074	type	Organization
:Entity_EDL_0000074	nominal_mention	"congressional"	bpoil_guardian__1000-01-01__timeline:10811-10823	1.0
:Entity_EDL_0000074	link	NIL000000064
:Entity_EDL_0000075	type	Person
:Entity_EDL_0000075	mention	"Tony Hayward"	bpoil_guardian__1000-01-01__timeline:24296-24307	1.0
:Entity_EDL_0000075	link	NIL000000065
:Entity_EDL_0000076	type	Organization
:Entity_EDL_0000076	canonical_mention	"Mitsui Oil Exploration"	bpoil_guardian__1000-01-01__timeline:18742-18763	1.0
:Entity_EDL_0000076	mention	"Mitsui Oil Exploration"	bpoil_guardian__1000-01-01__timeline:18742-18763	1.0
:Entity_EDL_0000076	link	NIL000000066
:Entity_EDL_0000077	type	Person
:Entity_EDL_0000077	canonical_mention	"Megrahi"	bpoil_guardian__1000-01-01__timeline:22230-22236	1.0
:Entity_EDL_0000077	mention	"Megrahi"	bpoil_guardian__1000-01-01__timeline:22230-22236	1.0
:Entity_EDL_0000077	link	NIL000000067
:Entity_EDL_0000078	type	GeopoliticalEntity
:Entity_EDL_0000078	mention	"Lockerbie"	bpoil_guardian__1000-01-01__timeline:22024-22032	1.0
:Entity_EDL_0000078	link	2643791
:Entity_EDL_0000079	type	Person
:Entity_EDL_0000079	canonical_mention	"writers"	bpoil_guardian__1000-01-01__timeline:18121-18127	1.0
:Entity_EDL_0000079	nominal_mention	"writers"	bpoil_guardian__1000-01-01__timeline:18121-18127	1.0
:Entity_EDL_0000079	link	NIL000000068
:Entity_EDL_0000080	type	Location
:Entity_EDL_0000080	canonical_mention	"Gulf of Mexico"	bpoil_guardian__1000-01-01__timeline:98-111	1.0
:Entity_EDL_0000080	mention	"Gulf of Mexico"	bpoil_guardian__1000-01-01__timeline:98-111	1.0
:Entity_EDL_0000080	link	3523271
:Entity_EDL_0000081	type	Person
:Entity_EDL_0000081	nominal_mention	"bomber"	bpoil_guardian__1000-01-01__timeline:22034-22039	1.0
:Entity_EDL_0000081	link	NIL000000069
:Entity_EDL_0000082	type	Organization
:Entity_EDL_0000082	canonical_mention	"Anadarko"	bpoil_guardian__1000-01-01__timeline:18729-18736	1.0
:Entity_EDL_0000082	mention	"Anadarko"	bpoil_guardian__1000-01-01__timeline:18729-18736	1.0
:Entity_EDL_0000082	link	NIL000000070
:Entity_EDL_0000083	type	Organization
:Entity_EDL_0000083	nominal_mention	"company"	bpoil_guardian__1000-01-01__timeline:24327-24333	1.0
:Entity_EDL_0000083	link	NIL000000071
:Entity_EDL_0000084	type	Organization
:Entity_EDL_0000084	nominal_mention	"company"	bpoil_guardian__1000-01-01__timeline:25878-25884	1.0
:Entity_EDL_0000084	link	NIL000000072
:Entity_EDL_0000085	type	Facility
:Entity_EDL_0000085	canonical_mention	"Downing Street"	bpoil_guardian__1000-01-01__timeline:14729-14742	1.0
:Entity_EDL_0000085	mention	"Downing Street"	bpoil_guardian__1000-01-01__timeline:14729-14742	1.0
:Entity_EDL_0000085	link	NIL000000073
:Entity_EDL_0000086	type	Person
:Entity_EDL_0000086	mention	"Tony Hayward"	bpoil_guardian__1000-01-01__timeline:18002-18013	1.0
:Entity_EDL_0000086	link	NIL000000074
:Entity_EDL_0000087	type	Facility
:Entity_EDL_0000087	mention	"Deepwater Horizon"	bpoil_guardian__1000-01-01__timeline:23820-23836	1.0
:Entity_EDL_0000087	link	NIL000000075
:Entity_EDL_0000088	type	Person
:Entity_EDL_0000088	mention	"Obama"	bpoil_guardian__1000-01-01__timeline:11396-11400	1.0
:Entity_EDL_0000088	link	30001628
:Entity_EDL_0000089	type	Person
:Entity_EDL_0000089	pronominal_mention	"he"	bpoil_guardian__1000-01-01__timeline:17974-17975	1.0
:Entity_EDL_0000089	link	NIL000000076
:Entity_EDL_0000090	type	Organization
:Entity_EDL_0000090	canonical_mention	"Minerals Management Service"	bpoil_guardian__1000-01-01__timeline:9888-9914	1.0
:Entity_EDL_0000090	mention	"Minerals Management Service"	bpoil_guardian__1000-01-01__timeline:9888-9914	1.0
:Entity_EDL_0000090	link	NIL000000077
:Entity_EDL_0000091	type	Person
:Entity_EDL_0000091	nominal_mention	"chairman"	bpoil_guardian__1000-01-01__timeline:14679-14686	1.0
:Entity_EDL_0000091	link	NIL000000078
:Entity_EDL_0000092	type	Location
:Entity_EDL_0000092	nominal_mention	"site"	bpoil_guardian__1000-01-01__timeline:24089-24092	1.0
:Entity_EDL_0000092	link	NIL000000079
:Entity_EDL_0000093	type	Organization
:Entity_EDL_0000093	pronominal_mention	"several"	bpoil_guardian__1000-01-01__timeline:36028-36034	1.0
:Entity_EDL_0000093	link	NIL000000080
:Entity_EDL_0000094	type	Organization
:Entity_EDL_0000094	nominal_mention	"company"	bpoil_guardian__1000-01-01__timeline:18701-18707	1.0
:Entity_EDL_0000094	link	NIL000000081
:Entity_EDL_0000095	type	Organization
:Entity_EDL_0000095	mention	"BP"	bpoil_guardian__1000-01-01__timeline:36021-36022	1.0
:Entity_EDL_0000095	link	NIL000000082
:Entity_EDL_0000096	type	GeopoliticalEntity
:Entity_EDL_0000096	mention	"Louisiana"	bpoil_guardian__1000-01-01__timeline:4806-4814	1.0
:Entity_EDL_0000096	link	4331987
:Entity_EDL_0000097	type	Person
:Entity_EDL_0000097	canonical_mention	"crews"	bpoil_guardian__1000-01-01__timeline:24069-24073	1.0
:Entity_EDL_0000097	nominal_mention	"crews"	bpoil_guardian__1000-01-01__timeline:24069-24073	1.0
:Entity_EDL_0000097	link	NIL000000083
:Entity_EDL_0000098	type	Facility
:Entity_EDL_0000098	canonical_mention	"refinery"	bpoil_guardian__1000-01-01__timeline:33982-33989	1.0
:Entity_EDL_0000098	nominal_mention	"refinery"	bpoil_guardian__1000-01-01__timeline:33982-33989	1.0
:Entity_EDL_0000098	link	NIL000000084
:Entity_EDL_0000099	type	Person
:Entity_EDL_0000099	mention	"David Cameron"	bpoil_guardian__1000-01-01__timeline:21882-21894	1.0
:Entity_EDL_0000099	link	30005047
:Entity_EDL_0000100	type	Organization
:Entity_EDL_0000100	mention	"BP"	bpoil_guardian__1000-01-01__timeline:24429-24430	1.0
:Entity_EDL_0000100	link	NIL000000085
:Entity_EDL_0000101	type	Person
:Entity_EDL_0000101	pronominal_mention	"who"	bpoil_guardian__1000-01-01__timeline:22101-22103	1.0
:Entity_EDL_0000101	link	NIL000000086
:Entity_EDL_0000102	type	Person
:Entity_EDL_0000102	canonical_mention	"workers"	bpoil_guardian__1000-01-01__timeline:623-629	1.0
:Entity_EDL_0000102	nominal_mention	"workers"	bpoil_guardian__1000-01-01__timeline:623-629	1.0
:Entity_EDL_0000102	link	NIL000000087
:Entity_EDL_0000103	type	Person
:Entity_EDL_0000103	pronominal_mention	"who"	bpoil_guardian__1000-01-01__timeline:29423-29425	1.0
:Entity_EDL_0000103	link	NIL000000088
:Entity_EDL_0000104	type	Person
:Entity_EDL_0000104	canonical_mention	"17"	bpoil_guardian__1000-01-01__timeline:169-170	1.0
:Entity_EDL_0000104	pronominal_mention	"17"	bpoil_guardian__1000-01-01__timeline:169-170	1.0
:Entity_EDL_0000104	link	NIL000000089
:Entity_EDL_0000105	type	Organization
:Entity_EDL_0000105	canonical_mention	"partners"	bpoil_guardian__1000-01-01__timeline:18816-18823	1.0
:Entity_EDL_0000105	nominal_mention	"partners"	bpoil_guardian__1000-01-01__timeline:18816-18823	1.0
:Entity_EDL_0000105	link	NIL000000090
:Entity_EDL_0000106	type	Person
:Entity_EDL_0000106	canonical_mention	"Thad Allen"	bpoil_guardian__1000-01-01__timeline:21570-21579	1.0
:Entity_EDL_0000106	mention	"Thad Allen"	bpoil_guardian__1000-01-01__timeline:21570-21579	1.0
:Entity_EDL_0000106	link	NIL000000091
