:Entity_EDL_0000000	type	Person
:Entity_EDL_0000000	mention	"Bob Dudley"	bpoil_bbc__1000-01-01__timeline:7573-7582	1.0
:Entity_EDL_0000000	link	NIL000000001
:Entity_EDL_0000001	type	Person
:Entity_EDL_0000001	mention	"Obama"	bpoil_bbc__1000-01-01__timeline:8423-8427	1.0
:Entity_EDL_0000001	link	30001628
:Entity_EDL_0000002	type	Location
:Entity_EDL_0000002	mention	"Gulf Coast"	bpoil_bbc__1000-01-01__timeline:10066-10075	1.0
:Entity_EDL_0000002	link	3523271
:Entity_EDL_0000003	type	Person
:Entity_EDL_0000003	pronominal_mention	"he"	bpoil_bbc__1000-01-01__timeline:4516-4517	1.0
:Entity_EDL_0000003	link	NIL000000002
:Entity_EDL_0000004	type	GeopoliticalEntity
:Entity_EDL_0000004	canonical_mention	"states"	bpoil_bbc__1000-01-01__timeline:2372-2377	1.0
:Entity_EDL_0000004	nominal_mention	"states"	bpoil_bbc__1000-01-01__timeline:2372-2377	1.0
:Entity_EDL_0000004	link	NIL000000003
:Entity_EDL_0000005	type	Organization
:Entity_EDL_0000005	mention	"BP"	bpoil_bbc__1000-01-01__timeline:3676-3677	1.0
:Entity_EDL_0000005	link	NIL000000004
:Entity_EDL_0000006	type	Vehicle
:Entity_EDL_0000006	canonical_mention	"vessels"	bpoil_bbc__1000-01-01__timeline:4985-4991	1.0
:Entity_EDL_0000006	nominal_mention	"vessels"	bpoil_bbc__1000-01-01__timeline:4985-4991	1.0
:Entity_EDL_0000006	link	NIL000000005
:Entity_EDL_0000007	type	Facility
:Entity_EDL_0000007	nominal_mention	"well"	bpoil_bbc__1000-01-01__timeline:1142-1145	1.0
:Entity_EDL_0000007	link	NIL000000006
:Entity_EDL_0000008	type	Organization
:Entity_EDL_0000008	mention	"BP"	bpoil_bbc__1000-01-01__timeline:3831-3832	1.0
:Entity_EDL_0000008	link	NIL000000007
:Entity_EDL_0000009	type	Person
:Entity_EDL_0000009	canonical_mention	"experts"	bpoil_bbc__1000-01-01__timeline:9186-9192	1.0
:Entity_EDL_0000009	nominal_mention	"experts"	bpoil_bbc__1000-01-01__timeline:9186-9192	1.0
:Entity_EDL_0000009	link	NIL000000008
:Entity_EDL_0000010	type	Organization
:Entity_EDL_0000010	mention	"BP"	bpoil_bbc__1000-01-01__timeline:13565-13566	1.0
:Entity_EDL_0000010	link	NIL000000009
:Entity_EDL_0000011	type	Organization
:Entity_EDL_0000011	mention	"BP"	bpoil_bbc__1000-01-01__timeline:12098-12099	1.0
:Entity_EDL_0000011	link	NIL000000010
:Entity_EDL_0000012	type	Location
:Entity_EDL_0000012	nominal_mention	"wellhead"	bpoil_bbc__1000-01-01__timeline:13597-13604	1.0
:Entity_EDL_0000012	link	NIL000000011
:Entity_EDL_0000013	type	Location
:Entity_EDL_0000013	nominal_mention	"region"	bpoil_bbc__1000-01-01__timeline:9653-9658	0.000
:Entity_EDL_0000013	link	NIL000000012
:Entity_EDL_0000014	type	Person
:Entity_EDL_0000014	canonical_mention	"Tony Hayward"	bpoil_bbc__1000-01-01__timeline:3709-3720	1.0
:Entity_EDL_0000014	mention	"Tony Hayward"	bpoil_bbc__1000-01-01__timeline:3709-3720	1.0
:Entity_EDL_0000014	link	NIL000000013
:Entity_EDL_0000015	type	Person
:Entity_EDL_0000015	pronominal_mention	"he"	bpoil_bbc__1000-01-01__timeline:9158-9159	1.0
:Entity_EDL_0000015	link	NIL000000014
:Entity_EDL_0000016	type	Location
:Entity_EDL_0000016	mention	"Gulf Coast"	bpoil_bbc__1000-01-01__timeline:12078-12087	1.0
:Entity_EDL_0000016	link	3523271
:Entity_EDL_0000017	type	Facility
:Entity_EDL_0000017	nominal_mention	"rig"	bpoil_bbc__1000-01-01__timeline:1090-1092	1.0
:Entity_EDL_0000017	link	NIL000000015
:Entity_EDL_0000018	type	Person
:Entity_EDL_0000018	pronominal_mention	"He"	bpoil_bbc__1000-01-01__timeline:4533-4534	1.0
:Entity_EDL_0000018	link	NIL000000016
:Entity_EDL_0000019	type	Location
:Entity_EDL_0000019	canonical_mention	"site"	bpoil_bbc__1000-01-01__timeline:5101-5104	1.0
:Entity_EDL_0000019	nominal_mention	"site"	bpoil_bbc__1000-01-01__timeline:5101-5104	1.0
:Entity_EDL_0000019	link	NIL000000017
:Entity_EDL_0000020	type	Person
:Entity_EDL_0000020	mention	"Obama"	bpoil_bbc__1000-01-01__timeline:9621-9625	1.0
:Entity_EDL_0000020	link	30001628
:Entity_EDL_0000021	type	Person
:Entity_EDL_0000021	canonical_mention	"him"	bpoil_bbc__1000-01-01__timeline:3852-3854	1.0
:Entity_EDL_0000021	pronominal_mention	"him"	bpoil_bbc__1000-01-01__timeline:3852-3854	1.0
:Entity_EDL_0000021	link	NIL000000018
:Entity_EDL_0000022	type	Organization
:Entity_EDL_0000022	pronominal_mention	"it"	bpoil_bbc__1000-01-01__timeline:8135-8136	1.0
:Entity_EDL_0000022	link	NIL000000019
:Entity_EDL_0000023	type	Person
:Entity_EDL_0000023	mention	"Obama"	bpoil_bbc__1000-01-01__timeline:9147-9151	1.0
:Entity_EDL_0000023	link	30001628
:Entity_EDL_0000024	type	Person
:Entity_EDL_0000024	mention	"Tony Hayward"	bpoil_bbc__1000-01-01__timeline:7765-7776	1.0
:Entity_EDL_0000024	link	NIL000000020
:Entity_EDL_0000025	type	Person
:Entity_EDL_0000025	mention	"Obama"	bpoil_bbc__1000-01-01__timeline:10049-10053	1.0
:Entity_EDL_0000025	link	30001628
:Entity_EDL_0000026	type	Person
:Entity_EDL_0000026	pronominal_mention	"some"	bpoil_bbc__1000-01-01__timeline:7195-7198	1.0
:Entity_EDL_0000026	link	NIL000000021
:Entity_EDL_0000027	type	Person
:Entity_EDL_0000027	mention	"Obama"	bpoil_bbc__1000-01-01__timeline:12044-12048	1.0
:Entity_EDL_0000027	link	30001628
:Entity_EDL_0000028	type	Location
:Entity_EDL_0000028	mention	"gulf"	bpoil_bbc__1000-01-01__timeline:8456-8459	1.0
:Entity_EDL_0000028	link	3523271
:Entity_EDL_0000029	type	Vehicle
:Entity_EDL_0000029	canonical_mention	"robots"	bpoil_bbc__1000-01-01__timeline:13583-13588	1.0
:Entity_EDL_0000029	nominal_mention	"robots"	bpoil_bbc__1000-01-01__timeline:13583-13588	1.0
:Entity_EDL_0000029	link	NIL000000022
:Entity_EDL_0000030	type	Person
:Entity_EDL_0000030	canonical_mention	"those"	bpoil_bbc__1000-01-01__timeline:2443-2447	1.0
:Entity_EDL_0000030	nominal_mention	"those"	bpoil_bbc__1000-01-01__timeline:2443-2447	1.0
:Entity_EDL_0000030	link	NIL000000023
:Entity_EDL_0000031	type	Organization
:Entity_EDL_0000031	mention	"BP"	bpoil_bbc__1000-01-01__timeline:7526-7527	1.0
:Entity_EDL_0000031	link	NIL000000024
:Entity_EDL_0000032	type	Person
:Entity_EDL_0000032	mention	"Tony Hayward"	bpoil_bbc__1000-01-01__timeline:4418-4429	1.0
:Entity_EDL_0000032	link	NIL000000025
:Entity_EDL_0000033	type	Vehicle
:Entity_EDL_0000033	nominal_mention	"rig"	bpoil_bbc__1000-01-01__timeline:14314-14316	1.0
:Entity_EDL_0000033	link	NIL000000026
:Entity_EDL_0000034	type	Location
:Entity_EDL_0000034	canonical_mention	"Gulf of Mexico"	bpoil_bbc__1000-01-01__timeline:375-388	1.0
:Entity_EDL_0000034	mention	"Gulf of Mexico"	bpoil_bbc__1000-01-01__timeline:375-388	1.0
:Entity_EDL_0000034	link	3523271
:Entity_EDL_0000035	type	Person
:Entity_EDL_0000035	pronominal_mention	"who"	bpoil_bbc__1000-01-01__timeline:3973-3975	1.0
:Entity_EDL_0000035	link	NIL000000027
:Entity_EDL_0000036	type	Vehicle
:Entity_EDL_0000036	nominal_mention	"rig"	bpoil_bbc__1000-01-01__timeline:5009-5011	1.0
:Entity_EDL_0000036	link	NIL000000028
:Entity_EDL_0000037	type	Person
:Entity_EDL_0000037	canonical_mention	"Hayward"	bpoil_bbc__1000-01-01__timeline:3637-3643	1.0
:Entity_EDL_0000037	mention	"Hayward"	bpoil_bbc__1000-01-01__timeline:3637-3643	1.0
:Entity_EDL_0000037	link	NIL000000029
:Entity_EDL_0000038	type	Person
:Entity_EDL_0000038	canonical_mention	"Bob Dudley"	bpoil_bbc__1000-01-01__timeline:3960-3969	1.0
:Entity_EDL_0000038	mention	"Bob Dudley"	bpoil_bbc__1000-01-01__timeline:3960-3969	1.0
:Entity_EDL_0000038	link	NIL000000030
:Entity_EDL_0000039	type	Person
:Entity_EDL_0000039	canonical_mention	"workers"	bpoil_bbc__1000-01-01__timeline:14412-14418	1.0
:Entity_EDL_0000039	nominal_mention	"workers"	bpoil_bbc__1000-01-01__timeline:14412-14418	1.0
:Entity_EDL_0000039	link	NIL000000031
:Entity_EDL_0000040	type	Person
:Entity_EDL_0000040	canonical_mention	"some"	bpoil_bbc__1000-01-01__timeline:2435-2438	1.0
:Entity_EDL_0000040	nominal_mention	"some"	bpoil_bbc__1000-01-01__timeline:2435-2438	1.0
:Entity_EDL_0000040	link	NIL000000032
:Entity_EDL_0000041	type	Location
:Entity_EDL_0000041	mention	"Gulf of Mexico"	bpoil_bbc__1000-01-01__timeline:14325-14338	1.0
:Entity_EDL_0000041	link	3523271
