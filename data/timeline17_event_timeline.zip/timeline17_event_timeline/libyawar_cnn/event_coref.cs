:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"war"	libyawar_cnn__1000-01-01__timeline:1865-1867	1.000
:Event_0000000	canonical_mention.actual	"war"	libyawar_cnn__1000-01-01__timeline:1865-1867	1.000
:Event_0000000	Conflict.Attack_Place.actual	:Entity_EDL_0000102	libyawar_cnn__1000-01-01__timeline:1835-1841	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"war"	libyawar_cnn__1000-01-01__timeline:7063-7065	1.000
:Event_0000000	canonical_mention.actual	"war"	libyawar_cnn__1000-01-01__timeline:7063-7065	1.000
:Event_0000000	Conflict.Attack_Place.actual	:Entity_EDL_0000021	libyawar_cnn__1000-01-01__timeline:7072-7078	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"war"	libyawar_cnn__1000-01-01__timeline:5440-5442	1.000
:Event_0000000	canonical_mention.actual	"war"	libyawar_cnn__1000-01-01__timeline:5440-5442	1.000
:Event_0000000	type	Conflict.Attack
:Event_0000000	mention.actual	"war"	libyawar_cnn__1000-01-01__timeline:7195-7197	1.000
:Event_0000000	canonical_mention.actual	"war"	libyawar_cnn__1000-01-01__timeline:7195-7197	1.000
:Event_0000000	Conflict.Attack_Target.actual	:Entity_EDL_0000045	libyawar_cnn__1000-01-01__timeline:7215-7220	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"fight"	libyawar_cnn__1000-01-01__timeline:5617-5621	1.000
:Event_0000001	canonical_mention.actual	"fight"	libyawar_cnn__1000-01-01__timeline:5617-5621	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000004	libyawar_cnn__1000-01-01__timeline:5613-5615	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"fight"	libyawar_cnn__1000-01-01__timeline:10178-10182	1.000
:Event_0000001	canonical_mention.actual	"fight"	libyawar_cnn__1000-01-01__timeline:10178-10182	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000036	libyawar_cnn__1000-01-01__timeline:10167-10173	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000067	libyawar_cnn__1000-01-01__timeline:10195-10200	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"fight"	libyawar_cnn__1000-01-01__timeline:11678-11682	1.000
:Event_0000001	canonical_mention.actual	"fight"	libyawar_cnn__1000-01-01__timeline:11678-11682	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000022	libyawar_cnn__1000-01-01__timeline:11654-11659	1.000
:Event_0000001	Conflict.Attack_Place.actual	:Entity_EDL_0000073	libyawar_cnn__1000-01-01__timeline:11691-11697	1.000
:Event_0000001	type	Conflict.Attack
:Event_0000001	mention.actual	"fight"	libyawar_cnn__1000-01-01__timeline:10441-10445	1.000
:Event_0000001	canonical_mention.actual	"fight"	libyawar_cnn__1000-01-01__timeline:10441-10445	1.000
:Event_0000001	Conflict.Attack_Attacker.actual	:Entity_EDL_0000087	libyawar_cnn__1000-01-01__timeline:10416-10419	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000011	libyawar_cnn__1000-01-01__timeline:10468-10472	1.000
:Event_0000001	Conflict.Attack_Target.actual	:Entity_EDL_0000009	libyawar_cnn__1000-01-01__timeline:10496-10503	1.000
:Event_0000002	type	Conflict.Demonstrate
:Event_0000002	mention.actual	"Protests"	libyawar_cnn__1000-01-01__timeline:1233-1240	1.000
:Event_0000002	canonical_mention.actual	"Protests"	libyawar_cnn__1000-01-01__timeline:1233-1240	1.000
:Event_0000002	type	Conflict.Demonstrate
:Event_0000002	mention.actual	"protests"	libyawar_cnn__1000-01-01__timeline:1878-1885	1.000
:Event_0000002	canonical_mention.actual	"protests"	libyawar_cnn__1000-01-01__timeline:1878-1885	1.000
:Event_0000002	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000102	libyawar_cnn__1000-01-01__timeline:1835-1841	1.000
:Event_0000002	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000089	libyawar_cnn__1000-01-01__timeline:1872-1876	1.000
:Event_0000002	type	Conflict.Demonstrate
:Event_0000002	mention.actual	"protesters"	libyawar_cnn__1000-01-01__timeline:2139-2148	1.000
:Event_0000002	canonical_mention.actual	"protesters"	libyawar_cnn__1000-01-01__timeline:2139-2148	1.000
:Event_0000002	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000064	libyawar_cnn__1000-01-01__timeline:2139-2148	1.000
:Event_0000002	type	Conflict.Demonstrate
:Event_0000002	mention.actual	"protesters"	libyawar_cnn__1000-01-01__timeline:1068-1077	1.000
:Event_0000002	canonical_mention.actual	"protesters"	libyawar_cnn__1000-01-01__timeline:1068-1077	1.000
:Event_0000002	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000090	libyawar_cnn__1000-01-01__timeline:1068-1077	1.000
:Event_0000002	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000068	libyawar_cnn__1000-01-01__timeline:1095-1101	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"raping"	libyawar_cnn__1000-01-01__timeline:6449-6454	1.000
:Event_0000003	canonical_mention.actual	"raping"	libyawar_cnn__1000-01-01__timeline:6449-6454	1.000
:Event_0000003	Conflict.Attack_Attacker.actual	:Entity_EDL_0000000	libyawar_cnn__1000-01-01__timeline:6434-6436	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000106	libyawar_cnn__1000-01-01__timeline:6456-6464	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"raped"	libyawar_cnn__1000-01-01__timeline:6058-6062	1.000
:Event_0000003	canonical_mention.actual	"raped"	libyawar_cnn__1000-01-01__timeline:6058-6062	1.000
:Event_0000003	Conflict.Attack_Place.actual	:Entity_EDL_0000107	libyawar_cnn__1000-01-01__timeline:5982-5991	1.000
:Event_0000003	Conflict.Attack_Attacker.actual	:Entity_EDL_0000082	libyawar_cnn__1000-01-01__timeline:6021-6022	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000056	libyawar_cnn__1000-01-01__timeline:6064-6066	1.000
:Event_0000003	type	Conflict.Attack
:Event_0000003	mention.actual	"beat"	libyawar_cnn__1000-01-01__timeline:6049-6052	1.000
:Event_0000003	canonical_mention.actual	"beat"	libyawar_cnn__1000-01-01__timeline:6049-6052	1.000
:Event_0000003	Conflict.Attack_Attacker.actual	:Entity_EDL_0000082	libyawar_cnn__1000-01-01__timeline:6021-6022	1.000
:Event_0000003	Conflict.Attack_Target.actual	:Entity_EDL_0000056	libyawar_cnn__1000-01-01__timeline:6064-6066	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"force"	libyawar_cnn__1000-01-01__timeline:2457-2461	1.000
:Event_0000004	canonical_mention.actual	"force"	libyawar_cnn__1000-01-01__timeline:2457-2461	1.000
:Event_0000004	Conflict.Attack_Target.actual	:Entity_EDL_0000029	libyawar_cnn__1000-01-01__timeline:2471-2479	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"force"	libyawar_cnn__1000-01-01__timeline:2103-2107	1.000
:Event_0000004	canonical_mention.actual	"force"	libyawar_cnn__1000-01-01__timeline:2103-2107	1.000
:Event_0000004	Conflict.Attack_Target.actual	:Entity_EDL_0000042	libyawar_cnn__1000-01-01__timeline:2013-2020	1.000
:Event_0000004	Conflict.Attack_Attacker.actual	:Entity_EDL_0000030	libyawar_cnn__1000-01-01__timeline:2124-2129	1.000
:Event_0000004	Conflict.Attack_Target.actual	:Entity_EDL_0000064	libyawar_cnn__1000-01-01__timeline:2139-2148	1.000
:Event_0000004	type	Conflict.Attack
:Event_0000004	mention.actual	"force"	libyawar_cnn__1000-01-01__timeline:5231-5235	1.000
:Event_0000004	canonical_mention.actual	"force"	libyawar_cnn__1000-01-01__timeline:5231-5235	1.000
:Event_0000004	Conflict.Attack_Attacker.actual	:Entity_EDL_0000088	libyawar_cnn__1000-01-01__timeline:5213-5218	1.000
:Event_0000004	Conflict.Attack_Target.actual	:Entity_EDL_0000109	libyawar_cnn__1000-01-01__timeline:5253-5258	1.000
:Event_0000005	type	Movement.TransportPerson
:Event_0000005	mention.actual	"left"	libyawar_cnn__1000-01-01__timeline:8511-8514	1.000
:Event_0000005	canonical_mention.actual	"left"	libyawar_cnn__1000-01-01__timeline:8511-8514	1.000
:Event_0000005	Movement.TransportPerson_Person.actual	:Entity_EDL_0000066	libyawar_cnn__1000-01-01__timeline:8508-8509	1.000
:Event_0000005	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000008	libyawar_cnn__1000-01-01__timeline:8545-8551	1.000
:Event_0000005	type	Movement.TransportPerson
:Event_0000005	mention.actual	"defects"	libyawar_cnn__1000-01-01__timeline:8477-8483	1.000
:Event_0000005	canonical_mention.actual	"defects"	libyawar_cnn__1000-01-01__timeline:8477-8483	1.000
:Event_0000005	Movement.TransportPerson_Person.actual	:Entity_EDL_0000010	libyawar_cnn__1000-01-01__timeline:8468-8475	1.000
:Event_0000005	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000049	libyawar_cnn__1000-01-01__timeline:8488-8492	1.000
:Event_0000006	type	Conflict.Demonstrate
:Event_0000006	mention.actual	"protests"	libyawar_cnn__1000-01-01__timeline:1422-1429	1.000
:Event_0000006	canonical_mention.actual	"protests"	libyawar_cnn__1000-01-01__timeline:1422-1429	1.000
:Event_0000006	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000058	libyawar_cnn__1000-01-01__timeline:1447-1452	1.000
:Event_0000006	type	Conflict.Demonstrate
:Event_0000006	mention.actual	"demonstrations"	libyawar_cnn__1000-01-01__timeline:1545-1558	1.000
:Event_0000006	canonical_mention.actual	"demonstrations"	libyawar_cnn__1000-01-01__timeline:1545-1558	1.000
:Event_0000006	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000074	libyawar_cnn__1000-01-01__timeline:1538-1543	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"attack"	libyawar_cnn__1000-01-01__timeline:7676-7681	1.000
:Event_0000007	canonical_mention.actual	"attack"	libyawar_cnn__1000-01-01__timeline:7676-7681	1.000
:Event_0000007	Conflict.Attack_Attacker.actual	:Entity_EDL_0000086	libyawar_cnn__1000-01-01__timeline:7652-7655	1.000
:Event_0000007	Conflict.Attack_Instrument.actual	:Entity_EDL_0000100	libyawar_cnn__1000-01-01__timeline:7668-7674	1.000
:Event_0000007	Conflict.Attack_Target.actual	:Entity_EDL_0000093	libyawar_cnn__1000-01-01__timeline:7688-7692	1.000
:Event_0000007	Conflict.Attack_Place.actual	:Entity_EDL_0000017	libyawar_cnn__1000-01-01__timeline:7697-7703	1.000
:Event_0000007	type	Conflict.Attack
:Event_0000007	mention.actual	"attack"	libyawar_cnn__1000-01-01__timeline:7712-7717	1.000
:Event_0000007	canonical_mention.actual	"attack"	libyawar_cnn__1000-01-01__timeline:7712-7717	1.000
:Event_0000007	Conflict.Attack_Target.actual	:Entity_EDL_0000020	libyawar_cnn__1000-01-01__timeline:7725-7727	1.000
:Event_0000008	type	Movement.TransportArtifact
:Event_0000008	mention.actual	"fled"	libyawar_cnn__1000-01-01__timeline:2256-2259	1.000
:Event_0000008	canonical_mention.actual	"fled"	libyawar_cnn__1000-01-01__timeline:2256-2259	1.000
:Event_0000008	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000081	libyawar_cnn__1000-01-01__timeline:2249-2250	1.000
:Event_0000008	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000070	libyawar_cnn__1000-01-01__timeline:2265-2271	1.000
:Event_0000008	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000094	libyawar_cnn__1000-01-01__timeline:2302-2306	1.000
:Event_0000008	type	Movement.TransportArtifact
:Event_0000008	mention.actual	"leave"	libyawar_cnn__1000-01-01__timeline:2296-2300	1.000
:Event_0000008	canonical_mention.actual	"leave"	libyawar_cnn__1000-01-01__timeline:2296-2300	1.000
:Event_0000008	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000070	libyawar_cnn__1000-01-01__timeline:2265-2271	1.000
:Event_0000008	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000094	libyawar_cnn__1000-01-01__timeline:2302-2306	1.000
:Event_0000009	type	Life.Die
:Event_0000009	mention.actual	"assassinated"	libyawar_cnn__1000-01-01__timeline:9792-9803	1.000
:Event_0000009	canonical_mention.actual	"assassinated"	libyawar_cnn__1000-01-01__timeline:9792-9803	1.000
:Event_0000009	Life.Die_Victim.actual	:Entity_EDL_0000018	libyawar_cnn__1000-01-01__timeline:9755-9763	1.000
:Event_0000009	Life.Die_Place.actual	:Entity_EDL_0000118	libyawar_cnn__1000-01-01__timeline:9808-9815	1.000
:Event_0000009	Life.Die_Victim.actual	:Entity_EDL_0000097	libyawar_cnn__1000-01-01__timeline:9839-9846	1.000
:Event_0000009	type	Life.Die
:Event_0000009	mention.actual	"killed"	libyawar_cnn__1000-01-01__timeline:11315-11320	1.000
:Event_0000009	canonical_mention.actual	"killed"	libyawar_cnn__1000-01-01__timeline:11315-11320	1.000
:Event_0000009	Life.Die_Victim.actual	:Entity_EDL_0000047	libyawar_cnn__1000-01-01__timeline:11237-11243	1.000
:Event_0000009	Life.Die_Instrument.actual	:Entity_EDL_0000072	libyawar_cnn__1000-01-01__timeline:11345-11352	1.000
:Event_0000010	type	Movement.TransportArtifact
:Event_0000010	mention.actual	"take"	libyawar_cnn__1000-01-01__timeline:1083-1086	1.000
:Event_0000010	canonical_mention.actual	"take"	libyawar_cnn__1000-01-01__timeline:1083-1086	1.000
:Event_0000010	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000068	libyawar_cnn__1000-01-01__timeline:1095-1101	1.000
:Event_0000010	type	Movement.TransportArtifact
:Event_0000010	mention.actual	"take"	libyawar_cnn__1000-01-01__timeline:418-421	1.000
:Event_0000010	canonical_mention.actual	"take"	libyawar_cnn__1000-01-01__timeline:418-421	1.000
:Event_0000010	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000031	libyawar_cnn__1000-01-01__timeline:362-374	1.000
:Event_0000010	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000019	libyawar_cnn__1000-01-01__timeline:430-436	1.000
:Event_0000011	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000011	mention.actual	"crimes"	libyawar_cnn__1000-01-01__timeline:3314-3319	1.000
:Event_0000011	canonical_mention.actual	"crimes"	libyawar_cnn__1000-01-01__timeline:3314-3319	1.000
:Event_0000011	GenericCrime.GenericCrime.GenericCrime_Perpetrator.actual	:Entity_EDL_0000120	libyawar_cnn__1000-01-01__timeline:3258-3264	1.000
:Event_0000011	type	GenericCrime.GenericCrime.GenericCrime
:Event_0000011	mention.actual	"crimes"	libyawar_cnn__1000-01-01__timeline:9111-9116	1.000
:Event_0000011	canonical_mention.actual	"crimes"	libyawar_cnn__1000-01-01__timeline:9111-9116	1.000
:Event_0000011	GenericCrime.GenericCrime.GenericCrime_Place.actual	:Entity_EDL_0000054	libyawar_cnn__1000-01-01__timeline:9205-9209	1.000
:Event_0000012	type	Movement.TransportArtifact
:Event_0000012	mention.actual	"crossed"	libyawar_cnn__1000-01-01__timeline:8036-8042	1.000
:Event_0000012	canonical_mention.actual	"crossed"	libyawar_cnn__1000-01-01__timeline:8036-8042	1.000
:Event_0000012	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000105	libyawar_cnn__1000-01-01__timeline:8028-8030	1.000
:Event_0000012	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000057	libyawar_cnn__1000-01-01__timeline:8049-8055	1.000
:Event_0000012	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000080	libyawar_cnn__1000-01-01__timeline:8095-8101	1.000
:Event_0000013	type	Movement.TransportArtifact
:Event_0000013	mention.actual	"leave"	libyawar_cnn__1000-01-01__timeline:12054-12058	1.000
:Event_0000013	canonical_mention.actual	"leave"	libyawar_cnn__1000-01-01__timeline:12054-12058	1.000
:Event_0000013	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000051	libyawar_cnn__1000-01-01__timeline:12028-12031	1.000
:Event_0000013	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000111	libyawar_cnn__1000-01-01__timeline:12037-12044	1.000
:Event_0000013	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000095	libyawar_cnn__1000-01-01__timeline:12064-12070	1.000
:Event_0000014	type	Life.Die
:Event_0000014	mention.actual	"kills"	libyawar_cnn__1000-01-01__timeline:7719-7723	1.000
:Event_0000014	canonical_mention.actual	"kills"	libyawar_cnn__1000-01-01__timeline:7719-7723	1.000
:Event_0000014	Life.Die_Victim.actual	:Entity_EDL_0000020	libyawar_cnn__1000-01-01__timeline:7725-7727	1.000
:Event_0000015	type	Justice.ArrestJail
:Event_0000015	mention.actual	"arrest"	libyawar_cnn__1000-01-01__timeline:8957-8962	1.000
:Event_0000015	canonical_mention.actual	"arrest"	libyawar_cnn__1000-01-01__timeline:8957-8962	1.000
:Event_0000015	Justice.ArrestJail_Person.actual	:Entity_EDL_0000038	libyawar_cnn__1000-01-01__timeline:8991-9005	1.000
:Event_0000016	type	Conflict.Attack
:Event_0000016	mention.actual	"airstrikes"	libyawar_cnn__1000-01-01__timeline:7449-7458	1.000
:Event_0000016	canonical_mention.actual	"airstrikes"	libyawar_cnn__1000-01-01__timeline:7449-7458	1.000
:Event_0000017	type	Conflict.Attack
:Event_0000017	mention.actual	"fight"	libyawar_cnn__1000-01-01__timeline:10537-10541	1.000
:Event_0000017	canonical_mention.actual	"fight"	libyawar_cnn__1000-01-01__timeline:10537-10541	1.000
:Event_0000017	Conflict.Attack_Attacker.actual	:Entity_EDL_0000092	libyawar_cnn__1000-01-01__timeline:10546-10549	1.000
:Event_0000018	type	Conflict.Attack
:Event_0000018	mention.actual	"conflict"	libyawar_cnn__1000-01-01__timeline:4529-4536	1.000
:Event_0000018	canonical_mention.actual	"conflict"	libyawar_cnn__1000-01-01__timeline:4529-4536	1.000
:Event_0000019	type	Movement.TransportArtifact
:Event_0000019	mention.actual	"deported"	libyawar_cnn__1000-01-01__timeline:8189-8196	1.000
:Event_0000019	canonical_mention.actual	"deported"	libyawar_cnn__1000-01-01__timeline:8189-8196	1.000
:Event_0000019	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000046	libyawar_cnn__1000-01-01__timeline:8137-8139	1.000
:Event_0000019	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000121	libyawar_cnn__1000-01-01__timeline:8206-8210	1.000
:Event_0000020	type	Life.Die
:Event_0000020	mention.actual	"murder"	libyawar_cnn__1000-01-01__timeline:9150-9155	1.000
:Event_0000020	canonical_mention.actual	"murder"	libyawar_cnn__1000-01-01__timeline:9150-9155	1.000
:Event_0000020	Life.Die_Place.actual	:Entity_EDL_0000054	libyawar_cnn__1000-01-01__timeline:9205-9209	1.000
:Event_0000021	type	Conflict.Attack
:Event_0000021	mention.actual	"clashes"	libyawar_cnn__1000-01-01__timeline:1355-1361	1.000
:Event_0000021	canonical_mention.actual	"clashes"	libyawar_cnn__1000-01-01__timeline:1355-1361	1.000
:Event_0000021	Conflict.Attack_Place.actual	:Entity_EDL_0000079	libyawar_cnn__1000-01-01__timeline:1320-1327	1.000
:Event_0000021	Conflict.Attack_Attacker.actual	:Entity_EDL_0000024	libyawar_cnn__1000-01-01__timeline:1368-1375	1.000
:Event_0000021	Conflict.Attack_Instrument.actual	:Entity_EDL_0000003	libyawar_cnn__1000-01-01__timeline:1384-1391	1.000
:Event_0000021	Conflict.Attack_Instrument.actual	:Entity_EDL_0000007	libyawar_cnn__1000-01-01__timeline:1397-1403	1.000
:Event_0000022	type	Conflict.Attack
:Event_0000022	mention.actual	"violence"	libyawar_cnn__1000-01-01__timeline:2437-2444	1.000
:Event_0000022	canonical_mention.actual	"violence"	libyawar_cnn__1000-01-01__timeline:2437-2444	1.000
:Event_0000023	type	Life.Die
:Event_0000023	mention.actual	"die"	libyawar_cnn__1000-01-01__timeline:2322-2324	1.000
:Event_0000023	canonical_mention.actual	"die"	libyawar_cnn__1000-01-01__timeline:2322-2324	1.000
:Event_0000024	type	Conflict.Attack
:Event_0000024	mention.actual	"firing"	libyawar_cnn__1000-01-01__timeline:1377-1382	1.000
:Event_0000024	canonical_mention.actual	"firing"	libyawar_cnn__1000-01-01__timeline:1377-1382	1.000
:Event_0000024	Conflict.Attack_Place.actual	:Entity_EDL_0000079	libyawar_cnn__1000-01-01__timeline:1320-1327	1.000
:Event_0000024	Conflict.Attack_Attacker.actual	:Entity_EDL_0000024	libyawar_cnn__1000-01-01__timeline:1368-1375	1.000
:Event_0000024	Conflict.Attack_Instrument.actual	:Entity_EDL_0000003	libyawar_cnn__1000-01-01__timeline:1384-1391	1.000
:Event_0000024	Conflict.Attack_Instrument.actual	:Entity_EDL_0000007	libyawar_cnn__1000-01-01__timeline:1397-1403	1.000
:Event_0000025	type	Conflict.Attack
:Event_0000025	mention.actual	"violence"	libyawar_cnn__1000-01-01__timeline:4761-4768	1.000
:Event_0000025	canonical_mention.actual	"violence"	libyawar_cnn__1000-01-01__timeline:4761-4768	1.000
:Event_0000026	type	Contact.Broadcast
:Event_0000026	mention.actual	"warn"	libyawar_cnn__1000-01-01__timeline:1807-1810	1.000
:Event_0000026	canonical_mention.actual	"warn"	libyawar_cnn__1000-01-01__timeline:1807-1810	1.000
:Event_0000026	Contact.Broadcast_Broadcaster.actual	:Entity_EDL_0000059	libyawar_cnn__1000-01-01__timeline:1754-1774	1.000
:Event_0000026	Contact.Broadcast_Audience.actual	:Entity_EDL_0000013	libyawar_cnn__1000-01-01__timeline:1812-1824	1.000
:Event_0000027	type	Movement.TransportArtifact
:Event_0000027	mention.actual	"creeps"	libyawar_cnn__1000-01-01__timeline:897-902	1.000
:Event_0000027	canonical_mention.actual	"creeps"	libyawar_cnn__1000-01-01__timeline:897-902	1.000
:Event_0000027	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000039	libyawar_cnn__1000-01-01__timeline:881-889	1.000
:Event_0000027	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000023	libyawar_cnn__1000-01-01__timeline:912-918	1.000
:Event_0000028	type	Conflict.Attack
:Event_0000028	mention.actual	"killing"	libyawar_cnn__1000-01-01__timeline:7502-7508	1.000
:Event_0000028	canonical_mention.actual	"killing"	libyawar_cnn__1000-01-01__timeline:7502-7508	1.000
:Event_0000028	Conflict.Attack_Attacker.actual	:Entity_EDL_0000112	libyawar_cnn__1000-01-01__timeline:7489-7497	1.000
:Event_0000028	Conflict.Attack_Target.actual	:Entity_EDL_0000014	libyawar_cnn__1000-01-01__timeline:7510-7518	1.000
:Event_0000029	type	Personnel.EndPosition
:Event_0000029	mention.actual	"fall"	libyawar_cnn__1000-01-01__timeline:32-35	1.000
:Event_0000029	canonical_mention.actual	"fall"	libyawar_cnn__1000-01-01__timeline:32-35	1.000
:Event_0000029	Personnel.EndPosition_Person.actual	:Entity_EDL_0000001	libyawar_cnn__1000-01-01__timeline:59-71	1.000
:Event_0000030	type	Conflict.Attack
:Event_0000030	mention.actual	"fighting"	libyawar_cnn__1000-01-01__timeline:683-690	1.000
:Event_0000030	canonical_mention.actual	"fighting"	libyawar_cnn__1000-01-01__timeline:683-690	1.000
:Event_0000030	Conflict.Attack_Attacker.actual	:Entity_EDL_0000119	libyawar_cnn__1000-01-01__timeline:676-681	1.000
:Event_0000030	Conflict.Attack_Target.actual	:Entity_EDL_0000041	libyawar_cnn__1000-01-01__timeline:692-701	1.000
:Event_0000031	type	Movement.TransportPerson
:Event_0000031	mention.actual	"fled"	libyawar_cnn__1000-01-01__timeline:7970-7973	1.000
:Event_0000031	canonical_mention.actual	"fled"	libyawar_cnn__1000-01-01__timeline:7970-7973	1.000
:Event_0000031	Movement.TransportPerson_Person.actual	:Entity_EDL_0000083	libyawar_cnn__1000-01-01__timeline:7962-7964	1.000
:Event_0000031	Movement.TransportPerson_Origin.actual	:Entity_EDL_0000016	libyawar_cnn__1000-01-01__timeline:7975-7979	1.000
:Event_0000032	type	Life.Die
:Event_0000032	mention.actual	"deaths"	libyawar_cnn__1000-01-01__timeline:2571-2576	1.000
:Event_0000032	canonical_mention.actual	"deaths"	libyawar_cnn__1000-01-01__timeline:2571-2576	1.000
:Event_0000032	Life.Die_Victim.actual	:Entity_EDL_0000071	libyawar_cnn__1000-01-01__timeline:2593-2601	1.000
:Event_0000032	Life.Die_Place.actual	:Entity_EDL_0000103	libyawar_cnn__1000-01-01__timeline:2609-2613	1.000
:Event_0000033	type	Personnel.EndPosition
:Event_0000033	mention.actual	"resigned"	libyawar_cnn__1000-01-01__timeline:2026-2033	1.000
:Event_0000033	canonical_mention.actual	"resigned"	libyawar_cnn__1000-01-01__timeline:2026-2033	1.000
:Event_0000033	Personnel.EndPosition_Person.actual	:Entity_EDL_0000042	libyawar_cnn__1000-01-01__timeline:2013-2020	1.000
:Event_0000034	type	Life.Die
:Event_0000034	mention.actual	"killed"	libyawar_cnn__1000-01-01__timeline:1128-1133	1.000
:Event_0000034	canonical_mention.actual	"killed"	libyawar_cnn__1000-01-01__timeline:1128-1133	1.000
:Event_0000034	Life.Die_Victim.actual	:Entity_EDL_0000090	libyawar_cnn__1000-01-01__timeline:1068-1077	1.000
:Event_0000034	Life.Die_Victim.actual	:Entity_EDL_0000044	libyawar_cnn__1000-01-01__timeline:1117-1122	1.000
:Event_0000035	type	Movement.TransportPerson
:Event_0000035	mention.actual	"arrival"	libyawar_cnn__1000-01-01__timeline:9555-9561	1.000
:Event_0000035	canonical_mention.actual	"arrival"	libyawar_cnn__1000-01-01__timeline:9555-9561	1.000
:Event_0000035	Movement.TransportPerson_Person.actual	:Entity_EDL_0000076	libyawar_cnn__1000-01-01__timeline:9551-9553	1.000
:Event_0000035	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000006	libyawar_cnn__1000-01-01__timeline:9570-9582	1.000
:Event_0000036	type	Conflict.Demonstrate
:Event_0000036	mention.actual	"protest"	libyawar_cnn__1000-01-01__timeline:2038-2044	1.000
:Event_0000036	canonical_mention.actual	"protest"	libyawar_cnn__1000-01-01__timeline:2038-2044	1.000
:Event_0000036	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000064	libyawar_cnn__1000-01-01__timeline:2139-2148	1.000
:Event_0000037	type	Conflict.Attack
:Event_0000037	mention.actual	"rape"	libyawar_cnn__1000-01-01__timeline:7912-7915	1.000
:Event_0000037	canonical_mention.actual	"rape"	libyawar_cnn__1000-01-01__timeline:7912-7915	1.000
:Event_0000038	type	Conflict.Attack
:Event_0000038	mention.actual	"destroying"	libyawar_cnn__1000-01-01__timeline:7524-7533	1.000
:Event_0000038	canonical_mention.actual	"destroying"	libyawar_cnn__1000-01-01__timeline:7524-7533	1.000
:Event_0000038	Conflict.Attack_Attacker.actual	:Entity_EDL_0000112	libyawar_cnn__1000-01-01__timeline:7489-7497	1.000
:Event_0000038	Conflict.Attack_Place.actual	:Entity_EDL_0000060	libyawar_cnn__1000-01-01__timeline:7539-7544	1.000
:Event_0000039	type	Transaction.TransferOwnership
:Event_0000039	mention.actual	"sale"	libyawar_cnn__1000-01-01__timeline:3524-3527	1.000
:Event_0000039	canonical_mention.actual	"sale"	libyawar_cnn__1000-01-01__timeline:3524-3527	1.000
:Event_0000039	Transaction.TransferOwnership_Thing.actual	:Entity_EDL_0000114	libyawar_cnn__1000-01-01__timeline:3532-3550	1.000
:Event_0000039	Transaction.TransferOwnership_Recipient.actual	:Entity_EDL_0000104	libyawar_cnn__1000-01-01__timeline:3555-3559	1.000
:Event_0000040	type	Justice.ChargeIndict
:Event_0000040	mention.actual	"charges"	libyawar_cnn__1000-01-01__timeline:6533-6539	1.000
:Event_0000040	canonical_mention.actual	"charges"	libyawar_cnn__1000-01-01__timeline:6533-6539	1.000
:Event_0000040	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000000	libyawar_cnn__1000-01-01__timeline:6434-6436	1.000
:Event_0000040	Justice.ChargeIndict_Defendant.actual	:Entity_EDL_0000085	libyawar_cnn__1000-01-01__timeline:6499-6506	1.000
:Event_0000041	type	Personnel.EndPosition
:Event_0000041	mention.actual	"dismissed"	libyawar_cnn__1000-01-01__timeline:10022-10030	1.000
:Event_0000041	canonical_mention.actual	"dismissed"	libyawar_cnn__1000-01-01__timeline:10022-10030	1.000
:Event_0000041	Personnel.EndPosition_Person.actual	:Entity_EDL_0000098	libyawar_cnn__1000-01-01__timeline:10065-10069	1.000
:Event_0000042	type	Life.Injure
:Event_0000042	mention.actual	"bruises"	libyawar_cnn__1000-01-01__timeline:5857-5863	1.000
:Event_0000042	canonical_mention.actual	"bruises"	libyawar_cnn__1000-01-01__timeline:5857-5863	1.000
:Event_0000043	type	Conflict.Attack
:Event_0000043	mention.actual	"attack"	libyawar_cnn__1000-01-01__timeline:993-998	1.000
:Event_0000043	canonical_mention.actual	"attack"	libyawar_cnn__1000-01-01__timeline:993-998	1.000
:Event_0000043	Conflict.Attack_Place.actual	:Entity_EDL_0000065	libyawar_cnn__1000-01-01__timeline:926-933	1.000
:Event_0000043	Conflict.Attack_Target.actual	:Entity_EDL_0000052	libyawar_cnn__1000-01-01__timeline:961-970	1.000
:Event_0000043	Conflict.Attack_Target.actual	:Entity_EDL_0000053	libyawar_cnn__1000-01-01__timeline:978-981	1.000
:Event_0000043	Conflict.Attack_Attacker.actual	:Entity_EDL_0000050	libyawar_cnn__1000-01-01__timeline:1027-1032	1.000
:Event_0000044	type	Conflict.Demonstrate
:Event_0000044	mention.actual	"protesting"	libyawar_cnn__1000-01-01__timeline:376-385	1.000
:Event_0000044	canonical_mention.actual	"protesting"	libyawar_cnn__1000-01-01__timeline:376-385	1.000
:Event_0000044	Conflict.Demonstrate_Demonstrator.actual	:Entity_EDL_0000031	libyawar_cnn__1000-01-01__timeline:362-374	1.000
:Event_0000045	type	Movement.TransportArtifact
:Event_0000045	mention.actual	"arrives"	libyawar_cnn__1000-01-01__timeline:9464-9470	1.000
:Event_0000045	canonical_mention.actual	"arrives"	libyawar_cnn__1000-01-01__timeline:9464-9470	1.000
:Event_0000045	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000037	libyawar_cnn__1000-01-01__timeline:9438-9450	1.000
:Event_0000045	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000043	libyawar_cnn__1000-01-01__timeline:9454-9462	1.000
:Event_0000045	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000035	libyawar_cnn__1000-01-01__timeline:9475-9482	1.000
:Event_0000045	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000005	libyawar_cnn__1000-01-01__timeline:9500-9505	1.000
:Event_0000045	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000026	libyawar_cnn__1000-01-01__timeline:9514-9524	1.000
:Event_0000046	type	Contact.Correspondence
:Event_0000046	mention.actual	"letter"	libyawar_cnn__1000-01-01__timeline:7104-7109	1.000
:Event_0000046	canonical_mention.actual	"letter"	libyawar_cnn__1000-01-01__timeline:7104-7109	1.000
:Event_0000046	Contact.Correspondence_Participant.actual	:Entity_EDL_0000096	libyawar_cnn__1000-01-01__timeline:6990-6996	1.000
:Event_0000047	type	Justice.ArrestJail
:Event_0000047	mention.actual	"arrest"	libyawar_cnn__1000-01-01__timeline:391-396	1.000
:Event_0000047	canonical_mention.actual	"arrest"	libyawar_cnn__1000-01-01__timeline:391-396	1.000
:Event_0000047	Justice.ArrestJail_Person.actual	:Entity_EDL_0000117	libyawar_cnn__1000-01-01__timeline:409-416	1.000
:Event_0000048	type	Conflict.Attack
:Event_0000048	mention.actual	"fired"	libyawar_cnn__1000-01-01__timeline:4999-5003	1.000
:Event_0000048	canonical_mention.actual	"fired"	libyawar_cnn__1000-01-01__timeline:4999-5003	1.000
:Event_0000048	Conflict.Attack_Instrument.actual	:Entity_EDL_0000075	libyawar_cnn__1000-01-01__timeline:4990-4997	1.000
:Event_0000048	Conflict.Attack_Instrument.actual	:Entity_EDL_0000108	libyawar_cnn__1000-01-01__timeline:5031-5035	1.000
:Event_0000048	Conflict.Attack_Instrument.actual	:Entity_EDL_0000063	libyawar_cnn__1000-01-01__timeline:5041-5050	1.000
:Event_0000049	type	Life.Injure
:Event_0000049	mention.actual	"wounded"	libyawar_cnn__1000-01-01__timeline:1147-1153	1.000
:Event_0000049	canonical_mention.actual	"wounded"	libyawar_cnn__1000-01-01__timeline:1147-1153	1.000
:Event_0000049	Life.Injure_Victim.actual	:Entity_EDL_0000078	libyawar_cnn__1000-01-01__timeline:1139-1141	1.000
:Event_0000050	type	Movement.TransportPerson
:Event_0000050	mention.actual	"bursts into"	libyawar_cnn__1000-01-01__timeline:5883-5893	1.000
:Event_0000050	canonical_mention.actual	"bursts into"	libyawar_cnn__1000-01-01__timeline:5883-5893	1.000
:Event_0000050	Movement.TransportPerson_Agent.actual	:Entity_EDL_0000002	libyawar_cnn__1000-01-01__timeline:5846-5850	1.000
:Event_0000050	Movement.TransportPerson_Destination.actual	:Entity_EDL_0000027	libyawar_cnn__1000-01-01__timeline:5905-5909	1.000
:Event_0000051	type	Conflict.Attack
:Event_0000051	mention.actual	"hit"	libyawar_cnn__1000-01-01__timeline:5052-5054	1.000
:Event_0000051	canonical_mention.actual	"hit"	libyawar_cnn__1000-01-01__timeline:5052-5054	1.000
:Event_0000051	Conflict.Attack_Instrument.actual	:Entity_EDL_0000075	libyawar_cnn__1000-01-01__timeline:4990-4997	1.000
:Event_0000052	type	Conflict.Attack
:Event_0000052	mention.actual	"campaign"	libyawar_cnn__1000-01-01__timeline:11550-11557	1.000
:Event_0000052	canonical_mention.actual	"campaign"	libyawar_cnn__1000-01-01__timeline:11550-11557	1.000
:Event_0000052	Conflict.Attack_Place.actual	:Entity_EDL_0000113	libyawar_cnn__1000-01-01__timeline:11517-11523	1.000
:Event_0000052	Conflict.Attack_Attacker.actual	:Entity_EDL_0000116	libyawar_cnn__1000-01-01__timeline:11541-11544	1.000
:Event_0000053	type	Movement.TransportArtifact
:Event_0000053	mention.actual	"arrives"	libyawar_cnn__1000-01-01__timeline:6638-6644	1.000
:Event_0000053	canonical_mention.actual	"arrives"	libyawar_cnn__1000-01-01__timeline:6638-6644	1.000
:Event_0000053	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000028	libyawar_cnn__1000-01-01__timeline:6624-6636	1.000
:Event_0000053	Movement.TransportArtifact_Destination.actual	:Entity_EDL_0000025	libyawar_cnn__1000-01-01__timeline:6653-6666	1.000
:Event_0000054	type	Life.Die
:Event_0000054	mention.actual	"killed"	libyawar_cnn__1000-01-01__timeline:1528-1533	1.000
:Event_0000054	canonical_mention.actual	"killed"	libyawar_cnn__1000-01-01__timeline:1528-1533	1.000
:Event_0000054	Life.Die_Victim.actual	:Entity_EDL_0000110	libyawar_cnn__1000-01-01__timeline:1511-1516	1.000
:Event_0000054	Life.Die_Place.actual	:Entity_EDL_0000074	libyawar_cnn__1000-01-01__timeline:1538-1543	1.000
:Event_0000055	type	Personnel.EndPosition
:Event_0000055	mention.actual	"resigned"	libyawar_cnn__1000-01-01__timeline:6711-6718	1.000
:Event_0000055	canonical_mention.actual	"resigned"	libyawar_cnn__1000-01-01__timeline:6711-6718	1.000
:Event_0000055	Personnel.EndPosition_Person.actual	:Entity_EDL_0000061	libyawar_cnn__1000-01-01__timeline:6704-6705	1.000
:Event_0000056	type	Conflict.Attack
:Event_0000056	mention.actual	"assassinations"	libyawar_cnn__1000-01-01__timeline:8820-8833	1.000
:Event_0000056	canonical_mention.actual	"assassinations"	libyawar_cnn__1000-01-01__timeline:8820-8833	1.000
:Event_0000057	type	Conflict.Attack
:Event_0000057	mention.actual	"battle"	libyawar_cnn__1000-01-01__timeline:11063-11068	1.000
:Event_0000057	canonical_mention.actual	"battle"	libyawar_cnn__1000-01-01__timeline:11063-11068	1.000
:Event_0000057	Conflict.Attack_Attacker.actual	:Entity_EDL_0000015	libyawar_cnn__1000-01-01__timeline:11017-11024	1.000
:Event_0000058	type	Conflict.Attack
:Event_0000058	mention.actual	"strikes"	libyawar_cnn__1000-01-01__timeline:10319-10325	1.000
:Event_0000058	canonical_mention.actual	"strikes"	libyawar_cnn__1000-01-01__timeline:10319-10325	1.000
:Event_0000059	type	Personnel.EndPosition
:Event_0000059	mention.actual	"former"	libyawar_cnn__1000-01-01__timeline:3405-3410	1.000
:Event_0000059	canonical_mention.actual	"former"	libyawar_cnn__1000-01-01__timeline:3405-3410	1.000
:Event_0000059	Personnel.EndPosition_Organization.actual	:Entity_EDL_0000040	libyawar_cnn__1000-01-01__timeline:3412-3418	1.000
:Event_0000059	Personnel.EndPosition_Person.actual	:Entity_EDL_0000084	libyawar_cnn__1000-01-01__timeline:3429-3447	1.000
:Event_0000060	type	Justice.ArrestJail
:Event_0000060	mention.actual	"arrested"	libyawar_cnn__1000-01-01__timeline:509-516	1.000
:Event_0000060	canonical_mention.actual	"arrested"	libyawar_cnn__1000-01-01__timeline:509-516	1.000
:Event_0000060	Justice.ArrestJail_Person.actual	:Entity_EDL_0000033	libyawar_cnn__1000-01-01__timeline:489-495	1.000
:Event_0000061	type	Movement.TransportPerson
:Event_0000061	mention.actual	"travel"	libyawar_cnn__1000-01-01__timeline:3197-3202	1.000
:Event_0000061	canonical_mention.actual	"travel"	libyawar_cnn__1000-01-01__timeline:3197-3202	1.000
:Event_0000061	Movement.TransportPerson_Person.actual	:Entity_EDL_0000062	libyawar_cnn__1000-01-01__timeline:3229-3238	1.000
:Event_0000062	type	Conflict.Demonstrate
:Event_0000062	mention.actual	"demonstrations"	libyawar_cnn__1000-01-01__timeline:113-126	1.000
:Event_0000062	canonical_mention.actual	"demonstrations"	libyawar_cnn__1000-01-01__timeline:113-126	1.000
:Event_0000062	Conflict.Demonstrate_Place.actual	:Entity_EDL_0000032	libyawar_cnn__1000-01-01__timeline:131-135	1.000
:Event_0000063	type	Life.Injure
:Event_0000063	mention.actual	"injury"	libyawar_cnn__1000-01-01__timeline:1291-1296	1.000
:Event_0000063	canonical_mention.actual	"injury"	libyawar_cnn__1000-01-01__timeline:1291-1296	1.000
:Event_0000064	type	Business.Start
:Event_0000064	mention.actual	"opens"	libyawar_cnn__1000-01-01__timeline:8278-8282	1.000
:Event_0000064	canonical_mention.actual	"opens"	libyawar_cnn__1000-01-01__timeline:8278-8282	1.000
:Event_0000064	Business.Start_Agent.actual	:Entity_EDL_0000069	libyawar_cnn__1000-01-01__timeline:8263-8276	1.000
:Event_0000064	Business.Start_Organization.actual	:Entity_EDL_0000101	libyawar_cnn__1000-01-01__timeline:8287-8292	1.000
:Event_0000064	Business.Start_Place.actual	:Entity_EDL_0000034	libyawar_cnn__1000-01-01__timeline:8319-8322	1.000
:Event_0000065	type	Movement.TransportArtifact
:Event_0000065	mention.actual	"taken"	libyawar_cnn__1000-01-01__timeline:5969-5973	1.000
:Event_0000065	canonical_mention.actual	"taken"	libyawar_cnn__1000-01-01__timeline:5969-5973	1.000
:Event_0000065	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000077	libyawar_cnn__1000-01-01__timeline:5961-5963	1.000
:Event_0000065	Movement.TransportArtifact_Origin.actual	:Entity_EDL_0000107	libyawar_cnn__1000-01-01__timeline:5982-5991	1.000
:Event_0000066	type	Life.Die
:Event_0000066	mention.actual	"death"	libyawar_cnn__1000-01-01__timeline:1281-1285	1.000
:Event_0000066	canonical_mention.actual	"death"	libyawar_cnn__1000-01-01__timeline:1281-1285	1.000
:Event_0000067	type	Conflict.Attack
:Event_0000067	mention.actual	"bombing"	libyawar_cnn__1000-01-01__timeline:7048-7054	1.000
:Event_0000067	canonical_mention.actual	"bombing"	libyawar_cnn__1000-01-01__timeline:7048-7054	1.000
:Event_0000067	Conflict.Attack_Attacker.actual	:Entity_EDL_0000055	libyawar_cnn__1000-01-01__timeline:7043-7046	1.000
:Event_0000067	Conflict.Attack_Target.actual	:Entity_EDL_0000021	libyawar_cnn__1000-01-01__timeline:7072-7078	1.000
:Event_0000068	type	Movement.TransportArtifact
:Event_0000068	mention.actual	"whisk"	libyawar_cnn__1000-01-01__timeline:6186-6190	1.000
:Event_0000068	canonical_mention.actual	"whisk"	libyawar_cnn__1000-01-01__timeline:6186-6190	1.000
:Event_0000068	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000115	libyawar_cnn__1000-01-01__timeline:6160-6168	1.000
:Event_0000068	Movement.TransportArtifact_Agent.actual	:Entity_EDL_0000048	libyawar_cnn__1000-01-01__timeline:6180-6184	1.000
:Event_0000068	Movement.TransportArtifact_Artifact.actual	:Entity_EDL_0000091	libyawar_cnn__1000-01-01__timeline:6192-6194	1.000
:Event_0000068	Movement.TransportArtifact_Instrument.actual	:Entity_EDL_0000012	libyawar_cnn__1000-01-01__timeline:6207-6209	1.000
