:Entity_EDL_0000000	type	Person
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4938-4942	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3251-3255	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3600-3604	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:795-799	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3958-3962	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4352-4356	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1654-1658	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4657-4661	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4109-4113	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5106-5110	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2354-2358	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:795-799	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3680-3684	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4520-4524	1.0
:Entity_EDL_0000000	mention	"Assad"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1912-1916	1.0
:Entity_EDL_0000000	link	30004507
:Entity_EDL_0000001	type	GeopoliticalEntity
:Entity_EDL_0000001	mention	"Syria"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5513-5517	1.0
:Entity_EDL_0000001	mention	"Syrian"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2655-2660	1.0
:Entity_EDL_0000001	mention	"Syria"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:669-673	1.0
:Entity_EDL_0000001	mention	"Syria"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1609-1613	1.0
:Entity_EDL_0000001	mention	"Syria"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2927-2931	1.0
:Entity_EDL_0000001	mention	"Syria"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4304-4308	1.0
:Entity_EDL_0000001	mention	"Syria"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:806-810	1.0
:Entity_EDL_0000001	mention	"Syria"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6191-6195	1.0
:Entity_EDL_0000001	mention	"Syria"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:669-673	1.0
:Entity_EDL_0000001	link	163843
:Entity_EDL_0000002	type	GeopoliticalEntity
:Entity_EDL_0000002	mention	"Damascus"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4489-4496	1.0
:Entity_EDL_0000002	mention	"Damascus"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1420-1427	1.0
:Entity_EDL_0000002	mention	"Damascus"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5757-5764	1.0
:Entity_EDL_0000002	canonical_mention	"Damascus"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:856-863	1.0
:Entity_EDL_0000002	mention	"Damascus"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:856-863	1.0
:Entity_EDL_0000002	mention	"Damascus"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5377-5384	1.0
:Entity_EDL_0000002	mention	"Damascus"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5744-5751	1.0
:Entity_EDL_0000002	mention	"Damascus"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6323-6330	1.0
:Entity_EDL_0000002	mention	"Damascus"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3156-3163	1.0
:Entity_EDL_0000002	mention	"Damascus"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5663-5670	1.0
:Entity_EDL_0000002	link	170654
:Entity_EDL_0000003	type	GeopoliticalEntity
:Entity_EDL_0000003	mention	"Hama"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3744-3747	1.0
:Entity_EDL_0000003	mention	"Hama"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2810-2813	1.0
:Entity_EDL_0000003	canonical_mention	"Hama"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1633-1636	1.0
:Entity_EDL_0000003	mention	"Hama"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1633-1636	1.0
:Entity_EDL_0000003	mention	"Hama"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2001-2004	1.0
:Entity_EDL_0000003	mention	"Hama"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3325-3328	1.0
:Entity_EDL_0000003	canonical_mention	"Hama"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:926-929	1.0
:Entity_EDL_0000003	mention	"Hama"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:926-929	1.0
:Entity_EDL_0000003	canonical_mention	"Hama"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1639-1642	1.0
:Entity_EDL_0000003	mention	"Hama"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1639-1642	1.0
:Entity_EDL_0000003	mention	"Hama"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3855-3858	1.0
:Entity_EDL_0000003	link	170017
:Entity_EDL_0000004	type	Vehicle
:Entity_EDL_0000004	canonical_mention	"Tanks"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:914-918	1.0
:Entity_EDL_0000004	nominal_mention	"Tanks"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:914-918	1.0
:Entity_EDL_0000004	canonical_mention	"tanks"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1989-1993	1.0
:Entity_EDL_0000004	nominal_mention	"tanks"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1989-1993	1.0
:Entity_EDL_0000004	canonical_mention	"tanks"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3313-3317	1.0
:Entity_EDL_0000004	nominal_mention	"tanks"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3313-3317	1.0
:Entity_EDL_0000004	link	NIL000000001
:Entity_EDL_0000005	type	Organization
:Entity_EDL_0000005	canonical_mention	"committee"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:587-595	1.0
:Entity_EDL_0000005	nominal_mention	"committee"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:587-595	1.0
:Entity_EDL_0000005	canonical_mention	"committee"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:279-287	1.0
:Entity_EDL_0000005	nominal_mention	"committee"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:279-287	1.0
:Entity_EDL_0000005	canonical_mention	"committee"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:279-287	1.0
:Entity_EDL_0000005	nominal_mention	"committee"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:279-287	1.0
:Entity_EDL_0000005	link	NIL000000002
:Entity_EDL_0000006	type	Person
:Entity_EDL_0000006	canonical_mention	"15"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:713-714	1.0
:Entity_EDL_0000006	nominal_mention	"15"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:713-714	1.0
:Entity_EDL_0000006	canonical_mention	"15"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:713-714	1.0
:Entity_EDL_0000006	nominal_mention	"15"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:713-714	1.0
:Entity_EDL_0000006	link	NIL000000003
:Entity_EDL_0000007	type	Location
:Entity_EDL_0000007	canonical_mention	"elsewhere"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:716-724	1.0
:Entity_EDL_0000007	pronominal_mention	"elsewhere"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:716-724	1.0
:Entity_EDL_0000007	canonical_mention	"elsewhere"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:716-724	1.0
:Entity_EDL_0000007	pronominal_mention	"elsewhere"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:716-724	1.0
:Entity_EDL_0000007	link	NIL000000004
:Entity_EDL_0000008	type	GeopoliticalEntity
:Entity_EDL_0000008	canonical_mention	"Deraa"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:697-701	1.0
:Entity_EDL_0000008	mention	"Deraa"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:697-701	1.0
:Entity_EDL_0000008	canonical_mention	"Deraa"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:697-701	1.0
:Entity_EDL_0000008	mention	"Deraa"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:697-701	1.0
:Entity_EDL_0000008	link	170905
:Entity_EDL_0000009	type	Person
:Entity_EDL_0000009	canonical_mention	"Adel Safar"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:521-530	1.0
:Entity_EDL_0000009	mention	"Adel Safar"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:521-530	1.0
:Entity_EDL_0000009	canonical_mention	"Adel Safar"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:521-530	1.0
:Entity_EDL_0000009	mention	"Adel Safar"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:521-530	1.0
:Entity_EDL_0000009	link	NIL000000005
:Entity_EDL_0000010	type	Person
:Entity_EDL_0000010	canonical_mention	"Demonstrators"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:640-652	1.0
:Entity_EDL_0000010	nominal_mention	"Demonstrators"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:640-652	1.0
:Entity_EDL_0000010	canonical_mention	"Demonstrators"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:640-652	1.0
:Entity_EDL_0000010	nominal_mention	"Demonstrators"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:640-652	1.0
:Entity_EDL_0000010	link	NIL000000006
:Entity_EDL_0000011	type	GeopoliticalEntity
:Entity_EDL_0000011	canonical_mention	"Homs"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1756-1759	1.0
:Entity_EDL_0000011	mention	"Homs"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1756-1759	1.0
:Entity_EDL_0000011	mention	"Homs"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4207-4210	1.0
:Entity_EDL_0000011	link	169577
:Entity_EDL_0000012	type	Organization
:Entity_EDL_0000012	mention	"Arab League"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2005-2015	1.0
:Entity_EDL_0000012	mention	"Arab League"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5724-5734	1.0
:Entity_EDL_0000012	link	20000138
:Entity_EDL_0000013	type	Person
:Entity_EDL_0000013	canonical_mention	"detainees"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:850-858	1.0
:Entity_EDL_0000013	nominal_mention	"detainees"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:850-858	1.0
:Entity_EDL_0000013	canonical_mention	"detainees"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:850-858	1.0
:Entity_EDL_0000013	nominal_mention	"detainees"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:850-858	1.0
:Entity_EDL_0000013	link	NIL000000007
:Entity_EDL_0000014	type	Organization
:Entity_EDL_0000014	canonical_mention	"military"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3788-3795	1.0
:Entity_EDL_0000014	nominal_mention	"military"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3788-3795	1.0
:Entity_EDL_0000014	canonical_mention	"military"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3977-3984	1.0
:Entity_EDL_0000014	nominal_mention	"military"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3977-3984	1.0
:Entity_EDL_0000014	link	NIL000000008
:Entity_EDL_0000015	type	Person
:Entity_EDL_0000015	canonical_mention	"gunmen"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1098-1103	1.0
:Entity_EDL_0000015	nominal_mention	"gunmen"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1098-1103	1.0
:Entity_EDL_0000015	canonical_mention	"gunmen"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1060-1065	1.0
:Entity_EDL_0000015	nominal_mention	"gunmen"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1060-1065	1.0
:Entity_EDL_0000015	link	NIL000000009
:Entity_EDL_0000016	type	Person
:Entity_EDL_0000016	canonical_mention	"Robert Ford"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2860-2870	1.0
:Entity_EDL_0000016	mention	"Robert Ford"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2860-2870	1.0
:Entity_EDL_0000016	canonical_mention	"Robert Ford"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1686-1696	1.0
:Entity_EDL_0000016	mention	"Robert Ford"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1686-1696	1.0
:Entity_EDL_0000016	link	NIL000000010
:Entity_EDL_0000017	type	Person
:Entity_EDL_0000017	canonical_mention	"intellectuals"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2375-2387	1.0
:Entity_EDL_0000017	nominal_mention	"intellectuals"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2375-2387	1.0
:Entity_EDL_0000017	canonical_mention	"intellectuals"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1474-1486	1.0
:Entity_EDL_0000017	nominal_mention	"intellectuals"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1474-1486	1.0
:Entity_EDL_0000017	link	NIL000000011
:Entity_EDL_0000018	type	Organization
:Entity_EDL_0000018	canonical_mention	"groups"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3016-3021	1.0
:Entity_EDL_0000018	nominal_mention	"groups"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3016-3021	1.0
:Entity_EDL_0000018	canonical_mention	"groups"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1842-1847	1.0
:Entity_EDL_0000018	nominal_mention	"groups"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1842-1847	1.0
:Entity_EDL_0000018	link	NIL000000012
:Entity_EDL_0000019	type	GeopoliticalEntity
:Entity_EDL_0000019	mention	"Turkey"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3193-3198	1.0
:Entity_EDL_0000019	mention	"Turkey"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2006-2011	1.0
:Entity_EDL_0000019	link	298795
:Entity_EDL_0000020	type	Person
:Entity_EDL_0000020	canonical_mention	"Eric Chevallier"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1720-1734	1.0
:Entity_EDL_0000020	mention	"Eric Chevallier"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1720-1734	1.0
:Entity_EDL_0000020	canonical_mention	"Eric Chevallier"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2894-2908	1.0
:Entity_EDL_0000020	mention	"Eric Chevallier"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2894-2908	1.0
:Entity_EDL_0000020	link	NIL000000013
:Entity_EDL_0000021	type	Organization
:Entity_EDL_0000021	mention	"U.N"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1943-1945	1.0
:Entity_EDL_0000021	canonical_mention	"United Nations"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1990-2003	1.0
:Entity_EDL_0000021	mention	"United Nations"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1990-2003	1.0
:Entity_EDL_0000021	link	20000193
:Entity_EDL_0000022	type	Person
:Entity_EDL_0000022	canonical_mention	"Thousands"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2791-2799	1.0
:Entity_EDL_0000022	pronominal_mention	"Thousands"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2791-2799	1.0
:Entity_EDL_0000022	canonical_mention	"Thousands"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1620-1628	1.0
:Entity_EDL_0000022	pronominal_mention	"Thousands"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1620-1628	1.0
:Entity_EDL_0000022	link	NIL000000014
:Entity_EDL_0000023	type	Person
:Entity_EDL_0000023	canonical_mention	"relatives"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:128-136	1.0
:Entity_EDL_0000023	nominal_mention	"relatives"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:128-136	1.0
:Entity_EDL_0000023	canonical_mention	"relatives"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:128-136	1.0
:Entity_EDL_0000023	nominal_mention	"relatives"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:128-136	1.0
:Entity_EDL_0000023	link	NIL000000015
:Entity_EDL_0000024	type	GeopoliticalEntity
:Entity_EDL_0000024	mention	"Jisr al-Shughour"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1955-1970	1.0
:Entity_EDL_0000024	link	169023
:Entity_EDL_0000025	type	Person
:Entity_EDL_0000025	nominal_mention	"forces"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4180-4185	0.000
:Entity_EDL_0000025	link	NIL000000016
:Entity_EDL_0000026	type	Person
:Entity_EDL_0000026	canonical_mention	"people"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:158-163	1.0
:Entity_EDL_0000026	nominal_mention	"people"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:158-163	1.0
:Entity_EDL_0000026	link	NIL000000017
:Entity_EDL_0000027	type	Person
:Entity_EDL_0000027	canonical_mention	"protester"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:834-842	1.0
:Entity_EDL_0000027	nominal_mention	"protester"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:834-842	1.0
:Entity_EDL_0000027	link	NIL000000018
:Entity_EDL_0000028	type	GeopoliticalEntity
:Entity_EDL_0000028	canonical_mention	"country"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4522-4528	1.0
:Entity_EDL_0000028	nominal_mention	"country"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4522-4528	1.0
:Entity_EDL_0000028	link	NIL000000019
:Entity_EDL_0000029	type	Organization
:Entity_EDL_0000029	nominal_mention	"government"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3046-3055	0.000
:Entity_EDL_0000029	link	NIL000000020
:Entity_EDL_0000030	type	Person
:Entity_EDL_0000030	canonical_mention	"troops"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3700-3705	1.0
:Entity_EDL_0000030	nominal_mention	"troops"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3700-3705	1.0
:Entity_EDL_0000030	link	NIL000000021
:Entity_EDL_0000031	type	Organization
:Entity_EDL_0000031	canonical_mention	"unit"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4736-4739	1.0
:Entity_EDL_0000031	nominal_mention	"unit"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4736-4739	1.0
:Entity_EDL_0000031	link	NIL000000022
:Entity_EDL_0000032	type	Location
:Entity_EDL_0000032	canonical_mention	"area"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6476-6479	1.0
:Entity_EDL_0000032	nominal_mention	"area"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6476-6479	1.0
:Entity_EDL_0000032	link	NIL000000023
:Entity_EDL_0000033	type	Person
:Entity_EDL_0000033	nominal_mention	"people"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:2077-2082	1.0
:Entity_EDL_0000033	link	NIL000000024
:Entity_EDL_0000034	type	GeopoliticalEntity
:Entity_EDL_0000034	nominal_mention	"suburb"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6565-6570	1.0
:Entity_EDL_0000034	link	NIL000000025
:Entity_EDL_0000035	type	Facility
:Entity_EDL_0000035	canonical_mention	"barracks"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5525-5532	1.0
:Entity_EDL_0000035	nominal_mention	"barracks"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5525-5532	1.0
:Entity_EDL_0000035	link	NIL000000026
:Entity_EDL_0000036	type	GeopoliticalEntity
:Entity_EDL_0000036	canonical_mention	"Cairo"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6155-6159	1.0
:Entity_EDL_0000036	mention	"Cairo"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6155-6159	1.0
:Entity_EDL_0000036	link	360630
:Entity_EDL_0000037	type	Person
:Entity_EDL_0000037	canonical_mention	"rebel"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5656-5660	1.0
:Entity_EDL_0000037	nominal_mention	"rebel"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5656-5660	1.0
:Entity_EDL_0000037	link	NIL000000027
:Entity_EDL_0000038	type	Person
:Entity_EDL_0000038	nominal_mention	"officials"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5731-5739	1.0
:Entity_EDL_0000038	link	NIL000000028
:Entity_EDL_0000039	type	GeopoliticalEntity
:Entity_EDL_0000039	pronominal_mention	"it"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6119-6120	1.0
:Entity_EDL_0000039	link	NIL000000029
:Entity_EDL_0000040	type	Organization
:Entity_EDL_0000040	nominal_mention	"government"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1872-1881	0.000
:Entity_EDL_0000040	link	NIL000000030
:Entity_EDL_0000041	type	Weapon
:Entity_EDL_0000041	canonical_mention	"grenades"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5624-5631	1.0
:Entity_EDL_0000041	nominal_mention	"grenades"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5624-5631	1.0
:Entity_EDL_0000041	link	NIL000000031
:Entity_EDL_0000042	type	Organization
:Entity_EDL_0000042	canonical_mention	"National Salvation Council"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3211-3236	1.0
:Entity_EDL_0000042	mention	"National Salvation Council"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3211-3236	1.0
:Entity_EDL_0000042	link	NIL000000032
:Entity_EDL_0000043	type	Person
:Entity_EDL_0000043	canonical_mention	"people"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:158-163	1.0
:Entity_EDL_0000043	nominal_mention	"people"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:158-163	1.0
:Entity_EDL_0000043	link	NIL000000033
:Entity_EDL_0000044	type	Person
:Entity_EDL_0000044	nominal_mention	"activists"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5280-5288	1.0
:Entity_EDL_0000044	link	NIL000000034
:Entity_EDL_0000045	type	Person
:Entity_EDL_0000045	canonical_mention	"Daoud Rajha"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5776-5786	1.0
:Entity_EDL_0000045	mention	"Daoud Rajha"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5776-5786	1.0
:Entity_EDL_0000045	link	NIL000000035
:Entity_EDL_0000046	type	Person
:Entity_EDL_0000046	canonical_mention	"defectors"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5266-5274	1.0
:Entity_EDL_0000046	nominal_mention	"defectors"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5266-5274	1.0
:Entity_EDL_0000046	link	NIL000000036
:Entity_EDL_0000047	type	Person
:Entity_EDL_0000047	nominal_mention	"forces"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3530-3535	0.000
:Entity_EDL_0000047	link	NIL000000037
:Entity_EDL_0000048	type	Person
:Entity_EDL_0000048	nominal_mention	"people"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3401-3406	1.0
:Entity_EDL_0000048	link	NIL000000038
:Entity_EDL_0000049	type	Organization
:Entity_EDL_0000049	nominal_mention	"television"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5093-5102	1.0
:Entity_EDL_0000049	link	NIL000000039
:Entity_EDL_0000050	type	GeopoliticalEntity
:Entity_EDL_0000050	mention	"Geneva"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5457-5462	1.0
:Entity_EDL_0000050	link	2660646
:Entity_EDL_0000051	type	Person
:Entity_EDL_0000051	nominal_mention	"people"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:218-223	1.0
:Entity_EDL_0000051	link	NIL000000040
:Entity_EDL_0000052	type	Person
:Entity_EDL_0000052	nominal_mention	"people"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3335-3340	1.0
:Entity_EDL_0000052	link	NIL000000041
:Entity_EDL_0000053	type	Location
:Entity_EDL_0000053	canonical_mention	"district"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2568-2575	1.0
:Entity_EDL_0000053	nominal_mention	"district"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2568-2575	1.0
:Entity_EDL_0000053	link	NIL000000042
:Entity_EDL_0000054	type	GeopoliticalEntity
:Entity_EDL_0000054	mention	"Latakia"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3928-3934	1.0
:Entity_EDL_0000054	link	173576
:Entity_EDL_0000055	type	GeopoliticalEntity
:Entity_EDL_0000055	pronominal_mention	"It"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6263-6264	1.0
:Entity_EDL_0000055	link	NIL000000043
:Entity_EDL_0000056	type	GeopoliticalEntity
:Entity_EDL_0000056	canonical_mention	"towns"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6159-6163	1.0
:Entity_EDL_0000056	nominal_mention	"towns"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6159-6163	1.0
:Entity_EDL_0000056	link	NIL000000044
:Entity_EDL_0000057	type	GeopoliticalEntity
:Entity_EDL_0000057	canonical_mention	"Nawa"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:419-422	1.0
:Entity_EDL_0000057	mention	"Nawa"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:419-422	1.0
:Entity_EDL_0000057	link	166365
:Entity_EDL_0000058	type	Person
:Entity_EDL_0000058	canonical_mention	"protesters"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:86-95	1.0
:Entity_EDL_0000058	nominal_mention	"protesters"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:86-95	1.0
:Entity_EDL_0000058	link	NIL000000045
:Entity_EDL_0000059	type	Person
:Entity_EDL_0000059	canonical_mention	"Elaraby"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4710-4716	1.0
:Entity_EDL_0000059	mention	"Elaraby"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4710-4716	1.0
:Entity_EDL_0000059	link	NIL000000046
:Entity_EDL_0000060	type	Person
:Entity_EDL_0000060	canonical_mention	"Ahmet Davutoglu"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3647-3661	1.0
:Entity_EDL_0000060	mention	"Ahmet Davutoglu"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3647-3661	1.0
:Entity_EDL_0000060	link	30004832
:Entity_EDL_0000061	type	Organization
:Entity_EDL_0000061	nominal_mention	"government"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:580-589	1.0
:Entity_EDL_0000061	link	NIL000000047
:Entity_EDL_0000062	type	Person
:Entity_EDL_0000062	nominal_mention	"protesters"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4326-4335	1.0
:Entity_EDL_0000062	link	NIL000000048
:Entity_EDL_0000063	type	GeopoliticalEntity
:Entity_EDL_0000063	nominal_mention	"city"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1863-1866	0.000
:Entity_EDL_0000063	link	NIL000000049
:Entity_EDL_0000064	type	Weapon
:Entity_EDL_0000064	canonical_mention	"weapons"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6148-6154	1.0
:Entity_EDL_0000064	nominal_mention	"weapons"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6148-6154	1.0
:Entity_EDL_0000064	link	NIL000000050
:Entity_EDL_0000065	type	Location
:Entity_EDL_0000065	canonical_mention	"edge"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4938-4941	1.0
:Entity_EDL_0000065	nominal_mention	"edge"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4938-4941	1.0
:Entity_EDL_0000065	link	NIL000000051
:Entity_EDL_0000066	type	Person
:Entity_EDL_0000066	canonical_mention	"Riyad Hijab"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3985-3995	1.0
:Entity_EDL_0000066	mention	"Riyad Hijab"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3985-3995	1.0
:Entity_EDL_0000066	link	NIL000000052
:Entity_EDL_0000067	type	Person
:Entity_EDL_0000067	nominal_mention	"people"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4277-4282	1.0
:Entity_EDL_0000067	link	NIL000000053
:Entity_EDL_0000068	type	Facility
:Entity_EDL_0000068	canonical_mention	"building"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5651-5658	1.0
:Entity_EDL_0000068	nominal_mention	"building"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5651-5658	1.0
:Entity_EDL_0000068	link	NIL000000054
:Entity_EDL_0000069	type	Person
:Entity_EDL_0000069	canonical_mention	"crowd"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6524-6528	1.0
:Entity_EDL_0000069	nominal_mention	"crowd"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6524-6528	1.0
:Entity_EDL_0000069	link	NIL000000055
:Entity_EDL_0000070	type	Person
:Entity_EDL_0000070	nominal_mention	"figures"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2531-2537	1.0
:Entity_EDL_0000070	link	NIL000000056
:Entity_EDL_0000071	type	Weapon
:Entity_EDL_0000071	canonical_mention	"Bomb"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5673-5676	1.0
:Entity_EDL_0000071	nominal_mention	"Bomb"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5673-5676	1.0
:Entity_EDL_0000071	link	NIL000000057
:Entity_EDL_0000072	type	GeopoliticalEntity
:Entity_EDL_0000072	canonical_mention	"capital"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5440-5446	1.0
:Entity_EDL_0000072	nominal_mention	"capital"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5440-5446	1.0
:Entity_EDL_0000072	link	NIL000000058
:Entity_EDL_0000073	type	Person
:Entity_EDL_0000073	nominal_mention	"protesters"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1100-1109	1.0
:Entity_EDL_0000073	link	NIL000000059
:Entity_EDL_0000074	type	Person
:Entity_EDL_0000074	nominal_mention	"representatives"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4724-4738	1.0
:Entity_EDL_0000074	link	NIL000000060
:Entity_EDL_0000075	type	Person
:Entity_EDL_0000075	nominal_mention	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1591-1600	1.0
:Entity_EDL_0000075	link	NIL000000061
:Entity_EDL_0000076	type	Person
:Entity_EDL_0000076	nominal_mention	"forces"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1087-1092	1.0
:Entity_EDL_0000076	link	NIL000000062
:Entity_EDL_0000077	type	GeopoliticalEntity
:Entity_EDL_0000077	nominal_mention	"town"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1722-1725	1.0
:Entity_EDL_0000077	link	NIL000000063
:Entity_EDL_0000078	type	Person
:Entity_EDL_0000078	canonical_mention	"Rebels"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2527-2532	1.0
:Entity_EDL_0000078	nominal_mention	"Rebels"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2527-2532	1.0
:Entity_EDL_0000078	link	NIL000000064
:Entity_EDL_0000079	type	Location
:Entity_EDL_0000079	nominal_mention	"region"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3501-3506	0.000
:Entity_EDL_0000079	link	NIL000000065
:Entity_EDL_0000080	type	Person
:Entity_EDL_0000080	nominal_mention	"forces"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:200-205	1.0
:Entity_EDL_0000080	link	NIL000000066
:Entity_EDL_0000081	type	Person
:Entity_EDL_0000081	nominal_mention	"forces"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1880-1885	1.0
:Entity_EDL_0000081	link	NIL000000067
:Entity_EDL_0000082	type	Person
:Entity_EDL_0000082	canonical_mention	"activists"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1067-1075	1.0
:Entity_EDL_0000082	nominal_mention	"activists"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1067-1075	1.0
:Entity_EDL_0000082	link	NIL000000068
:Entity_EDL_0000083	type	Person
:Entity_EDL_0000083	canonical_mention	"Mohammad Ibrahim al-Shaar"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5932-5956	1.0
:Entity_EDL_0000083	mention	"Mohammad Ibrahim al-Shaar"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5932-5956	1.0
:Entity_EDL_0000083	link	NIL000000069
:Entity_EDL_0000084	type	Person
:Entity_EDL_0000084	nominal_mention	"people"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:393-398	1.0
:Entity_EDL_0000084	link	NIL000000070
:Entity_EDL_0000085	type	Person
:Entity_EDL_0000085	canonical_mention	"Kofi Annan"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1966-1975	1.0
:Entity_EDL_0000085	mention	"Kofi Annan"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1966-1975	1.0
:Entity_EDL_0000085	link	NIL000000071
:Entity_EDL_0000086	type	Person
:Entity_EDL_0000086	nominal_mention	"people"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1442-1447	1.0
:Entity_EDL_0000086	link	NIL000000072
:Entity_EDL_0000087	type	Person
:Entity_EDL_0000087	nominal_mention	"forces"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1567-1572	1.0
:Entity_EDL_0000087	link	NIL000000073
:Entity_EDL_0000088	type	GeopoliticalEntity
:Entity_EDL_0000088	nominal_mention	"suburb"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6059-6064	1.0
:Entity_EDL_0000088	link	NIL000000074
:Entity_EDL_0000089	type	Organization
:Entity_EDL_0000089	canonical_mention	"Human Rights Council"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5410-5429	1.0
:Entity_EDL_0000089	mention	"Human Rights Council"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5410-5429	1.0
:Entity_EDL_0000089	link	NIL000000075
:Entity_EDL_0000090	type	Person
:Entity_EDL_0000090	nominal_mention	"minister"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:555-562	1.0
:Entity_EDL_0000090	link	NIL000000076
:Entity_EDL_0000091	type	Facility
:Entity_EDL_0000091	canonical_mention	"consulates"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4521-4530	1.0
:Entity_EDL_0000091	nominal_mention	"consulates"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4521-4530	1.0
:Entity_EDL_0000091	link	NIL000000077
:Entity_EDL_0000092	type	Person
:Entity_EDL_0000092	nominal_mention	"people"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4695-4700	1.0
:Entity_EDL_0000092	link	NIL000000078
:Entity_EDL_0000093	type	Person
:Entity_EDL_0000093	nominal_mention	"people"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3754-3759	1.0
:Entity_EDL_0000093	link	NIL000000079
:Entity_EDL_0000094	type	Person
:Entity_EDL_0000094	nominal_mention	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2945-2954	1.0
:Entity_EDL_0000094	link	NIL000000080
:Entity_EDL_0000095	type	GeopoliticalEntity
:Entity_EDL_0000095	canonical_mention	"Tunis"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2135-2139	1.0
:Entity_EDL_0000095	mention	"Tunis"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2135-2139	1.0
:Entity_EDL_0000095	link	2464470
:Entity_EDL_0000096	type	Person
:Entity_EDL_0000096	nominal_mention	"ministers"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5701-5709	1.0
:Entity_EDL_0000096	link	NIL000000081
:Entity_EDL_0000097	type	Person
:Entity_EDL_0000097	nominal_mention	"people"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1735-1740	1.0
:Entity_EDL_0000097	link	NIL000000082
:Entity_EDL_0000098	type	Person
:Entity_EDL_0000098	canonical_mention	"Crowds"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4446-4451	1.0
:Entity_EDL_0000098	nominal_mention	"Crowds"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4446-4451	1.0
:Entity_EDL_0000098	link	NIL000000083
:Entity_EDL_0000099	type	GeopoliticalEntity
:Entity_EDL_0000099	mention	"Houla"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3631-3635	1.0
:Entity_EDL_0000099	link	11287703
:Entity_EDL_0000100	type	Person
:Entity_EDL_0000100	nominal_mention	"people"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5127-5132	1.0
:Entity_EDL_0000100	link	NIL000000084
:Entity_EDL_0000101	type	Person
:Entity_EDL_0000101	canonical_mention	"soldiers"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6420-6427	1.0
:Entity_EDL_0000101	nominal_mention	"soldiers"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6420-6427	1.0
:Entity_EDL_0000101	link	NIL000000085
:Entity_EDL_0000102	type	Person
:Entity_EDL_0000102	nominal_mention	"people"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3828-3833	1.0
:Entity_EDL_0000102	link	NIL000000086
:Entity_EDL_0000103	type	Person
:Entity_EDL_0000103	nominal_mention	"people"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5486-5491	1.0
:Entity_EDL_0000103	link	NIL000000087
:Entity_EDL_0000104	type	Person
:Entity_EDL_0000104	nominal_mention	"forces"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1049-1054	1.0
:Entity_EDL_0000104	link	NIL000000088
:Entity_EDL_0000105	type	Person
:Entity_EDL_0000105	nominal_mention	"voters"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2938-2943	1.0
:Entity_EDL_0000105	link	NIL000000089
:Entity_EDL_0000106	type	GeopoliticalEntity
:Entity_EDL_0000106	canonical_mention	"al-Ghouta"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6461-6469	1.0
:Entity_EDL_0000106	mention	"al-Ghouta"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6461-6469	1.0
:Entity_EDL_0000106	link	173866
:Entity_EDL_0000107	type	Person
:Entity_EDL_0000107	nominal_mention	"people"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:680-685	1.0
:Entity_EDL_0000107	link	NIL000000090
:Entity_EDL_0000108	type	Organization
:Entity_EDL_0000108	mention	"al Qaeda"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3266-3273	1.0
:Entity_EDL_0000108	link	NIL000000091
:Entity_EDL_0000109	type	Facility
:Entity_EDL_0000109	canonical_mention	"Marjeh Square"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:53-65	1.0
:Entity_EDL_0000109	mention	"Marjeh Square"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:53-65	1.0
:Entity_EDL_0000109	link	NIL000000092
:Entity_EDL_0000110	type	Location
:Entity_EDL_0000110	nominal_mention	"Deraa"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:256-260	1.0
:Entity_EDL_0000110	link	NIL000000093
:Entity_EDL_0000111	type	Person
:Entity_EDL_0000111	canonical_mention	"people"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:22-27	1.0
:Entity_EDL_0000111	nominal_mention	"people"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:22-27	1.0
:Entity_EDL_0000111	link	NIL000000094
:Entity_EDL_0000112	type	Person
:Entity_EDL_0000112	canonical_mention	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:86-95	1.0
:Entity_EDL_0000112	nominal_mention	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:86-95	1.0
:Entity_EDL_0000112	link	NIL000000095
:Entity_EDL_0000113	type	Person
:Entity_EDL_0000113	canonical_mention	"opposition"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3169-3178	1.0
:Entity_EDL_0000113	nominal_mention	"opposition"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3169-3178	1.0
:Entity_EDL_0000113	link	NIL000000096
:Entity_EDL_0000114	type	Person
:Entity_EDL_0000114	nominal_mention	"forces"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:5996-6001	1.0
:Entity_EDL_0000114	link	NIL000000097
:Entity_EDL_0000115	type	Person
:Entity_EDL_0000115	canonical_mention	"children"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3472-3479	1.0
:Entity_EDL_0000115	nominal_mention	"children"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3472-3479	1.0
:Entity_EDL_0000115	link	NIL000000098
:Entity_EDL_0000116	type	Person
:Entity_EDL_0000116	nominal_mention	"rebels"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4666-4671	1.0
:Entity_EDL_0000116	link	NIL000000099
:Entity_EDL_0000117	type	Person
:Entity_EDL_0000117	nominal_mention	"militiamen"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5101-5110	1.0
:Entity_EDL_0000117	link	NIL000000100
:Entity_EDL_0000118	type	GeopoliticalEntity
:Entity_EDL_0000118	canonical_mention	"Deraa"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:409-413	1.0
:Entity_EDL_0000118	mention	"Deraa"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:409-413	1.0
:Entity_EDL_0000118	link	170905
:Entity_EDL_0000119	type	GeopoliticalEntity
:Entity_EDL_0000119	canonical_mention	"Paris"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4626-4630	1.0
:Entity_EDL_0000119	mention	"Paris"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4626-4630	1.0
:Entity_EDL_0000119	link	2988507
:Entity_EDL_0000120	type	Person
:Entity_EDL_0000120	canonical_mention	"journalists"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1783-1793	1.0
:Entity_EDL_0000120	nominal_mention	"journalists"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1783-1793	1.0
:Entity_EDL_0000120	link	NIL000000101
:Entity_EDL_0000121	type	Person
:Entity_EDL_0000121	nominal_mention	"ministers"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:2089-2097	1.0
:Entity_EDL_0000121	link	NIL000000102
:Entity_EDL_0000122	type	Vehicle
:Entity_EDL_0000122	nominal_mention	"Tanks"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3909-3913	1.0
:Entity_EDL_0000122	link	NIL000000103
:Entity_EDL_0000123	type	Person
:Entity_EDL_0000123	canonical_mention	"Ban Ki-moon"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4080-4090	1.0
:Entity_EDL_0000123	mention	"Ban Ki-moon"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4080-4090	1.0
:Entity_EDL_0000123	link	NIL000000104
:Entity_EDL_0000124	type	Person
:Entity_EDL_0000124	nominal_mention	"envoy"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:3722-3726	1.0
:Entity_EDL_0000124	link	NIL000000105
:Entity_EDL_0000125	type	Weapon
:Entity_EDL_0000125	canonical_mention	"gun"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6403-6405	1.0
:Entity_EDL_0000125	nominal_mention	"gun"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6403-6405	1.0
:Entity_EDL_0000125	link	NIL000000106
:Entity_EDL_0000126	type	Facility
:Entity_EDL_0000126	canonical_mention	"Marjeh Square"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:53-65	1.0
:Entity_EDL_0000126	mention	"Marjeh Square"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:53-65	1.0
:Entity_EDL_0000126	link	NIL000000107
:Entity_EDL_0000127	type	Person
:Entity_EDL_0000127	nominal_mention	"people"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:989-994	1.0
:Entity_EDL_0000127	link	NIL000000108
:Entity_EDL_0000128	type	Person
:Entity_EDL_0000128	nominal_mention	"forces"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6390-6395	1.0
:Entity_EDL_0000128	link	NIL000000109
:Entity_EDL_0000129	type	Person
:Entity_EDL_0000129	nominal_mention	"troops"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4339-4344	1.0
:Entity_EDL_0000129	link	NIL000000110
:Entity_EDL_0000130	type	Organization
:Entity_EDL_0000130	canonical_mention	"parliament"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3587-3596	1.0
:Entity_EDL_0000130	nominal_mention	"parliament"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3587-3596	1.0
:Entity_EDL_0000130	link	NIL000000111
:Entity_EDL_0000131	type	Person
:Entity_EDL_0000131	canonical_mention	"militiamen"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3711-3720	1.0
:Entity_EDL_0000131	nominal_mention	"militiamen"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3711-3720	1.0
:Entity_EDL_0000131	link	NIL000000112
:Entity_EDL_0000132	type	Location
:Entity_EDL_0000132	nominal_mention	"district"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5624-5631	1.0
:Entity_EDL_0000132	link	NIL000000113
:Entity_EDL_0000133	type	GeopoliticalEntity
:Entity_EDL_0000133	canonical_mention	"Old Damascus"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:47-58	1.0
:Entity_EDL_0000133	mention	"Old Damascus"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:47-58	1.0
:Entity_EDL_0000133	link	4214047
:Entity_EDL_0000134	type	Facility
:Entity_EDL_0000134	canonical_mention	"buildings"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1407-1415	1.0
:Entity_EDL_0000134	nominal_mention	"buildings"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1407-1415	1.0
:Entity_EDL_0000134	link	NIL000000114
:Entity_EDL_0000135	type	Facility
:Entity_EDL_0000135	canonical_mention	"headquarters"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6201-6212	1.0
:Entity_EDL_0000135	nominal_mention	"headquarters"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:6201-6212	1.0
:Entity_EDL_0000135	link	NIL000000115
:Entity_EDL_0000136	type	Person
:Entity_EDL_0000136	canonical_mention	"ministers"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6176-6184	1.0
:Entity_EDL_0000136	nominal_mention	"ministers"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6176-6184	1.0
:Entity_EDL_0000136	link	NIL000000116
:Entity_EDL_0000137	type	Organization
:Entity_EDL_0000137	mention	"Friends of Syria"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4598-4613	1.0
:Entity_EDL_0000137	link	NIL000000117
:Entity_EDL_0000138	type	Person
:Entity_EDL_0000138	nominal_mention	"people"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4197-4202	1.0
:Entity_EDL_0000138	link	NIL000000118
:Entity_EDL_0000139	type	GeopoliticalEntity
:Entity_EDL_0000139	nominal_mention	"city"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:3724-3727	1.0
:Entity_EDL_0000139	link	NIL000000119
:Entity_EDL_0000140	type	Person
:Entity_EDL_0000140	nominal_mention	"troops"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5080-5085	1.0
:Entity_EDL_0000140	link	NIL000000120
:Entity_EDL_0000141	type	Organization
:Entity_EDL_0000141	nominal_mention	"government"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:580-589	1.0
:Entity_EDL_0000141	link	NIL000000121
:Entity_EDL_0000142	type	Facility
:Entity_EDL_0000142	canonical_mention	"embassy"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4478-4484	1.0
:Entity_EDL_0000142	nominal_mention	"embassy"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4478-4484	1.0
:Entity_EDL_0000142	link	NIL000000122
:Entity_EDL_0000143	type	Person
:Entity_EDL_0000143	canonical_mention	"Nabil Elaraby"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6306-6318	1.0
:Entity_EDL_0000143	mention	"Nabil Elaraby"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6306-6318	1.0
:Entity_EDL_0000143	link	NIL000000123
:Entity_EDL_0000144	type	Weapon
:Entity_EDL_0000144	canonical_mention	"bombs"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1381-1385	1.0
:Entity_EDL_0000144	nominal_mention	"bombs"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1381-1385	1.0
:Entity_EDL_0000144	link	NIL000000124
:Entity_EDL_0000145	type	Person
:Entity_EDL_0000145	nominal_mention	"opposition"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4130-4139	0.000
:Entity_EDL_0000145	link	NIL000000125
:Entity_EDL_0000146	type	Person
:Entity_EDL_0000146	canonical_mention	"he"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2149-2150	1.0
:Entity_EDL_0000146	pronominal_mention	"he"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2149-2150	1.0
:Entity_EDL_0000146	link	NIL000000126
:Entity_EDL_0000147	type	Person
:Entity_EDL_0000147	nominal_mention	"people"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:680-685	1.0
:Entity_EDL_0000147	link	NIL000000127
:Entity_EDL_0000148	type	Person
:Entity_EDL_0000148	canonical_mention	"370"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3149-3151	1.0
:Entity_EDL_0000148	pronominal_mention	"370"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3149-3151	1.0
:Entity_EDL_0000148	link	NIL000000128
:Entity_EDL_0000149	type	Person
:Entity_EDL_0000149	nominal_mention	"rebels"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5367-5372	1.0
:Entity_EDL_0000149	link	NIL000000129
:Entity_EDL_0000150	type	Person
:Entity_EDL_0000150	nominal_mention	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1138-1147	1.0
:Entity_EDL_0000150	link	NIL000000130
:Entity_EDL_0000151	type	GeopoliticalEntity
:Entity_EDL_0000151	canonical_mention	"Mazraat al-Qabeer"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3764-3780	1.0
:Entity_EDL_0000151	mention	"Mazraat al-Qabeer"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3764-3780	1.0
:Entity_EDL_0000151	link	NIL000000131
:Entity_EDL_0000152	type	GeopoliticalEntity
:Entity_EDL_0000152	nominal_mention	"village"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5154-5160	1.0
:Entity_EDL_0000152	link	NIL000000132
:Entity_EDL_0000153	type	Person
:Entity_EDL_0000153	nominal_mention	"protesters"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1771-1780	1.0
:Entity_EDL_0000153	link	NIL000000133
:Entity_EDL_0000154	type	Facility
:Entity_EDL_0000154	canonical_mention	"complex"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4923-4929	1.0
:Entity_EDL_0000154	nominal_mention	"complex"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4923-4929	1.0
:Entity_EDL_0000154	link	NIL000000134
:Entity_EDL_0000155	type	Person
:Entity_EDL_0000155	nominal_mention	"minister"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:555-562	1.0
:Entity_EDL_0000155	link	NIL000000135
:Entity_EDL_0000156	type	Person
:Entity_EDL_0000156	nominal_mention	"people"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3437-3442	1.0
:Entity_EDL_0000156	link	NIL000000136
:Entity_EDL_0000157	type	GeopoliticalEntity
:Entity_EDL_0000157	nominal_mention	"city"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:2920-2923	0.000
:Entity_EDL_0000157	link	NIL000000137
:Entity_EDL_0000158	type	Person
:Entity_EDL_0000158	canonical_mention	"defectors"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4880-4888	1.0
:Entity_EDL_0000158	nominal_mention	"defectors"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:4880-4888	1.0
:Entity_EDL_0000158	link	NIL000000138
:Entity_EDL_0000159	type	Person
:Entity_EDL_0000159	pronominal_mention	"his"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5322-5324	1.0
:Entity_EDL_0000159	link	NIL000000139
:Entity_EDL_0000160	type	GeopoliticalEntity
:Entity_EDL_0000160	nominal_mention	"city"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:1746-1749	0.000
:Entity_EDL_0000160	link	NIL000000140
:Entity_EDL_0000161	type	GeopoliticalEntity
:Entity_EDL_0000161	nominal_mention	"city"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:4001-4004	0.000
:Entity_EDL_0000161	link	NIL000000141
:Entity_EDL_0000162	type	Person
:Entity_EDL_0000162	canonical_mention	"bombers"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3106-3112	1.0
:Entity_EDL_0000162	nominal_mention	"bombers"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3106-3112	1.0
:Entity_EDL_0000162	link	NIL000000142
:Entity_EDL_0000163	type	Person
:Entity_EDL_0000163	canonical_mention	"Manaf Tlas"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4710-4719	1.0
:Entity_EDL_0000163	mention	"Manaf Tlas"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4710-4719	1.0
:Entity_EDL_0000163	link	NIL000000143
:Entity_EDL_0000164	type	Vehicle
:Entity_EDL_0000164	canonical_mention	"warplane"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4367-4374	1.0
:Entity_EDL_0000164	nominal_mention	"warplane"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4367-4374	1.0
:Entity_EDL_0000164	link	NIL000000144
:Entity_EDL_0000165	type	Organization
:Entity_EDL_0000165	nominal_mention	"government"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:4011-4020	1.0
:Entity_EDL_0000165	link	NIL000000145
:Entity_EDL_0000166	type	Person
:Entity_EDL_0000166	nominal_mention	"protesters"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:6011-6020	1.0
:Entity_EDL_0000166	link	NIL000000146
:Entity_EDL_0000167	type	Person
:Entity_EDL_0000167	canonical_mention	"residents"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1988-1996	1.0
:Entity_EDL_0000167	nominal_mention	"residents"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1988-1996	1.0
:Entity_EDL_0000167	link	NIL000000147
:Entity_EDL_0000168	type	Person
:Entity_EDL_0000168	canonical_mention	"ambassadors"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5206-5216	1.0
:Entity_EDL_0000168	nominal_mention	"ambassadors"	syriancrisis_reuters_tl2.3.txt__1000-01-01__timeline:5206-5216	1.0
:Entity_EDL_0000168	link	NIL000000148
:Entity_EDL_0000169	type	Vehicle
:Entity_EDL_0000169	canonical_mention	"vehicles"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5347-5354	1.0
:Entity_EDL_0000169	nominal_mention	"vehicles"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:5347-5354	1.0
:Entity_EDL_0000169	link	NIL000000149
:Entity_EDL_0000170	type	Person
:Entity_EDL_0000170	nominal_mention	"people"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:1810-1815	1.0
:Entity_EDL_0000170	link	NIL000000150
:Entity_EDL_0000171	type	Person
:Entity_EDL_0000171	nominal_mention	"people"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3122-3127	1.0
:Entity_EDL_0000171	link	NIL000000151
:Entity_EDL_0000172	type	Weapon
:Entity_EDL_0000172	nominal_mention	"bombs"	syriancrisis_reuters_tl2.2.txt__1000-01-01__timeline:3306-3310	1.0
:Entity_EDL_0000172	link	NIL000000152
:Entity_EDL_0000173	type	Person
:Entity_EDL_0000173	nominal_mention	"members"	syriancrisis_reuters_tl2.1.txt__1000-01-01__timeline:1811-1817	1.0
:Entity_EDL_0000173	link	NIL000000153
