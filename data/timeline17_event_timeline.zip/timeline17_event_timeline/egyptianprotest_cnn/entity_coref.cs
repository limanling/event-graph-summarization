:Entity_EDL_0000000	type	Facility
:Entity_EDL_0000000	mention	"Tahrir Square"	egyptianprotest_cnn__1000-01-01__timeline:3565-3577	1.0
:Entity_EDL_0000000	link	NIL000000001
:Entity_EDL_0000001	type	Organization
:Entity_EDL_0000001	canonical_mention	"businesses"	egyptianprotest_cnn__1000-01-01__timeline:7939-7948	1.0
:Entity_EDL_0000001	nominal_mention	"businesses"	egyptianprotest_cnn__1000-01-01__timeline:7939-7948	1.0
:Entity_EDL_0000001	link	NIL000000002
:Entity_EDL_0000002	type	Person
:Entity_EDL_0000002	canonical_mention	"49"	egyptianprotest_cnn__1000-01-01__timeline:222-223	1.0
:Entity_EDL_0000002	pronominal_mention	"49"	egyptianprotest_cnn__1000-01-01__timeline:222-223	1.0
:Entity_EDL_0000002	link	NIL000000003
:Entity_EDL_0000003	type	Person
:Entity_EDL_0000003	canonical_mention	"administrators"	egyptianprotest_cnn__1000-01-01__timeline:4301-4314	1.0
:Entity_EDL_0000003	nominal_mention	"administrators"	egyptianprotest_cnn__1000-01-01__timeline:4301-4314	1.0
:Entity_EDL_0000003	link	NIL000000004
:Entity_EDL_0000004	type	Facility
:Entity_EDL_0000004	canonical_mention	"street"	egyptianprotest_cnn__1000-01-01__timeline:3534-3539	1.0
:Entity_EDL_0000004	nominal_mention	"street"	egyptianprotest_cnn__1000-01-01__timeline:3534-3539	1.0
:Entity_EDL_0000004	link	NIL000000005
:Entity_EDL_0000005	type	Person
:Entity_EDL_0000005	canonical_mention	"force"	egyptianprotest_cnn__1000-01-01__timeline:4196-4200	1.0
:Entity_EDL_0000005	nominal_mention	"force"	egyptianprotest_cnn__1000-01-01__timeline:4196-4200	1.0
:Entity_EDL_0000005	link	NIL000000006
:Entity_EDL_0000006	type	Facility
:Entity_EDL_0000006	canonical_mention	"newsroom"	egyptianprotest_cnn__1000-01-01__timeline:4245-4252	1.0
:Entity_EDL_0000006	nominal_mention	"newsroom"	egyptianprotest_cnn__1000-01-01__timeline:4245-4252	1.0
:Entity_EDL_0000006	link	NIL000000007
:Entity_EDL_0000007	type	Weapon
:Entity_EDL_0000007	canonical_mention	"Molotov cocktails"	egyptianprotest_cnn__1000-01-01__timeline:3208-3224	1.0
:Entity_EDL_0000007	nominal_mention	"Molotov cocktails"	egyptianprotest_cnn__1000-01-01__timeline:3208-3224	1.0
:Entity_EDL_0000007	link	NIL000000008
:Entity_EDL_0000008	type	GeopoliticalEntity
:Entity_EDL_0000008	mention	"Egypt"	egyptianprotest_cnn__1000-01-01__timeline:5852-5856	1.0
:Entity_EDL_0000008	link	357994
:Entity_EDL_0000009	type	Weapon
:Entity_EDL_0000009	canonical_mention	"rocks"	egyptianprotest_cnn__1000-01-01__timeline:3177-3181	1.0
:Entity_EDL_0000009	nominal_mention	"rocks"	egyptianprotest_cnn__1000-01-01__timeline:3177-3181	1.0
:Entity_EDL_0000009	link	NIL000000009
:Entity_EDL_0000010	type	Person
:Entity_EDL_0000010	mention	"Mubarak"	egyptianprotest_cnn__1000-01-01__timeline:6703-6709	1.0
:Entity_EDL_0000010	link	30000327
:Entity_EDL_0000011	type	Person
:Entity_EDL_0000011	canonical_mention	"people"	egyptianprotest_cnn__1000-01-01__timeline:1831-1836	1.0
:Entity_EDL_0000011	nominal_mention	"people"	egyptianprotest_cnn__1000-01-01__timeline:1831-1836	1.0
:Entity_EDL_0000011	link	NIL000000010
:Entity_EDL_0000012	type	Person
:Entity_EDL_0000012	mention	"Hosni Mubarak"	egyptianprotest_cnn__1000-01-01__timeline:8297-8309	1.0
:Entity_EDL_0000012	link	NIL000000011
:Entity_EDL_0000013	type	Person
:Entity_EDL_0000013	canonical_mention	"workers"	egyptianprotest_cnn__1000-01-01__timeline:3406-3412	1.0
:Entity_EDL_0000013	nominal_mention	"workers"	egyptianprotest_cnn__1000-01-01__timeline:3406-3412	1.0
:Entity_EDL_0000013	link	NIL000000012
:Entity_EDL_0000014	type	Facility
:Entity_EDL_0000014	canonical_mention	"headquarters"	egyptianprotest_cnn__1000-01-01__timeline:1169-1180	1.0
:Entity_EDL_0000014	nominal_mention	"headquarters"	egyptianprotest_cnn__1000-01-01__timeline:1169-1180	1.0
:Entity_EDL_0000014	link	NIL000000013
:Entity_EDL_0000015	type	Organization
:Entity_EDL_0000015	nominal_mention	"government"	egyptianprotest_cnn__1000-01-01__timeline:2474-2483	0.000
:Entity_EDL_0000015	link	NIL000000014
:Entity_EDL_0000016	type	GeopoliticalEntity
:Entity_EDL_0000016	mention	"Egypt"	egyptianprotest_cnn__1000-01-01__timeline:794-798	1.0
:Entity_EDL_0000016	link	357994
:Entity_EDL_0000017	type	Person
:Entity_EDL_0000017	nominal_mention	"protesters"	egyptianprotest_cnn__1000-01-01__timeline:2417-2426	1.0
:Entity_EDL_0000017	link	NIL000000015
:Entity_EDL_0000018	type	Organization
:Entity_EDL_0000018	canonical_mention	"command"	egyptianprotest_cnn__1000-01-01__timeline:2367-2373	1.0
:Entity_EDL_0000018	nominal_mention	"command"	egyptianprotest_cnn__1000-01-01__timeline:2367-2373	1.0
:Entity_EDL_0000018	link	NIL000000016
:Entity_EDL_0000019	type	GeopoliticalEntity
:Entity_EDL_0000019	canonical_mention	"country"	egyptianprotest_cnn__1000-01-01__timeline:2251-2257	1.0
:Entity_EDL_0000019	nominal_mention	"country"	egyptianprotest_cnn__1000-01-01__timeline:2251-2257	1.0
:Entity_EDL_0000019	link	NIL000000017
:Entity_EDL_0000020	type	Facility
:Entity_EDL_0000020	nominal_mention	"streets"	egyptianprotest_cnn__1000-01-01__timeline:1290-1296	0.000
:Entity_EDL_0000020	link	NIL000000018
:Entity_EDL_0000021	type	Person
:Entity_EDL_0000021	nominal_mention	"Police"	egyptianprotest_cnn__1000-01-01__timeline:356-361	1.0
:Entity_EDL_0000021	link	NIL000000019
:Entity_EDL_0000022	type	Person
:Entity_EDL_0000022	nominal_mention	"officials"	egyptianprotest_cnn__1000-01-01__timeline:6386-6394	1.0
:Entity_EDL_0000022	link	NIL000000020
:Entity_EDL_0000023	type	Facility
:Entity_EDL_0000023	canonical_mention	"there"	egyptianprotest_cnn__1000-01-01__timeline:1855-1859	1.0
:Entity_EDL_0000023	nominal_mention	"there"	egyptianprotest_cnn__1000-01-01__timeline:1855-1859	1.0
:Entity_EDL_0000023	link	NIL000000021
:Entity_EDL_0000024	type	Person
:Entity_EDL_0000024	canonical_mention	"Cabinet"	egyptianprotest_cnn__1000-01-01__timeline:1580-1586	1.0
:Entity_EDL_0000024	nominal_mention	"Cabinet"	egyptianprotest_cnn__1000-01-01__timeline:1580-1586	1.0
:Entity_EDL_0000024	link	NIL000000022
:Entity_EDL_0000025	type	Person
:Entity_EDL_0000025	canonical_mention	"three"	egyptianprotest_cnn__1000-01-01__timeline:207-211	1.0
:Entity_EDL_0000025	nominal_mention	"three"	egyptianprotest_cnn__1000-01-01__timeline:207-211	1.0
:Entity_EDL_0000025	link	NIL000000023
:Entity_EDL_0000026	type	Person
:Entity_EDL_0000026	nominal_mention	"police"	egyptianprotest_cnn__1000-01-01__timeline:1088-1093	1.0
:Entity_EDL_0000026	link	NIL000000024
:Entity_EDL_0000027	type	GeopoliticalEntity
:Entity_EDL_0000027	mention	"Cairo"	egyptianprotest_cnn__1000-01-01__timeline:6276-6280	1.0
:Entity_EDL_0000027	link	360630
:Entity_EDL_0000028	type	GeopoliticalEntity
:Entity_EDL_0000028	nominal_mention	"country"	egyptianprotest_cnn__1000-01-01__timeline:8188-8194	1.0
:Entity_EDL_0000028	link	NIL000000025
:Entity_EDL_0000029	type	Person
:Entity_EDL_0000029	canonical_mention	"supporters"	egyptianprotest_cnn__1000-01-01__timeline:899-908	1.0
:Entity_EDL_0000029	nominal_mention	"supporters"	egyptianprotest_cnn__1000-01-01__timeline:899-908	1.0
:Entity_EDL_0000029	link	NIL000000026
:Entity_EDL_0000030	type	Facility
:Entity_EDL_0000030	mention	"Tahrir Square"	egyptianprotest_cnn__1000-01-01__timeline:6285-6297	1.0
:Entity_EDL_0000030	link	NIL000000027
:Entity_EDL_0000031	type	Person
:Entity_EDL_0000031	canonical_mention	"gang"	egyptianprotest_cnn__1000-01-01__timeline:4219-4222	1.0
:Entity_EDL_0000031	nominal_mention	"gang"	egyptianprotest_cnn__1000-01-01__timeline:4219-4222	1.0
:Entity_EDL_0000031	link	NIL000000028
:Entity_EDL_0000032	type	Facility
:Entity_EDL_0000032	nominal_mention	"streets"	egyptianprotest_cnn__1000-01-01__timeline:446-452	1.0
:Entity_EDL_0000032	link	NIL000000029
:Entity_EDL_0000033	type	GeopoliticalEntity
:Entity_EDL_0000033	mention	"Cairo"	egyptianprotest_cnn__1000-01-01__timeline:277-281	1.0
:Entity_EDL_0000033	link	360630
:Entity_EDL_0000034	type	GeopoliticalEntity
:Entity_EDL_0000034	mention	"Suez"	egyptianprotest_cnn__1000-01-01__timeline:1106-1109	1.0
:Entity_EDL_0000034	link	359796
:Entity_EDL_0000035	type	Person
:Entity_EDL_0000035	nominal_mention	"protesters"	egyptianprotest_cnn__1000-01-01__timeline:252-261	1.0
:Entity_EDL_0000035	link	NIL000000030
:Entity_EDL_0000036	type	Person
:Entity_EDL_0000036	pronominal_mention	"he"	egyptianprotest_cnn__1000-01-01__timeline:3781-3782	1.0
:Entity_EDL_0000036	link	NIL000000031
:Entity_EDL_0000037	type	Person
:Entity_EDL_0000037	canonical_mention	"their"	egyptianprotest_cnn__1000-01-01__timeline:3021-3025	1.0
:Entity_EDL_0000037	pronominal_mention	"their"	egyptianprotest_cnn__1000-01-01__timeline:3021-3025	1.0
:Entity_EDL_0000037	link	NIL000000032
:Entity_EDL_0000038	type	Facility
:Entity_EDL_0000038	canonical_mention	"compound"	egyptianprotest_cnn__1000-01-01__timeline:6337-6344	1.0
:Entity_EDL_0000038	nominal_mention	"compound"	egyptianprotest_cnn__1000-01-01__timeline:6337-6344	1.0
:Entity_EDL_0000038	link	NIL000000033
:Entity_EDL_0000039	type	Weapon
:Entity_EDL_0000039	canonical_mention	"tear gas"	egyptianprotest_cnn__1000-01-01__timeline:385-392	1.0
:Entity_EDL_0000039	nominal_mention	"tear gas"	egyptianprotest_cnn__1000-01-01__timeline:385-392	1.0
:Entity_EDL_0000039	link	NIL000000034
:Entity_EDL_0000040	type	Facility
:Entity_EDL_0000040	nominal_mention	"square"	egyptianprotest_cnn__1000-01-01__timeline:2108-2113	0.000
:Entity_EDL_0000040	link	NIL000000035
:Entity_EDL_0000041	type	Person
:Entity_EDL_0000041	nominal_mention	"people"	egyptianprotest_cnn__1000-01-01__timeline:3995-4000	1.0
:Entity_EDL_0000041	link	NIL000000036
:Entity_EDL_0000042	type	Person
:Entity_EDL_0000042	pronominal_mention	"he"	egyptianprotest_cnn__1000-01-01__timeline:2203-2204	1.0
:Entity_EDL_0000042	link	NIL000000037
:Entity_EDL_0000043	type	Person
:Entity_EDL_0000043	mention	"Omar Suleiman"	egyptianprotest_cnn__1000-01-01__timeline:4857-4869	1.0
:Entity_EDL_0000043	link	NIL000000038
:Entity_EDL_0000044	type	Organization
:Entity_EDL_0000044	nominal_mention	"parties"	egyptianprotest_cnn__1000-01-01__timeline:2529-2535	0.000
:Entity_EDL_0000044	link	NIL000000039
:Entity_EDL_0000045	type	Organization
:Entity_EDL_0000045	pronominal_mention	"It"	egyptianprotest_cnn__1000-01-01__timeline:8323-8324	1.0
:Entity_EDL_0000045	link	NIL000000040
:Entity_EDL_0000046	type	Location
:Entity_EDL_0000046	nominal_mention	"Egypt"	egyptianprotest_cnn__1000-01-01__timeline:6511-6515	1.0
:Entity_EDL_0000046	link	NIL000000041
:Entity_EDL_0000047	type	GeopoliticalEntity
:Entity_EDL_0000047	mention	"Suez"	egyptianprotest_cnn__1000-01-01__timeline:599-602	1.0
:Entity_EDL_0000047	link	359796
:Entity_EDL_0000048	type	Organization
:Entity_EDL_0000048	canonical_mention	"agency"	egyptianprotest_cnn__1000-01-01__timeline:736-741	1.0
:Entity_EDL_0000048	nominal_mention	"agency"	egyptianprotest_cnn__1000-01-01__timeline:736-741	1.0
:Entity_EDL_0000048	link	NIL000000042
:Entity_EDL_0000049	type	Person
:Entity_EDL_0000049	canonical_mention	"figures"	egyptianprotest_cnn__1000-01-01__timeline:5475-5481	1.0
:Entity_EDL_0000049	nominal_mention	"figures"	egyptianprotest_cnn__1000-01-01__timeline:5475-5481	1.0
:Entity_EDL_0000049	link	NIL000000043
:Entity_EDL_0000050	type	Organization
:Entity_EDL_0000050	nominal_mention	"parliament"	egyptianprotest_cnn__1000-01-01__timeline:8159-8168	1.0
:Entity_EDL_0000050	link	NIL000000044
:Entity_EDL_0000051	type	Person
:Entity_EDL_0000051	nominal_mention	"people"	egyptianprotest_cnn__1000-01-01__timeline:6435-6440	1.0
:Entity_EDL_0000051	link	NIL000000045
:Entity_EDL_0000052	type	GeopoliticalEntity
:Entity_EDL_0000052	mention	"Egypt"	egyptianprotest_cnn__1000-01-01__timeline:7153-7157	1.0
:Entity_EDL_0000052	link	357994
:Entity_EDL_0000053	type	Facility
:Entity_EDL_0000053	canonical_mention	"plaza"	egyptianprotest_cnn__1000-01-01__timeline:4067-4071	1.0
:Entity_EDL_0000053	nominal_mention	"plaza"	egyptianprotest_cnn__1000-01-01__timeline:4067-4071	1.0
:Entity_EDL_0000053	link	NIL000000046
:Entity_EDL_0000054	type	Person
:Entity_EDL_0000054	mention	"Mubarak"	egyptianprotest_cnn__1000-01-01__timeline:7505-7511	1.0
:Entity_EDL_0000054	link	30000327
:Entity_EDL_0000055	type	Person
:Entity_EDL_0000055	nominal_mention	"journalists"	egyptianprotest_cnn__1000-01-01__timeline:4271-4281	1.0
:Entity_EDL_0000055	link	NIL000000047
:Entity_EDL_0000056	type	Facility
:Entity_EDL_0000056	mention	"Tahrir Square"	egyptianprotest_cnn__1000-01-01__timeline:3233-3245	1.0
:Entity_EDL_0000056	link	NIL000000048
:Entity_EDL_0000057	type	Person
:Entity_EDL_0000057	canonical_mention	"police"	egyptianprotest_cnn__1000-01-01__timeline:267-272	1.0
:Entity_EDL_0000057	nominal_mention	"police"	egyptianprotest_cnn__1000-01-01__timeline:267-272	1.0
:Entity_EDL_0000057	link	NIL000000049
:Entity_EDL_0000058	type	Vehicle
:Entity_EDL_0000058	canonical_mention	"cars"	egyptianprotest_cnn__1000-01-01__timeline:7657-7660	1.0
:Entity_EDL_0000058	nominal_mention	"cars"	egyptianprotest_cnn__1000-01-01__timeline:7657-7660	1.0
:Entity_EDL_0000058	link	NIL000000050
:Entity_EDL_0000059	type	Facility
:Entity_EDL_0000059	mention	"Tahrir Square"	egyptianprotest_cnn__1000-01-01__timeline:4005-4017	1.0
:Entity_EDL_0000059	link	NIL000000051
:Entity_EDL_0000060	type	GeopoliticalEntity
:Entity_EDL_0000060	canonical_mention	"sides"	egyptianprotest_cnn__1000-01-01__timeline:5110-5114	1.0
:Entity_EDL_0000060	nominal_mention	"sides"	egyptianprotest_cnn__1000-01-01__timeline:5110-5114	1.0
:Entity_EDL_0000060	link	NIL000000052
:Entity_EDL_0000061	type	Person
:Entity_EDL_0000061	pronominal_mention	"he"	egyptianprotest_cnn__1000-01-01__timeline:2090-2091	1.0
:Entity_EDL_0000061	link	NIL000000053
:Entity_EDL_0000062	type	Person
:Entity_EDL_0000062	canonical_mention	"troops"	egyptianprotest_cnn__1000-01-01__timeline:1269-1274	1.0
:Entity_EDL_0000062	nominal_mention	"troops"	egyptianprotest_cnn__1000-01-01__timeline:1269-1274	1.0
:Entity_EDL_0000062	link	NIL000000054
:Entity_EDL_0000063	type	Facility
:Entity_EDL_0000063	canonical_mention	"office"	egyptianprotest_cnn__1000-01-01__timeline:4362-4367	1.0
:Entity_EDL_0000063	nominal_mention	"office"	egyptianprotest_cnn__1000-01-01__timeline:4362-4367	1.0
:Entity_EDL_0000063	link	NIL000000055
:Entity_EDL_0000064	type	Person
:Entity_EDL_0000064	canonical_mention	"27"	egyptianprotest_cnn__1000-01-01__timeline:585-586	1.0
:Entity_EDL_0000064	nominal_mention	"27"	egyptianprotest_cnn__1000-01-01__timeline:585-586	1.0
:Entity_EDL_0000064	link	NIL000000056
:Entity_EDL_0000065	type	Facility
:Entity_EDL_0000065	canonical_mention	"site"	egyptianprotest_cnn__1000-01-01__timeline:6423-6426	1.0
:Entity_EDL_0000065	nominal_mention	"site"	egyptianprotest_cnn__1000-01-01__timeline:6423-6426	1.0
:Entity_EDL_0000065	link	NIL000000057
:Entity_EDL_0000066	type	Person
:Entity_EDL_0000066	mention	"Mubarak"	egyptianprotest_cnn__1000-01-01__timeline:2215-2221	1.0
:Entity_EDL_0000066	link	30000327
:Entity_EDL_0000067	type	Person
:Entity_EDL_0000067	canonical_mention	"protesters"	egyptianprotest_cnn__1000-01-01__timeline:28-37	1.0
:Entity_EDL_0000067	nominal_mention	"protesters"	egyptianprotest_cnn__1000-01-01__timeline:28-37	1.0
:Entity_EDL_0000067	link	NIL000000058
:Entity_EDL_0000068	type	GeopoliticalEntity
:Entity_EDL_0000068	nominal_mention	"city"	egyptianprotest_cnn__1000-01-01__timeline:296-299	1.0
:Entity_EDL_0000068	link	NIL000000059
:Entity_EDL_0000069	type	GeopoliticalEntity
:Entity_EDL_0000069	mention	"Egypt"	egyptianprotest_cnn__1000-01-01__timeline:3860-3864	1.0
:Entity_EDL_0000069	link	357994
:Entity_EDL_0000070	type	Person
:Entity_EDL_0000070	canonical_mention	"others"	egyptianprotest_cnn__1000-01-01__timeline:6457-6462	1.0
:Entity_EDL_0000070	pronominal_mention	"others"	egyptianprotest_cnn__1000-01-01__timeline:6457-6462	1.0
:Entity_EDL_0000070	link	NIL000000060
:Entity_EDL_0000071	type	GeopoliticalEntity
:Entity_EDL_0000071	mention	"Cairo"	egyptianprotest_cnn__1000-01-01__timeline:535-539	1.0
:Entity_EDL_0000071	link	360630
:Entity_EDL_0000072	type	GeopoliticalEntity
:Entity_EDL_0000072	canonical_mention	"Alexandria"	egyptianprotest_cnn__1000-01-01__timeline:1115-1124	1.0
:Entity_EDL_0000072	mention	"Alexandria"	egyptianprotest_cnn__1000-01-01__timeline:1115-1124	1.0
:Entity_EDL_0000072	link	361058
:Entity_EDL_0000073	type	Person
:Entity_EDL_0000073	canonical_mention	"son"	egyptianprotest_cnn__1000-01-01__timeline:4505-4507	1.0
:Entity_EDL_0000073	nominal_mention	"son"	egyptianprotest_cnn__1000-01-01__timeline:4505-4507	1.0
:Entity_EDL_0000073	link	NIL000000061
:Entity_EDL_0000074	type	Person
:Entity_EDL_0000074	canonical_mention	"head"	egyptianprotest_cnn__1000-01-01__timeline:702-705	1.0
:Entity_EDL_0000074	nominal_mention	"head"	egyptianprotest_cnn__1000-01-01__timeline:702-705	1.0
:Entity_EDL_0000074	link	NIL000000062
:Entity_EDL_0000075	type	Person
:Entity_EDL_0000075	canonical_mention	"other"	egyptianprotest_cnn__1000-01-01__timeline:3166-3170	1.0
:Entity_EDL_0000075	pronominal_mention	"other"	egyptianprotest_cnn__1000-01-01__timeline:3166-3170	1.0
:Entity_EDL_0000075	link	NIL000000063
:Entity_EDL_0000076	type	Person
:Entity_EDL_0000076	canonical_mention	"Hosni Mubarak"	egyptianprotest_cnn__1000-01-01__timeline:7896-7908	1.0
:Entity_EDL_0000076	mention	"Hosni Mubarak"	egyptianprotest_cnn__1000-01-01__timeline:7896-7908	1.0
:Entity_EDL_0000076	link	NIL000000064
:Entity_EDL_0000077	type	Person
:Entity_EDL_0000077	canonical_mention	"Mubrarak"	egyptianprotest_cnn__1000-01-01__timeline:7237-7244	1.0
:Entity_EDL_0000077	mention	"Mubrarak"	egyptianprotest_cnn__1000-01-01__timeline:7237-7244	1.0
:Entity_EDL_0000077	link	30000327
:Entity_EDL_0000078	type	GeopoliticalEntity
:Entity_EDL_0000078	mention	"Cairo"	egyptianprotest_cnn__1000-01-01__timeline:1098-1102	1.0
:Entity_EDL_0000078	link	360630
:Entity_EDL_0000079	type	Person
:Entity_EDL_0000079	pronominal_mention	"his"	egyptianprotest_cnn__1000-01-01__timeline:3821-3823	1.0
:Entity_EDL_0000079	link	NIL000000065
:Entity_EDL_0000080	type	Person
:Entity_EDL_0000080	canonical_mention	"Wael Gohnim"	egyptianprotest_cnn__1000-01-01__timeline:5606-5616	1.0
:Entity_EDL_0000080	mention	"Wael Gohnim"	egyptianprotest_cnn__1000-01-01__timeline:5606-5616	1.0
:Entity_EDL_0000080	link	NIL000000066
:Entity_EDL_0000081	type	Person
:Entity_EDL_0000081	nominal_mention	"protesters"	egyptianprotest_cnn__1000-01-01__timeline:6261-6270	1.0
:Entity_EDL_0000081	link	NIL000000067
:Entity_EDL_0000082	type	Organization
:Entity_EDL_0000082	canonical_mention	"party"	egyptianprotest_cnn__1000-01-01__timeline:4447-4451	1.0
:Entity_EDL_0000082	nominal_mention	"party"	egyptianprotest_cnn__1000-01-01__timeline:4447-4451	1.0
:Entity_EDL_0000082	link	NIL000000068
:Entity_EDL_0000083	type	Person
:Entity_EDL_0000083	canonical_mention	"representatives"	egyptianprotest_cnn__1000-01-01__timeline:4882-4896	1.0
:Entity_EDL_0000083	nominal_mention	"representatives"	egyptianprotest_cnn__1000-01-01__timeline:4882-4896	1.0
:Entity_EDL_0000083	link	NIL000000069
:Entity_EDL_0000084	type	Facility
:Entity_EDL_0000084	nominal_mention	"streets"	egyptianprotest_cnn__1000-01-01__timeline:54-60	1.0
:Entity_EDL_0000084	link	NIL000000070
:Entity_EDL_0000085	type	Person
:Entity_EDL_0000085	canonical_mention	"millions"	egyptianprotest_cnn__1000-01-01__timeline:2338-2345	1.0
:Entity_EDL_0000085	pronominal_mention	"millions"	egyptianprotest_cnn__1000-01-01__timeline:2338-2345	1.0
:Entity_EDL_0000085	link	NIL000000071
:Entity_EDL_0000086	type	Person
:Entity_EDL_0000086	nominal_mention	"demonstrators"	egyptianprotest_cnn__1000-01-01__timeline:3140-3152	1.0
:Entity_EDL_0000086	link	NIL000000072
:Entity_EDL_0000087	type	Person
:Entity_EDL_0000087	canonical_mention	"gangs"	egyptianprotest_cnn__1000-01-01__timeline:4110-4114	1.0
:Entity_EDL_0000087	nominal_mention	"gangs"	egyptianprotest_cnn__1000-01-01__timeline:4110-4114	1.0
:Entity_EDL_0000087	link	NIL000000073
:Entity_EDL_0000088	type	Person
:Entity_EDL_0000088	nominal_mention	"Protesters"	egyptianprotest_cnn__1000-01-01__timeline:1070-1079	1.0
:Entity_EDL_0000088	link	NIL000000074
:Entity_EDL_0000089	type	Person
:Entity_EDL_0000089	canonical_mention	"members"	egyptianprotest_cnn__1000-01-01__timeline:4420-4426	1.0
:Entity_EDL_0000089	nominal_mention	"members"	egyptianprotest_cnn__1000-01-01__timeline:4420-4426	1.0
:Entity_EDL_0000089	link	NIL000000075
:Entity_EDL_0000090	type	Organization
:Entity_EDL_0000090	canonical_mention	"committees"	egyptianprotest_cnn__1000-01-01__timeline:5194-5203	1.0
:Entity_EDL_0000090	nominal_mention	"committees"	egyptianprotest_cnn__1000-01-01__timeline:5194-5203	1.0
:Entity_EDL_0000090	link	NIL000000076
:Entity_EDL_0000091	type	Person
:Entity_EDL_0000091	nominal_mention	"protesters"	egyptianprotest_cnn__1000-01-01__timeline:415-424	1.0
:Entity_EDL_0000091	link	NIL000000077
:Entity_EDL_0000092	type	Organization
:Entity_EDL_0000092	canonical_mention	"parliament"	egyptianprotest_cnn__1000-01-01__timeline:6401-6410	1.0
:Entity_EDL_0000092	nominal_mention	"parliament"	egyptianprotest_cnn__1000-01-01__timeline:6401-6410	1.0
:Entity_EDL_0000092	link	NIL000000078
:Entity_EDL_0000093	type	Person
:Entity_EDL_0000093	canonical_mention	"technicians"	egyptianprotest_cnn__1000-01-01__timeline:4285-4295	1.0
:Entity_EDL_0000093	nominal_mention	"technicians"	egyptianprotest_cnn__1000-01-01__timeline:4285-4295	1.0
:Entity_EDL_0000093	link	NIL000000079
:Entity_EDL_0000094	type	Person
:Entity_EDL_0000094	canonical_mention	"300"	egyptianprotest_cnn__1000-01-01__timeline:6599-6601	1.0
:Entity_EDL_0000094	nominal_mention	"300"	egyptianprotest_cnn__1000-01-01__timeline:6599-6601	1.0
:Entity_EDL_0000094	link	NIL000000080
:Entity_EDL_0000095	type	Organization
:Entity_EDL_0000095	mention	"CNN"	egyptianprotest_cnn__1000-01-01__timeline:2187-2189	1.0
:Entity_EDL_0000095	link	NIL000000081
:Entity_EDL_0000096	type	Location
:Entity_EDL_0000096	canonical_mention	"locations"	egyptianprotest_cnn__1000-01-01__timeline:2671-2679	1.0
:Entity_EDL_0000096	nominal_mention	"locations"	egyptianprotest_cnn__1000-01-01__timeline:2671-2679	1.0
:Entity_EDL_0000096	link	NIL000000082
:Entity_EDL_0000097	type	Weapon
:Entity_EDL_0000097	canonical_mention	"cannons"	egyptianprotest_cnn__1000-01-01__timeline:373-379	1.0
:Entity_EDL_0000097	nominal_mention	"cannons"	egyptianprotest_cnn__1000-01-01__timeline:373-379	1.0
:Entity_EDL_0000097	link	NIL000000083
:Entity_EDL_0000098	type	Person
:Entity_EDL_0000098	nominal_mention	"police"	egyptianprotest_cnn__1000-01-01__timeline:6492-6497	1.0
:Entity_EDL_0000098	link	NIL000000084
